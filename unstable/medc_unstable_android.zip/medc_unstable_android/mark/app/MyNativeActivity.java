package mark.app;

import android.app.NativeActivity;
import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
//import java.io.StringReader;
import java.io.PrintWriter;

import android.content.Context;
//import android.util.AttributeSet;
//import android.util.Xml;
import android.view.KeyEvent;
import android.view.ViewTreeObserver;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputConnectionWrapper;
//import org.xmlpull.v1.XmlPullParser;
//import org.xmlpull.v1.XmlPullParserFactory;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.io.File;
import android.graphics.Rect;
import android.util.DisplayMetrics;


public class MyNativeActivity extends NativeActivity {

	static {
		System.loadLibrary("mynativeactivity");
	}

	private native void onBackspaceNative(long handle);
	private native void onTypeNative(long handle, int n, byte[] s);
	private native void onChangeHframeNative(long handle, int hframenew);

	private long mNativeHandle;
	private PrintWriter f;
	private boolean isKeyboardShown;
	private int hFrame = 0;
	public String sDeletedBatchEdit = null;

	public void log(String fmt, Object... args) {
		try {
			if (f == null) {
				try {
					new File("/storage/emulated/0/Android/data/com.vulkan.tutorials.sixcsim/files/log3.txt").delete();
				} catch (Exception e) {}
				f=new PrintWriter("/storage/emulated/0/Android/data/com.vulkan.tutorials.sixcsim/files/log3.txt", "UTF-8");
				try {
				f.println(LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
				} catch (Exception e) { e.printStackTrace(f); f.println("hmm"); }
			}
		} catch (Exception e) {}
		f.printf(fmt, args);
		f.println();
		f.flush();
	}

	static class MyTextWatcher implements TextWatcher {

		private MyNativeActivity activity;

		MyTextWatcher(MyNativeActivity activity, EditText editText) {
			this.activity = activity;
			if (editText != null) this.activity=activity;
		}

		@Override
		public void afterTextChanged(Editable e) {
			//int len = e.length();
			//if (len == 1) return;
			///*if (len == 0) activity.onBackspace();
			//else*/ if (len > 1) {
			//	byte[] b = e.toString().substring(1).getBytes(StandardCharsets.UTF_8);
			//	activity.onType(b.length, b);
			//}
			//editText.setText(" ");
			//editText.setSelection(1);
		}

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
			activity.log("beforeTextChanged start%d count%d after%d: %s", start, count, after, s.toString());
			//if (after-count==-1 && !Character.isWhitespace(s.charAt(start))) activity.onBackspace();
			if (activity.sDeletedBatchEdit != null) {
				//if (count>0 && after==0)
				//	activity.sDeletedBatchEdit = s.subSequence(start,start+count).toString() + activity.sDeletedBatchEdit;
				if (count > after)
					activity.sDeletedBatchEdit = s.subSequence(start+after,start+count).toString() + activity.sDeletedBatchEdit;
				activity.log("sDBE: %s", activity.sDeletedBatchEdit);
			}
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
			activity.log("onTextChanged start%d before%d count%d: %s", start, before, count, s.toString());
			int nadd = count - before;
			if (nadd>0 && (activity.sDeletedBatchEdit==null||activity.sDeletedBatchEdit.length()<nadd)) {
				byte[] b = s.subSequence(start+count-nadd,start+count).toString().getBytes(StandardCharsets.UTF_8);
				activity.onType(b.length, b);
			} //else if (nadd == -1) activity.onBackspace();
			if (activity.sDeletedBatchEdit != null) {
				if (before==0 && count>0)
					activity.sDeletedBatchEdit = activity.sDeletedBatchEdit.substring(count>activity.sDeletedBatchEdit.length()?activity.sDeletedBatchEdit.length():count, activity.sDeletedBatchEdit.length());
				activity.log("sDBE: %s", activity.sDeletedBatchEdit);
			}
		}
	}

	static class MyInputConnection extends InputConnectionWrapper {

		private MyNativeActivity activity;

		public MyInputConnection(InputConnection target, boolean mutable, MyNativeActivity activity) {
			super(target, mutable);
			this.activity = activity;
		}

		@Override
		public boolean sendKeyEvent(KeyEvent event) {
			activity.log("SKE %x %x", event.getAction(), event.getKeyCode());
			if (event.getAction()==KeyEvent.ACTION_DOWN && event.getKeyCode()==KeyEvent.KEYCODE_DEL) {
				//activity.onBackspace();
				// Un-comment if you wish to cancel the backspace:
				// return false;
			}
			return super.sendKeyEvent(event);
		}


		@Override
		public boolean deleteSurroundingText(int beforeLength, int afterLength) {
			activity.log("DST %d %d", beforeLength, afterLength);
			// magic: in latest Android, deleteSurroundingText(1, 0) will be called for backspace
			if (beforeLength==1 && afterLength==0) {
				// backspace
				return sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DEL))
					&& sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_DEL));
			}

			return super.deleteSurroundingText(beforeLength, afterLength);
		}

		@Override
		public boolean setComposingText(CharSequence text, int newCursorPosition) {
			activity.log("setComposingText %d: %s", newCursorPosition, text.toString());
			return super.setComposingText(text, newCursorPosition);
		}

		@Override
		public boolean commitText(CharSequence text, int newCursorPosition) {
			activity.log("commitText %d: %s", newCursorPosition, text.toString());
			return super.commitText(text, newCursorPosition);
		}

		@Override
		public boolean endBatchEdit() {
			activity.log("endBatchEdit");
			if (activity.sDeletedBatchEdit.length() > 0)
				activity.onBackspace();
			activity.sDeletedBatchEdit = null;
			return super.endBatchEdit();
		}

		@Override
		public boolean beginBatchEdit() {
			activity.log("beginBatchEdit");
			activity.sDeletedBatchEdit = "";
			return super.beginBatchEdit();
		}
	}

	static class MyEditText extends EditText {
		//public MyEditText(Context context, AttributeSet attrs, int defStyle) {
		//	super(context, attrs, defStyle);
		//}

		//public MyEditText(Context context, AttributeSet attrs) {
		//	super(context, attrs);
		//}

		private MyNativeActivity activity;

		/*
		private static AttributeSet getAttrsXml() {
			try {
				XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
				factory.setNamespaceAware(true);
				factory.setValidating(true);
				XmlPullParser xpp = factory.newPullParser();
				xpp.setInput(new StringReader("<EditText xmlns:android=\"http://schemas.android.com/apk/res/android\">android:inputType=\"number\"</EditText>"));
				return Xml.asAttributeSet(xpp);
			} catch (Exception e) {
				return null;
			}
		}
		*/

		public MyEditText(Context context, final MyNativeActivity activity) {
			super(context);
			//super(context, getAttrsXml());
			this.activity = activity;
			final MyEditText et = this;
			this.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
				@Override
				public void onGlobalLayout() {
					//activity.log("onGlobalLayout %d", et.getMeasuredHeight());
					DisplayMetrics displayMetrics = new DisplayMetrics();
					((Activity)et.getContext()).getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
					Rect rect=new Rect(); et.getWindowVisibleDisplayFrame(rect);
					activity.log("onGlobalLayout %d %d", rect.bottom, displayMetrics.heightPixels);
					activity.isKeyboardShown = rect.bottom != displayMetrics.heightPixels;
					if (activity.hFrame != rect.bottom) {
						activity.hFrame = rect.bottom;
						activity.onChangeHframe();
					}
				}
			});
		}

		@Override
		public boolean onKeyPreIme(int keyCode, KeyEvent event) {
			activity.log("PRE %d %d", keyCode, event.getAction());
			return super.onKeyPreIme(keyCode, event);
		}

		@Override
		public boolean dispatchKeyEvent(KeyEvent event) {
			activity.log("DKE %d %x", event.getAction(), event.getKeyCode());
			return super.dispatchKeyEvent(event);
		}

		@Override
		public boolean dispatchKeyEventPreIme(KeyEvent event) {
			activity.log("DKP %d %x", event.getAction(), event.getKeyCode());
			return super.dispatchKeyEventPreIme(event);
		}

		@Override
		public InputConnection onCreateInputConnection(EditorInfo outAttrs) {
			return new MyInputConnection(super.onCreateInputConnection(outAttrs), true, this.activity);
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		try {
			Field field = NativeActivity.class.getDeclaredField("mNativeHandle");
			field.setAccessible(true);
			mNativeHandle = (long)field.get(this);
		} catch (Exception e) {}
	}

	public void onBackspace() {
		if (mNativeHandle != 0) onBackspaceNative(mNativeHandle);
	}

	public void onType(int n, byte[] s) {
		if (mNativeHandle != 0) onTypeNative(mNativeHandle, n, s);
	}

	public void onChangeHframe() {
		if (mNativeHandle != 0) onChangeHframeNative(mNativeHandle, hFrame);
	}
}
