#!/bin/sh
sh build.sh && termux-open bin/com.vulkan.tutorials.sixcsim.apk
