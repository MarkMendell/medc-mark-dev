#include <android/configuration.h>
#include <android/native_activity.h>
#include <jni.h>
#include <errno.h>
#include <pthread.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

uint64_t nsstartup = 0;

/* GEN
echo 'enum {'
<c/AndroidMain.c sed -n '/^	APP_CMD/,/^}/p'
<c/AndroidMain.c sed -n '/^struct android_app;/,/^}/p'
<c/AndroidMain.c sed -n '/^struct android_app {/,/^}/p'
*/
enum {
	APP_CMD_INPUT_CHANGED,

	/**
	 * Command from main thread: a new ANativeWindow is ready for use.  Upon
	 * receiving this command, android_app->window will contain the new window
	 * surface.
	 */
	APP_CMD_INIT_WINDOW,

	/**
	 * Command from main thread: the existing ANativeWindow needs to be
	 * terminated.  Upon receiving this command, android_app->window still
	 * contains the existing window; after calling android_app_exec_cmd
	 * it will be set to NULL.
	 */
	APP_CMD_TERM_WINDOW,

	/**
	 * Command from main thread: the current ANativeWindow has been resized.
	 * Please redraw with its new size.
	 */
	APP_CMD_WINDOW_RESIZED,

	/**
	 * Command from main thread: the system needs that the current ANativeWindow
	 * be redrawn.  You should redraw the window before handing this to
	 * android_app_exec_cmd() in order to avoid transient drawing glitches.
	 */
	APP_CMD_WINDOW_REDRAW_NEEDED,

	/**
	 * Command from main thread: the content area of the window has changed,
	 * such as from the soft input window being shown or hidden.  You can
	 * find the new content rect in android_app::contentRect.
	 */
	APP_CMD_CONTENT_RECT_CHANGED,

	/**
	 * Command from main thread: the app's activity window has gained
	 * input focus.
	 */
	APP_CMD_GAINED_FOCUS,

	/**
	 * Command from main thread: the app's activity window has lost
	 * input focus.
	 */
	APP_CMD_LOST_FOCUS,

	/**
	 * Command from main thread: the current device configuration has changed.
	 */
	APP_CMD_CONFIG_CHANGED,

	/**
	 * Command from main thread: the system is running low on memory.
	 * Try to reduce your memory use.
	 */
	APP_CMD_LOW_MEMORY,

	/**
	 * Command from main thread: the app's activity has been started.
	 */
	APP_CMD_START,

	/**
	 * Command from main thread: the app's activity has been resumed.
	 */
	APP_CMD_RESUME,

	/**
	 * Command from main thread: the app should generate a new saved state
	 * for itself, to restore from later if needed.  If you have saved state,
	 * allocate it with malloc and place it in android_app.savedState with
	 * the size in android_app.savedStateSize.  The will be freed for you
	 * later.
	 */
	APP_CMD_SAVE_STATE,

	/**
	 * Command from main thread: the app's activity has been paused.
	 */
	APP_CMD_PAUSE,

	/**
	 * Command from main thread: the app's activity has been stopped.
	 */
	APP_CMD_STOP,

	/**
	 * Command from main thread: the app's activity is being destroyed,
	 * and waiting for the app thread to clean up and exit before proceeding.
	 */
	APP_CMD_DESTROY,

	APP_CMD_BACKSPACE,
	APP_CMD_TYPE,
	APP_CMD_HFRAME
};
struct android_app;
struct android_poll_source {

	// The identifier of this source.  May be LOOPER_ID_MAIN or
	// LOOPER_ID_INPUT.
	int32_t id;

	// The android_app this ident is associated with.
	struct android_app* app;

	// Function to call to perform the standard processing of data from
	// this source.
	void (*process)(struct android_app* app, struct android_poll_source* source);
};
struct android_app {
	// The application can place a pointer to its own state object
	// here if it likes.
	void* userData;

	// Fill this in with the function to process main app commands (APP_CMD_*)
	void (*onAppCmd)(struct android_app* app, int32_t cmd);

	// Fill this in with the function to process input events.  At this point
	// the event has already been pre-dispatched, and it will be finished upon
	// return.  Return 1 if you have handled the event, 0 for any default
	// dispatching.
	int32_t (*onInputEvent)(struct android_app* app, AInputEvent* event);

	// The ANativeActivity object instance that this app is running in.
	ANativeActivity* activity;

	// The current configuration the app is running in.
	AConfiguration* config;

	// This is the last instance's saved state, as provided at creation time.
	// It is NULL if there was no state.  You can use this as you need; the
	// memory will remain around until you call android_app_exec_cmd() for
	// APP_CMD_RESUME, at which point it will be freed and savedState set to NULL.
	// These variables should only be changed when processing a APP_CMD_SAVE_STATE,
	// at which point they will be initialized to NULL and you can malloc your
	// state and place the information here.  In that case the memory will be
	// freed for you later.
	void* savedState;
	size_t savedStateSize;

	// The ALooper associated with the app's thread.
	ALooper* looper;

	// When non-NULL, this is the input queue from which the app will
	// receive user input events.
	AInputQueue* inputQueue;

	// When non-NULL, this is the window surface that the app can draw in.
	ANativeWindow* window;

	// Current content rectangle of the window; this is the area where the
	// window's content should be placed to be seen by the user.
	ARect contentRect;

	// Current state of the app's activity.  May be either APP_CMD_START,
	// APP_CMD_RESUME, APP_CMD_PAUSE, or APP_CMD_STOP; see below.
	int activityState;

	// This is non-zero when the application's NativeActivity is being
	// destroyed and waiting for the app thread to complete.
	int destroyRequested;

	// -------------------------------------------------
	// Below are "private" implementation of the glue code.

	pthread_mutex_t mutex;
	pthread_cond_t cond;

	int msgread;
	int msgwrite;

	pthread_t thread;

	struct android_poll_source cmdPollSource;
	struct android_poll_source inputPollSource;

	int running;
	int stateSaved;
	int destroyed;
	int redrawNeeded;
	AInputQueue* pendingInputQueue;
	ANativeWindow* pendingWindow;
	ARect pendingContentRect;
	size_t ntype, sizetype;
	uint8_t *buftype;
	char isfaketype;
	long hframenew;
	char ispendingbackspace;
} *appg;
//ENDGEN

FILE*
getf(void)
{
	static FILE *f = NULL;
	if (!f) f=fopen("/storage/emulated/0/Android/data/com.vulkan.tutorials.sixcsim/files/log2.txt", "w");
	return f;
}

uint64_t
getns(void)
{
	struct timespec ts; if (clock_gettime(CLOCK_MONOTONIC,&ts)) {fprintf(getf(),"medcn: clock_gettime: %s\n",strerror(errno));exit(EXIT_FAILURE);}
	return ts.tv_sec*1e9+ts.tv_nsec;
}

double
et(uint64_t ns)
{
	if (!nsstartup) nsstartup=getns();
	return (ns-nsstartup) / 1.0e9;
}

JNIEXPORT void JNICALL
Java_mark_app_MyNativeActivity_onBackspaceNative(JNIEnv *env, jobject this, jlong handle)
{
	ANativeActivity *activity = (ANativeActivity*)handle;
	struct android_app *app = (struct android_app*)activity->instance;
	pthread_mutex_lock(&app->mutex);
	//if (app->ntype) {
	//} else {
		app->ispendingbackspace = 1;
		write(app->msgwrite, (uint8_t[1]){APP_CMD_BACKSPACE}, 1);
		while (app->ispendingbackspace) pthread_cond_wait(&app->cond,&app->mutex);
	//}
	pthread_mutex_unlock(&app->mutex);
}

JNIEXPORT void JNICALL
Java_mark_app_MyNativeActivity_onChangeHframeNative(JNIEnv *env, jobject this, jlong handle, jint hframenew)
{
	ANativeActivity *activity = (ANativeActivity*)handle;
	struct android_app *app = (struct android_app*)activity->instance;
	pthread_mutex_lock(&app->mutex);
	app->hframenew = hframenew;
	write(app->msgwrite, (uint8_t[1]){APP_CMD_HFRAME}, 1);
	pthread_mutex_unlock(&app->mutex);
}

JNIEXPORT void JNICALL
Java_mark_app_MyNativeActivity_onTypeNative(JNIEnv *env, jobject this, jlong handle, jint n, jbyteArray s)
{
	if (!n) return;
	ANativeActivity *activity = (ANativeActivity*)handle;
	struct android_app *app = (struct android_app*)activity->instance;
	pthread_mutex_lock(&app->mutex);
	if (app->sizetype < app->ntype+n) app->buftype=realloc(app->buftype,app->sizetype=app->ntype+n);
	memcpy(app->buftype+app->ntype, (*env)->GetByteArrayElements(env,s,0), n);
	app->ntype += n;
	write(app->msgwrite, (uint8_t[1]){APP_CMD_TYPE}, 1);
	fprintf(getf(),"%.3f type %zu %.*s\n", et(getns()), app->ntype, (int)app->ntype, app->buftype);
	fflush(getf());
	//while (app->ntype) pthread_cond_wait(&app->cond,&app->mutex);
	//fprintf(getf(), "%.3f resolved\n", et(getns()));
	//fflush(getf());
	pthread_mutex_unlock(&app->mutex);
}
