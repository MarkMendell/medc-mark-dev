#!/bin/sh
aarch64-linux-android-clang -g -o lib/arm64-v8a/libmynativeactivity.so -fPIC -DAPPNAME=\"sixcsim\" -DANDROID_TOOLCHAIN=clang -DVK_USE_PLATFORM_ANDROID_KHR my-native-activity.c -shared -lm -landroid -llog -lvulkan -Wl,--no-undefined
