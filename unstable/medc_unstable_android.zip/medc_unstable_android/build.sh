#!/bin/sh

for dir in assets bin gen obj res; do
	test -d $dir || mkdir $dir
done

<<'!' cat >/dev/null
CFLAGS?=-ffunction-sections -Os -fdata-sections -Wall -fvisibility=hidden
LDFLAGS?=-Wl,--gc-sections -s
CFLAGS+=-Os -DANDROID -DAPPNAME=\"$(APPNAME)\"
CFLAGS +=-DANDROID_FULLSCREEN
CFLAGS+= -I$(RAWDRAWANDROID)/rawdraw -I$(NDK)/sysroot/usr/include -I$(NDK)/sysroot/usr/include/android -I$(NDK)/toolchains/llvm/prebuilt/$(OS_NAME)/sysroot/usr/include/android -fPIC -I$(RAWDRAWANDROID) -DANDROIDVERSION=$(ANDROIDVERSION)
LDFLAGS += -lm -lGLESv3 -lEGL -landroid -llog
LDFLAGS += -shared -uANativeActivity_onCreate
CC_ARM64:=$(NDK)/toolchains/llvm/prebuilt/$(OS_NAME)/bin/aarch64-linux-android$(ANDROIDVERSION)-clang
TARGETS += makecapk/lib/arm64-v8a/lib$(APPNAME).so
CFLAGS_ARM64:=-m64
	mkdir -p makecapk/lib/arm64-v8a
makecapk/lib/arm64-v8a/lib$(APPNAME).so : $(ANDROIDSRCS)
	mkdir -p makecapk/lib/arm64-v8a
	$(CC_ARM64) $(CFLAGS) $(CFLAGS_ARM64) -o $@ $^ -L$(NDK)/toolchains/llvm/prebuilt/$(OS_NAME)/sysroot/usr/lib/aarch64-linux-android/$(ANDROIDVERSION) $(LDFLAGS)
makecapk.apk : $(TARGETS) $(EXTRA_ASSETS_TRIGGER) AndroidManifest.xml
	mkdir -p makecapk/assets
	cp -r Sources/assets/* makecapk/assets
	rm -rf temp.apk
	$(AAPT) package -f -F temp.apk -I $(ANDROIDSDK)/platforms/android-$(ANDROIDVERSION)/android.jar -M AndroidManifest.xml -S Sources/res -A makecapk/assets -v --target-sdk-version $(ANDROIDTARGET)
	unzip -o temp.apk -d makecapk
	rm -rf makecapk.apk
	cd makecapk && zip -D9r ../makecapk.apk . && zip -D0r ../makecapk.apk ./resources.arsc ./AndroidManifest.xml
	jarsigner -sigalg SHA1withRSA -digestalg SHA1 -verbose -keystore $(KEYSTOREFILE) -storepass $(STOREPASS) makecapk.apk $(ALIASNAME)
	rm -rf $(APKFILE)
	$(BUILD_TOOLS)/zipalign -v 4 makecapk.apk $(APKFILE)
	#Using the apksigner in this way is only required on Android 30+
	$(BUILD_TOOLS)/apksigner sign --key-pass pass:$(STOREPASS) --ks-pass pass:$(STOREPASS) --ks $(KEYSTOREFILE) $(APKFILE)
	rm -rf temp.apk
	rm -rf makecapk.apk
	@ls -l $(APKFILE)


# makecapk.apk
#  TARGETS
#   makecapk/lib/arm64-v8a/lib$(APPNAME).so
#    ANDROIDSRCS
#     SRC
#      nothing? just the c file i believe
#     RAWDRAWANDROIDSRCS
#      the android_native_app_glue.c file
#    .
mkdir -p makecapk/lib/arm64-v8a
#    $(CC_ARM64) $(CFLAGS) $(CFLAGS_ARM64) -o $@ $^ -L$(NDK)/toolchains/llvm/prebuilt/$(OS_NAME)/sysroot/usr/lib/aarch64-linux-android/$(ANDROIDVERSION) $(LDFLAGS)
#     CC_ARM64
#      $(NDK)/toolchains/llvm/prebuilt/$(OS_NAME)/bin/aarch64-linux-android$(ANDROIDVERSION)-clang
#     CFLAGS
#      -ffunction-sections -Os -fdata-sections -Wall -fvisibility=hidden -Os -DANDROID -DAPPNAME=\"$(APPNAME)\" -DANDROID_FULLSCREEN -I$(RAWDRAWANDROID)/rawdraw -I$(NDK)/sysroot/usr/include -I$(NDK)/sysroot/usr/include/android -I$(NDK)/toolchains/llvm/prebuilt/$(OS_NAME)/sysroot/usr/include/android -fPIC -I$(RAWDRAWANDROID) -DANDROIDVERSION=$(ANDROIDVERSION)
#     CFLAGS_ARM64
#      -m64
#     LDFLAGS
#      -lm -lGLESv3 -lEGL -landroid -llog -shared -uANativeActivity_onCreate
#      probably replace GL stuff with Vulkan VK
#  .
mkdir -p makecapk/assets
cp -r Sources/assets/* makecapk/assets
rm -rf temp.apk
$(AAPT) package -f -F temp.apk -I $(ANDROIDSDK)/platforms/android-$(ANDROIDVERSION)/android.jar -M AndroidManifest.xml -S Sources/res -A makecapk/assets -v --target-sdk-version $(ANDROIDTARGET)
unzip -o temp.apk -d makecapk
rm -rf makecapk.apk
cd makecapk && zip -D9r ../makecapk.apk . && zip -D0r ../makecapk.apk ./resources.arsc ./AndroidManifest.xml
jarsigner -sigalg SHA1withRSA -digestalg SHA1 -verbose -keystore $(KEYSTOREFILE) -storepass $(STOREPASS) makecapk.apk $(ALIASNAME)
rm -rf $(APKFILE)
$(BUILD_TOOLS)/zipalign -v 4 makecapk.apk $(APKFILE)
#Using the apksigner in this way is only required on Android 30+
$(BUILD_TOOLS)/apksigner sign --key-pass pass:$(STOREPASS) --ks-pass pass:$(STOREPASS) --ks $(KEYSTOREFILE) $(APKFILE)
rm -rf temp.apk
rm -rf makecapk.apk
@ls -l $(APKFILE)
!

printf 'aapt\r' >&2
aapt package -f -m -M AndroidManifest.xml -J gen -S res || exit 1

printf '\033[Kecj\r' >&2
ecj -d obj -sourcepath . ./gen/com/vulkan/tutorials/sixcsim/R.java ./mark/app/MyNativeActivity.java || exit 1

printf '\033[Kdx\r' >&2
dx --dex --output=bin/classes.dex obj || exit 1

printf '\033[Kaapt 2\r' >&2
aapt package -f \
       	--min-sdk-version 27 \
       	--target-sdk-version 27 \
       	-M AndroidManifest.xml \
       	-S res \
       	-A assets \
       	-F bin/com.vulkan.tutorials.sixcsim.apk || exit 1

#aarch64-linux-android-clang -o lib/arm64-v8a/libvktuts.so jni/hello-jni.c -shared
sh compile.sh || exit 1
sh compilejni.sh || exit 1
aapt add bin/com.vulkan.tutorials.sixcsim.apk lib/arm64-v8a/libvktuts.so
aapt add bin/com.vulkan.tutorials.sixcsim.apk lib/arm64-v8a/libmynativeactivity.so
#aapt add bin/com.vulkan.tutorials.sixcsim.apk lib/arm64-v8a/libc++_shared.so
aapt add bin/com.vulkan.tutorials.sixcsim.apk lib/arm64-v8a/libVkLayer_khronos_validation.so

aapt add bin/com.vulkan.tutorials.sixcsim.apk lib/arm64-v8a/libclang_rt.asan-aarch64-android.so
aapt add bin/com.vulkan.tutorials.sixcsim.apk lib/arm64-v8a/libc++_shared.so

#aapt add bin/com.vulkan.tutorials.sixcsim.apk lib/arm64-v8a/libVkLayer_core_validation.so
#aapt add bin/com.vulkan.tutorials.sixcsim.apk lib/arm64-v8a/libVkLayer_object_tracker.so
#aapt add bin/com.vulkan.tutorials.sixcsim.apk lib/arm64-v8a/libVkLayer_parameter_validation.so
#aapt add bin/com.vulkan.tutorials.sixcsim.apk lib/arm64-v8a/libVkLayer_threading.so
#aapt add bin/com.vulkan.tutorials.sixcsim.apk lib/arm64-v8a/libVkLayer_unique_objects.so
#aapt add bin/com.vulkan.tutorials.sixcsim.apk lib/arm64-v8a/libvulkan.so

cd bin
printf '\033[Kaapt 3\r' >&2
aapt add -f com.vulkan.tutorials.sixcsim.apk classes.dex || exit 1

printf '\033[Kapksigner\r' >&2
apksigner sign --cert ~/buildAPKs/opt/key/certificate.pem --key ~/buildAPKs/opt/key/key.pk8 com.vulkan.tutorials.sixcsim.apk || exit 1
#apksigner verify --verbose com.myapp.apk || exit 1
