#!/bin/sh
# For if only the c changes
sh compile.sh || exit 1
aapt remove bin/com.vulkan.tutorials.sixcsim.apk lib/arm64-v8a/libvktuts.so
aapt add bin/com.vulkan.tutorials.sixcsim.apk lib/arm64-v8a/libvktuts.so
#aapt add bin/com.vulkan.tutorials.sixcsim.apk lib/arm64-v8a/libvulkan.so

cd bin

printf '\033[Kapksigner\r' >&2
apksigner sign --cert ~/buildAPKs/opt/key/certificate.pem --key ~/buildAPKs/opt/key/key.pk8 com.vulkan.tutorials.sixcsim.apk || exit 1
#apksigner verify --verbose com.myapp.apk || exit 1
