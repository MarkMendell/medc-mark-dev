#!/bin/sh
#aarch64-linux-android-clang++ -c -fPIC -D__ANDROID_API__=29 -DAPPNAME=\"six\" -DANDROID_TOOLCHAIN=clang -DVK_USE_PLATFORM_ANDROID_KHR -std=c++11 system_fonts_bridge.cpp -lm -landroid -llog -Wl,--no-undefined
aarch64-linux-android-clang++ -c -fPIC -D__ANDROID_API__=29 -DAPPNAME=\"six\" -DANDROID_TOOLCHAIN=clang -DVK_USE_PLATFORM_ANDROID_KHR -std=c++11 system_fonts_bridge.cpp
