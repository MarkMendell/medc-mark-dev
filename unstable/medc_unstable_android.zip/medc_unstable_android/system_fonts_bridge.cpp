// Because system_fonts.cpp doesn't say extern c...
#include <stdint.h>
#include <android/font_matcher.h>

extern "C" {

void*
AFontMatcher_createc(void)
{
	return (void*)AFontMatcher_create();
}

void*
AFontMatcher_matchc(void *matcher,char *familyName, uint16_t *text, uint32_t textLength ,uint32_t *runLength)
{
	return (void*)AFontMatcher_match((AFontMatcher*)matcher, familyName, text, textLength, runLength);
}

void
AFontMatcher_destroyc(void *matcher)
{
	AFontMatcher_destroy((AFontMatcher*)matcher);
}

const char*
AFont_getFontFilePathc(void *font)
{
	return AFont_getFontFilePath((AFont*)font);
}

void
AFont_closec(void *font)
{
	AFont_close((AFont*)font);
}

}
