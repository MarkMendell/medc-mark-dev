/*
expand, closeopen, expand another, closeopen crash
cant type "btnssearch[SEARCHCASE].lines[0][3]=='
	then "I"
suggest typing word when typing before another word
global replace
tap overlay should stop spacing
special niceness for fprintf/perror
	type ipe<enter> gets replaced with
		check, perror, exit
	take params for special
swipe up should show keyboard
get regenerate shaderc working
suggest strerror, EXIT_FAILURE
space if (a && b) { f(a,b); f(b); }
suggest xlosing charactera of uneven line
handle spaced cursor taps correctly (and draws)
paste multiple vloxks after block is 1
handle tapping atart od line
recommend suffixes before deletions
dont space when past end of line
paste after block where next is expanded
adjust indent if delete } line (similar pasting })
give Join hide option like paste maybe just time out for undo/join
search for number
cut line merge blocks
 x = malloc() enter should add type of x
show label of func, not declaration
emoji / chinese
dont draw excessively
show inner flow rect inside of exp rect
dont show search option if no alphabet for case
expand "Add keywords" geberated line, unexpand weird
*/
#include <assert.h>
#include <ctype.h>
#include <errno.h>
#include <poll.h>
#include <pthread.h>
#include <regex.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>
#include <android/configuration.h>
#include <android/looper.h>
#include <android/native_activity.h>
#include <android/log.h>
#include <jni.h>
#include <sched.h>
#define STB_IMAGE_IMPLEMENTATION
#define STBI_ONLY_PNG
#include <stb/stb_image.h>
#include <stdbool.h>
#include <sys/resource.h>
#include <vulkan_wrapper.h>

#include <dirent.h>

VkDebugReportCallbackEXT debugUtilsMessenger;
ANativeActivity* activity;
jobject editText;

// UI constants
const double wtab = 30.0,
	pxhfont = 40.0,
	windentlabel = wtab,
	windentsearch = wtab,
	plrb = 15.0,
	pudb = 30.0,
	mlrb = 10.0,
	mudb = 10.0,
	mudwin = 40.0,
	padwin = 4.0,
	hline = 27.0,
	mline = 13.0,
	hbtn = 200.0,
	rhbtn0 = 0.55,
	y0search = mudwin + hline + 7,
	rx0tab = 0.63,
	rx1tab = 0.77,
	hbtntab = 90.0,
	wspacing = 20.0;
const unsigned MAXLABELS = 128;
//char *pathopen = "/storage/emulated/0/Android/data/com.vulkan.tutorials.sixcsim/files/f.txt";
char *pathopen = "/storage/emulated/0/Android/data/com.vulkan.tutorials.sixcsim/files/c/AndroidMain.c";
char *pathsavestate = "/data/data/com.vulkan.tutorials.sixcsim/cache/fsavestate";

// Overlay buttons
#if 0
{
#endif

	// Main overlay
	// Generated: printf '\tenum button { '; <c/AndroidMain.c sed -n '/^\tstruct buttoninfo {/,/^	}/s,^		\[\([^]]*\).*,\1,p' | sed -n 'H;${x;s,\n,,;s/\n/, /gp;}' | tr -d '\n'; echo ', NBUTTONS};'
	enum button { CUTLINE, PASTEBELOW, FLOWLINE, SELECTLINES, SAVE, MULTICURSOR, GOTOP, ENTERAFTERBLOCK, REGENERATE, ENTERBELOW, SELECT, PASTE, UNDO, JOIN, INTENTTERMUX, PASTEAFTERBLOCK, CUTBLOCK, COPYBLOCK, ENTEROUTEXPAND, NBUTTONS};
	struct buttoninfo { char *lines[2]; uint64_t flag; } buttons[] = {
	
		// Row 0
		[CUTLINE] = { {"Cut","line"}, 8},
		[PASTEBELOW] = { {"Paste","below"}, 8},
		[FLOWLINE] = { {"Flow","line"}, 64},
		[SELECTLINES] = { {"Select","lines"}, 2},
		[SAVE] = { {"Save"}, 0},
		
		// Row 1
		[MULTICURSOR] = { {"Multi","cursor"}, 8},
		[GOTOP] = { {"Go","top"}, 16},
		[ENTERAFTERBLOCK] = { {"Enter after","block"} },
		[REGENERATE] = { {"Regenerate"}, 32},
		[ENTERBELOW] = { {"Enter","below"}, 2},
		
		// Row 3
		[SELECT] = { {"Select"}, 2},
		[PASTE] = { {"Paste"}, 8},
		[UNDO] = { {"Undo"}, 128},
		[JOIN] = { {"Join"}, 0x100},
		[INTENTTERMUX] = { {"Intent","Termux"} },
		
		// Row 4
		[PASTEAFTERBLOCK] = { {"Paste after","block"} },
		[CUTBLOCK] = { {"Cut","block"} },
		[COPYBLOCK] = { {"Copy","block"} },
		[ENTEROUTEXPAND] = { {"Enter out","expand"}, 0x200}
	};

	// Overlay for choosing a multi cursor range
	// Generated: printf '\tenum btnmulticurstop { '; <c/AndroidMain.c sed -n '/^\tstruct buttoninfo btnsmulticurstop\[/,/^	}/s,^		\[\([^]]*\).*,\1,p' | sed -n 'H;${x;s,\n,,;s/\n/, /gp;}' | tr -d '\n'; echo '};'
	enum btnmulticurstop { _0MCSTOP, _1MCSTOP, _2MCSTOP, MCSTOPCHOOSE, MCSTOPCANCEL};
	struct buttoninfo btnsmulticurstop[] = {
		[_0MCSTOP] = {0},
		[_1MCSTOP] = {0},
		[_2MCSTOP] = {0},
		[MCSTOPCHOOSE] = { {"Choose"} },
		[MCSTOPCANCEL] = { {"Cancel"} }
	};

	// Overlay for neutral multi cursor state
	// Generated: printf '\tenum btnmulticuract { '; <c/AndroidMain.c sed -n '/^\tstruct buttoninfo btnsmulticuract\[/,/^	}/s,^		\[\([^]]*\).*,\1,p' | sed -n 'H;${x;s,\n,,;s/\n/, /gp;}' | tr -d '\n'; echo '};'
	enum btnmulticuract { MCACTADDLINES, MCACTSELECT, MCACTBACKMATCH, MCACTENDOFLINE, MCACTDONE, MCACTPASTE, MCACTMOVEN, MCACTNEXTENDWORD, MCACTTOGGLELINES, MCACTCOPY, MCACTRIGHT};
	struct buttoninfo btnsmulticuract[] = {
		
		// Row 0
		[MCACTADDLINES] = { {"Add","lines"} },
		[MCACTSELECT] = { {"Select"} },
		[MCACTBACKMATCH] = { {"Back","match"} },
		[MCACTENDOFLINE] = { {"End of","Line"} },
		[MCACTDONE] = { {"Done"} },
	
		// Row 1
		[MCACTPASTE] = { {"Paste"}, },
		[MCACTMOVEN] = { {"Move","n"} },
		[MCACTNEXTENDWORD] = { {"Next","end word"} },
		[MCACTTOGGLELINES] = { {"Toggle","lines"} },
		[MCACTCOPY] = { {"Copy"} },
		
		// Row 2
		[MCACTRIGHT] = { {"Right"} }
	};

	// Overlay for multi cursor back match
	// Generated: printf '\tenum btnmcbackmatch { '; <c/AndroidMain.c sed -n '/^\tstruct buttoninfo btnsmcbackmatch\[/,/^	}/s,^		\[\([^]]*\).*,\1,p' | sed -n 'H;${x;s,\n,,;s/\n/, /gp;}' | tr -d '\n'; echo '};'
	enum btnmcbackmatch { _0MCBM, _1MCBM, _2MCBM, _3MCBM, MCBMCANCEL};
	struct buttoninfo btnsmcbackmatch[] = {
		[_0MCBM] = {0},
		[_1MCBM] = {0},
		[_2MCBM] = {0},
		[_3MCBM] = {0},
		[MCBMCANCEL] = { {"Cancel"} }
	};
	
	// Overlay for cancel
	// Generated: printf '\tenum btncancel { '; <c/AndroidMain.c sed -n '/^\tstruct buttoninfo btnscancel\[/,/^	}/s,^		\[\([^]]*\).*,\1,p' | sed -n 'H;${x;s,\n,,;s/\n/, /gp;}' | tr -d '\n'; echo '};'
	enum btncancel { _0CANCEL, _1CANCEL, _2CANCEL, _3CANCEL, CANCELCANCEL};
	struct buttoninfo btnscancel[] = {
		[_0CANCEL] = {0},
		[_1CANCEL] = {0},
		[_2CANCEL] = {0},
		[_3CANCEL] = {0},
		[CANCELCANCEL] = { {"Cancel"} }
	};
	
	// Overlay for selecting
	// Generated: printf '\tenum btnselect { '; <c/AndroidMain.c sed -n '/^\tstruct buttoninfo btnsselect\[/,/^	}/s,^		\[\([^]]*\).*,\1,p' | sed -n 'H;${x;s,\n,,;s/\n/, /gp;}' | tr -d '\n'; echo '};'
	enum btnselect { SELECTINCLUDEPRELINES, SELECTMAKEFUNCTION, SELECTREPLACE, SELECTCOPY, SELECTCANCEL};
	struct buttoninfo btnsselect[] = {
		[SELECTINCLUDEPRELINES] = { {"Include","pre lines"}, 1},
		[SELECTMAKEFUNCTION] = { {"Make","function"} },
		[SELECTREPLACE] = { {"Replace"} },
		[SELECTCOPY] = { {"Copy"} },
		[SELECTCANCEL] = { {"Cancel"} }
	};
	
	// Overlay for replacing
	// Generated: printf '\tenum btnreplace { '; <c/AndroidMain.c sed -n '/^\tstruct buttoninfo btnsreplace\[/,/^	}/s,^		\[\([^]]*\).*,\1,p' | sed -n 'H;${x;s,\n,,;s/\n/, /gp;}' | tr -d '\n'; echo '};'
	enum btnreplace { _0REPLACE, _1REPLACE, REPLACECASE, REPLACEREPLACE, REPLACECANCEL};
	struct buttoninfo btnsreplace[] = {
		[_0REPLACE] = {0},
		[_1REPLACE] = {0},
		[REPLACECASE] = { {"<> Replace","case"} },
		[REPLACEREPLACE] = { {"Replace"} },
		[REPLACECANCEL] = { {"Cancel"} }
	};

	// Overlay for multi cursor add lines
	// Generated: printf '\tenum btnmcaddlines { '; <c/AndroidMain.c sed -n '/^\tstruct buttoninfo btnsmcaddlines\[/,/^	}/s,^		\[\([^]]*\).*,\1,p' | sed -n 'H;${x;s,\n,,;s/\n/, /gp;}' | tr -d '\n'; echo '};'
	enum btnmcaddlines { _0MCAL, _1MCAL, _2MCAL, _3MCAL, MCALCANCEL};
	struct buttoninfo btnsmcaddlines[] = {
		[_0MCAL] = {0},
		[_1MCAL] = {0},
		[_2MCAL] = {0},
		[_3MCAL] = {0},
		[MCALCANCEL] = { {"Cancel"} }
	};

	// Overlay for multi cursor move n
	// Generated: printf '\tenum btnmcmoven { '; <c/AndroidMain.c sed -n '/^\tstruct buttoninfo btnsmcmoven\[/,/^	}/s,^		\[\([^]]*\).*,\1,p' | sed -n 'H;${x;s,\n,,;s/\n/, /gp;}' | tr -d '\n'; echo '};'
	enum btnmcmoven { _0MCMN, _1MCMN, _2MCMN, _3MCMN, MCMNCANCEL};
	struct buttoninfo btnsmcmoven[] = {
		[_0MCMN] = {0},
		[_1MCMN] = {0},
		[_2MCMN] = {0},
		[_3MCMN] = {0},
		[MCMNCANCEL] = { {"Cancel"} }
	};
	
	// Overlay for multi cursor toggle lines
	// Generated: printf '\tenum btnmctoglines { '; <c/AndroidMain.c sed -n '/^\tstruct buttoninfo btnsmctoglines\[/,/^	}/s,^		\[\([^]]*\).*,\1,p' | sed -n 'H;${x;s,\n,,;s/\n/, /gp;}' | tr -d '\n'; echo '};'
	enum btnmctoglines { _0MCTL, _1MCTL, _2MCTL, _3MCTL, MCTLDONE};
	struct buttoninfo btnsmctoglines[] = {
		[_0MCTL] = {0},
		[_1MCTL] = {0},
		[_2MCTL] = {0},
		[_3MCTL] = {0},
		[MCTLDONE] = { {"Done"} }
	};
	
	// Overlay for make function
	// Generated: printf '\tenum btnmakefunction { '; <c/AndroidMain.c sed -n '/^\tstruct buttoninfo btnsmakefunction\[/,/^	}/s,^		\[\([^]]*\).*,\1,p' | sed -n 'H;${x;s,\n,,;s/\n/, /gp;}' | tr -d '\n'; echo '};'
	enum btnmakefunction { _0MKFN, _1MKFN, _2MKFN, _3MKFN, MKFNDONE};
	struct buttoninfo btnsmakefunction[] = {
		[_0MKFN] = {0},
		[_1MKFN] = {0},
		[_2MKFN] = {0},
		[_3MKFN] = {0},
		[MKFNDONE] = { {"Done","naming"} }
	};
	
	// Overlay for when just copied
	// Generated: printf '\tenum btncopied { '; <c/AndroidMain.c sed -n '/^\tstruct buttoninfo btnscopied\[/,/^	}/s,^		\[\([^]]*\).*,\1,p' | sed -n 'H;${x;s,\n,,;s/\n/, /gp;}' | tr -d '\n'; echo '};'
	enum btncopied { _0COPIED, COPIEDHIDE, COPIEDPASTEAFTERBLOCK, COPIEDPASTE, COPIEDPASTEBELOW};
	struct buttoninfo btnscopied[] = {
		[_0COPIED] = {0},
		[COPIEDHIDE] = { {"Hide"} },
		[COPIEDPASTEAFTERBLOCK] = { {"Paste after","block"} },
		[COPIEDPASTE] = { {"Paste"}, 1},
		[COPIEDPASTEBELOW] = { {"Paste","below"}, 1}
	};
	
	// Overlay for when just undid
	// Generated: printf '\tenum btnundid { '; <c/AndroidMain.c sed -n '/^\tstruct buttoninfo btnsundid\[/,/^	}/s,^		\[\([^]]*\).*,\1,p' | sed -n 'H;${x;s,\n,,;s/\n/, /gp;}' | tr -d '\n'; echo '};'
	enum btnundid { _0UNDID, _1UNDID, _2UNDID, _3UNDID, _4UNDID, _5UNDID, _6UNDID, _7UNDID, _8UNDID, _9UNDID, _10UNDID, _11UNDID, UNDIDUNDO};
	struct buttoninfo btnsundid[] = {
		[_0UNDID] = {0},
		[_1UNDID] = {0},
		[_2UNDID] = {0},
		[_3UNDID] = {0},
		[_4UNDID] = {0},
		[_5UNDID] = {0},
		[_6UNDID] = {0},
		[_7UNDID] = {0},
		[_8UNDID] = {0},
		[_9UNDID] = {0},
		[_10UNDID] = {0},
		[_11UNDID] = {0},
		[UNDIDUNDO] = { {"Undo"}, 1}
	};
	
	// Overlay for when just joined
	// Generated: printf '\tenum btnjoined { '; <c/AndroidMain.c sed -n '/^\tstruct buttoninfo btnsjoined\[/,/^	}/s,^		\[\([^]]*\).*,\1,p' | sed -n 'H;${x;s,\n,,;s/\n/, /gp;}' | tr -d '\n'; echo '};'
	enum btnjoined { _0JOINED, _1JOINED, _2JOINED, _3JOINED, _4JOINED, _5JOINED, _6JOINED, _7JOINED, _8JOINED, _9JOINED, _10JOINED, _11JOINED, _12JOINED, JOINEDJOIN};
	struct buttoninfo btnsjoined[] = {
		[_0JOINED] = {0},
		[_1JOINED] = {0},
		[_2JOINED] = {0},
		[_3JOINED] = {0},
		[_4JOINED] = {0},
		[_5JOINED] = {0},
		[_6JOINED] = {0},
		[_7JOINED] = {0},
		[_8JOINED] = {0},
		[_9JOINED] = {0},
		[_10JOINED] = {0},
		[_11JOINED] = {0},
		[_12JOINED] = {0},
		[JOINEDJOIN] = { {"Join"}, 1}
	};
	
	// Overlay for when tapped near start
	// Generated: printf '\tenum btntap0 { '; <c/AndroidMain.c sed -n '/^\tstruct buttoninfo btnstap0\[/,/^	}/s,^		\[\([^]]*\).*,\1,p' | sed -n 'H;${x;s,\n,,;s/\n/, /gp;}' | tr -d '\n'; echo '};'
	enum btntap0 { TAP0STARTOFLINE };
	struct buttoninfo btnstap0[] = {
		[TAP0STARTOFLINE] = { {"Start","of line"} }
	};
	
	// Overlay for when searching
	// Generated: printf '\tenum btnsearch { '; <c/AndroidMain.c sed -n '/^\tstruct buttoninfo btnssearch\[/,/^	}/s,^		\[\([^]]*\).*,\1,p' | sed -n 'H;${x;s,\n,,;s/\n/, /gp;}' | tr -d '\n'; echo '};'
	enum btnsearch { _SEARCH0, _SEARCH1, _SEARCH2, _SEARCH3, SEARCHCASE};
	struct buttoninfo btnssearch[] = {
		[_SEARCH0] = {0},
		[_SEARCH1] = {0},
		[_SEARCH2] = {0},
		[_SEARCH3] = {0},
		[SEARCHCASE] = { {"<> Ignore","case"} }
	};
	
#if 0
}
#endif

// Unicode groups
const uint32_t Extended_Pictographic[] =
// Generated: curl unicode.org/Public/emoji/12.1/emoji-data.txt | grep 'Extended_Pictographic#' | cut -d ' ' -f 1 | sed 's/[^.]\{1,\}/0x&/g' | sed 's/\.\./,/' | sed '/,/!s/.*/&,&/' | sed -n 'H;${x;s/\n//;s/\n/, /gp;}' | sed 's/.*/{&};/'
{0x00A9,0x00A9, 0x00AE,0x00AE, 0x203C,0x203C, 0x2049,0x2049, 0x2122,0x2122, 0x2139,0x2139, 0x2194,0x2199, 0x21A9,0x21AA, 0x231A,0x231B, 0x2328,0x2328, 0x2388,0x2388, 0x23CF,0x23CF, 0x23E9,0x23F3, 0x23F8,0x23FA, 0x24C2,0x24C2, 0x25AA,0x25AB, 0x25B6,0x25B6, 0x25C0,0x25C0, 0x25FB,0x25FE, 0x2600,0x2604, 0x2605,0x2605, 0x2607,0x260D, 0x260E,0x260E, 0x260F,0x2610, 0x2611,0x2611, 0x2612,0x2612, 0x2614,0x2615, 0x2616,0x2617, 0x2618,0x2618, 0x2619,0x261C, 0x261D,0x261D, 0x261E,0x261F, 0x2620,0x2620, 0x2621,0x2621, 0x2622,0x2623, 0x2624,0x2625, 0x2626,0x2626, 0x2627,0x2629, 0x262A,0x262A, 0x262B,0x262D, 0x262E,0x262F, 0x2630,0x2637, 0x2638,0x263A, 0x263B,0x263F, 0x2640,0x2640, 0x2641,0x2641, 0x2642,0x2642, 0x2643,0x2647, 0x2648,0x2653, 0x2654,0x265E, 0x265F,0x265F, 0x2660,0x2660, 0x2661,0x2662, 0x2663,0x2663, 0x2664,0x2664, 0x2665,0x2666, 0x2667,0x2667, 0x2668,0x2668, 0x2669,0x267A, 0x267B,0x267B, 0x267C,0x267D, 0x267E,0x267E, 0x267F,0x267F, 0x2680,0x2685, 0x2690,0x2691, 0x2692,0x2694, 0x2695,0x2695, 0x2696,0x2697, 0x2698,0x2698, 0x2699,0x2699, 0x269A,0x269A, 0x269B,0x269C, 0x269D,0x269F, 0x26A0,0x26A1, 0x26A2,0x26A9, 0x26AA,0x26AB, 0x26AC,0x26AF, 0x26B0,0x26B1, 0x26B2,0x26BC, 0x26BD,0x26BE, 0x26BF,0x26C3, 0x26C4,0x26C5, 0x26C6,0x26C7, 0x26C8,0x26C8, 0x26C9,0x26CD, 0x26CE,0x26CF, 0x26D0,0x26D0, 0x26D1,0x26D1, 0x26D2,0x26D2, 0x26D3,0x26D4, 0x26D5,0x26E8, 0x26E9,0x26EA, 0x26EB,0x26EF, 0x26F0,0x26F5, 0x26F6,0x26F6, 0x26F7,0x26FA, 0x26FB,0x26FC, 0x26FD,0x26FD, 0x26FE,0x2701, 0x2702,0x2702, 0x2703,0x2704, 0x2705,0x2705, 0x2708,0x270D, 0x270E,0x270E, 0x270F,0x270F, 0x2710,0x2711, 0x2712,0x2712, 0x2714,0x2714, 0x2716,0x2716, 0x271D,0x271D, 0x2721,0x2721, 0x2728,0x2728, 0x2733,0x2734, 0x2744,0x2744, 0x2747,0x2747, 0x274C,0x274C, 0x274E,0x274E, 0x2753,0x2755, 0x2757,0x2757, 0x2763,0x2764, 0x2765,0x2767, 0x2795,0x2797, 0x27A1,0x27A1, 0x27B0,0x27B0, 0x27BF,0x27BF, 0x2934,0x2935, 0x2B05,0x2B07, 0x2B1B,0x2B1C, 0x2B50,0x2B50, 0x2B55,0x2B55, 0x3030,0x3030, 0x303D,0x303D, 0x3297,0x3297, 0x3299,0x3299, 0x1F000,0x1F003, 0x1F004,0x1F004, 0x1F005,0x1F0CE, 0x1F0CF,0x1F0CF, 0x1F0D0,0x1F0FF, 0x1F10D,0x1F10F, 0x1F12F,0x1F12F, 0x1F16C,0x1F16F, 0x1F170,0x1F171, 0x1F17E,0x1F17F, 0x1F18E,0x1F18E, 0x1F191,0x1F19A, 0x1F1AD,0x1F1E5, 0x1F201,0x1F202, 0x1F203,0x1F20F, 0x1F21A,0x1F21A, 0x1F22F,0x1F22F, 0x1F232,0x1F23A, 0x1F23C,0x1F23F, 0x1F249,0x1F24F, 0x1F250,0x1F251, 0x1F252,0x1F2FF, 0x1F300,0x1F321, 0x1F322,0x1F323, 0x1F324,0x1F393, 0x1F394,0x1F395, 0x1F396,0x1F397, 0x1F398,0x1F398, 0x1F399,0x1F39B, 0x1F39C,0x1F39D, 0x1F39E,0x1F3F0, 0x1F3F1,0x1F3F2, 0x1F3F3,0x1F3F5, 0x1F3F6,0x1F3F6, 0x1F3F7,0x1F3FA, 0x1F400,0x1F4FD, 0x1F4FE,0x1F4FE, 0x1F4FF,0x1F53D, 0x1F546,0x1F548, 0x1F549,0x1F54E, 0x1F54F,0x1F54F, 0x1F550,0x1F567, 0x1F568,0x1F56E, 0x1F56F,0x1F570, 0x1F571,0x1F572, 0x1F573,0x1F579, 0x1F57A,0x1F57A, 0x1F57B,0x1F586, 0x1F587,0x1F587, 0x1F588,0x1F589, 0x1F58A,0x1F58D, 0x1F58E,0x1F58F, 0x1F590,0x1F590, 0x1F591,0x1F594, 0x1F595,0x1F596, 0x1F597,0x1F5A3, 0x1F5A4,0x1F5A4, 0x1F5A5,0x1F5A5, 0x1F5A6,0x1F5A7, 0x1F5A8,0x1F5A8, 0x1F5A9,0x1F5B0, 0x1F5B1,0x1F5B2, 0x1F5B3,0x1F5BB, 0x1F5BC,0x1F5BC, 0x1F5BD,0x1F5C1, 0x1F5C2,0x1F5C4, 0x1F5C5,0x1F5D0, 0x1F5D1,0x1F5D3, 0x1F5D4,0x1F5DB, 0x1F5DC,0x1F5DE, 0x1F5DF,0x1F5E0, 0x1F5E1,0x1F5E1, 0x1F5E2,0x1F5E2, 0x1F5E3,0x1F5E3, 0x1F5E4,0x1F5E7, 0x1F5E8,0x1F5E8, 0x1F5E9,0x1F5EE, 0x1F5EF,0x1F5EF, 0x1F5F0,0x1F5F2, 0x1F5F3,0x1F5F3, 0x1F5F4,0x1F5F9, 0x1F5FA,0x1F64F, 0x1F680,0x1F6C5, 0x1F6C6,0x1F6CA, 0x1F6CB,0x1F6D0, 0x1F6D1,0x1F6D2, 0x1F6D3,0x1F6D4, 0x1F6D5,0x1F6D5, 0x1F6D6,0x1F6DF, 0x1F6E0,0x1F6E5, 0x1F6E6,0x1F6E8, 0x1F6E9,0x1F6E9, 0x1F6EA,0x1F6EA, 0x1F6EB,0x1F6EC, 0x1F6ED,0x1F6EF, 0x1F6F0,0x1F6F0, 0x1F6F1,0x1F6F2, 0x1F6F3,0x1F6F3, 0x1F6F4,0x1F6F6, 0x1F6F7,0x1F6F8, 0x1F6F9,0x1F6F9, 0x1F6FA,0x1F6FA, 0x1F6FB,0x1F6FF, 0x1F774,0x1F77F, 0x1F7D5,0x1F7DF, 0x1F7E0,0x1F7EB, 0x1F7EC,0x1F7FF, 0x1F80C,0x1F80F, 0x1F848,0x1F84F, 0x1F85A,0x1F85F, 0x1F888,0x1F88F, 0x1F8AE,0x1F8FF, 0x1F90C,0x1F90C, 0x1F90D,0x1F90F, 0x1F910,0x1F918, 0x1F919,0x1F91E, 0x1F91F,0x1F91F, 0x1F920,0x1F927, 0x1F928,0x1F92F, 0x1F930,0x1F930, 0x1F931,0x1F932, 0x1F933,0x1F93A, 0x1F93C,0x1F93E, 0x1F93F,0x1F93F, 0x1F940,0x1F945, 0x1F947,0x1F94B, 0x1F94C,0x1F94C, 0x1F94D,0x1F94F, 0x1F950,0x1F95E, 0x1F95F,0x1F96B, 0x1F96C,0x1F970, 0x1F971,0x1F971, 0x1F972,0x1F972, 0x1F973,0x1F976, 0x1F977,0x1F979, 0x1F97A,0x1F97A, 0x1F97B,0x1F97B, 0x1F97C,0x1F97F, 0x1F980,0x1F984, 0x1F985,0x1F991, 0x1F992,0x1F997, 0x1F998,0x1F9A2, 0x1F9A3,0x1F9A4, 0x1F9A5,0x1F9AA, 0x1F9AB,0x1F9AD, 0x1F9AE,0x1F9AF, 0x1F9B0,0x1F9B9, 0x1F9BA,0x1F9BF, 0x1F9C0,0x1F9C0, 0x1F9C1,0x1F9C2, 0x1F9C3,0x1F9CA, 0x1F9CB,0x1F9CC, 0x1F9CD,0x1F9CF, 0x1F9D0,0x1F9E6, 0x1F9E7,0x1F9FF, 0x1FA00,0x1FA6F, 0x1FA70,0x1FA73, 0x1FA74,0x1FA77, 0x1FA78,0x1FA7A, 0x1FA7B,0x1FA7F, 0x1FA80,0x1FA82, 0x1FA83,0x1FA8F, 0x1FA90,0x1FA95, 0x1FA96,0x1FFFD};
const uint32_t Regional_Indicator[] =
{0x1f1e6,0x1f1ff};
const uint32_t gbpPrepend[] =
// Generated: curl unicode.org/Public/12.1.0/ucd/auxiliary/GraphemeBreakProperty.txt | grep Prepend | cut -d ' ' -f 1 | sed 's/[^.]\{1,\}/0x&/g' | sed 's/\.\./,/' | sed '/,/!s/.*/&,&/' | sed -n 'H;${x;s/\n//;s/\n/, /gp;}' | sed 's/.*/{&};/'
{0x0600,0x0605, 0x06DD,0x06DD, 0x070F,0x070F, 0x08E2,0x08E2, 0x0D4E,0x0D4E, 0x110BD,0x110BD, 0x110CD,0x110CD, 0x111C2,0x111C3, 0x11A3A,0x11A3A, 0x11A84,0x11A89, 0x11D46,0x11D46};
const uint32_t gbpControl[] =
// Generated: curl unicode.org/Public/12.1.0/ucd/auxiliary/GraphemeBreakProperty.txt | grep Control | cut -d ' ' -f 1 | sed 's/[^.]\{1,\}/0x&/g' | sed 's/\.\./,/' | sed '/,/!s/.*/&,&/' | sed -n 'H;${x;s/\n//;s/\n/, /gp;}' | sed 's/.*/{&};/'
{0x0000,0x0009, 0x000B,0x000C, 0x000E,0x001F, 0x007F,0x009F, 0x00AD,0x00AD, 0x061C,0x061C, 0x180E,0x180E, 0x200B,0x200B, 0x200E,0x200F, 0x2028,0x2028, 0x2029,0x2029, 0x202A,0x202E, 0x2060,0x2064, 0x2065,0x2065, 0x2066,0x206F, 0xFEFF,0xFEFF, 0xFFF0,0xFFF8, 0xFFF9,0xFFFB, 0x13430,0x13438, 0x1BCA0,0x1BCA3, 0x1D173,0x1D17A, 0xE0000,0xE0000, 0xE0001,0xE0001, 0xE0002,0xE001F, 0xE0080,0xE00FF, 0xE01F0,0xE0FFF};
const uint32_t gbpExtend[] =
// Generated: curl unicode.org/Public/12.1.0/ucd/auxiliary/GraphemeBreakProperty.txt | grep Extend | cut -d ' ' -f 1 | sed 's/[^.]\{1,\}/0x&/g' | sed 's/\.\./,/' | sed '/,/!s/.*/&,&/' | sed -n 'H;${x;s/\n//;s/\n/, /gp;}' | sed 's/.*/{&};/'
{0x0300,0x036F, 0x0483,0x0487, 0x0488,0x0489, 0x0591,0x05BD, 0x05BF,0x05BF, 0x05C1,0x05C2, 0x05C4,0x05C5, 0x05C7,0x05C7, 0x0610,0x061A, 0x064B,0x065F, 0x0670,0x0670, 0x06D6,0x06DC, 0x06DF,0x06E4, 0x06E7,0x06E8, 0x06EA,0x06ED, 0x0711,0x0711, 0x0730,0x074A, 0x07A6,0x07B0, 0x07EB,0x07F3, 0x07FD,0x07FD, 0x0816,0x0819, 0x081B,0x0823, 0x0825,0x0827, 0x0829,0x082D, 0x0859,0x085B, 0x08D3,0x08E1, 0x08E3,0x0902, 0x093A,0x093A, 0x093C,0x093C, 0x0941,0x0948, 0x094D,0x094D, 0x0951,0x0957, 0x0962,0x0963, 0x0981,0x0981, 0x09BC,0x09BC, 0x09BE,0x09BE, 0x09C1,0x09C4, 0x09CD,0x09CD, 0x09D7,0x09D7, 0x09E2,0x09E3, 0x09FE,0x09FE, 0x0A01,0x0A02, 0x0A3C,0x0A3C, 0x0A41,0x0A42, 0x0A47,0x0A48, 0x0A4B,0x0A4D, 0x0A51,0x0A51, 0x0A70,0x0A71, 0x0A75,0x0A75, 0x0A81,0x0A82, 0x0ABC,0x0ABC, 0x0AC1,0x0AC5, 0x0AC7,0x0AC8, 0x0ACD,0x0ACD, 0x0AE2,0x0AE3, 0x0AFA,0x0AFF, 0x0B01,0x0B01, 0x0B3C,0x0B3C, 0x0B3E,0x0B3E, 0x0B3F,0x0B3F, 0x0B41,0x0B44, 0x0B4D,0x0B4D, 0x0B56,0x0B56, 0x0B57,0x0B57, 0x0B62,0x0B63, 0x0B82,0x0B82, 0x0BBE,0x0BBE, 0x0BC0,0x0BC0, 0x0BCD,0x0BCD, 0x0BD7,0x0BD7, 0x0C00,0x0C00, 0x0C04,0x0C04, 0x0C3E,0x0C40, 0x0C46,0x0C48, 0x0C4A,0x0C4D, 0x0C55,0x0C56, 0x0C62,0x0C63, 0x0C81,0x0C81, 0x0CBC,0x0CBC, 0x0CBF,0x0CBF, 0x0CC2,0x0CC2, 0x0CC6,0x0CC6, 0x0CCC,0x0CCD, 0x0CD5,0x0CD6, 0x0CE2,0x0CE3, 0x0D00,0x0D01, 0x0D3B,0x0D3C, 0x0D3E,0x0D3E, 0x0D41,0x0D44, 0x0D4D,0x0D4D, 0x0D57,0x0D57, 0x0D62,0x0D63, 0x0DCA,0x0DCA, 0x0DCF,0x0DCF, 0x0DD2,0x0DD4, 0x0DD6,0x0DD6, 0x0DDF,0x0DDF, 0x0E31,0x0E31, 0x0E34,0x0E3A, 0x0E47,0x0E4E, 0x0EB1,0x0EB1, 0x0EB4,0x0EBC, 0x0EC8,0x0ECD, 0x0F18,0x0F19, 0x0F35,0x0F35, 0x0F37,0x0F37, 0x0F39,0x0F39, 0x0F71,0x0F7E, 0x0F80,0x0F84, 0x0F86,0x0F87, 0x0F8D,0x0F97, 0x0F99,0x0FBC, 0x0FC6,0x0FC6, 0x102D,0x1030, 0x1032,0x1037, 0x1039,0x103A, 0x103D,0x103E, 0x1058,0x1059, 0x105E,0x1060, 0x1071,0x1074, 0x1082,0x1082, 0x1085,0x1086, 0x108D,0x108D, 0x109D,0x109D, 0x135D,0x135F, 0x1712,0x1714, 0x1732,0x1734, 0x1752,0x1753, 0x1772,0x1773, 0x17B4,0x17B5, 0x17B7,0x17BD, 0x17C6,0x17C6, 0x17C9,0x17D3, 0x17DD,0x17DD, 0x180B,0x180D, 0x1885,0x1886, 0x18A9,0x18A9, 0x1920,0x1922, 0x1927,0x1928, 0x1932,0x1932, 0x1939,0x193B, 0x1A17,0x1A18, 0x1A1B,0x1A1B, 0x1A56,0x1A56, 0x1A58,0x1A5E, 0x1A60,0x1A60, 0x1A62,0x1A62, 0x1A65,0x1A6C, 0x1A73,0x1A7C, 0x1A7F,0x1A7F, 0x1AB0,0x1ABD, 0x1ABE,0x1ABE, 0x1B00,0x1B03, 0x1B34,0x1B34, 0x1B35,0x1B35, 0x1B36,0x1B3A, 0x1B3C,0x1B3C, 0x1B42,0x1B42, 0x1B6B,0x1B73, 0x1B80,0x1B81, 0x1BA2,0x1BA5, 0x1BA8,0x1BA9, 0x1BAB,0x1BAD, 0x1BE6,0x1BE6, 0x1BE8,0x1BE9, 0x1BED,0x1BED, 0x1BEF,0x1BF1, 0x1C2C,0x1C33, 0x1C36,0x1C37, 0x1CD0,0x1CD2, 0x1CD4,0x1CE0, 0x1CE2,0x1CE8, 0x1CED,0x1CED, 0x1CF4,0x1CF4, 0x1CF8,0x1CF9, 0x1DC0,0x1DF9, 0x1DFB,0x1DFF, 0x200C,0x200C, 0x20D0,0x20DC, 0x20DD,0x20E0, 0x20E1,0x20E1, 0x20E2,0x20E4, 0x20E5,0x20F0, 0x2CEF,0x2CF1, 0x2D7F,0x2D7F, 0x2DE0,0x2DFF, 0x302A,0x302D, 0x302E,0x302F, 0x3099,0x309A, 0xA66F,0xA66F, 0xA670,0xA672, 0xA674,0xA67D, 0xA69E,0xA69F, 0xA6F0,0xA6F1, 0xA802,0xA802, 0xA806,0xA806, 0xA80B,0xA80B, 0xA825,0xA826, 0xA8C4,0xA8C5, 0xA8E0,0xA8F1, 0xA8FF,0xA8FF, 0xA926,0xA92D, 0xA947,0xA951, 0xA980,0xA982, 0xA9B3,0xA9B3, 0xA9B6,0xA9B9, 0xA9BC,0xA9BD, 0xA9E5,0xA9E5, 0xAA29,0xAA2E, 0xAA31,0xAA32, 0xAA35,0xAA36, 0xAA43,0xAA43, 0xAA4C,0xAA4C, 0xAA7C,0xAA7C, 0xAAB0,0xAAB0, 0xAAB2,0xAAB4, 0xAAB7,0xAAB8, 0xAABE,0xAABF, 0xAAC1,0xAAC1, 0xAAEC,0xAAED, 0xAAF6,0xAAF6, 0xABE5,0xABE5, 0xABE8,0xABE8, 0xABED,0xABED, 0xFB1E,0xFB1E, 0xFE00,0xFE0F, 0xFE20,0xFE2F, 0xFF9E,0xFF9F, 0x101FD,0x101FD, 0x102E0,0x102E0, 0x10376,0x1037A, 0x10A01,0x10A03, 0x10A05,0x10A06, 0x10A0C,0x10A0F, 0x10A38,0x10A3A, 0x10A3F,0x10A3F, 0x10AE5,0x10AE6, 0x10D24,0x10D27, 0x10F46,0x10F50, 0x11001,0x11001, 0x11038,0x11046, 0x1107F,0x11081, 0x110B3,0x110B6, 0x110B9,0x110BA, 0x11100,0x11102, 0x11127,0x1112B, 0x1112D,0x11134, 0x11173,0x11173, 0x11180,0x11181, 0x111B6,0x111BE, 0x111C9,0x111CC, 0x1122F,0x11231, 0x11234,0x11234, 0x11236,0x11237, 0x1123E,0x1123E, 0x112DF,0x112DF, 0x112E3,0x112EA, 0x11300,0x11301, 0x1133B,0x1133C, 0x1133E,0x1133E, 0x11340,0x11340, 0x11357,0x11357, 0x11366,0x1136C, 0x11370,0x11374, 0x11438,0x1143F, 0x11442,0x11444, 0x11446,0x11446, 0x1145E,0x1145E, 0x114B0,0x114B0, 0x114B3,0x114B8, 0x114BA,0x114BA, 0x114BD,0x114BD, 0x114BF,0x114C0, 0x114C2,0x114C3, 0x115AF,0x115AF, 0x115B2,0x115B5, 0x115BC,0x115BD, 0x115BF,0x115C0, 0x115DC,0x115DD, 0x11633,0x1163A, 0x1163D,0x1163D, 0x1163F,0x11640, 0x116AB,0x116AB, 0x116AD,0x116AD, 0x116B0,0x116B5, 0x116B7,0x116B7, 0x1171D,0x1171F, 0x11722,0x11725, 0x11727,0x1172B, 0x1182F,0x11837, 0x11839,0x1183A, 0x119D4,0x119D7, 0x119DA,0x119DB, 0x119E0,0x119E0, 0x11A01,0x11A0A, 0x11A33,0x11A38, 0x11A3B,0x11A3E, 0x11A47,0x11A47, 0x11A51,0x11A56, 0x11A59,0x11A5B, 0x11A8A,0x11A96, 0x11A98,0x11A99, 0x11C30,0x11C36, 0x11C38,0x11C3D, 0x11C3F,0x11C3F, 0x11C92,0x11CA7, 0x11CAA,0x11CB0, 0x11CB2,0x11CB3, 0x11CB5,0x11CB6, 0x11D31,0x11D36, 0x11D3A,0x11D3A, 0x11D3C,0x11D3D, 0x11D3F,0x11D45, 0x11D47,0x11D47, 0x11D90,0x11D91, 0x11D95,0x11D95, 0x11D97,0x11D97, 0x11EF3,0x11EF4, 0x16AF0,0x16AF4, 0x16B30,0x16B36, 0x16F4F,0x16F4F, 0x16F8F,0x16F92, 0x1BC9D,0x1BC9E, 0x1D165,0x1D165, 0x1D167,0x1D169, 0x1D16E,0x1D172, 0x1D17B,0x1D182, 0x1D185,0x1D18B, 0x1D1AA,0x1D1AD, 0x1D242,0x1D244, 0x1DA00,0x1DA36, 0x1DA3B,0x1DA6C, 0x1DA75,0x1DA75, 0x1DA84,0x1DA84, 0x1DA9B,0x1DA9F, 0x1DAA1,0x1DAAF, 0x1E000,0x1E006, 0x1E008,0x1E018, 0x1E01B,0x1E021, 0x1E023,0x1E024, 0x1E026,0x1E02A, 0x1E130,0x1E136, 0x1E2EC,0x1E2EF, 0x1E8D0,0x1E8D6, 0x1E944,0x1E94A, 0x1F3FB,0x1F3FF, 0xE0020,0xE007F, 0xE0100,0xE01EF};
const uint32_t gbpSpacingMark[] =
// Generated: curl unicode.org/Public/12.1.0/ucd/auxiliary/GraphemeBreakProperty.txt | grep SpacingMark | cut -d ' ' -f 1 | sed 's/[^.]\{1,\}/0x&/g' | sed 's/\.\./,/' | sed '/,/!s/.*/&,&/' | sed -n 'H;${x;s/\n//;s/\n/, /gp;}' | sed 's/.*/{&};/'
{0x0903,0x0903, 0x093B,0x093B, 0x093E,0x0940, 0x0949,0x094C, 0x094E,0x094F, 0x0982,0x0983, 0x09BF,0x09C0, 0x09C7,0x09C8, 0x09CB,0x09CC, 0x0A03,0x0A03, 0x0A3E,0x0A40, 0x0A83,0x0A83, 0x0ABE,0x0AC0, 0x0AC9,0x0AC9, 0x0ACB,0x0ACC, 0x0B02,0x0B03, 0x0B40,0x0B40, 0x0B47,0x0B48, 0x0B4B,0x0B4C, 0x0BBF,0x0BBF, 0x0BC1,0x0BC2, 0x0BC6,0x0BC8, 0x0BCA,0x0BCC, 0x0C01,0x0C03, 0x0C41,0x0C44, 0x0C82,0x0C83, 0x0CBE,0x0CBE, 0x0CC0,0x0CC1, 0x0CC3,0x0CC4, 0x0CC7,0x0CC8, 0x0CCA,0x0CCB, 0x0D02,0x0D03, 0x0D3F,0x0D40, 0x0D46,0x0D48, 0x0D4A,0x0D4C, 0x0D82,0x0D83, 0x0DD0,0x0DD1, 0x0DD8,0x0DDE, 0x0DF2,0x0DF3, 0x0E33,0x0E33, 0x0EB3,0x0EB3, 0x0F3E,0x0F3F, 0x0F7F,0x0F7F, 0x1031,0x1031, 0x103B,0x103C, 0x1056,0x1057, 0x1084,0x1084, 0x17B6,0x17B6, 0x17BE,0x17C5, 0x17C7,0x17C8, 0x1923,0x1926, 0x1929,0x192B, 0x1930,0x1931, 0x1933,0x1938, 0x1A19,0x1A1A, 0x1A55,0x1A55, 0x1A57,0x1A57, 0x1A6D,0x1A72, 0x1B04,0x1B04, 0x1B3B,0x1B3B, 0x1B3D,0x1B41, 0x1B43,0x1B44, 0x1B82,0x1B82, 0x1BA1,0x1BA1, 0x1BA6,0x1BA7, 0x1BAA,0x1BAA, 0x1BE7,0x1BE7, 0x1BEA,0x1BEC, 0x1BEE,0x1BEE, 0x1BF2,0x1BF3, 0x1C24,0x1C2B, 0x1C34,0x1C35, 0x1CE1,0x1CE1, 0x1CF7,0x1CF7, 0xA823,0xA824, 0xA827,0xA827, 0xA880,0xA881, 0xA8B4,0xA8C3, 0xA952,0xA953, 0xA983,0xA983, 0xA9B4,0xA9B5, 0xA9BA,0xA9BB, 0xA9BE,0xA9C0, 0xAA2F,0xAA30, 0xAA33,0xAA34, 0xAA4D,0xAA4D, 0xAAEB,0xAAEB, 0xAAEE,0xAAEF, 0xAAF5,0xAAF5, 0xABE3,0xABE4, 0xABE6,0xABE7, 0xABE9,0xABEA, 0xABEC,0xABEC, 0x11000,0x11000, 0x11002,0x11002, 0x11082,0x11082, 0x110B0,0x110B2, 0x110B7,0x110B8, 0x1112C,0x1112C, 0x11145,0x11146, 0x11182,0x11182, 0x111B3,0x111B5, 0x111BF,0x111C0, 0x1122C,0x1122E, 0x11232,0x11233, 0x11235,0x11235, 0x112E0,0x112E2, 0x11302,0x11303, 0x1133F,0x1133F, 0x11341,0x11344, 0x11347,0x11348, 0x1134B,0x1134D, 0x11362,0x11363, 0x11435,0x11437, 0x11440,0x11441, 0x11445,0x11445, 0x114B1,0x114B2, 0x114B9,0x114B9, 0x114BB,0x114BC, 0x114BE,0x114BE, 0x114C1,0x114C1, 0x115B0,0x115B1, 0x115B8,0x115BB, 0x115BE,0x115BE, 0x11630,0x11632, 0x1163B,0x1163C, 0x1163E,0x1163E, 0x116AC,0x116AC, 0x116AE,0x116AF, 0x116B6,0x116B6, 0x11720,0x11721, 0x11726,0x11726, 0x1182C,0x1182E, 0x11838,0x11838, 0x119D1,0x119D3, 0x119DC,0x119DF, 0x119E4,0x119E4, 0x11A39,0x11A39, 0x11A57,0x11A58, 0x11A97,0x11A97, 0x11C2F,0x11C2F, 0x11C3E,0x11C3E, 0x11CA9,0x11CA9, 0x11CB1,0x11CB1, 0x11CB4,0x11CB4, 0x11D8A,0x11D8E, 0x11D93,0x11D94, 0x11D96,0x11D96, 0x11EF5,0x11EF6, 0x16F51,0x16F87, 0x1D166,0x1D166, 0x1D16D,0x1D16D};
const uint32_t gbpL[] =
// Generated: curl unicode.org/Public/12.1.0/ucd/auxiliary/GraphemeBreakProperty.txt | grep '; L ' | cut -d ' ' -f 1 | sed 's/[^.]\{1,\}/0x&/g' | sed 's/\.\./,/' | sed '/,/!s/.*/&,&/' | sed -n 'H;${x;s/\n//;s/\n/, /gp;}' | sed 's/.*/{&};/'
{0x1100,0x115F, 0xA960,0xA97C};
const uint32_t gbpV[] =
// Generated: curl unicode.org/Public/12.1.0/ucd/auxiliary/GraphemeBreakProperty.txt | grep '; V ' | cut -d ' ' -f 1 | sed 's/[^.]\{1,\}/0x&/g' | sed 's/\.\./,/' | sed '/,/!s/.*/&,&/' | sed -n 'H;${x;s/\n//;s/\n/, /gp;}' | sed 's/.*/{&};/'
{0x1160,0x11A7, 0xD7B0,0xD7C6};
const uint32_t gbpT[] =
// Generated: curl unicode.org/Public/12.1.0/ucd/auxiliary/GraphemeBreakProperty.txt | grep '; T ' | cut -d ' ' -f 1 | sed 's/[^.]\{1,\}/0x&/g' | sed 's/\.\./,/' | sed '/,/!s/.*/&,&/' | sed -n 'H;${x;s/\n//;s/\n/, /gp;}' | sed 's/.*/{&};/'
{0x11A8,0x11FF, 0xD7CB,0xD7FB};
const uint32_t gbpLV[] =
// Generated: curl unicode.org/Public/12.1.0/ucd/auxiliary/GraphemeBreakProperty.txt | grep '; LV ' | cut -d ' ' -f 1 | sed 's/[^.]\{1,\}/0x&/g' | sed 's/\.\./,/' | sed '/,/!s/.*/&,&/' | sed -n 'H;${x;s/\n//;s/\n/, /gp;}' | sed 's/.*/{&};/'
{0xAC00,0xAC00, 0xAC1C,0xAC1C, 0xAC38,0xAC38, 0xAC54,0xAC54, 0xAC70,0xAC70, 0xAC8C,0xAC8C, 0xACA8,0xACA8, 0xACC4,0xACC4, 0xACE0,0xACE0, 0xACFC,0xACFC, 0xAD18,0xAD18, 0xAD34,0xAD34, 0xAD50,0xAD50, 0xAD6C,0xAD6C, 0xAD88,0xAD88, 0xADA4,0xADA4, 0xADC0,0xADC0, 0xADDC,0xADDC, 0xADF8,0xADF8, 0xAE14,0xAE14, 0xAE30,0xAE30, 0xAE4C,0xAE4C, 0xAE68,0xAE68, 0xAE84,0xAE84, 0xAEA0,0xAEA0, 0xAEBC,0xAEBC, 0xAED8,0xAED8, 0xAEF4,0xAEF4, 0xAF10,0xAF10, 0xAF2C,0xAF2C, 0xAF48,0xAF48, 0xAF64,0xAF64, 0xAF80,0xAF80, 0xAF9C,0xAF9C, 0xAFB8,0xAFB8, 0xAFD4,0xAFD4, 0xAFF0,0xAFF0, 0xB00C,0xB00C, 0xB028,0xB028, 0xB044,0xB044, 0xB060,0xB060, 0xB07C,0xB07C, 0xB098,0xB098, 0xB0B4,0xB0B4, 0xB0D0,0xB0D0, 0xB0EC,0xB0EC, 0xB108,0xB108, 0xB124,0xB124, 0xB140,0xB140, 0xB15C,0xB15C, 0xB178,0xB178, 0xB194,0xB194, 0xB1B0,0xB1B0, 0xB1CC,0xB1CC, 0xB1E8,0xB1E8, 0xB204,0xB204, 0xB220,0xB220, 0xB23C,0xB23C, 0xB258,0xB258, 0xB274,0xB274, 0xB290,0xB290, 0xB2AC,0xB2AC, 0xB2C8,0xB2C8, 0xB2E4,0xB2E4, 0xB300,0xB300, 0xB31C,0xB31C, 0xB338,0xB338, 0xB354,0xB354, 0xB370,0xB370, 0xB38C,0xB38C, 0xB3A8,0xB3A8, 0xB3C4,0xB3C4, 0xB3E0,0xB3E0, 0xB3FC,0xB3FC, 0xB418,0xB418, 0xB434,0xB434, 0xB450,0xB450, 0xB46C,0xB46C, 0xB488,0xB488, 0xB4A4,0xB4A4, 0xB4C0,0xB4C0, 0xB4DC,0xB4DC, 0xB4F8,0xB4F8, 0xB514,0xB514, 0xB530,0xB530, 0xB54C,0xB54C, 0xB568,0xB568, 0xB584,0xB584, 0xB5A0,0xB5A0, 0xB5BC,0xB5BC, 0xB5D8,0xB5D8, 0xB5F4,0xB5F4, 0xB610,0xB610, 0xB62C,0xB62C, 0xB648,0xB648, 0xB664,0xB664, 0xB680,0xB680, 0xB69C,0xB69C, 0xB6B8,0xB6B8, 0xB6D4,0xB6D4, 0xB6F0,0xB6F0, 0xB70C,0xB70C, 0xB728,0xB728, 0xB744,0xB744, 0xB760,0xB760, 0xB77C,0xB77C, 0xB798,0xB798, 0xB7B4,0xB7B4, 0xB7D0,0xB7D0, 0xB7EC,0xB7EC, 0xB808,0xB808, 0xB824,0xB824, 0xB840,0xB840, 0xB85C,0xB85C, 0xB878,0xB878, 0xB894,0xB894, 0xB8B0,0xB8B0, 0xB8CC,0xB8CC, 0xB8E8,0xB8E8, 0xB904,0xB904, 0xB920,0xB920, 0xB93C,0xB93C, 0xB958,0xB958, 0xB974,0xB974, 0xB990,0xB990, 0xB9AC,0xB9AC, 0xB9C8,0xB9C8, 0xB9E4,0xB9E4, 0xBA00,0xBA00, 0xBA1C,0xBA1C, 0xBA38,0xBA38, 0xBA54,0xBA54, 0xBA70,0xBA70, 0xBA8C,0xBA8C, 0xBAA8,0xBAA8, 0xBAC4,0xBAC4, 0xBAE0,0xBAE0, 0xBAFC,0xBAFC, 0xBB18,0xBB18, 0xBB34,0xBB34, 0xBB50,0xBB50, 0xBB6C,0xBB6C, 0xBB88,0xBB88, 0xBBA4,0xBBA4, 0xBBC0,0xBBC0, 0xBBDC,0xBBDC, 0xBBF8,0xBBF8, 0xBC14,0xBC14, 0xBC30,0xBC30, 0xBC4C,0xBC4C, 0xBC68,0xBC68, 0xBC84,0xBC84, 0xBCA0,0xBCA0, 0xBCBC,0xBCBC, 0xBCD8,0xBCD8, 0xBCF4,0xBCF4, 0xBD10,0xBD10, 0xBD2C,0xBD2C, 0xBD48,0xBD48, 0xBD64,0xBD64, 0xBD80,0xBD80, 0xBD9C,0xBD9C, 0xBDB8,0xBDB8, 0xBDD4,0xBDD4, 0xBDF0,0xBDF0, 0xBE0C,0xBE0C, 0xBE28,0xBE28, 0xBE44,0xBE44, 0xBE60,0xBE60, 0xBE7C,0xBE7C, 0xBE98,0xBE98, 0xBEB4,0xBEB4, 0xBED0,0xBED0, 0xBEEC,0xBEEC, 0xBF08,0xBF08, 0xBF24,0xBF24, 0xBF40,0xBF40, 0xBF5C,0xBF5C, 0xBF78,0xBF78, 0xBF94,0xBF94, 0xBFB0,0xBFB0, 0xBFCC,0xBFCC, 0xBFE8,0xBFE8, 0xC004,0xC004, 0xC020,0xC020, 0xC03C,0xC03C, 0xC058,0xC058, 0xC074,0xC074, 0xC090,0xC090, 0xC0AC,0xC0AC, 0xC0C8,0xC0C8, 0xC0E4,0xC0E4, 0xC100,0xC100, 0xC11C,0xC11C, 0xC138,0xC138, 0xC154,0xC154, 0xC170,0xC170, 0xC18C,0xC18C, 0xC1A8,0xC1A8, 0xC1C4,0xC1C4, 0xC1E0,0xC1E0, 0xC1FC,0xC1FC, 0xC218,0xC218, 0xC234,0xC234, 0xC250,0xC250, 0xC26C,0xC26C, 0xC288,0xC288, 0xC2A4,0xC2A4, 0xC2C0,0xC2C0, 0xC2DC,0xC2DC, 0xC2F8,0xC2F8, 0xC314,0xC314, 0xC330,0xC330, 0xC34C,0xC34C, 0xC368,0xC368, 0xC384,0xC384, 0xC3A0,0xC3A0, 0xC3BC,0xC3BC, 0xC3D8,0xC3D8, 0xC3F4,0xC3F4, 0xC410,0xC410, 0xC42C,0xC42C, 0xC448,0xC448, 0xC464,0xC464, 0xC480,0xC480, 0xC49C,0xC49C, 0xC4B8,0xC4B8, 0xC4D4,0xC4D4, 0xC4F0,0xC4F0, 0xC50C,0xC50C, 0xC528,0xC528, 0xC544,0xC544, 0xC560,0xC560, 0xC57C,0xC57C, 0xC598,0xC598, 0xC5B4,0xC5B4, 0xC5D0,0xC5D0, 0xC5EC,0xC5EC, 0xC608,0xC608, 0xC624,0xC624, 0xC640,0xC640, 0xC65C,0xC65C, 0xC678,0xC678, 0xC694,0xC694, 0xC6B0,0xC6B0, 0xC6CC,0xC6CC, 0xC6E8,0xC6E8, 0xC704,0xC704, 0xC720,0xC720, 0xC73C,0xC73C, 0xC758,0xC758, 0xC774,0xC774, 0xC790,0xC790, 0xC7AC,0xC7AC, 0xC7C8,0xC7C8, 0xC7E4,0xC7E4, 0xC800,0xC800, 0xC81C,0xC81C, 0xC838,0xC838, 0xC854,0xC854, 0xC870,0xC870, 0xC88C,0xC88C, 0xC8A8,0xC8A8, 0xC8C4,0xC8C4, 0xC8E0,0xC8E0, 0xC8FC,0xC8FC, 0xC918,0xC918, 0xC934,0xC934, 0xC950,0xC950, 0xC96C,0xC96C, 0xC988,0xC988, 0xC9A4,0xC9A4, 0xC9C0,0xC9C0, 0xC9DC,0xC9DC, 0xC9F8,0xC9F8, 0xCA14,0xCA14, 0xCA30,0xCA30, 0xCA4C,0xCA4C, 0xCA68,0xCA68, 0xCA84,0xCA84, 0xCAA0,0xCAA0, 0xCABC,0xCABC, 0xCAD8,0xCAD8, 0xCAF4,0xCAF4, 0xCB10,0xCB10, 0xCB2C,0xCB2C, 0xCB48,0xCB48, 0xCB64,0xCB64, 0xCB80,0xCB80, 0xCB9C,0xCB9C, 0xCBB8,0xCBB8, 0xCBD4,0xCBD4, 0xCBF0,0xCBF0, 0xCC0C,0xCC0C, 0xCC28,0xCC28, 0xCC44,0xCC44, 0xCC60,0xCC60, 0xCC7C,0xCC7C, 0xCC98,0xCC98, 0xCCB4,0xCCB4, 0xCCD0,0xCCD0, 0xCCEC,0xCCEC, 0xCD08,0xCD08, 0xCD24,0xCD24, 0xCD40,0xCD40, 0xCD5C,0xCD5C, 0xCD78,0xCD78, 0xCD94,0xCD94, 0xCDB0,0xCDB0, 0xCDCC,0xCDCC, 0xCDE8,0xCDE8, 0xCE04,0xCE04, 0xCE20,0xCE20, 0xCE3C,0xCE3C, 0xCE58,0xCE58, 0xCE74,0xCE74, 0xCE90,0xCE90, 0xCEAC,0xCEAC, 0xCEC8,0xCEC8, 0xCEE4,0xCEE4, 0xCF00,0xCF00, 0xCF1C,0xCF1C, 0xCF38,0xCF38, 0xCF54,0xCF54, 0xCF70,0xCF70, 0xCF8C,0xCF8C, 0xCFA8,0xCFA8, 0xCFC4,0xCFC4, 0xCFE0,0xCFE0, 0xCFFC,0xCFFC, 0xD018,0xD018, 0xD034,0xD034, 0xD050,0xD050, 0xD06C,0xD06C, 0xD088,0xD088, 0xD0A4,0xD0A4, 0xD0C0,0xD0C0, 0xD0DC,0xD0DC, 0xD0F8,0xD0F8, 0xD114,0xD114, 0xD130,0xD130, 0xD14C,0xD14C, 0xD168,0xD168, 0xD184,0xD184, 0xD1A0,0xD1A0, 0xD1BC,0xD1BC, 0xD1D8,0xD1D8, 0xD1F4,0xD1F4, 0xD210,0xD210, 0xD22C,0xD22C, 0xD248,0xD248, 0xD264,0xD264, 0xD280,0xD280, 0xD29C,0xD29C, 0xD2B8,0xD2B8, 0xD2D4,0xD2D4, 0xD2F0,0xD2F0, 0xD30C,0xD30C, 0xD328,0xD328, 0xD344,0xD344, 0xD360,0xD360, 0xD37C,0xD37C, 0xD398,0xD398, 0xD3B4,0xD3B4, 0xD3D0,0xD3D0, 0xD3EC,0xD3EC, 0xD408,0xD408, 0xD424,0xD424, 0xD440,0xD440, 0xD45C,0xD45C, 0xD478,0xD478, 0xD494,0xD494, 0xD4B0,0xD4B0, 0xD4CC,0xD4CC, 0xD4E8,0xD4E8, 0xD504,0xD504, 0xD520,0xD520, 0xD53C,0xD53C, 0xD558,0xD558, 0xD574,0xD574, 0xD590,0xD590, 0xD5AC,0xD5AC, 0xD5C8,0xD5C8, 0xD5E4,0xD5E4, 0xD600,0xD600, 0xD61C,0xD61C, 0xD638,0xD638, 0xD654,0xD654, 0xD670,0xD670, 0xD68C,0xD68C, 0xD6A8,0xD6A8, 0xD6C4,0xD6C4, 0xD6E0,0xD6E0, 0xD6FC,0xD6FC, 0xD718,0xD718, 0xD734,0xD734, 0xD750,0xD750, 0xD76C,0xD76C, 0xD788,0xD788};
const uint32_t gbpLVT[] =
// Generated: curl unicode.org/Public/12.1.0/ucd/auxiliary/GraphemeBreakProperty.txt | grep '; LVT ' | cut -d ' ' -f 1 | sed 's/[^.]\{1,\}/0x&/g' | sed 's/\.\./,/' | sed '/,/!s/.*/&,&/' | sed -n 'H;${x;s/\n//;s/\n/, /gp;}' | sed 's/.*/{&};/'
{0xAC01,0xAC1B, 0xAC1D,0xAC37, 0xAC39,0xAC53, 0xAC55,0xAC6F, 0xAC71,0xAC8B, 0xAC8D,0xACA7, 0xACA9,0xACC3, 0xACC5,0xACDF, 0xACE1,0xACFB, 0xACFD,0xAD17, 0xAD19,0xAD33, 0xAD35,0xAD4F, 0xAD51,0xAD6B, 0xAD6D,0xAD87, 0xAD89,0xADA3, 0xADA5,0xADBF, 0xADC1,0xADDB, 0xADDD,0xADF7, 0xADF9,0xAE13, 0xAE15,0xAE2F, 0xAE31,0xAE4B, 0xAE4D,0xAE67, 0xAE69,0xAE83, 0xAE85,0xAE9F, 0xAEA1,0xAEBB, 0xAEBD,0xAED7, 0xAED9,0xAEF3, 0xAEF5,0xAF0F, 0xAF11,0xAF2B, 0xAF2D,0xAF47, 0xAF49,0xAF63, 0xAF65,0xAF7F, 0xAF81,0xAF9B, 0xAF9D,0xAFB7, 0xAFB9,0xAFD3, 0xAFD5,0xAFEF, 0xAFF1,0xB00B, 0xB00D,0xB027, 0xB029,0xB043, 0xB045,0xB05F, 0xB061,0xB07B, 0xB07D,0xB097, 0xB099,0xB0B3, 0xB0B5,0xB0CF, 0xB0D1,0xB0EB, 0xB0ED,0xB107, 0xB109,0xB123, 0xB125,0xB13F, 0xB141,0xB15B, 0xB15D,0xB177, 0xB179,0xB193, 0xB195,0xB1AF, 0xB1B1,0xB1CB, 0xB1CD,0xB1E7, 0xB1E9,0xB203, 0xB205,0xB21F, 0xB221,0xB23B, 0xB23D,0xB257, 0xB259,0xB273, 0xB275,0xB28F, 0xB291,0xB2AB, 0xB2AD,0xB2C7, 0xB2C9,0xB2E3, 0xB2E5,0xB2FF, 0xB301,0xB31B, 0xB31D,0xB337, 0xB339,0xB353, 0xB355,0xB36F, 0xB371,0xB38B, 0xB38D,0xB3A7, 0xB3A9,0xB3C3, 0xB3C5,0xB3DF, 0xB3E1,0xB3FB, 0xB3FD,0xB417, 0xB419,0xB433, 0xB435,0xB44F, 0xB451,0xB46B, 0xB46D,0xB487, 0xB489,0xB4A3, 0xB4A5,0xB4BF, 0xB4C1,0xB4DB, 0xB4DD,0xB4F7, 0xB4F9,0xB513, 0xB515,0xB52F, 0xB531,0xB54B, 0xB54D,0xB567, 0xB569,0xB583, 0xB585,0xB59F, 0xB5A1,0xB5BB, 0xB5BD,0xB5D7, 0xB5D9,0xB5F3, 0xB5F5,0xB60F, 0xB611,0xB62B, 0xB62D,0xB647, 0xB649,0xB663, 0xB665,0xB67F, 0xB681,0xB69B, 0xB69D,0xB6B7, 0xB6B9,0xB6D3, 0xB6D5,0xB6EF, 0xB6F1,0xB70B, 0xB70D,0xB727, 0xB729,0xB743, 0xB745,0xB75F, 0xB761,0xB77B, 0xB77D,0xB797, 0xB799,0xB7B3, 0xB7B5,0xB7CF, 0xB7D1,0xB7EB, 0xB7ED,0xB807, 0xB809,0xB823, 0xB825,0xB83F, 0xB841,0xB85B, 0xB85D,0xB877, 0xB879,0xB893, 0xB895,0xB8AF, 0xB8B1,0xB8CB, 0xB8CD,0xB8E7, 0xB8E9,0xB903, 0xB905,0xB91F, 0xB921,0xB93B, 0xB93D,0xB957, 0xB959,0xB973, 0xB975,0xB98F, 0xB991,0xB9AB, 0xB9AD,0xB9C7, 0xB9C9,0xB9E3, 0xB9E5,0xB9FF, 0xBA01,0xBA1B, 0xBA1D,0xBA37, 0xBA39,0xBA53, 0xBA55,0xBA6F, 0xBA71,0xBA8B, 0xBA8D,0xBAA7, 0xBAA9,0xBAC3, 0xBAC5,0xBADF, 0xBAE1,0xBAFB, 0xBAFD,0xBB17, 0xBB19,0xBB33, 0xBB35,0xBB4F, 0xBB51,0xBB6B, 0xBB6D,0xBB87, 0xBB89,0xBBA3, 0xBBA5,0xBBBF, 0xBBC1,0xBBDB, 0xBBDD,0xBBF7, 0xBBF9,0xBC13, 0xBC15,0xBC2F, 0xBC31,0xBC4B, 0xBC4D,0xBC67, 0xBC69,0xBC83, 0xBC85,0xBC9F, 0xBCA1,0xBCBB, 0xBCBD,0xBCD7, 0xBCD9,0xBCF3, 0xBCF5,0xBD0F, 0xBD11,0xBD2B, 0xBD2D,0xBD47, 0xBD49,0xBD63, 0xBD65,0xBD7F, 0xBD81,0xBD9B, 0xBD9D,0xBDB7, 0xBDB9,0xBDD3, 0xBDD5,0xBDEF, 0xBDF1,0xBE0B, 0xBE0D,0xBE27, 0xBE29,0xBE43, 0xBE45,0xBE5F, 0xBE61,0xBE7B, 0xBE7D,0xBE97, 0xBE99,0xBEB3, 0xBEB5,0xBECF, 0xBED1,0xBEEB, 0xBEED,0xBF07, 0xBF09,0xBF23, 0xBF25,0xBF3F, 0xBF41,0xBF5B, 0xBF5D,0xBF77, 0xBF79,0xBF93, 0xBF95,0xBFAF, 0xBFB1,0xBFCB, 0xBFCD,0xBFE7, 0xBFE9,0xC003, 0xC005,0xC01F, 0xC021,0xC03B, 0xC03D,0xC057, 0xC059,0xC073, 0xC075,0xC08F, 0xC091,0xC0AB, 0xC0AD,0xC0C7, 0xC0C9,0xC0E3, 0xC0E5,0xC0FF, 0xC101,0xC11B, 0xC11D,0xC137, 0xC139,0xC153, 0xC155,0xC16F, 0xC171,0xC18B, 0xC18D,0xC1A7, 0xC1A9,0xC1C3, 0xC1C5,0xC1DF, 0xC1E1,0xC1FB, 0xC1FD,0xC217, 0xC219,0xC233, 0xC235,0xC24F, 0xC251,0xC26B, 0xC26D,0xC287, 0xC289,0xC2A3, 0xC2A5,0xC2BF, 0xC2C1,0xC2DB, 0xC2DD,0xC2F7, 0xC2F9,0xC313, 0xC315,0xC32F, 0xC331,0xC34B, 0xC34D,0xC367, 0xC369,0xC383, 0xC385,0xC39F, 0xC3A1,0xC3BB, 0xC3BD,0xC3D7, 0xC3D9,0xC3F3, 0xC3F5,0xC40F, 0xC411,0xC42B, 0xC42D,0xC447, 0xC449,0xC463, 0xC465,0xC47F, 0xC481,0xC49B, 0xC49D,0xC4B7, 0xC4B9,0xC4D3, 0xC4D5,0xC4EF, 0xC4F1,0xC50B, 0xC50D,0xC527, 0xC529,0xC543, 0xC545,0xC55F, 0xC561,0xC57B, 0xC57D,0xC597, 0xC599,0xC5B3, 0xC5B5,0xC5CF, 0xC5D1,0xC5EB, 0xC5ED,0xC607, 0xC609,0xC623, 0xC625,0xC63F, 0xC641,0xC65B, 0xC65D,0xC677, 0xC679,0xC693, 0xC695,0xC6AF, 0xC6B1,0xC6CB, 0xC6CD,0xC6E7, 0xC6E9,0xC703, 0xC705,0xC71F, 0xC721,0xC73B, 0xC73D,0xC757, 0xC759,0xC773, 0xC775,0xC78F, 0xC791,0xC7AB, 0xC7AD,0xC7C7, 0xC7C9,0xC7E3, 0xC7E5,0xC7FF, 0xC801,0xC81B, 0xC81D,0xC837, 0xC839,0xC853, 0xC855,0xC86F, 0xC871,0xC88B, 0xC88D,0xC8A7, 0xC8A9,0xC8C3, 0xC8C5,0xC8DF, 0xC8E1,0xC8FB, 0xC8FD,0xC917, 0xC919,0xC933, 0xC935,0xC94F, 0xC951,0xC96B, 0xC96D,0xC987, 0xC989,0xC9A3, 0xC9A5,0xC9BF, 0xC9C1,0xC9DB, 0xC9DD,0xC9F7, 0xC9F9,0xCA13, 0xCA15,0xCA2F, 0xCA31,0xCA4B, 0xCA4D,0xCA67, 0xCA69,0xCA83, 0xCA85,0xCA9F, 0xCAA1,0xCABB, 0xCABD,0xCAD7, 0xCAD9,0xCAF3, 0xCAF5,0xCB0F, 0xCB11,0xCB2B, 0xCB2D,0xCB47, 0xCB49,0xCB63, 0xCB65,0xCB7F, 0xCB81,0xCB9B, 0xCB9D,0xCBB7, 0xCBB9,0xCBD3, 0xCBD5,0xCBEF, 0xCBF1,0xCC0B, 0xCC0D,0xCC27, 0xCC29,0xCC43, 0xCC45,0xCC5F, 0xCC61,0xCC7B, 0xCC7D,0xCC97, 0xCC99,0xCCB3, 0xCCB5,0xCCCF, 0xCCD1,0xCCEB, 0xCCED,0xCD07, 0xCD09,0xCD23, 0xCD25,0xCD3F, 0xCD41,0xCD5B, 0xCD5D,0xCD77, 0xCD79,0xCD93, 0xCD95,0xCDAF, 0xCDB1,0xCDCB, 0xCDCD,0xCDE7, 0xCDE9,0xCE03, 0xCE05,0xCE1F, 0xCE21,0xCE3B, 0xCE3D,0xCE57, 0xCE59,0xCE73, 0xCE75,0xCE8F, 0xCE91,0xCEAB, 0xCEAD,0xCEC7, 0xCEC9,0xCEE3, 0xCEE5,0xCEFF, 0xCF01,0xCF1B, 0xCF1D,0xCF37, 0xCF39,0xCF53, 0xCF55,0xCF6F, 0xCF71,0xCF8B, 0xCF8D,0xCFA7, 0xCFA9,0xCFC3, 0xCFC5,0xCFDF, 0xCFE1,0xCFFB, 0xCFFD,0xD017, 0xD019,0xD033, 0xD035,0xD04F, 0xD051,0xD06B, 0xD06D,0xD087, 0xD089,0xD0A3, 0xD0A5,0xD0BF, 0xD0C1,0xD0DB, 0xD0DD,0xD0F7, 0xD0F9,0xD113, 0xD115,0xD12F, 0xD131,0xD14B, 0xD14D,0xD167, 0xD169,0xD183, 0xD185,0xD19F, 0xD1A1,0xD1BB, 0xD1BD,0xD1D7, 0xD1D9,0xD1F3, 0xD1F5,0xD20F, 0xD211,0xD22B, 0xD22D,0xD247, 0xD249,0xD263, 0xD265,0xD27F, 0xD281,0xD29B, 0xD29D,0xD2B7, 0xD2B9,0xD2D3, 0xD2D5,0xD2EF, 0xD2F1,0xD30B, 0xD30D,0xD327, 0xD329,0xD343, 0xD345,0xD35F, 0xD361,0xD37B, 0xD37D,0xD397, 0xD399,0xD3B3, 0xD3B5,0xD3CF, 0xD3D1,0xD3EB, 0xD3ED,0xD407, 0xD409,0xD423, 0xD425,0xD43F, 0xD441,0xD45B, 0xD45D,0xD477, 0xD479,0xD493, 0xD495,0xD4AF, 0xD4B1,0xD4CB, 0xD4CD,0xD4E7, 0xD4E9,0xD503, 0xD505,0xD51F, 0xD521,0xD53B, 0xD53D,0xD557, 0xD559,0xD573, 0xD575,0xD58F, 0xD591,0xD5AB, 0xD5AD,0xD5C7, 0xD5C9,0xD5E3, 0xD5E5,0xD5FF, 0xD601,0xD61B, 0xD61D,0xD637, 0xD639,0xD653, 0xD655,0xD66F, 0xD671,0xD68B, 0xD68D,0xD6A7, 0xD6A9,0xD6C3, 0xD6C5,0xD6DF, 0xD6E1,0xD6FB, 0xD6FD,0xD717, 0xD719,0xD733, 0xD735,0xD74F, 0xD751,0xD76B, 0xD76D,0xD787, 0xD789,0xD7A3};
const uint32_t ZlZpCcCfCsCoCn[] =
// Generated: curl unicode.org/Public/12.1.0/ucd/extracted/DerivedGeneralCategory.txt | grep "$(printf 'Zl\nZp\nCc\nCf\nCs\n; Co\nCn')" | cut -d ' ' -f1 | tr -d ';' | awk -F '[.][.]' '{printf("0x%6s,0x%s\n",$1,$2?$2:$1)}' | tr ' ' 0 | sort | sed -n 'H;${x;s/\n//;s/\n/, /gp;}' | sed 's/.*/{&};/'
{0x000000,0x001F, 0x00007F,0x009F, 0x0000AD,0x00AD, 0x000378,0x0379, 0x000380,0x0383, 0x00038B,0x038B, 0x00038D,0x038D, 0x0003A2,0x03A2, 0x000530,0x0530, 0x000557,0x0558, 0x00058B,0x058C, 0x000590,0x0590, 0x0005C8,0x05CF, 0x0005EB,0x05EE, 0x0005F5,0x05FF, 0x000600,0x0605, 0x00061C,0x061C, 0x00061D,0x061D, 0x0006DD,0x06DD, 0x00070E,0x070E, 0x00070F,0x070F, 0x00074B,0x074C, 0x0007B2,0x07BF, 0x0007FB,0x07FC, 0x00082E,0x082F, 0x00083F,0x083F, 0x00085C,0x085D, 0x00085F,0x085F, 0x00086B,0x089F, 0x0008B5,0x08B5, 0x0008BE,0x08D2, 0x0008E2,0x08E2, 0x000984,0x0984, 0x00098D,0x098E, 0x000991,0x0992, 0x0009A9,0x09A9, 0x0009B1,0x09B1, 0x0009B3,0x09B5, 0x0009BA,0x09BB, 0x0009C5,0x09C6, 0x0009C9,0x09CA, 0x0009CF,0x09D6, 0x0009D8,0x09DB, 0x0009DE,0x09DE, 0x0009E4,0x09E5, 0x0009FF,0x0A00, 0x000A04,0x0A04, 0x000A0B,0x0A0E, 0x000A11,0x0A12, 0x000A29,0x0A29, 0x000A31,0x0A31, 0x000A34,0x0A34, 0x000A37,0x0A37, 0x000A3A,0x0A3B, 0x000A3D,0x0A3D, 0x000A43,0x0A46, 0x000A49,0x0A4A, 0x000A4E,0x0A50, 0x000A52,0x0A58, 0x000A5D,0x0A5D, 0x000A5F,0x0A65, 0x000A77,0x0A80, 0x000A84,0x0A84, 0x000A8E,0x0A8E, 0x000A92,0x0A92, 0x000AA9,0x0AA9, 0x000AB1,0x0AB1, 0x000AB4,0x0AB4, 0x000ABA,0x0ABB, 0x000AC6,0x0AC6, 0x000ACA,0x0ACA, 0x000ACE,0x0ACF, 0x000AD1,0x0ADF, 0x000AE4,0x0AE5, 0x000AF2,0x0AF8, 0x000B00,0x0B00, 0x000B04,0x0B04, 0x000B0D,0x0B0E, 0x000B11,0x0B12, 0x000B29,0x0B29, 0x000B31,0x0B31, 0x000B34,0x0B34, 0x000B3A,0x0B3B, 0x000B45,0x0B46, 0x000B49,0x0B4A, 0x000B4E,0x0B55, 0x000B58,0x0B5B, 0x000B5E,0x0B5E, 0x000B64,0x0B65, 0x000B78,0x0B81, 0x000B84,0x0B84, 0x000B8B,0x0B8D, 0x000B91,0x0B91, 0x000B96,0x0B98, 0x000B9B,0x0B9B, 0x000B9D,0x0B9D, 0x000BA0,0x0BA2, 0x000BA5,0x0BA7, 0x000BAB,0x0BAD, 0x000BBA,0x0BBD, 0x000BC3,0x0BC5, 0x000BC9,0x0BC9, 0x000BCE,0x0BCF, 0x000BD1,0x0BD6, 0x000BD8,0x0BE5, 0x000BFB,0x0BFF, 0x000C0D,0x0C0D, 0x000C11,0x0C11, 0x000C29,0x0C29, 0x000C3A,0x0C3C, 0x000C45,0x0C45, 0x000C49,0x0C49, 0x000C4E,0x0C54, 0x000C57,0x0C57, 0x000C5B,0x0C5F, 0x000C64,0x0C65, 0x000C70,0x0C76, 0x000C8D,0x0C8D, 0x000C91,0x0C91, 0x000CA9,0x0CA9, 0x000CB4,0x0CB4, 0x000CBA,0x0CBB, 0x000CC5,0x0CC5, 0x000CC9,0x0CC9, 0x000CCE,0x0CD4, 0x000CD7,0x0CDD, 0x000CDF,0x0CDF, 0x000CE4,0x0CE5, 0x000CF0,0x0CF0, 0x000CF3,0x0CFF, 0x000D04,0x0D04, 0x000D0D,0x0D0D, 0x000D11,0x0D11, 0x000D45,0x0D45, 0x000D49,0x0D49, 0x000D50,0x0D53, 0x000D64,0x0D65, 0x000D80,0x0D81, 0x000D84,0x0D84, 0x000D97,0x0D99, 0x000DB2,0x0DB2, 0x000DBC,0x0DBC, 0x000DBE,0x0DBF, 0x000DC7,0x0DC9, 0x000DCB,0x0DCE, 0x000DD5,0x0DD5, 0x000DD7,0x0DD7, 0x000DE0,0x0DE5, 0x000DF0,0x0DF1, 0x000DF5,0x0DF5, 0x000E3B,0x0E3E, 0x000E5C,0x0E5C, 0x000E83,0x0E83, 0x000E85,0x0E85, 0x000E8B,0x0E8B, 0x000EA4,0x0EA4, 0x000EA6,0x0EA6, 0x000EBE,0x0EBF, 0x000EC5,0x0EC5, 0x000EC7,0x0EC7, 0x000ECE,0x0ECF, 0x000EDA,0x0EDB, 0x000EE0,0x0EFF, 0x000F48,0x0F48, 0x000F6D,0x0F70, 0x000F98,0x0F98, 0x000FBD,0x0FBD, 0x000FCD,0x0FCD, 0x000FDB,0x0FFF, 0x0010C6,0x10C6, 0x0010C8,0x10CC, 0x0010CE,0x10CF, 0x001249,0x1249, 0x00124E,0x124F, 0x001257,0x1257, 0x001259,0x1259, 0x00125E,0x125F, 0x001289,0x1289, 0x00128E,0x128F, 0x0012B1,0x12B1, 0x0012B6,0x12B7, 0x0012BF,0x12BF, 0x0012C1,0x12C1, 0x0012C6,0x12C7, 0x0012D7,0x12D7, 0x001311,0x1311, 0x001316,0x1317, 0x00135B,0x135C, 0x00137D,0x137F, 0x00139A,0x139F, 0x0013F6,0x13F7, 0x0013FE,0x13FF, 0x00169D,0x169F, 0x0016F9,0x16FF, 0x00170D,0x170D, 0x001715,0x171F, 0x001737,0x173F, 0x001754,0x175F, 0x00176D,0x176D, 0x001771,0x1771, 0x001774,0x177F, 0x0017DE,0x17DF, 0x0017EA,0x17EF, 0x0017FA,0x17FF, 0x00180E,0x180E, 0x00180F,0x180F, 0x00181A,0x181F, 0x001879,0x187F, 0x0018AB,0x18AF, 0x0018F6,0x18FF, 0x00191F,0x191F, 0x00192C,0x192F, 0x00193C,0x193F, 0x001941,0x1943, 0x00196E,0x196F, 0x001975,0x197F, 0x0019AC,0x19AF, 0x0019CA,0x19CF, 0x0019DB,0x19DD, 0x001A1C,0x1A1D, 0x001A5F,0x1A5F, 0x001A7D,0x1A7E, 0x001A8A,0x1A8F, 0x001A9A,0x1A9F, 0x001AAE,0x1AAF, 0x001ABF,0x1AFF, 0x001B4C,0x1B4F, 0x001B7D,0x1B7F, 0x001BF4,0x1BFB, 0x001C38,0x1C3A, 0x001C4A,0x1C4C, 0x001C89,0x1C8F, 0x001CBB,0x1CBC, 0x001CC8,0x1CCF, 0x001CFB,0x1CFF, 0x001DFA,0x1DFA, 0x001F16,0x1F17, 0x001F1E,0x1F1F, 0x001F46,0x1F47, 0x001F4E,0x1F4F, 0x001F58,0x1F58, 0x001F5A,0x1F5A, 0x001F5C,0x1F5C, 0x001F5E,0x1F5E, 0x001F7E,0x1F7F, 0x001FB5,0x1FB5, 0x001FC5,0x1FC5, 0x001FD4,0x1FD5, 0x001FDC,0x1FDC, 0x001FF0,0x1FF1, 0x001FF5,0x1FF5, 0x001FFF,0x1FFF, 0x00200B,0x200F, 0x002028,0x2028, 0x002029,0x2029, 0x00202A,0x202E, 0x002060,0x2064, 0x002065,0x2065, 0x002066,0x206F, 0x002072,0x2073, 0x00208F,0x208F, 0x00209D,0x209F, 0x0020C0,0x20CF, 0x0020F1,0x20FF, 0x00218C,0x218F, 0x002427,0x243F, 0x00244B,0x245F, 0x002B74,0x2B75, 0x002B96,0x2B97, 0x002C2F,0x2C2F, 0x002C5F,0x2C5F, 0x002CF4,0x2CF8, 0x002D26,0x2D26, 0x002D28,0x2D2C, 0x002D2E,0x2D2F, 0x002D68,0x2D6E, 0x002D71,0x2D7E, 0x002D97,0x2D9F, 0x002DA7,0x2DA7, 0x002DAF,0x2DAF, 0x002DB7,0x2DB7, 0x002DBF,0x2DBF, 0x002DC7,0x2DC7, 0x002DCF,0x2DCF, 0x002DD7,0x2DD7, 0x002DDF,0x2DDF, 0x002E50,0x2E7F, 0x002E9A,0x2E9A, 0x002EF4,0x2EFF, 0x002FD6,0x2FEF, 0x002FFC,0x2FFF, 0x003040,0x3040, 0x003097,0x3098, 0x003100,0x3104, 0x003130,0x3130, 0x00318F,0x318F, 0x0031BB,0x31BF, 0x0031E4,0x31EF, 0x00321F,0x321F, 0x004DB6,0x4DBF, 0x009FF0,0x9FFF, 0x00A48D,0xA48F, 0x00A4C7,0xA4CF, 0x00A62C,0xA63F, 0x00A6F8,0xA6FF, 0x00A7C0,0xA7C1, 0x00A7C7,0xA7F6, 0x00A82C,0xA82F, 0x00A83A,0xA83F, 0x00A878,0xA87F, 0x00A8C6,0xA8CD, 0x00A8DA,0xA8DF, 0x00A954,0xA95E, 0x00A97D,0xA97F, 0x00A9CE,0xA9CE, 0x00A9DA,0xA9DD, 0x00A9FF,0xA9FF, 0x00AA37,0xAA3F, 0x00AA4E,0xAA4F, 0x00AA5A,0xAA5B, 0x00AAC3,0xAADA, 0x00AAF7,0xAB00, 0x00AB07,0xAB08, 0x00AB0F,0xAB10, 0x00AB17,0xAB1F, 0x00AB27,0xAB27, 0x00AB2F,0xAB2F, 0x00AB68,0xAB6F, 0x00ABEE,0xABEF, 0x00ABFA,0xABFF, 0x00D7A4,0xD7AF, 0x00D7C7,0xD7CA, 0x00D7FC,0xD7FF, 0x00D800,0xDFFF, 0x00E000,0xF8FF, 0x00FA6E,0xFA6F, 0x00FADA,0xFAFF, 0x00FB07,0xFB12, 0x00FB18,0xFB1C, 0x00FB37,0xFB37, 0x00FB3D,0xFB3D, 0x00FB3F,0xFB3F, 0x00FB42,0xFB42, 0x00FB45,0xFB45, 0x00FBC2,0xFBD2, 0x00FD40,0xFD4F, 0x00FD90,0xFD91, 0x00FDC8,0xFDEF, 0x00FDFE,0xFDFF, 0x00FE1A,0xFE1F, 0x00FE53,0xFE53, 0x00FE67,0xFE67, 0x00FE6C,0xFE6F, 0x00FE75,0xFE75, 0x00FEFD,0xFEFE, 0x00FEFF,0xFEFF, 0x00FF00,0xFF00, 0x00FFBF,0xFFC1, 0x00FFC8,0xFFC9, 0x00FFD0,0xFFD1, 0x00FFD8,0xFFD9, 0x00FFDD,0xFFDF, 0x00FFE7,0xFFE7, 0x00FFEF,0xFFF8, 0x00FFF9,0xFFFB, 0x00FFFE,0xFFFF, 0x01000C,0x1000C, 0x010027,0x10027, 0x01003B,0x1003B, 0x01003E,0x1003E, 0x01004E,0x1004F, 0x01005E,0x1007F, 0x0100FB,0x100FF, 0x010103,0x10106, 0x010134,0x10136, 0x01018F,0x1018F, 0x01019C,0x1019F, 0x0101A1,0x101CF, 0x0101FE,0x1027F, 0x01029D,0x1029F, 0x0102D1,0x102DF, 0x0102FC,0x102FF, 0x010324,0x1032C, 0x01034B,0x1034F, 0x01037B,0x1037F, 0x01039E,0x1039E, 0x0103C4,0x103C7, 0x0103D6,0x103FF, 0x01049E,0x1049F, 0x0104AA,0x104AF, 0x0104D4,0x104D7, 0x0104FC,0x104FF, 0x010528,0x1052F, 0x010564,0x1056E, 0x010570,0x105FF, 0x010737,0x1073F, 0x010756,0x1075F, 0x010768,0x107FF, 0x010806,0x10807, 0x010809,0x10809, 0x010836,0x10836, 0x010839,0x1083B, 0x01083D,0x1083E, 0x010856,0x10856, 0x01089F,0x108A6, 0x0108B0,0x108DF, 0x0108F3,0x108F3, 0x0108F6,0x108FA, 0x01091C,0x1091E, 0x01093A,0x1093E, 0x010940,0x1097F, 0x0109B8,0x109BB, 0x0109D0,0x109D1, 0x010A04,0x10A04, 0x010A07,0x10A0B, 0x010A14,0x10A14, 0x010A18,0x10A18, 0x010A36,0x10A37, 0x010A3B,0x10A3E, 0x010A49,0x10A4F, 0x010A59,0x10A5F, 0x010AA0,0x10ABF, 0x010AE7,0x10AEA, 0x010AF7,0x10AFF, 0x010B36,0x10B38, 0x010B56,0x10B57, 0x010B73,0x10B77, 0x010B92,0x10B98, 0x010B9D,0x10BA8, 0x010BB0,0x10BFF, 0x010C49,0x10C7F, 0x010CB3,0x10CBF, 0x010CF3,0x10CF9, 0x010D28,0x10D2F, 0x010D3A,0x10E5F, 0x010E7F,0x10EFF, 0x010F28,0x10F2F, 0x010F5A,0x10FDF, 0x010FF7,0x10FFF, 0x01104E,0x11051, 0x011070,0x1107E, 0x0110BD,0x110BD, 0x0110C2,0x110CC, 0x0110CD,0x110CD, 0x0110CE,0x110CF, 0x0110E9,0x110EF, 0x0110FA,0x110FF, 0x011135,0x11135, 0x011147,0x1114F, 0x011177,0x1117F, 0x0111CE,0x111CF, 0x0111E0,0x111E0, 0x0111F5,0x111FF, 0x011212,0x11212, 0x01123F,0x1127F, 0x011287,0x11287, 0x011289,0x11289, 0x01128E,0x1128E, 0x01129E,0x1129E, 0x0112AA,0x112AF, 0x0112EB,0x112EF, 0x0112FA,0x112FF, 0x011304,0x11304, 0x01130D,0x1130E, 0x011311,0x11312, 0x011329,0x11329, 0x011331,0x11331, 0x011334,0x11334, 0x01133A,0x1133A, 0x011345,0x11346, 0x011349,0x1134A, 0x01134E,0x1134F, 0x011351,0x11356, 0x011358,0x1135C, 0x011364,0x11365, 0x01136D,0x1136F, 0x011375,0x113FF, 0x01145A,0x1145A, 0x01145C,0x1145C, 0x011460,0x1147F, 0x0114C8,0x114CF, 0x0114DA,0x1157F, 0x0115B6,0x115B7, 0x0115DE,0x115FF, 0x011645,0x1164F, 0x01165A,0x1165F, 0x01166D,0x1167F, 0x0116B9,0x116BF, 0x0116CA,0x116FF, 0x01171B,0x1171C, 0x01172C,0x1172F, 0x011740,0x117FF, 0x01183C,0x1189F, 0x0118F3,0x118FE, 0x011900,0x1199F, 0x0119A8,0x119A9, 0x0119D8,0x119D9, 0x0119E5,0x119FF, 0x011A48,0x11A4F, 0x011AA3,0x11ABF, 0x011AF9,0x11BFF, 0x011C09,0x11C09, 0x011C37,0x11C37, 0x011C46,0x11C4F, 0x011C6D,0x11C6F, 0x011C90,0x11C91, 0x011CA8,0x11CA8, 0x011CB7,0x11CFF, 0x011D07,0x11D07, 0x011D0A,0x11D0A, 0x011D37,0x11D39, 0x011D3B,0x11D3B, 0x011D3E,0x11D3E, 0x011D48,0x11D4F, 0x011D5A,0x11D5F, 0x011D66,0x11D66, 0x011D69,0x11D69, 0x011D8F,0x11D8F, 0x011D92,0x11D92, 0x011D99,0x11D9F, 0x011DAA,0x11EDF, 0x011EF9,0x11FBF, 0x011FF2,0x11FFE, 0x01239A,0x123FF, 0x01246F,0x1246F, 0x012475,0x1247F, 0x012544,0x12FFF, 0x01342F,0x1342F, 0x013430,0x13438, 0x013439,0x143FF, 0x014647,0x167FF, 0x016A39,0x16A3F, 0x016A5F,0x16A5F, 0x016A6A,0x16A6D, 0x016A70,0x16ACF, 0x016AEE,0x16AEF, 0x016AF6,0x16AFF, 0x016B46,0x16B4F, 0x016B5A,0x16B5A, 0x016B62,0x16B62, 0x016B78,0x16B7C, 0x016B90,0x16E3F, 0x016E9B,0x16EFF, 0x016F4B,0x16F4E, 0x016F88,0x16F8E, 0x016FA0,0x16FDF, 0x016FE4,0x16FFF, 0x0187F8,0x187FF, 0x018AF3,0x1AFFF, 0x01B11F,0x1B14F, 0x01B153,0x1B163, 0x01B168,0x1B16F, 0x01B2FC,0x1BBFF, 0x01BC6B,0x1BC6F, 0x01BC7D,0x1BC7F, 0x01BC89,0x1BC8F, 0x01BC9A,0x1BC9B, 0x01BCA0,0x1BCA3, 0x01BCA4,0x1CFFF, 0x01D0F6,0x1D0FF, 0x01D127,0x1D128, 0x01D173,0x1D17A, 0x01D1E9,0x1D1FF, 0x01D246,0x1D2DF, 0x01D2F4,0x1D2FF, 0x01D357,0x1D35F, 0x01D379,0x1D3FF, 0x01D455,0x1D455, 0x01D49D,0x1D49D, 0x01D4A0,0x1D4A1, 0x01D4A3,0x1D4A4, 0x01D4A7,0x1D4A8, 0x01D4AD,0x1D4AD, 0x01D4BA,0x1D4BA, 0x01D4BC,0x1D4BC, 0x01D4C4,0x1D4C4, 0x01D506,0x1D506, 0x01D50B,0x1D50C, 0x01D515,0x1D515, 0x01D51D,0x1D51D, 0x01D53A,0x1D53A, 0x01D53F,0x1D53F, 0x01D545,0x1D545, 0x01D547,0x1D549, 0x01D551,0x1D551, 0x01D6A6,0x1D6A7, 0x01D7CC,0x1D7CD, 0x01DA8C,0x1DA9A, 0x01DAA0,0x1DAA0, 0x01DAB0,0x1DFFF, 0x01E007,0x1E007, 0x01E019,0x1E01A, 0x01E022,0x1E022, 0x01E025,0x1E025, 0x01E02B,0x1E0FF, 0x01E12D,0x1E12F, 0x01E13E,0x1E13F, 0x01E14A,0x1E14D, 0x01E150,0x1E2BF, 0x01E2FA,0x1E2FE, 0x01E300,0x1E7FF, 0x01E8C5,0x1E8C6, 0x01E8D7,0x1E8FF, 0x01E94C,0x1E94F, 0x01E95A,0x1E95D, 0x01E960,0x1EC70, 0x01ECB5,0x1ED00, 0x01ED3E,0x1EDFF, 0x01EE04,0x1EE04, 0x01EE20,0x1EE20, 0x01EE23,0x1EE23, 0x01EE25,0x1EE26, 0x01EE28,0x1EE28, 0x01EE33,0x1EE33, 0x01EE38,0x1EE38, 0x01EE3A,0x1EE3A, 0x01EE3C,0x1EE41, 0x01EE43,0x1EE46, 0x01EE48,0x1EE48, 0x01EE4A,0x1EE4A, 0x01EE4C,0x1EE4C, 0x01EE50,0x1EE50, 0x01EE53,0x1EE53, 0x01EE55,0x1EE56, 0x01EE58,0x1EE58, 0x01EE5A,0x1EE5A, 0x01EE5C,0x1EE5C, 0x01EE5E,0x1EE5E, 0x01EE60,0x1EE60, 0x01EE63,0x1EE63, 0x01EE65,0x1EE66, 0x01EE6B,0x1EE6B, 0x01EE73,0x1EE73, 0x01EE78,0x1EE78, 0x01EE7D,0x1EE7D, 0x01EE7F,0x1EE7F, 0x01EE8A,0x1EE8A, 0x01EE9C,0x1EEA0, 0x01EEA4,0x1EEA4, 0x01EEAA,0x1EEAA, 0x01EEBC,0x1EEEF, 0x01EEF2,0x1EFFF, 0x01F02C,0x1F02F, 0x01F094,0x1F09F, 0x01F0AF,0x1F0B0, 0x01F0C0,0x1F0C0, 0x01F0D0,0x1F0D0, 0x01F0F6,0x1F0FF, 0x01F10D,0x1F10F, 0x01F16D,0x1F16F, 0x01F1AD,0x1F1E5, 0x01F203,0x1F20F, 0x01F23C,0x1F23F, 0x01F249,0x1F24F, 0x01F252,0x1F25F, 0x01F266,0x1F2FF, 0x01F6D6,0x1F6DF, 0x01F6ED,0x1F6EF, 0x01F6FB,0x1F6FF, 0x01F774,0x1F77F, 0x01F7D9,0x1F7DF, 0x01F7EC,0x1F7FF, 0x01F80C,0x1F80F, 0x01F848,0x1F84F, 0x01F85A,0x1F85F, 0x01F888,0x1F88F, 0x01F8AE,0x1F8FF, 0x01F90C,0x1F90C, 0x01F972,0x1F972, 0x01F977,0x1F979, 0x01F9A3,0x1F9A4, 0x01F9AB,0x1F9AD, 0x01F9CB,0x1F9CC, 0x01FA54,0x1FA5F, 0x01FA6E,0x1FA6F, 0x01FA74,0x1FA77, 0x01FA7B,0x1FA7F, 0x01FA83,0x1FA8F, 0x01FA96,0x1FFFF, 0x02A6D7,0x2A6FF, 0x02B735,0x2B73F, 0x02B81E,0x2B81F, 0x02CEA2,0x2CEAF, 0x02EBE1,0x2F7FF, 0x02FA1E,0xE0000, 0x0E0001,0xE0001, 0x0E0002,0xE001F, 0x0E0020,0xE007F, 0x0E0080,0xE00FF, 0x0E01F0,0xEFFFF, 0x0F0000,0xFFFFD, 0x0FFFFE,0xFFFFF, 0x100000,0x10FFFD, 0x10FFFE,0x10FFFF};

// Text buffer
size_t sizetext=0, ntext=0;
uint8_t *text = NULL;

// UI state
// Start of saved state sections
char needsredraw = 1,
	needsredrawcur = 1,
	needsredrawkb = 1,
	isuptap = 0,
	isupswipelr = 0,
	isdown = 0,
	justbraced = 0,
	isselectinglines = 0,
	showntab = 0,
	shownac = 0,
	isenterafterblock = 0,
	ispasteafterblock = 0,
	iscutblock = 0,
	iscopyblock = 0,
	istypedwordfromstart = 0;
float xdown=INFINITY, ydown=INFINITY,
	yscr = INFINITY;
double ytopdown = INFINITY,
	ymoveprev = INFINITY,
	yvelocity = 0.0,
	xcolud = INFINITY,
	y0tab = INFINITY,
	ybottomov = INFINITY;
uint64_t nsdown = UINT64_MAX,
	nsstartup = 0,
	nsmoveprev = UINT64_MAX,
	nsflingprev = UINT64_MAX,
	stateovvert = 0,
	statekbvert = 0;
unsigned vwinsize = 0;
enum overlay {
	OVNONE,
	OVMAIN,
	OVCANCEL,
	OVMULTICURSTOP,
	OVMULTICURACT,
	OVMCBACKMATCH,
	OVMCTOGGLELINES,
	OVSELECT,
	OVREPLACE,
	OVMAKEFUNCTION,
	OVCOPIED,
	OVUNDID,
	OVJOINED,
	OVTAP0
} overlay=0, overlaypremain=0, overlayverted=-1;
long mssaved = 0,
	msensurekeyboard = 0,
	hframe = -1,
	hframeoverride,
	msoverridehframe = 0,
	hframeovverted = -2;
size_t icurvert = SIZE_MAX;

// Making function from selection
size_t inamemkfn = SIZE_MAX;
	
// Renaming
size_t irenaming = SIZE_MAX,
	nrenamed = 0,
	sizerenamed = 0;
unsigned vtextrenaming = -1;
uint8_t *bufrenamed = NULL;

// Replace
size_t nreplace=0, sizeisreplace=0, *isreplace=NULL;
struct replace {
	size_t n, norig, sizeorig;
	uint8_t *orig;
} *replaces = NULL;
size_t i0replace=SIZE_MAX, i1replace, nreplaced=0;
size_t nflowreplace=0, sizeflowreplace=0, *isflowreplace=NULL;
size_t nbufreplace0=0, sizebufreplace0=0;
uint8_t *bufreplace0 = NULL;
size_t nbufreplace1=0, sizebufreplace1=0;
uint8_t *bufreplace1 = NULL;

// Flow indices
size_t nflow=0, sizeflows=0, *isflow=NULL;

// Multi cursors
size_t nmulti=0, sizemulti=0;
struct multicur{size_t i,sizecopy,ncopy,iselect;uint8_t *bufcopy;} *multis=NULL;
size_t imultistart = SIZE_MAX;
size_t nflowmulti=0, sizeflowmulti=0, *isflowmulti=NULL;
size_t nbufmulti=0, sizebufmulti=0;
uint8_t *bufmulti = NULL;

// Cursor location
size_t icur = SIZE_MAX;
char curshown = 0;
enum cursorspot {
	CURTEXT,
	CURSEARCH,
	CURMULTI,
	CURREPLACE0,
	CURREPLACE1
} cur = 0;
uint64_t phasecur = 0;

// Undo
size_t nundo=0, sizeundo=0;
struct undo {
	char type;
	size_t i, n, sizebuf;
	uint8_t *buf;
	unsigned idchain;
} *undos;
unsigned idchainundo = 0;
char isundoing = 0;

// Positions in the blocks
struct atblk {
	size_t i, i0blk;
	ssize_t row;
	struct block *blk;
	double x, y;
};
typedef struct atblk atblk;
union ssize_tdouble { ssize_t s; double d; };

// Selecting
size_t iselectstart = SIZE_MAX,
	iselectend;
char curselect = -1;

// Spacing out info
double xdowntaptextprev=INFINITY, ydowntaptextprev=INFINITY;
uint64_t nsdowntaptextprev = 0;
double x0spacing;
size_t ilspaced = SIZE_MAX;

// Search buffer
size_t nsearch=0, sizesearch=0;
uint8_t *bufsearch = NULL;
uint8_t vsearch = 0;
size_t itoppresearch, icurpresearch;
double ytoppresearch;

// Positions in the search results
struct atsearch {
	ssize_t row;
	size_t isr, irow;
	double x, y;
};
typedef struct atsearch atsearch;

// Cached search results, last is ntext
unsigned vtextsearchresults=-1, vsearchsearchresults=-1, vwinsizesearchresults=-1;
size_t nsearched=0, sizeissearchresults=0, nissearchresults=0;
char sectionssearched = 0;  // 1=toplevel, 2=labels
size_t isrlabels, isrdirect;
size_t *issearchresults = NULL;
char *typessearchresults = NULL; // 0=parent, 1=row start, 2=row continue, 3=direct

// Positions in the text+screen
struct at {
	size_t i;
	ssize_t row, graph;
	double x, y;  // of topleft
};
typedef struct at at;

// Top of screen
size_t itop = 0,
	isrtop = 0,
	irowtop = 0;
double ytop = mudwin;  // offset of first row

// Cached syntax states
size_t sizesynsts = 0,
	nsynsts = 0;
struct synst {
	char syn;
	size_t i1;
} *synsts = NULL;

// Text state
unsigned vtext = 0,
	vtextsaved = 0;

// Expanded lines
size_t nilexps = 0,
	sizeilexps = 0,
	*ilexps = NULL;
struct expanse {
	size_t n;
	size_t norig;
	uint8_t *orig;
	char unsaved;
} *exps = NULL;
// End of saved state sections

// Autocorrect suggestions
size_t sizeisac=0, nisac=0, *nsac=NULL, *countsac=NULL;
uint8_t *distsac=NULL, **wsac=NULL;
unsigned vtextac = -1;
size_t icurac = SIZE_MAX - 1,
	iacpre0 = 5;
char curac = -1;

// Blocks
size_t sizeblocks=0, nblocks=0;
struct block {
	size_t n;
	char expanded, // 3 = don't coalesce next ones
		needsreblockize;
	struct block *blocks;
	size_t sizeblocks, nblocks, iblocks;
	struct block *parent;
	size_t iminshow1; // minimum 1-indexed index to show at start ofblock
} *blocks = NULL;

// Pipelines
VkPipelineLayout layout_, layoutblks, layoutcur, layouttextov, layoutbackov, layoutbtnov, layoutexp, layoutselect, layoutbtnkb, layouttextkb, layoutbackkb, layoutflow, layoutund;
VkPipeline pipeline_, pipelineblks, pipelinecur, pipelinetextov, pipelinebackov, pipelinebtnov, pipelineexp, pipelineselect, pipelinebtnkb, pipelinetextkb, pipelinebackkb, pipelineflow, pipelineund;
VkPipelineCache cache_, pipelinecacheblks, pipelinecachecur, pipelinecachetextov, pipelinecachebackov, pipelinecachebtnov, pipelinecacheexp, pipelinecacheselect, pipelinecachebtnkb, pipelinecachetextkb, pipelinecachebackkb, pipelinecacheflow, pipelinecacheund;
VkBuffer vertexBuf_, vbufblks, vbufcur, vbuftextov, vbufbackov, vbufbtnov, vbufexp, vbufselect, vbufbtnkb, vbuftextkb, vbufbackkb, vbufflow, vbufund;
VkDeviceMemory deviceMemory, memvbufblks, memvbufcur, memvbuftextov, memvbufbackov, memvbufbtnov, memvbufexp, memvbufselect, memvbufbtnkb, memvbuftextkb, memvbufbackkb, memvbufflow, memvbufund;
VkDescriptorSet descsettext, descsettextov, descsettextkb;
VkDescriptorPool descpooltext, descpooltextov, descpooltextkb;
size_t sizevertstext=134217728, sizevertsblks=134217728, sizevertscur=32768, sizevertstextov=32768, sizevertsbackov=32768, sizevertsbtnov=32768, sizevertsexp=32768, sizevertsselect=32768, sizevertsbackkb=32768, sizevertstextkb=32768, sizevertsbtnkb=32768, sizevertsflow=32768, sizevertsund=32768,
	nvertstext=0, nvertsblks=0, nvertscur=0, nvertstextov=0, nvertsbackov=0, nvertsbtnov=0, nvertsexp=0, nvertsselect=0, nvertsbtnkb=0, nvertsbackkb=0, nvertstextkb=0, nvertsflow=0, nvertsund=0;
char needsvertcur=0, needsverttext=0, needsvertblks=0, needsverttextov=0, needsvertbackov=0, needsvertbtnov=0, needsvertexp=0, needsvertselect=0, needsverttextkb=0, needsvertbackkb=0, needsvertbtnkb=0, needsvertflow=0, needsvertund=0;
struct vtext { float x,y; uint32_t syn; float u,v; } *vertstext = NULL;
struct vblks { float x,y; uint32_t color; } *vertsblks = NULL;
struct vcur { float x,y; } *vertscur = NULL;
struct vtextov { float x,y,u,v; } *vertstextov = NULL;
struct vbackov { float x,y; } *vertsbackov = NULL;
struct vbtnov { float x,y,xopp,yopp; } *vertsbtnov = NULL;
struct vexp { float x,y,xp,yp; uint32_t borderud; } *vertsexp = NULL;
struct vselect { float x,y; } *vertsselect = NULL;
struct vtextkb { float x,y,u,v; } *vertstextkb = NULL;
struct vbackkb { float x,y; } *vertsbackkb = NULL;
struct vbtnkb { float x,y,xopp,yopp; } *vertsbtnkb = NULL;
struct vflow { float x,y,xp,yp; uint32_t borderud; } *vertsflow = NULL;
struct vund { float x,y; } *vertsund = NULL;
VkDescriptorSetLayout desclayouts[20], *desclayoutnext=desclayouts;
unsigned vtextvert = -1;

// Global Variables
VkExtent2D displaySize_={0};
VkSurfaceKHR surface_;
VkPhysicalDevice gpuDevice_;
bool initialized_;
VkDevice device_;
uint32_t queueFamilyIndex_;
VkQueue queue_;
VkSwapchainKHR swapchain_=0;
VkCommandBuffer* cmdBuffer_;
VkSemaphore semaphore_;
VkFence fence_;
VkCommandPool cmdPool_;
VkInstance instance_;
VkImage* displayImages_=NULL;
VkImageView* displayViews_=NULL;
VkFramebuffer* framebuffers_=NULL;
uint32_t swapchainLength_=0;
VkRenderPass renderPass_;
uint32_t cmdBufferLen_;
extern PFN_vkCreateDebugReportCallbackEXT vkCreateDebugReportCallbackEXT;
extern PFN_vkDestroyDebugReportCallbackEXT vkDestroyDebugReportCallbackEXT;
VkImage imagetex = VK_NULL_HANDLE;
VkMemoryAllocateInfo mem_alloc;
VkDeviceMemory mem;
VkSampler sampler;
VkImageView view;
VkMemoryRequirements mem_reqs;

/**
* Data associated with an ALooper fd that will be returned as the "outData"
* when that source has data ready.
*/
struct android_app;
struct android_poll_source {

	// The identifier of this source.  May be LOOPER_ID_MAIN or
	// LOOPER_ID_INPUT.
	int32_t id;

	// The android_app this ident is associated with.
	struct android_app* app;

	// Function to call to perform the standard processing of data from
	// this source.
	void (*process)(struct android_app* app, struct android_poll_source* source);
};

/**
* This is the interface for the standard glue code of a threaded
* application.  In this model, the application's code is running
* in its own thread separate from the main thread of the process.
* It is not required that this thread be associated with the Java
* VM, although it will need to be in order to make JNI calls any
* Java objects.
*/
struct android_app {
	// The application can place a pointer to its own state object
	// here if it likes.
	void* userData;

	// Fill this in with the function to process main app commands (APP_CMD_*)
	void (*onAppCmd)(struct android_app* app, int32_t cmd);

	// Fill this in with the function to process input events.  At this point
	// the event has already been pre-dispatched, and it will be finished upon
	// return.  Return 1 if you have handled the event, 0 for any default
	// dispatching.
	int32_t (*onInputEvent)(struct android_app* app, AInputEvent* event);

	// The ANativeActivity object instance that this app is running in.
	ANativeActivity* activity;

	// The current configuration the app is running in.
	AConfiguration* config;

	// This is the last instance's saved state, as provided at creation time.
	// It is NULL if there was no state.  You can use this as you need; the
	// memory will remain around until you call android_app_exec_cmd() for
	// APP_CMD_RESUME, at which point it will be freed and savedState set to NULL.
	// These variables should only be changed when processing a APP_CMD_SAVE_STATE,
	// at which point they will be initialized to NULL and you can malloc your
	// state and place the information here.  In that case the memory will be
	// freed for you later.
	void* savedState;
	size_t savedStateSize;

	// The ALooper associated with the app's thread.
	ALooper* looper;

	// When non-NULL, this is the input queue from which the app will
	// receive user input events.
	AInputQueue* inputQueue;

	// When non-NULL, this is the window surface that the app can draw in.
	ANativeWindow* window;

	// Current content rectangle of the window; this is the area where the
	// window's content should be placed to be seen by the user.
	ARect contentRect;

	// Current state of the app's activity.  May be either APP_CMD_START,
	// APP_CMD_RESUME, APP_CMD_PAUSE, or APP_CMD_STOP; see below.
	int activityState;

	// This is non-zero when the application's NativeActivity is being
	// destroyed and waiting for the app thread to complete.
	int destroyRequested;

	// -------------------------------------------------
	// Below are "private" implementation of the glue code.

	pthread_mutex_t mutex;
	pthread_cond_t cond;

	int msgread;
	int msgwrite;

	pthread_t thread;

	struct android_poll_source cmdPollSource;
	struct android_poll_source inputPollSource;

	int running;
	int stateSaved;
	int destroyed;
	int redrawNeeded;
	AInputQueue* pendingInputQueue;
	ANativeWindow* pendingWindow;
	ARect pendingContentRect;
	size_t ntype, sizetype;
	uint8_t *buftype;
	char isfaketype;
	long hframenew;
	char ispendingbackspace;
} *appg;

enum {
	/**
	 * Looper data ID of commands coming from the app's main thread, which
	 * is returned as an identifier from ALooper_pollOnce().  The data for this
	 * identifier is a pointer to an android_poll_source structure.
	 * These can be retrieved and processed with android_app_read_cmd()
	 * and android_app_exec_cmd().
	 */
	LOOPER_ID_MAIN = 1,

	/**
	 * Looper data ID of events coming from the AInputQueue of the
	 * application's window, which is returned as an identifier from
	 * ALooper_pollOnce().  The data for this identifier is a pointer to an
	 * android_poll_source structure.  These can be read via the inputQueue
	 * object of android_app.
	 */
	LOOPER_ID_INPUT = 2,

	/**
	 * Start of user-defined ALooper identifiers.
	 */
	LOOPER_ID_USER = 3,
};

enum {
	/**
	 * Command from main thread: the AInputQueue has changed.  Upon processing
	 * this command, android_app->inputQueue will be updated to the new queue
	 * (or NULL).
	 */
	APP_CMD_INPUT_CHANGED,

	/**
	 * Command from main thread: a new ANativeWindow is ready for use.  Upon
	 * receiving this command, android_app->window will contain the new window
	 * surface.
	 */
	APP_CMD_INIT_WINDOW,

	/**
	 * Command from main thread: the existing ANativeWindow needs to be
	 * terminated.  Upon receiving this command, android_app->window still
	 * contains the existing window; after calling android_app_exec_cmd
	 * it will be set to NULL.
	 */
	APP_CMD_TERM_WINDOW,

	/**
	 * Command from main thread: the current ANativeWindow has been resized.
	 * Please redraw with its new size.
	 */
	APP_CMD_WINDOW_RESIZED,

	/**
	 * Command from main thread: the system needs that the current ANativeWindow
	 * be redrawn.  You should redraw the window before handing this to
	 * android_app_exec_cmd() in order to avoid transient drawing glitches.
	 */
	APP_CMD_WINDOW_REDRAW_NEEDED,

	/**
	 * Command from main thread: the content area of the window has changed,
	 * such as from the soft input window being shown or hidden.  You can
	 * find the new content rect in android_app::contentRect.
	 */
	APP_CMD_CONTENT_RECT_CHANGED,

	/**
	 * Command from main thread: the app's activity window has gained
	 * input focus.
	 */
	APP_CMD_GAINED_FOCUS,

	/**
	 * Command from main thread: the app's activity window has lost
	 * input focus.
	 */
	APP_CMD_LOST_FOCUS,

	/**
	 * Command from main thread: the current device configuration has changed.
	 */
	APP_CMD_CONFIG_CHANGED,

	/**
	 * Command from main thread: the system is running low on memory.
	 * Try to reduce your memory use.
	 */
	APP_CMD_LOW_MEMORY,

	/**
	 * Command from main thread: the app's activity has been started.
	 */
	APP_CMD_START,

	/**
	 * Command from main thread: the app's activity has been resumed.
	 */
	APP_CMD_RESUME,

	/**
	 * Command from main thread: the app should generate a new saved state
	 * for itself, to restore from later if needed.  If you have saved state,
	 * allocate it with malloc and place it in android_app.savedState with
	 * the size in android_app.savedStateSize.  The will be freed for you
	 * later.
	 */
	APP_CMD_SAVE_STATE,

	/**
	 * Command from main thread: the app's activity has been paused.
	 */
	APP_CMD_PAUSE,

	/**
	 * Command from main thread: the app's activity has been stopped.
	 */
	APP_CMD_STOP,

	/**
	 * Command from main thread: the app's activity is being destroyed,
	 * and waiting for the app thread to clean up and exit before proceeding.
	 */
	APP_CMD_DESTROY,

	APP_CMD_BACKSPACE,
	APP_CMD_TYPE,
	APP_CMD_HFRAME
};

// Shaders
/* GEN
shaderbuf()
{
	printf 'uint8_t bufshader%s%s[] = {' $1 $2
	glslc -c -o - -fshader-stage=$1 - |
		od -vt u1 |
		cut -d ' ' -f 2- |
		sed '$d' |
		sed -n 'H;${x;s%^[[:space:]]*%%;s/[[:space:]]\{1,\}/,/g;p;}' |
		tr -d '\n'
	echo '};'
}

<<\! shaderbuf vert text
#version 400
#extension GL_ARB_separate_shader_objects : enable
#extension GL_ARB_shading_language_420pack : enable
layout (push_constant) uniform Scale {
	float x, y;
} scale;
//layout (location = 0) in vec4 pos;
//layout (location = 1) in vec2 attr;
layout (location = 0) in vec2 pos;
layout (location = 1) in uint synin;
layout (location = 2) in vec2 texcoordin;
layout (location = 0) out vec2 texcoordout;
layout (location = 1) out uint synout;
void main() {
  //texcoord = attr;
  texcoordout = texcoordin;
	 synout = synin;
  gl_Position = vec4(pos.x/scale.x-1.0, -(pos.y/scale.y+1.0), 0.0, 1.0);
}
!

<<\! shaderbuf frag text
#version 400
#extension GL_ARB_separate_shader_objects : enable
#extension GL_ARB_shading_language_420pack : enable

const vec3 colors[6] = {
   vec3(1.0f,1.0f,1.0f), // 0 normal
   vec3(1.0f,1.0f,1.0f), // 1 
   vec3(0.337255f,0.478431f,0.890196f), // 2 // comment
   vec3(1.0f,
0.188235f,
0.062745f), // 3 <header.h>, "string", 'char'
   vec3(0.894118f,
0.145098f,
1.0f), // 4 #include, keyword
   vec3(0.109804f,
0.929412f,
0.078431f) // 5 type
};

layout (binding = 0) uniform sampler2D tex;
layout (location = 0) in vec2 texcoord;
layout (location = 1) flat in uint syn;
layout (location = 0) out vec4 uFragColor;
void main() {
	vec4 tex = texture(tex, texcoord);
	vec3 color = colors[syn];
	uFragColor = vec4(tex.r*color.r, tex.g*color.g, tex.b*color.b, tex.a);
	//uFragColor = texture(tex, texcoord);
}
!

<<\! shaderbuf vert blks
#version 400
#extension GL_ARB_separate_shader_objects : enable
#extension GL_ARB_shading_language_420pack : enable
layout (push_constant) uniform Scale {
	float x, y;
} scale;
layout (location = 0) in vec2 pos;
layout (location = 1) in uint colorin;
layout (location = 0) out vec4 colorout;
void main() {
  colorout = colorin==0 ? vec4(0.25,0.25,0.25,1.0) : vec4(0.5,0.5,0.5,1.0);
  gl_Position = vec4(pos.x/scale.x-1.0, -(pos.y/scale.y+1.0), 0.0, 1.0);
}
!

<<\! shaderbuf frag blks
#version 400
#extension GL_ARB_separate_shader_objects : enable
#extension GL_ARB_shading_language_420pack : enable
layout (location = 0) in vec4 color;
layout (location = 0) out vec4 uFragColor;
void main() {
  uFragColor = color;
}
!

<<\! shaderbuf vert und
#version 400
#extension GL_ARB_separate_shader_objects : enable
#extension GL_ARB_shading_language_420pack : enable
layout (push_constant) uniform Scale {
	float x, y;
} scale;
layout (location = 0) in vec2 pos;
void main() {
  gl_Position = vec4(pos.x/scale.x-1.0, -(pos.y/scale.y+1.0), 0.0, 1.0);
}
!

<<\! shaderbuf frag und
#version 400
#extension GL_ARB_separate_shader_objects : enable
#extension GL_ARB_shading_language_420pack : enable
layout (location = 0) out vec4 uFragColor;
void main() {
  uFragColor = vec4(1.0, 1.0, 1.0, 1.0);
}
!

<<\! shaderbuf vert cur
#version 400
#extension GL_ARB_separate_shader_objects : enable
#extension GL_ARB_shading_language_420pack : enable
layout (push_constant) uniform Scale {
	float x, y;
} scale;
layout (location = 0) in vec2 pos;
void main() {
	gl_Position = vec4(pos.x/scale.x-1.0, -(pos.y/scale.y+1.0), 0.0, 1.0);
}
!

<<\! shaderbuf frag cur
#version 400
#extension GL_ARB_separate_shader_objects : enable
#extension GL_ARB_shading_language_420pack : enable
layout (location = 0) out vec4 uFragColor;
void main() {
  uFragColor = vec4(1.0, 1.0, 1.0, 1.0);
}
!

<<\! shaderbuf vert textov
#version 400
#extension GL_ARB_separate_shader_objects : enable
#extension GL_ARB_shading_language_420pack : enable
layout (push_constant) uniform Scale {
	float x, y;
} scale;
layout (location = 0) in vec2 pos;
layout (location = 1) in vec2 texcoordin;
layout (location = 0) out vec2 texcoordout;
void main() {
  texcoordout = texcoordin;
  gl_Position = vec4(pos.x/scale.x-1.0, -(pos.y/scale.y+1.0), 0.0, 1.0);
}
!

<<\! shaderbuf frag textov
#version 400
#extension GL_ARB_separate_shader_objects : enable
#extension GL_ARB_shading_language_420pack : enable

layout (binding = 0) uniform sampler2D tex;
layout (location = 0) in vec2 texcoord;
layout (location = 0) out vec4 uFragColor;
void main() {
	vec4 tex = texture(tex, texcoord);
	vec3 color = vec3(0, 0, 1.0);
	uFragColor = vec4(tex.r*color.r, tex.g*color.g, tex.b*color.b, tex.a);
}
!

<<\! shaderbuf vert backov
#version 400
#extension GL_ARB_separate_shader_objects : enable
#extension GL_ARB_shading_language_420pack : enable
layout (push_constant) uniform Scale {
	float x, y;
} scale;
layout (location = 0) in vec2 pos;
void main() {
  gl_Position = vec4(pos.x/scale.x-1.0, -(pos.y/scale.y+1.0), 0.0, 1.0);
}
!

<<\! shaderbuf frag backov
#version 400
#extension GL_ARB_separate_shader_objects : enable
#extension GL_ARB_shading_language_420pack : enable

layout (location = 0) out vec4 uFragColor;
void main() {
	uFragColor = vec4(1.0, 1.0, 1.0, 1.0);
}
!

<<\! shaderbuf vert btnov
#version 400
#extension GL_ARB_separate_shader_objects : enable
#extension GL_ARB_shading_language_420pack : enable
layout (push_constant) uniform Scale {
	float x, y;
} scale;
layout (location = 0) in vec2 pos;
layout (location = 1) in vec2 opp;
layout (location = 0) out vec4 lrud;
void main() {
	gl_Position = vec4(pos.x/scale.x-1.0, -(pos.y/scale.y+1.0), 0.0, 1.0);
	lrud = vec4(min(pos.x,opp.x), max(pos.x,opp.x), min(pos.y,opp.y), max(pos.y,opp.y));
}
!

<<\! shaderbuf frag btnov
#version 400
#extension GL_ARB_separate_shader_objects : enable
#extension GL_ARB_shading_language_420pack : enable

layout (location = 0) flat in vec4 lrud;
layout (location = 0) out vec4 uFragColor;
void main() {
	if ((lrud.x-2<gl_FragCoord.x && gl_FragCoord.x<lrud.x+2) ||
			(lrud.y-2<gl_FragCoord.x && gl_FragCoord.x<lrud.y+2) ||
			(lrud.z-2<gl_FragCoord.y && gl_FragCoord.y<lrud.z+2) ||
			(lrud.w-2<gl_FragCoord.y && gl_FragCoord.y<lrud.w+2))
		uFragColor = vec4(1.0, 1.0, 1.0, 1.0f);
	else uFragColor = vec4(0.0f, 0.0f, 0.0f, 0.0f);
}
!

<<\! shaderbuf vert select
#version 400
#extension GL_ARB_separate_shader_objects : enable
#extension GL_ARB_shading_language_420pack : enable
layout (push_constant) uniform Scale {
	float x, y;
} scale;
layout (location = 0) in vec2 pos;
void main() {
  gl_Position = vec4(pos.x/scale.x-1.0, -(pos.y/scale.y+1.0), 0.0, 1.0);
}
!

<<\! shaderbuf frag select
#version 400
#extension GL_ARB_separate_shader_objects : enable
#extension GL_ARB_shading_language_420pack : enable

layout (location = 0) out vec4 uFragColor;
void main() {
	uFragColor = vec4(0.3, 0.3, 0.3, 1.0);
}
!

<<\! shaderbuf vert exp
#version 400
#extension GL_ARB_separate_shader_objects : enable
#extension GL_ARB_shading_language_420pack : enable
const float inf = 1.0 / 0.0;
layout (push_constant) uniform Scale {
	float x, y;
} scale;
layout (location = 0) in vec2 pos;
layout (location = 1) in vec2 opp;
layout (location = 2) in uint borderud;
layout (location = 0) out vec4 lrud;
void main() {
	gl_Position = vec4(pos.x/scale.x-1.0, -(pos.y/scale.y+1.0), 0.0, 1.0);
	lrud = vec4(min(pos.x,opp.x), max(pos.x,opp.x), (((borderud&1)>0)?min(pos.y,opp.y):inf), (((borderud&2)>0)?max(pos.y,opp.y):inf));
}
!

<<\! shaderbuf frag exp
#version 400
#extension GL_ARB_separate_shader_objects : enable
#extension GL_ARB_shading_language_420pack : enable

layout (location = 0) flat in vec4 lrud;
layout (location = 0) out vec4 uFragColor;
void main() {
	if ((lrud.x-2<gl_FragCoord.x && gl_FragCoord.x<lrud.x+2) ||
			(lrud.y-2<gl_FragCoord.x && gl_FragCoord.x<lrud.y+2) ||
			(lrud.z-2<gl_FragCoord.y && gl_FragCoord.y<lrud.z+2) ||
			(lrud.w-2<gl_FragCoord.y && gl_FragCoord.y<lrud.w+2))
		uFragColor = vec4(0.212, 0.812, 0.38, 1.0);
	else uFragColor = vec4(0.0f, 0.0f, 0.0f, 0.0f);
}
!

<<\! shaderbuf vert textkb
#version 400
#extension GL_ARB_separate_shader_objects : enable
#extension GL_ARB_shading_language_420pack : enable
layout (push_constant) uniform Scale {
	float x, y;
} scale;
layout (location = 0) in vec2 pos;
layout (location = 1) in vec2 texcoordin;
layout (location = 0) out vec2 texcoordout;
void main() {
  texcoordout = texcoordin;
  gl_Position = vec4(pos.x/scale.x-1.0, -(pos.y/scale.y+1.0), 0.0, 1.0);
}
!

<<\! shaderbuf frag textkb
#version 400
#extension GL_ARB_separate_shader_objects : enable
#extension GL_ARB_shading_language_420pack : enable

layout (binding = 0) uniform sampler2D tex;
layout (location = 0) in vec2 texcoord;
layout (location = 0) out vec4 uFragColor;
void main() {
	vec4 tex = texture(tex, texcoord);
	vec3 color = vec3(0, 0, 1.0);
	uFragColor = vec4(tex.r*color.r, tex.g*color.g, tex.b*color.b, tex.a);
}
!

<<\! shaderbuf vert backkb
#version 400
#extension GL_ARB_separate_shader_objects : enable
#extension GL_ARB_shading_language_420pack : enable
layout (push_constant) uniform Scale {
	float x, y;
} scale;
layout (location = 0) in vec2 pos;
void main() {
  gl_Position = vec4(pos.x/scale.x-1.0, -(pos.y/scale.y+1.0), 0.0, 1.0);
}
!

<<\! shaderbuf frag backkb
#version 400
#extension GL_ARB_separate_shader_objects : enable
#extension GL_ARB_shading_language_420pack : enable

layout (location = 0) out vec4 uFragColor;
void main() {
	uFragColor = vec4(1.0, 1.0, 1.0, 1.0);
}
!

<<\! shaderbuf vert btnkb
#version 400
#extension GL_ARB_separate_shader_objects : enable
#extension GL_ARB_shading_language_420pack : enable
layout (push_constant) uniform Scale {
	float x, y;
} scale;
layout (location = 0) in vec2 pos;
layout (location = 1) in vec2 opp;
layout (location = 0) out vec4 lrud;
void main() {
	gl_Position = vec4(pos.x/scale.x-1.0, -(pos.y/scale.y+1.0), 0.0, 1.0);
	lrud = vec4(min(pos.x,opp.x), max(pos.x,opp.x), min(pos.y,opp.y), max(pos.y,opp.y));
}
!

<<\! shaderbuf frag btnkb
#version 400
#extension GL_ARB_separate_shader_objects : enable
#extension GL_ARB_shading_language_420pack : enable

layout (location = 0) flat in vec4 lrud;
layout (location = 0) out vec4 uFragColor;
void main() {
	if ((lrud.x-2<gl_FragCoord.x && gl_FragCoord.x<lrud.x+2) ||
			(lrud.y-2<gl_FragCoord.x && gl_FragCoord.x<lrud.y+2) ||
			(lrud.z-2<gl_FragCoord.y && gl_FragCoord.y<lrud.z+2) ||
			(lrud.w-2<gl_FragCoord.y && gl_FragCoord.y<lrud.w+2))
		uFragColor = vec4(1.0, 1.0, 1.0, 1.0f);
	else uFragColor = vec4(0.0f, 0.0f, 0.0f, 0.0f);
}
!

<<\! shaderbuf vert flow
#version 400
#extension GL_ARB_separate_shader_objects : enable
#extension GL_ARB_shading_language_420pack : enable
const float inf = 1.0 / 0.0;
layout (push_constant) uniform Scale {
	float x, y;
} scale;
layout (location = 0) in vec2 pos;
layout (location = 1) in vec2 opp;
layout (location = 2) in uint borderud;
layout (location = 0) out vec4 lrud;
void main() {
	gl_Position = vec4(pos.x/scale.x-1.0, -(pos.y/scale.y+1.0), 0.0, 1.0);
	lrud = vec4(min(pos.x,opp.x), max(pos.x,opp.x), (((borderud&1)>0)?min(pos.y,opp.y):inf), (((borderud&2)>0)?max(pos.y,opp.y):inf));
}
!

<<\! shaderbuf frag flow
#version 400
#extension GL_ARB_separate_shader_objects : enable
#extension GL_ARB_shading_language_420pack : enable

layout (location = 0) flat in vec4 lrud;
layout (location = 0) out vec4 uFragColor;
void main() {
	if ((lrud.x-2<gl_FragCoord.x && gl_FragCoord.x<lrud.x+2) ||
			(lrud.y-2<gl_FragCoord.x && gl_FragCoord.x<lrud.y+2) ||
			(lrud.z-2<gl_FragCoord.y && gl_FragCoord.y<lrud.z+2) ||
			(lrud.w-2<gl_FragCoord.y && gl_FragCoord.y<lrud.w+2))
		uFragColor = vec4(0.658824f,
		0.196078f,
		0.627451f, 1.0);
	else uFragColor = vec4(0.0f, 0.0f, 0.0f, 0.0f);
}
!
*/
uint8_t bufshaderverttext[] = {3,2,35,7,0,0,1,0,10,0,13,0,53,0,0,0,0,0,0,0,17,0,2,0,1,0,0,0,11,0,6,0,1,0,0,0,71,76,83,76,46,115,116,100,46,52,53,48,0,0,0,0,14,0,3,0,0,0,0,0,1,0,0,0,15,0,11,0,0,0,0,0,4,0,0,0,109,97,105,110,0,0,0,0,9,0,0,0,11,0,0,0,15,0,0,0,17,0,0,0,24,0,0,0,27,0,0,0,3,0,3,0,2,0,0,0,144,1,0,0,4,0,9,0,71,76,95,65,82,66,95,115,101,112,97,114,97,116,101,95,115,104,97,100,101,114,95,111,98,106,101,99,116,115,0,0,4,0,9,0,71,76,95,65,82,66,95,115,104,97,100,105,110,103,95,108,97,110,103,117,97,103,101,95,52,50,48,112,97,99,107,0,4,0,10,0,71,76,95,71,79,79,71,76,69,95,99,112,112,95,115,116,121,108,101,95,108,105,110,101,95,100,105,114,101,99,116,105,118,101,0,0,4,0,8,0,71,76,95,71,79,79,71,76,69,95,105,110,99,108,117,100,101,95,100,105,114,101,99,116,105,118,101,0,5,0,4,0,4,0,0,0,109,97,105,110,0,0,0,0,5,0,5,0,9,0,0,0,116,101,120,99,111,111,114,100,111,117,116,0,5,0,5,0,11,0,0,0,116,101,120,99,111,111,114,100,105,110,0,0,5,0,4,0,15,0,0,0,115,121,110,111,117,116,0,0,5,0,4,0,17,0,0,0,115,121,110,105,110,0,0,0,5,0,6,0,22,0,0,0,103,108,95,80,101,114,86,101,114,116,101,120,0,0,0,0,6,0,6,0,22,0,0,0,0,0,0,0,103,108,95,80,111,115,105,116,105,111,110,0,6,0,7,0,22,0,0,0,1,0,0,0,103,108,95,80,111,105,110,116,83,105,122,101,0,0,0,0,6,0,7,0,22,0,0,0,2,0,0,0,103,108,95,67,108,105,112,68,105,115,116,97,110,99,101,0,5,0,3,0,24,0,0,0,0,0,0,0,5,0,3,0,27,0,0,0,112,111,115,0,5,0,4,0,32,0,0,0,83,99,97,108,101,0,0,0,6,0,4,0,32,0,0,0,0,0,0,0,120,0,0,0,6,0,4,0,32,0,0,0,1,0,0,0,121,0,0,0,5,0,4,0,34,0,0,0,115,99,97,108,101,0,0,0,71,0,4,0,9,0,0,0,30,0,0,0,0,0,0,0,71,0,4,0,11,0,0,0,30,0,0,0,2,0,0,0,71,0,4,0,15,0,0,0,30,0,0,0,1,0,0,0,71,0,4,0,17,0,0,0,30,0,0,0,1,0,0,0,72,0,5,0,22,0,0,0,0,0,0,0,11,0,0,0,0,0,0,0,72,0,5,0,22,0,0,0,1,0,0,0,11,0,0,0,1,0,0,0,72,0,5,0,22,0,0,0,2,0,0,0,11,0,0,0,3,0,0,0,71,0,3,0,22,0,0,0,2,0,0,0,71,0,4,0,27,0,0,0,30,0,0,0,0,0,0,0,72,0,5,0,32,0,0,0,0,0,0,0,35,0,0,0,0,0,0,0,72,0,5,0,32,0,0,0,1,0,0,0,35,0,0,0,4,0,0,0,71,0,3,0,32,0,0,0,2,0,0,0,19,0,2,0,2,0,0,0,33,0,3,0,3,0,0,0,2,0,0,0,22,0,3,0,6,0,0,0,32,0,0,0,23,0,4,0,7,0,0,0,6,0,0,0,2,0,0,0,32,0,4,0,8,0,0,0,3,0,0,0,7,0,0,0,59,0,4,0,8,0,0,0,9,0,0,0,3,0,0,0,32,0,4,0,10,0,0,0,1,0,0,0,7,0,0,0,59,0,4,0,10,0,0,0,11,0,0,0,1,0,0,0,21,0,4,0,13,0,0,0,32,0,0,0,0,0,0,0,32,0,4,0,14,0,0,0,3,0,0,0,13,0,0,0,59,0,4,0,14,0,0,0,15,0,0,0,3,0,0,0,32,0,4,0,16,0,0,0,1,0,0,0,13,0,0,0,59,0,4,0,16,0,0,0,17,0,0,0,1,0,0,0,23,0,4,0,19,0,0,0,6,0,0,0,4,0,0,0,43,0,4,0,13,0,0,0,20,0,0,0,1,0,0,0,28,0,4,0,21,0,0,0,6,0,0,0,20,0,0,0,30,0,5,0,22,0,0,0,19,0,0,0,6,0,0,0,21,0,0,0,32,0,4,0,23,0,0,0,3,0,0,0,22,0,0,0,59,0,4,0,23,0,0,0,24,0,0,0,3,0,0,0,21,0,4,0,25,0,0,0,32,0,0,0,1,0,0,0,43,0,4,0,25,0,0,0,26,0,0,0,0,0,0,0,59,0,4,0,10,0,0,0,27,0,0,0,1,0,0,0,43,0,4,0,13,0,0,0,28,0,0,0,0,0,0,0,32,0,4,0,29,0,0,0,1,0,0,0,6,0,0,0,30,0,4,0,32,0,0,0,6,0,0,0,6,0,0,0,32,0,4,0,33,0,0,0,9,0,0,0,32,0,0,0,59,0,4,0,33,0,0,0,34,0,0,0,9,0,0,0,32,0,4,0,35,0,0,0,9,0,0,0,6,0,0,0,43,0,4,0,6,0,0,0,39,0,0,0,0,0,128,63,43,0,4,0,25,0,0,0,43,0,0,0,1,0,0,0,43,0,4,0,6,0,0,0,49,0,0,0,0,0,0,0,32,0,4,0,51,0,0,0,3,0,0,0,19,0,0,0,54,0,5,0,2,0,0,0,4,0,0,0,0,0,0,0,3,0,0,0,248,0,2,0,5,0,0,0,61,0,4,0,7,0,0,0,12,0,0,0,11,0,0,0,62,0,3,0,9,0,0,0,12,0,0,0,61,0,4,0,13,0,0,0,18,0,0,0,17,0,0,0,62,0,3,0,15,0,0,0,18,0,0,0,65,0,5,0,29,0,0,0,30,0,0,0,27,0,0,0,28,0,0,0,61,0,4,0,6,0,0,0,31,0,0,0,30,0,0,0,65,0,5,0,35,0,0,0,36,0,0,0,34,0,0,0,26,0,0,0,61,0,4,0,6,0,0,0,37,0,0,0,36,0,0,0,136,0,5,0,6,0,0,0,38,0,0,0,31,0,0,0,37,0,0,0,131,0,5,0,6,0,0,0,40,0,0,0,38,0,0,0,39,0,0,0,65,0,5,0,29,0,0,0,41,0,0,0,27,0,0,0,20,0,0,0,61,0,4,0,6,0,0,0,42,0,0,0,41,0,0,0,65,0,5,0,35,0,0,0,44,0,0,0,34,0,0,0,43,0,0,0,61,0,4,0,6,0,0,0,45,0,0,0,44,0,0,0,136,0,5,0,6,0,0,0,46,0,0,0,42,0,0,0,45,0,0,0,129,0,5,0,6,0,0,0,47,0,0,0,46,0,0,0,39,0,0,0,127,0,4,0,6,0,0,0,48,0,0,0,47,0,0,0,80,0,7,0,19,0,0,0,50,0,0,0,40,0,0,0,48,0,0,0,49,0,0,0,39,0,0,0,65,0,5,0,51,0,0,0,52,0,0,0,24,0,0,0,26,0,0,0,62,0,3,0,52,0,0,0,50,0,0,0,253,0,1,0,56,0,1,0};
uint8_t bufshaderfragtext[] = {3,2,35,7,0,0,1,0,10,0,13,0,75,0,0,0,0,0,0,0,17,0,2,0,1,0,0,0,11,0,6,0,1,0,0,0,71,76,83,76,46,115,116,100,46,52,53,48,0,0,0,0,14,0,3,0,0,0,0,0,1,0,0,0,15,0,8,0,4,0,0,0,4,0,0,0,109,97,105,110,0,0,0,0,17,0,0,0,44,0,0,0,51,0,0,0,16,0,3,0,4,0,0,0,7,0,0,0,3,0,3,0,2,0,0,0,144,1,0,0,4,0,9,0,71,76,95,65,82,66,95,115,101,112,97,114,97,116,101,95,115,104,97,100,101,114,95,111,98,106,101,99,116,115,0,0,4,0,9,0,71,76,95,65,82,66,95,115,104,97,100,105,110,103,95,108,97,110,103,117,97,103,101,95,52,50,48,112,97,99,107,0,4,0,10,0,71,76,95,71,79,79,71,76,69,95,99,112,112,95,115,116,121,108,101,95,108,105,110,101,95,100,105,114,101,99,116,105,118,101,0,0,4,0,8,0,71,76,95,71,79,79,71,76,69,95,105,110,99,108,117,100,101,95,100,105,114,101,99,116,105,118,101,0,5,0,4,0,4,0,0,0,109,97,105,110,0,0,0,0,5,0,3,0,9,0,0,0,116,101,120,0,5,0,3,0,13,0,0,0,116,101,120,0,5,0,5,0,17,0,0,0,116,101,120,99,111,111,114,100,0,0,0,0,5,0,4,0,22,0,0,0,99,111,108,111,114,0,0,0,5,0,3,0,44,0,0,0,115,121,110,0,5,0,5,0,47,0,0,0,105,110,100,101,120,97,98,108,101,0,0,0,5,0,5,0,51,0,0,0,117,70,114,97,103,67,111,108,111,114,0,0,71,0,4,0,13,0,0,0,34,0,0,0,0,0,0,0,71,0,4,0,13,0,0,0,33,0,0,0,0,0,0,0,71,0,4,0,17,0,0,0,30,0,0,0,0,0,0,0,71,0,3,0,44,0,0,0,14,0,0,0,71,0,4,0,44,0,0,0,30,0,0,0,1,0,0,0,71,0,4,0,51,0,0,0,30,0,0,0,0,0,0,0,19,0,2,0,2,0,0,0,33,0,3,0,3,0,0,0,2,0,0,0,22,0,3,0,6,0,0,0,32,0,0,0,23,0,4,0,7,0,0,0,6,0,0,0,4,0,0,0,32,0,4,0,8,0,0,0,7,0,0,0,7,0,0,0,25,0,9,0,10,0,0,0,6,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,27,0,3,0,11,0,0,0,10,0,0,0,32,0,4,0,12,0,0,0,0,0,0,0,11,0,0,0,59,0,4,0,12,0,0,0,13,0,0,0,0,0,0,0,23,0,4,0,15,0,0,0,6,0,0,0,2,0,0,0,32,0,4,0,16,0,0,0,1,0,0,0,15,0,0,0,59,0,4,0,16,0,0,0,17,0,0,0,1,0,0,0,23,0,4,0,20,0,0,0,6,0,0,0,3,0,0,0,32,0,4,0,21,0,0,0,7,0,0,0,20,0,0,0,21,0,4,0,23,0,0,0,32,0,0,0,0,0,0,0,43,0,4,0,23,0,0,0,24,0,0,0,6,0,0,0,28,0,4,0,25,0,0,0,20,0,0,0,24,0,0,0,43,0,4,0,6,0,0,0,26,0,0,0,0,0,128,63,44,0,6,0,20,0,0,0,27,0,0,0,26,0,0,0,26,0,0,0,26,0,0,0,43,0,4,0,6,0,0,0,28,0,0,0,176,172,172,62,43,0,4,0,6,0,0,0,29,0,0,0,232,244,244,62,43,0,4,0,6,0,0,0,30,0,0,0,227,227,99,63,44,0,6,0,20,0,0,0,31,0,0,0,28,0,0,0,29,0,0,0,30,0,0,0,43,0,4,0,6,0,0,0,32,0,0,0,173,192,64,62,43,0,4,0,6,0,0,0,33,0,0,0,115,128,128,61,44,0,6,0,20,0,0,0,34,0,0,0,26,0,0,0,32,0,0,0,33,0,0,0,43,0,4,0,6,0,0,0,35,0,0,0,235,228,100,63,43,0,4,0,6,0,0,0,36,0,0,0,146,148,20,62,44,0,6,0,20,0,0,0,37,0,0,0,35,0,0,0,36,0,0,0,26,0,0,0,43,0,4,0,6,0,0,0,38,0,0,0,235,224,224,61,43,0,4,0,6,0,0,0,39,0,0,0,242,237,109,63,43,0,4,0,6,0,0,0,40,0,0,0,111,160,160,61,44,0,6,0,20,0,0,0,41,0,0,0,38,0,0,0,39,0,0,0,40,0,0,0,44,0,9,0,25,0,0,0,42,0,0,0,27,0,0,0,27,0,0,0,31,0,0,0,34,0,0,0,37,0,0,0,41,0,0,0,32,0,4,0,43,0,0,0,1,0,0,0,23,0,0,0,59,0,4,0,43,0,0,0,44,0,0,0,1,0,0,0,32,0,4,0,46,0,0,0,7,0,0,0,25,0,0,0,32,0,4,0,50,0,0,0,3,0,0,0,7,0,0,0,59,0,4,0,50,0,0,0,51,0,0,0,3,0,0,0,43,0,4,0,23,0,0,0,52,0,0,0,0,0,0,0,32,0,4,0,53,0,0,0,7,0,0,0,6,0,0,0,43,0,4,0,23,0,0,0,59,0,0,0,1,0,0,0,43,0,4,0,23,0,0,0,65,0,0,0,2,0,0,0,43,0,4,0,23,0,0,0,71,0,0,0,3,0,0,0,54,0,5,0,2,0,0,0,4,0,0,0,0,0,0,0,3,0,0,0,248,0,2,0,5,0,0,0,59,0,4,0,8,0,0,0,9,0,0,0,7,0,0,0,59,0,4,0,21,0,0,0,22,0,0,0,7,0,0,0,59,0,4,0,46,0,0,0,47,0,0,0,7,0,0,0,61,0,4,0,11,0,0,0,14,0,0,0,13,0,0,0,61,0,4,0,15,0,0,0,18,0,0,0,17,0,0,0,87,0,5,0,7,0,0,0,19,0,0,0,14,0,0,0,18,0,0,0,62,0,3,0,9,0,0,0,19,0,0,0,61,0,4,0,23,0,0,0,45,0,0,0,44,0,0,0,62,0,3,0,47,0,0,0,42,0,0,0,65,0,5,0,21,0,0,0,48,0,0,0,47,0,0,0,45,0,0,0,61,0,4,0,20,0,0,0,49,0,0,0,48,0,0,0,62,0,3,0,22,0,0,0,49,0,0,0,65,0,5,0,53,0,0,0,54,0,0,0,9,0,0,0,52,0,0,0,61,0,4,0,6,0,0,0,55,0,0,0,54,0,0,0,65,0,5,0,53,0,0,0,56,0,0,0,22,0,0,0,52,0,0,0,61,0,4,0,6,0,0,0,57,0,0,0,56,0,0,0,133,0,5,0,6,0,0,0,58,0,0,0,55,0,0,0,57,0,0,0,65,0,5,0,53,0,0,0,60,0,0,0,9,0,0,0,59,0,0,0,61,0,4,0,6,0,0,0,61,0,0,0,60,0,0,0,65,0,5,0,53,0,0,0,62,0,0,0,22,0,0,0,59,0,0,0,61,0,4,0,6,0,0,0,63,0,0,0,62,0,0,0,133,0,5,0,6,0,0,0,64,0,0,0,61,0,0,0,63,0,0,0,65,0,5,0,53,0,0,0,66,0,0,0,9,0,0,0,65,0,0,0,61,0,4,0,6,0,0,0,67,0,0,0,66,0,0,0,65,0,5,0,53,0,0,0,68,0,0,0,22,0,0,0,65,0,0,0,61,0,4,0,6,0,0,0,69,0,0,0,68,0,0,0,133,0,5,0,6,0,0,0,70,0,0,0,67,0,0,0,69,0,0,0,65,0,5,0,53,0,0,0,72,0,0,0,9,0,0,0,71,0,0,0,61,0,4,0,6,0,0,0,73,0,0,0,72,0,0,0,80,0,7,0,7,0,0,0,74,0,0,0,58,0,0,0,64,0,0,0,70,0,0,0,73,0,0,0,62,0,3,0,51,0,0,0,74,0,0,0,253,0,1,0,56,0,1,0};
uint8_t bufshadervertblks[] = {3,2,35,7,0,0,1,0,10,0,13,0,57,0,0,0,0,0,0,0,17,0,2,0,1,0,0,0,11,0,6,0,1,0,0,0,71,76,83,76,46,115,116,100,46,52,53,48,0,0,0,0,14,0,3,0,0,0,0,0,1,0,0,0,15,0,9,0,0,0,0,0,4,0,0,0,109,97,105,110,0,0,0,0,9,0,0,0,12,0,0,0,29,0,0,0,34,0,0,0,3,0,3,0,2,0,0,0,144,1,0,0,4,0,9,0,71,76,95,65,82,66,95,115,101,112,97,114,97,116,101,95,115,104,97,100,101,114,95,111,98,106,101,99,116,115,0,0,4,0,9,0,71,76,95,65,82,66,95,115,104,97,100,105,110,103,95,108,97,110,103,117,97,103,101,95,52,50,48,112,97,99,107,0,4,0,10,0,71,76,95,71,79,79,71,76,69,95,99,112,112,95,115,116,121,108,101,95,108,105,110,101,95,100,105,114,101,99,116,105,118,101,0,0,4,0,8,0,71,76,95,71,79,79,71,76,69,95,105,110,99,108,117,100,101,95,100,105,114,101,99,116,105,118,101,0,5,0,4,0,4,0,0,0,109,97,105,110,0,0,0,0,5,0,5,0,9,0,0,0,99,111,108,111,114,111,117,116,0,0,0,0,5,0,4,0,12,0,0,0,99,111,108,111,114,105,110,0,5,0,6,0,27,0,0,0,103,108,95,80,101,114,86,101,114,116,101,120,0,0,0,0,6,0,6,0,27,0,0,0,0,0,0,0,103,108,95,80,111,115,105,116,105,111,110,0,6,0,7,0,27,0,0,0,1,0,0,0,103,108,95,80,111,105,110,116,83,105,122,101,0,0,0,0,6,0,7,0,27,0,0,0,2,0,0,0,103,108,95,67,108,105,112,68,105,115,116,97,110,99,101,0,5,0,3,0,29,0,0,0,0,0,0,0,5,0,3,0,34,0,0,0,112,111,115,0,5,0,4,0,38,0,0,0,83,99,97,108,101,0,0,0,6,0,4,0,38,0,0,0,0,0,0,0,120,0,0,0,6,0,4,0,38,0,0,0,1,0,0,0,121,0,0,0,5,0,4,0,40,0,0,0,115,99,97,108,101,0,0,0,71,0,4,0,9,0,0,0,30,0,0,0,0,0,0,0,71,0,4,0,12,0,0,0,30,0,0,0,1,0,0,0,72,0,5,0,27,0,0,0,0,0,0,0,11,0,0,0,0,0,0,0,72,0,5,0,27,0,0,0,1,0,0,0,11,0,0,0,1,0,0,0,72,0,5,0,27,0,0,0,2,0,0,0,11,0,0,0,3,0,0,0,71,0,3,0,27,0,0,0,2,0,0,0,71,0,4,0,34,0,0,0,30,0,0,0,0,0,0,0,72,0,5,0,38,0,0,0,0,0,0,0,35,0,0,0,0,0,0,0,72,0,5,0,38,0,0,0,1,0,0,0,35,0,0,0,4,0,0,0,71,0,3,0,38,0,0,0,2,0,0,0,19,0,2,0,2,0,0,0,33,0,3,0,3,0,0,0,2,0,0,0,22,0,3,0,6,0,0,0,32,0,0,0,23,0,4,0,7,0,0,0,6,0,0,0,4,0,0,0,32,0,4,0,8,0,0,0,3,0,0,0,7,0,0,0,59,0,4,0,8,0,0,0,9,0,0,0,3,0,0,0,21,0,4,0,10,0,0,0,32,0,0,0,0,0,0,0,32,0,4,0,11,0,0,0,1,0,0,0,10,0,0,0,59,0,4,0,11,0,0,0,12,0,0,0,1,0,0,0,43,0,4,0,10,0,0,0,14,0,0,0,0,0,0,0,20,0,2,0,15,0,0,0,43,0,4,0,6,0,0,0,17,0,0,0,0,0,128,62,43,0,4,0,6,0,0,0,18,0,0,0,0,0,128,63,44,0,7,0,7,0,0,0,19,0,0,0,17,0,0,0,17,0,0,0,17,0,0,0,18,0,0,0,43,0,4,0,6,0,0,0,20,0,0,0,0,0,0,63,44,0,7,0,7,0,0,0,21,0,0,0,20,0,0,0,20,0,0,0,20,0,0,0,18,0,0,0,23,0,4,0,22,0,0,0,15,0,0,0,4,0,0,0,43,0,4,0,10,0,0,0,25,0,0,0,1,0,0,0,28,0,4,0,26,0,0,0,6,0,0,0,25,0,0,0,30,0,5,0,27,0,0,0,7,0,0,0,6,0,0,0,26,0,0,0,32,0,4,0,28,0,0,0,3,0,0,0,27,0,0,0,59,0,4,0,28,0,0,0,29,0,0,0,3,0,0,0,21,0,4,0,30,0,0,0,32,0,0,0,1,0,0,0,43,0,4,0,30,0,0,0,31,0,0,0,0,0,0,0,23,0,4,0,32,0,0,0,6,0,0,0,2,0,0,0,32,0,4,0,33,0,0,0,1,0,0,0,32,0,0,0,59,0,4,0,33,0,0,0,34,0,0,0,1,0,0,0,32,0,4,0,35,0,0,0,1,0,0,0,6,0,0,0,30,0,4,0,38,0,0,0,6,0,0,0,6,0,0,0,32,0,4,0,39,0,0,0,9,0,0,0,38,0,0,0,59,0,4,0,39,0,0,0,40,0,0,0,9,0,0,0,32,0,4,0,41,0,0,0,9,0,0,0,6,0,0,0,43,0,4,0,30,0,0,0,48,0,0,0,1,0,0,0,43,0,4,0,6,0,0,0,54,0,0,0,0,0,0,0,54,0,5,0,2,0,0,0,4,0,0,0,0,0,0,0,3,0,0,0,248,0,2,0,5,0,0,0,61,0,4,0,10,0,0,0,13,0,0,0,12,0,0,0,170,0,5,0,15,0,0,0,16,0,0,0,13,0,0,0,14,0,0,0,80,0,7,0,22,0,0,0,23,0,0,0,16,0,0,0,16,0,0,0,16,0,0,0,16,0,0,0,169,0,6,0,7,0,0,0,24,0,0,0,23,0,0,0,19,0,0,0,21,0,0,0,62,0,3,0,9,0,0,0,24,0,0,0,65,0,5,0,35,0,0,0,36,0,0,0,34,0,0,0,14,0,0,0,61,0,4,0,6,0,0,0,37,0,0,0,36,0,0,0,65,0,5,0,41,0,0,0,42,0,0,0,40,0,0,0,31,0,0,0,61,0,4,0,6,0,0,0,43,0,0,0,42,0,0,0,136,0,5,0,6,0,0,0,44,0,0,0,37,0,0,0,43,0,0,0,131,0,5,0,6,0,0,0,45,0,0,0,44,0,0,0,18,0,0,0,65,0,5,0,35,0,0,0,46,0,0,0,34,0,0,0,25,0,0,0,61,0,4,0,6,0,0,0,47,0,0,0,46,0,0,0,65,0,5,0,41,0,0,0,49,0,0,0,40,0,0,0,48,0,0,0,61,0,4,0,6,0,0,0,50,0,0,0,49,0,0,0,136,0,5,0,6,0,0,0,51,0,0,0,47,0,0,0,50,0,0,0,129,0,5,0,6,0,0,0,52,0,0,0,51,0,0,0,18,0,0,0,127,0,4,0,6,0,0,0,53,0,0,0,52,0,0,0,80,0,7,0,7,0,0,0,55,0,0,0,45,0,0,0,53,0,0,0,54,0,0,0,18,0,0,0,65,0,5,0,8,0,0,0,56,0,0,0,29,0,0,0,31,0,0,0,62,0,3,0,56,0,0,0,55,0,0,0,253,0,1,0,56,0,1,0};
uint8_t bufshaderfragblks[] = {3,2,35,7,0,0,1,0,10,0,13,0,13,0,0,0,0,0,0,0,17,0,2,0,1,0,0,0,11,0,6,0,1,0,0,0,71,76,83,76,46,115,116,100,46,52,53,48,0,0,0,0,14,0,3,0,0,0,0,0,1,0,0,0,15,0,7,0,4,0,0,0,4,0,0,0,109,97,105,110,0,0,0,0,9,0,0,0,11,0,0,0,16,0,3,0,4,0,0,0,7,0,0,0,3,0,3,0,2,0,0,0,144,1,0,0,4,0,9,0,71,76,95,65,82,66,95,115,101,112,97,114,97,116,101,95,115,104,97,100,101,114,95,111,98,106,101,99,116,115,0,0,4,0,9,0,71,76,95,65,82,66,95,115,104,97,100,105,110,103,95,108,97,110,103,117,97,103,101,95,52,50,48,112,97,99,107,0,4,0,10,0,71,76,95,71,79,79,71,76,69,95,99,112,112,95,115,116,121,108,101,95,108,105,110,101,95,100,105,114,101,99,116,105,118,101,0,0,4,0,8,0,71,76,95,71,79,79,71,76,69,95,105,110,99,108,117,100,101,95,100,105,114,101,99,116,105,118,101,0,5,0,4,0,4,0,0,0,109,97,105,110,0,0,0,0,5,0,5,0,9,0,0,0,117,70,114,97,103,67,111,108,111,114,0,0,5,0,4,0,11,0,0,0,99,111,108,111,114,0,0,0,71,0,4,0,9,0,0,0,30,0,0,0,0,0,0,0,71,0,4,0,11,0,0,0,30,0,0,0,0,0,0,0,19,0,2,0,2,0,0,0,33,0,3,0,3,0,0,0,2,0,0,0,22,0,3,0,6,0,0,0,32,0,0,0,23,0,4,0,7,0,0,0,6,0,0,0,4,0,0,0,32,0,4,0,8,0,0,0,3,0,0,0,7,0,0,0,59,0,4,0,8,0,0,0,9,0,0,0,3,0,0,0,32,0,4,0,10,0,0,0,1,0,0,0,7,0,0,0,59,0,4,0,10,0,0,0,11,0,0,0,1,0,0,0,54,0,5,0,2,0,0,0,4,0,0,0,0,0,0,0,3,0,0,0,248,0,2,0,5,0,0,0,61,0,4,0,7,0,0,0,12,0,0,0,11,0,0,0,62,0,3,0,9,0,0,0,12,0,0,0,253,0,1,0,56,0,1,0};
uint8_t bufshadervertund[] = {3,2,35,7,0,0,1,0,10,0,13,0,44,0,0,0,0,0,0,0,17,0,2,0,1,0,0,0,11,0,6,0,1,0,0,0,71,76,83,76,46,115,116,100,46,52,53,48,0,0,0,0,14,0,3,0,0,0,0,0,1,0,0,0,15,0,7,0,0,0,0,0,4,0,0,0,109,97,105,110,0,0,0,0,13,0,0,0,18,0,0,0,3,0,3,0,2,0,0,0,144,1,0,0,4,0,9,0,71,76,95,65,82,66,95,115,101,112,97,114,97,116,101,95,115,104,97,100,101,114,95,111,98,106,101,99,116,115,0,0,4,0,9,0,71,76,95,65,82,66,95,115,104,97,100,105,110,103,95,108,97,110,103,117,97,103,101,95,52,50,48,112,97,99,107,0,4,0,10,0,71,76,95,71,79,79,71,76,69,95,99,112,112,95,115,116,121,108,101,95,108,105,110,101,95,100,105,114,101,99,116,105,118,101,0,0,4,0,8,0,71,76,95,71,79,79,71,76,69,95,105,110,99,108,117,100,101,95,100,105,114,101,99,116,105,118,101,0,5,0,4,0,4,0,0,0,109,97,105,110,0,0,0,0,5,0,6,0,11,0,0,0,103,108,95,80,101,114,86,101,114,116,101,120,0,0,0,0,6,0,6,0,11,0,0,0,0,0,0,0,103,108,95,80,111,115,105,116,105,111,110,0,6,0,7,0,11,0,0,0,1,0,0,0,103,108,95,80,111,105,110,116,83,105,122,101,0,0,0,0,6,0,7,0,11,0,0,0,2,0,0,0,103,108,95,67,108,105,112,68,105,115,116,97,110,99,101,0,5,0,3,0,13,0,0,0,0,0,0,0,5,0,3,0,18,0,0,0,112,111,115,0,5,0,4,0,23,0,0,0,83,99,97,108,101,0,0,0,6,0,4,0,23,0,0,0,0,0,0,0,120,0,0,0,6,0,4,0,23,0,0,0,1,0,0,0,121,0,0,0,5,0,4,0,25,0,0,0,115,99,97,108,101,0,0,0,72,0,5,0,11,0,0,0,0,0,0,0,11,0,0,0,0,0,0,0,72,0,5,0,11,0,0,0,1,0,0,0,11,0,0,0,1,0,0,0,72,0,5,0,11,0,0,0,2,0,0,0,11,0,0,0,3,0,0,0,71,0,3,0,11,0,0,0,2,0,0,0,71,0,4,0,18,0,0,0,30,0,0,0,0,0,0,0,72,0,5,0,23,0,0,0,0,0,0,0,35,0,0,0,0,0,0,0,72,0,5,0,23,0,0,0,1,0,0,0,35,0,0,0,4,0,0,0,71,0,3,0,23,0,0,0,2,0,0,0,19,0,2,0,2,0,0,0,33,0,3,0,3,0,0,0,2,0,0,0,22,0,3,0,6,0,0,0,32,0,0,0,23,0,4,0,7,0,0,0,6,0,0,0,4,0,0,0,21,0,4,0,8,0,0,0,32,0,0,0,0,0,0,0,43,0,4,0,8,0,0,0,9,0,0,0,1,0,0,0,28,0,4,0,10,0,0,0,6,0,0,0,9,0,0,0,30,0,5,0,11,0,0,0,7,0,0,0,6,0,0,0,10,0,0,0,32,0,4,0,12,0,0,0,3,0,0,0,11,0,0,0,59,0,4,0,12,0,0,0,13,0,0,0,3,0,0,0,21,0,4,0,14,0,0,0,32,0,0,0,1,0,0,0,43,0,4,0,14,0,0,0,15,0,0,0,0,0,0,0,23,0,4,0,16,0,0,0,6,0,0,0,2,0,0,0,32,0,4,0,17,0,0,0,1,0,0,0,16,0,0,0,59,0,4,0,17,0,0,0,18,0,0,0,1,0,0,0,43,0,4,0,8,0,0,0,19,0,0,0,0,0,0,0,32,0,4,0,20,0,0,0,1,0,0,0,6,0,0,0,30,0,4,0,23,0,0,0,6,0,0,0,6,0,0,0,32,0,4,0,24,0,0,0,9,0,0,0,23,0,0,0,59,0,4,0,24,0,0,0,25,0,0,0,9,0,0,0,32,0,4,0,26,0,0,0,9,0,0,0,6,0,0,0,43,0,4,0,6,0,0,0,30,0,0,0,0,0,128,63,43,0,4,0,14,0,0,0,34,0,0,0,1,0,0,0,43,0,4,0,6,0,0,0,40,0,0,0,0,0,0,0,32,0,4,0,42,0,0,0,3,0,0,0,7,0,0,0,54,0,5,0,2,0,0,0,4,0,0,0,0,0,0,0,3,0,0,0,248,0,2,0,5,0,0,0,65,0,5,0,20,0,0,0,21,0,0,0,18,0,0,0,19,0,0,0,61,0,4,0,6,0,0,0,22,0,0,0,21,0,0,0,65,0,5,0,26,0,0,0,27,0,0,0,25,0,0,0,15,0,0,0,61,0,4,0,6,0,0,0,28,0,0,0,27,0,0,0,136,0,5,0,6,0,0,0,29,0,0,0,22,0,0,0,28,0,0,0,131,0,5,0,6,0,0,0,31,0,0,0,29,0,0,0,30,0,0,0,65,0,5,0,20,0,0,0,32,0,0,0,18,0,0,0,9,0,0,0,61,0,4,0,6,0,0,0,33,0,0,0,32,0,0,0,65,0,5,0,26,0,0,0,35,0,0,0,25,0,0,0,34,0,0,0,61,0,4,0,6,0,0,0,36,0,0,0,35,0,0,0,136,0,5,0,6,0,0,0,37,0,0,0,33,0,0,0,36,0,0,0,129,0,5,0,6,0,0,0,38,0,0,0,37,0,0,0,30,0,0,0,127,0,4,0,6,0,0,0,39,0,0,0,38,0,0,0,80,0,7,0,7,0,0,0,41,0,0,0,31,0,0,0,39,0,0,0,40,0,0,0,30,0,0,0,65,0,5,0,42,0,0,0,43,0,0,0,13,0,0,0,15,0,0,0,62,0,3,0,43,0,0,0,41,0,0,0,253,0,1,0,56,0,1,0};
uint8_t bufshaderfragund[] = {3,2,35,7,0,0,1,0,10,0,13,0,12,0,0,0,0,0,0,0,17,0,2,0,1,0,0,0,11,0,6,0,1,0,0,0,71,76,83,76,46,115,116,100,46,52,53,48,0,0,0,0,14,0,3,0,0,0,0,0,1,0,0,0,15,0,6,0,4,0,0,0,4,0,0,0,109,97,105,110,0,0,0,0,9,0,0,0,16,0,3,0,4,0,0,0,7,0,0,0,3,0,3,0,2,0,0,0,144,1,0,0,4,0,9,0,71,76,95,65,82,66,95,115,101,112,97,114,97,116,101,95,115,104,97,100,101,114,95,111,98,106,101,99,116,115,0,0,4,0,9,0,71,76,95,65,82,66,95,115,104,97,100,105,110,103,95,108,97,110,103,117,97,103,101,95,52,50,48,112,97,99,107,0,4,0,10,0,71,76,95,71,79,79,71,76,69,95,99,112,112,95,115,116,121,108,101,95,108,105,110,101,95,100,105,114,101,99,116,105,118,101,0,0,4,0,8,0,71,76,95,71,79,79,71,76,69,95,105,110,99,108,117,100,101,95,100,105,114,101,99,116,105,118,101,0,5,0,4,0,4,0,0,0,109,97,105,110,0,0,0,0,5,0,5,0,9,0,0,0,117,70,114,97,103,67,111,108,111,114,0,0,71,0,4,0,9,0,0,0,30,0,0,0,0,0,0,0,19,0,2,0,2,0,0,0,33,0,3,0,3,0,0,0,2,0,0,0,22,0,3,0,6,0,0,0,32,0,0,0,23,0,4,0,7,0,0,0,6,0,0,0,4,0,0,0,32,0,4,0,8,0,0,0,3,0,0,0,7,0,0,0,59,0,4,0,8,0,0,0,9,0,0,0,3,0,0,0,43,0,4,0,6,0,0,0,10,0,0,0,0,0,128,63,44,0,7,0,7,0,0,0,11,0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,54,0,5,0,2,0,0,0,4,0,0,0,0,0,0,0,3,0,0,0,248,0,2,0,5,0,0,0,62,0,3,0,9,0,0,0,11,0,0,0,253,0,1,0,56,0,1,0};
uint8_t bufshadervertcur[] = {3,2,35,7,0,0,1,0,10,0,13,0,44,0,0,0,0,0,0,0,17,0,2,0,1,0,0,0,11,0,6,0,1,0,0,0,71,76,83,76,46,115,116,100,46,52,53,48,0,0,0,0,14,0,3,0,0,0,0,0,1,0,0,0,15,0,7,0,0,0,0,0,4,0,0,0,109,97,105,110,0,0,0,0,13,0,0,0,18,0,0,0,3,0,3,0,2,0,0,0,144,1,0,0,4,0,9,0,71,76,95,65,82,66,95,115,101,112,97,114,97,116,101,95,115,104,97,100,101,114,95,111,98,106,101,99,116,115,0,0,4,0,9,0,71,76,95,65,82,66,95,115,104,97,100,105,110,103,95,108,97,110,103,117,97,103,101,95,52,50,48,112,97,99,107,0,4,0,10,0,71,76,95,71,79,79,71,76,69,95,99,112,112,95,115,116,121,108,101,95,108,105,110,101,95,100,105,114,101,99,116,105,118,101,0,0,4,0,8,0,71,76,95,71,79,79,71,76,69,95,105,110,99,108,117,100,101,95,100,105,114,101,99,116,105,118,101,0,5,0,4,0,4,0,0,0,109,97,105,110,0,0,0,0,5,0,6,0,11,0,0,0,103,108,95,80,101,114,86,101,114,116,101,120,0,0,0,0,6,0,6,0,11,0,0,0,0,0,0,0,103,108,95,80,111,115,105,116,105,111,110,0,6,0,7,0,11,0,0,0,1,0,0,0,103,108,95,80,111,105,110,116,83,105,122,101,0,0,0,0,6,0,7,0,11,0,0,0,2,0,0,0,103,108,95,67,108,105,112,68,105,115,116,97,110,99,101,0,5,0,3,0,13,0,0,0,0,0,0,0,5,0,3,0,18,0,0,0,112,111,115,0,5,0,4,0,23,0,0,0,83,99,97,108,101,0,0,0,6,0,4,0,23,0,0,0,0,0,0,0,120,0,0,0,6,0,4,0,23,0,0,0,1,0,0,0,121,0,0,0,5,0,4,0,25,0,0,0,115,99,97,108,101,0,0,0,72,0,5,0,11,0,0,0,0,0,0,0,11,0,0,0,0,0,0,0,72,0,5,0,11,0,0,0,1,0,0,0,11,0,0,0,1,0,0,0,72,0,5,0,11,0,0,0,2,0,0,0,11,0,0,0,3,0,0,0,71,0,3,0,11,0,0,0,2,0,0,0,71,0,4,0,18,0,0,0,30,0,0,0,0,0,0,0,72,0,5,0,23,0,0,0,0,0,0,0,35,0,0,0,0,0,0,0,72,0,5,0,23,0,0,0,1,0,0,0,35,0,0,0,4,0,0,0,71,0,3,0,23,0,0,0,2,0,0,0,19,0,2,0,2,0,0,0,33,0,3,0,3,0,0,0,2,0,0,0,22,0,3,0,6,0,0,0,32,0,0,0,23,0,4,0,7,0,0,0,6,0,0,0,4,0,0,0,21,0,4,0,8,0,0,0,32,0,0,0,0,0,0,0,43,0,4,0,8,0,0,0,9,0,0,0,1,0,0,0,28,0,4,0,10,0,0,0,6,0,0,0,9,0,0,0,30,0,5,0,11,0,0,0,7,0,0,0,6,0,0,0,10,0,0,0,32,0,4,0,12,0,0,0,3,0,0,0,11,0,0,0,59,0,4,0,12,0,0,0,13,0,0,0,3,0,0,0,21,0,4,0,14,0,0,0,32,0,0,0,1,0,0,0,43,0,4,0,14,0,0,0,15,0,0,0,0,0,0,0,23,0,4,0,16,0,0,0,6,0,0,0,2,0,0,0,32,0,4,0,17,0,0,0,1,0,0,0,16,0,0,0,59,0,4,0,17,0,0,0,18,0,0,0,1,0,0,0,43,0,4,0,8,0,0,0,19,0,0,0,0,0,0,0,32,0,4,0,20,0,0,0,1,0,0,0,6,0,0,0,30,0,4,0,23,0,0,0,6,0,0,0,6,0,0,0,32,0,4,0,24,0,0,0,9,0,0,0,23,0,0,0,59,0,4,0,24,0,0,0,25,0,0,0,9,0,0,0,32,0,4,0,26,0,0,0,9,0,0,0,6,0,0,0,43,0,4,0,6,0,0,0,30,0,0,0,0,0,128,63,43,0,4,0,14,0,0,0,34,0,0,0,1,0,0,0,43,0,4,0,6,0,0,0,40,0,0,0,0,0,0,0,32,0,4,0,42,0,0,0,3,0,0,0,7,0,0,0,54,0,5,0,2,0,0,0,4,0,0,0,0,0,0,0,3,0,0,0,248,0,2,0,5,0,0,0,65,0,5,0,20,0,0,0,21,0,0,0,18,0,0,0,19,0,0,0,61,0,4,0,6,0,0,0,22,0,0,0,21,0,0,0,65,0,5,0,26,0,0,0,27,0,0,0,25,0,0,0,15,0,0,0,61,0,4,0,6,0,0,0,28,0,0,0,27,0,0,0,136,0,5,0,6,0,0,0,29,0,0,0,22,0,0,0,28,0,0,0,131,0,5,0,6,0,0,0,31,0,0,0,29,0,0,0,30,0,0,0,65,0,5,0,20,0,0,0,32,0,0,0,18,0,0,0,9,0,0,0,61,0,4,0,6,0,0,0,33,0,0,0,32,0,0,0,65,0,5,0,26,0,0,0,35,0,0,0,25,0,0,0,34,0,0,0,61,0,4,0,6,0,0,0,36,0,0,0,35,0,0,0,136,0,5,0,6,0,0,0,37,0,0,0,33,0,0,0,36,0,0,0,129,0,5,0,6,0,0,0,38,0,0,0,37,0,0,0,30,0,0,0,127,0,4,0,6,0,0,0,39,0,0,0,38,0,0,0,80,0,7,0,7,0,0,0,41,0,0,0,31,0,0,0,39,0,0,0,40,0,0,0,30,0,0,0,65,0,5,0,42,0,0,0,43,0,0,0,13,0,0,0,15,0,0,0,62,0,3,0,43,0,0,0,41,0,0,0,253,0,1,0,56,0,1,0};
uint8_t bufshaderfragcur[] = {3,2,35,7,0,0,1,0,10,0,13,0,12,0,0,0,0,0,0,0,17,0,2,0,1,0,0,0,11,0,6,0,1,0,0,0,71,76,83,76,46,115,116,100,46,52,53,48,0,0,0,0,14,0,3,0,0,0,0,0,1,0,0,0,15,0,6,0,4,0,0,0,4,0,0,0,109,97,105,110,0,0,0,0,9,0,0,0,16,0,3,0,4,0,0,0,7,0,0,0,3,0,3,0,2,0,0,0,144,1,0,0,4,0,9,0,71,76,95,65,82,66,95,115,101,112,97,114,97,116,101,95,115,104,97,100,101,114,95,111,98,106,101,99,116,115,0,0,4,0,9,0,71,76,95,65,82,66,95,115,104,97,100,105,110,103,95,108,97,110,103,117,97,103,101,95,52,50,48,112,97,99,107,0,4,0,10,0,71,76,95,71,79,79,71,76,69,95,99,112,112,95,115,116,121,108,101,95,108,105,110,101,95,100,105,114,101,99,116,105,118,101,0,0,4,0,8,0,71,76,95,71,79,79,71,76,69,95,105,110,99,108,117,100,101,95,100,105,114,101,99,116,105,118,101,0,5,0,4,0,4,0,0,0,109,97,105,110,0,0,0,0,5,0,5,0,9,0,0,0,117,70,114,97,103,67,111,108,111,114,0,0,71,0,4,0,9,0,0,0,30,0,0,0,0,0,0,0,19,0,2,0,2,0,0,0,33,0,3,0,3,0,0,0,2,0,0,0,22,0,3,0,6,0,0,0,32,0,0,0,23,0,4,0,7,0,0,0,6,0,0,0,4,0,0,0,32,0,4,0,8,0,0,0,3,0,0,0,7,0,0,0,59,0,4,0,8,0,0,0,9,0,0,0,3,0,0,0,43,0,4,0,6,0,0,0,10,0,0,0,0,0,128,63,44,0,7,0,7,0,0,0,11,0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,54,0,5,0,2,0,0,0,4,0,0,0,0,0,0,0,3,0,0,0,248,0,2,0,5,0,0,0,62,0,3,0,9,0,0,0,11,0,0,0,253,0,1,0,56,0,1,0};
uint8_t bufshaderverttextov[] = {3,2,35,7,0,0,1,0,10,0,13,0,48,0,0,0,0,0,0,0,17,0,2,0,1,0,0,0,11,0,6,0,1,0,0,0,71,76,83,76,46,115,116,100,46,52,53,48,0,0,0,0,14,0,3,0,0,0,0,0,1,0,0,0,15,0,9,0,0,0,0,0,4,0,0,0,109,97,105,110,0,0,0,0,9,0,0,0,11,0,0,0,19,0,0,0,22,0,0,0,3,0,3,0,2,0,0,0,144,1,0,0,4,0,9,0,71,76,95,65,82,66,95,115,101,112,97,114,97,116,101,95,115,104,97,100,101,114,95,111,98,106,101,99,116,115,0,0,4,0,9,0,71,76,95,65,82,66,95,115,104,97,100,105,110,103,95,108,97,110,103,117,97,103,101,95,52,50,48,112,97,99,107,0,4,0,10,0,71,76,95,71,79,79,71,76,69,95,99,112,112,95,115,116,121,108,101,95,108,105,110,101,95,100,105,114,101,99,116,105,118,101,0,0,4,0,8,0,71,76,95,71,79,79,71,76,69,95,105,110,99,108,117,100,101,95,100,105,114,101,99,116,105,118,101,0,5,0,4,0,4,0,0,0,109,97,105,110,0,0,0,0,5,0,5,0,9,0,0,0,116,101,120,99,111,111,114,100,111,117,116,0,5,0,5,0,11,0,0,0,116,101,120,99,111,111,114,100,105,110,0,0,5,0,6,0,17,0,0,0,103,108,95,80,101,114,86,101,114,116,101,120,0,0,0,0,6,0,6,0,17,0,0,0,0,0,0,0,103,108,95,80,111,115,105,116,105,111,110,0,6,0,7,0,17,0,0,0,1,0,0,0,103,108,95,80,111,105,110,116,83,105,122,101,0,0,0,0,6,0,7,0,17,0,0,0,2,0,0,0,103,108,95,67,108,105,112,68,105,115,116,97,110,99,101,0,5,0,3,0,19,0,0,0,0,0,0,0,5,0,3,0,22,0,0,0,112,111,115,0,5,0,4,0,27,0,0,0,83,99,97,108,101,0,0,0,6,0,4,0,27,0,0,0,0,0,0,0,120,0,0,0,6,0,4,0,27,0,0,0,1,0,0,0,121,0,0,0,5,0,4,0,29,0,0,0,115,99,97,108,101,0,0,0,71,0,4,0,9,0,0,0,30,0,0,0,0,0,0,0,71,0,4,0,11,0,0,0,30,0,0,0,1,0,0,0,72,0,5,0,17,0,0,0,0,0,0,0,11,0,0,0,0,0,0,0,72,0,5,0,17,0,0,0,1,0,0,0,11,0,0,0,1,0,0,0,72,0,5,0,17,0,0,0,2,0,0,0,11,0,0,0,3,0,0,0,71,0,3,0,17,0,0,0,2,0,0,0,71,0,4,0,22,0,0,0,30,0,0,0,0,0,0,0,72,0,5,0,27,0,0,0,0,0,0,0,35,0,0,0,0,0,0,0,72,0,5,0,27,0,0,0,1,0,0,0,35,0,0,0,4,0,0,0,71,0,3,0,27,0,0,0,2,0,0,0,19,0,2,0,2,0,0,0,33,0,3,0,3,0,0,0,2,0,0,0,22,0,3,0,6,0,0,0,32,0,0,0,23,0,4,0,7,0,0,0,6,0,0,0,2,0,0,0,32,0,4,0,8,0,0,0,3,0,0,0,7,0,0,0,59,0,4,0,8,0,0,0,9,0,0,0,3,0,0,0,32,0,4,0,10,0,0,0,1,0,0,0,7,0,0,0,59,0,4,0,10,0,0,0,11,0,0,0,1,0,0,0,23,0,4,0,13,0,0,0,6,0,0,0,4,0,0,0,21,0,4,0,14,0,0,0,32,0,0,0,0,0,0,0,43,0,4,0,14,0,0,0,15,0,0,0,1,0,0,0,28,0,4,0,16,0,0,0,6,0,0,0,15,0,0,0,30,0,5,0,17,0,0,0,13,0,0,0,6,0,0,0,16,0,0,0,32,0,4,0,18,0,0,0,3,0,0,0,17,0,0,0,59,0,4,0,18,0,0,0,19,0,0,0,3,0,0,0,21,0,4,0,20,0,0,0,32,0,0,0,1,0,0,0,43,0,4,0,20,0,0,0,21,0,0,0,0,0,0,0,59,0,4,0,10,0,0,0,22,0,0,0,1,0,0,0,43,0,4,0,14,0,0,0,23,0,0,0,0,0,0,0,32,0,4,0,24,0,0,0,1,0,0,0,6,0,0,0,30,0,4,0,27,0,0,0,6,0,0,0,6,0,0,0,32,0,4,0,28,0,0,0,9,0,0,0,27,0,0,0,59,0,4,0,28,0,0,0,29,0,0,0,9,0,0,0,32,0,4,0,30,0,0,0,9,0,0,0,6,0,0,0,43,0,4,0,6,0,0,0,34,0,0,0,0,0,128,63,43,0,4,0,20,0,0,0,38,0,0,0,1,0,0,0,43,0,4,0,6,0,0,0,44,0,0,0,0,0,0,0,32,0,4,0,46,0,0,0,3,0,0,0,13,0,0,0,54,0,5,0,2,0,0,0,4,0,0,0,0,0,0,0,3,0,0,0,248,0,2,0,5,0,0,0,61,0,4,0,7,0,0,0,12,0,0,0,11,0,0,0,62,0,3,0,9,0,0,0,12,0,0,0,65,0,5,0,24,0,0,0,25,0,0,0,22,0,0,0,23,0,0,0,61,0,4,0,6,0,0,0,26,0,0,0,25,0,0,0,65,0,5,0,30,0,0,0,31,0,0,0,29,0,0,0,21,0,0,0,61,0,4,0,6,0,0,0,32,0,0,0,31,0,0,0,136,0,5,0,6,0,0,0,33,0,0,0,26,0,0,0,32,0,0,0,131,0,5,0,6,0,0,0,35,0,0,0,33,0,0,0,34,0,0,0,65,0,5,0,24,0,0,0,36,0,0,0,22,0,0,0,15,0,0,0,61,0,4,0,6,0,0,0,37,0,0,0,36,0,0,0,65,0,5,0,30,0,0,0,39,0,0,0,29,0,0,0,38,0,0,0,61,0,4,0,6,0,0,0,40,0,0,0,39,0,0,0,136,0,5,0,6,0,0,0,41,0,0,0,37,0,0,0,40,0,0,0,129,0,5,0,6,0,0,0,42,0,0,0,41,0,0,0,34,0,0,0,127,0,4,0,6,0,0,0,43,0,0,0,42,0,0,0,80,0,7,0,13,0,0,0,45,0,0,0,35,0,0,0,43,0,0,0,44,0,0,0,34,0,0,0,65,0,5,0,46,0,0,0,47,0,0,0,19,0,0,0,21,0,0,0,62,0,3,0,47,0,0,0,45,0,0,0,253,0,1,0,56,0,1,0};
uint8_t bufshaderfragtextov[] = {3,2,35,7,0,0,1,0,10,0,13,0,52,0,0,0,0,0,0,0,17,0,2,0,1,0,0,0,11,0,6,0,1,0,0,0,71,76,83,76,46,115,116,100,46,52,53,48,0,0,0,0,14,0,3,0,0,0,0,0,1,0,0,0,15,0,7,0,4,0,0,0,4,0,0,0,109,97,105,110,0,0,0,0,17,0,0,0,27,0,0,0,16,0,3,0,4,0,0,0,7,0,0,0,3,0,3,0,2,0,0,0,144,1,0,0,4,0,9,0,71,76,95,65,82,66,95,115,101,112,97,114,97,116,101,95,115,104,97,100,101,114,95,111,98,106,101,99,116,115,0,0,4,0,9,0,71,76,95,65,82,66,95,115,104,97,100,105,110,103,95,108,97,110,103,117,97,103,101,95,52,50,48,112,97,99,107,0,4,0,10,0,71,76,95,71,79,79,71,76,69,95,99,112,112,95,115,116,121,108,101,95,108,105,110,101,95,100,105,114,101,99,116,105,118,101,0,0,4,0,8,0,71,76,95,71,79,79,71,76,69,95,105,110,99,108,117,100,101,95,100,105,114,101,99,116,105,118,101,0,5,0,4,0,4,0,0,0,109,97,105,110,0,0,0,0,5,0,3,0,9,0,0,0,116,101,120,0,5,0,3,0,13,0,0,0,116,101,120,0,5,0,5,0,17,0,0,0,116,101,120,99,111,111,114,100,0,0,0,0,5,0,4,0,22,0,0,0,99,111,108,111,114,0,0,0,5,0,5,0,27,0,0,0,117,70,114,97,103,67,111,108,111,114,0,0,71,0,4,0,13,0,0,0,34,0,0,0,0,0,0,0,71,0,4,0,13,0,0,0,33,0,0,0,0,0,0,0,71,0,4,0,17,0,0,0,30,0,0,0,0,0,0,0,71,0,4,0,27,0,0,0,30,0,0,0,0,0,0,0,19,0,2,0,2,0,0,0,33,0,3,0,3,0,0,0,2,0,0,0,22,0,3,0,6,0,0,0,32,0,0,0,23,0,4,0,7,0,0,0,6,0,0,0,4,0,0,0,32,0,4,0,8,0,0,0,7,0,0,0,7,0,0,0,25,0,9,0,10,0,0,0,6,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,27,0,3,0,11,0,0,0,10,0,0,0,32,0,4,0,12,0,0,0,0,0,0,0,11,0,0,0,59,0,4,0,12,0,0,0,13,0,0,0,0,0,0,0,23,0,4,0,15,0,0,0,6,0,0,0,2,0,0,0,32,0,4,0,16,0,0,0,1,0,0,0,15,0,0,0,59,0,4,0,16,0,0,0,17,0,0,0,1,0,0,0,23,0,4,0,20,0,0,0,6,0,0,0,3,0,0,0,32,0,4,0,21,0,0,0,7,0,0,0,20,0,0,0,43,0,4,0,6,0,0,0,23,0,0,0,0,0,0,0,43,0,4,0,6,0,0,0,24,0,0,0,0,0,128,63,44,0,6,0,20,0,0,0,25,0,0,0,23,0,0,0,23,0,0,0,24,0,0,0,32,0,4,0,26,0,0,0,3,0,0,0,7,0,0,0,59,0,4,0,26,0,0,0,27,0,0,0,3,0,0,0,21,0,4,0,28,0,0,0,32,0,0,0,0,0,0,0,43,0,4,0,28,0,0,0,29,0,0,0,0,0,0,0,32,0,4,0,30,0,0,0,7,0,0,0,6,0,0,0,43,0,4,0,28,0,0,0,36,0,0,0,1,0,0,0,43,0,4,0,28,0,0,0,42,0,0,0,2,0,0,0,43,0,4,0,28,0,0,0,48,0,0,0,3,0,0,0,54,0,5,0,2,0,0,0,4,0,0,0,0,0,0,0,3,0,0,0,248,0,2,0,5,0,0,0,59,0,4,0,8,0,0,0,9,0,0,0,7,0,0,0,59,0,4,0,21,0,0,0,22,0,0,0,7,0,0,0,61,0,4,0,11,0,0,0,14,0,0,0,13,0,0,0,61,0,4,0,15,0,0,0,18,0,0,0,17,0,0,0,87,0,5,0,7,0,0,0,19,0,0,0,14,0,0,0,18,0,0,0,62,0,3,0,9,0,0,0,19,0,0,0,62,0,3,0,22,0,0,0,25,0,0,0,65,0,5,0,30,0,0,0,31,0,0,0,9,0,0,0,29,0,0,0,61,0,4,0,6,0,0,0,32,0,0,0,31,0,0,0,65,0,5,0,30,0,0,0,33,0,0,0,22,0,0,0,29,0,0,0,61,0,4,0,6,0,0,0,34,0,0,0,33,0,0,0,133,0,5,0,6,0,0,0,35,0,0,0,32,0,0,0,34,0,0,0,65,0,5,0,30,0,0,0,37,0,0,0,9,0,0,0,36,0,0,0,61,0,4,0,6,0,0,0,38,0,0,0,37,0,0,0,65,0,5,0,30,0,0,0,39,0,0,0,22,0,0,0,36,0,0,0,61,0,4,0,6,0,0,0,40,0,0,0,39,0,0,0,133,0,5,0,6,0,0,0,41,0,0,0,38,0,0,0,40,0,0,0,65,0,5,0,30,0,0,0,43,0,0,0,9,0,0,0,42,0,0,0,61,0,4,0,6,0,0,0,44,0,0,0,43,0,0,0,65,0,5,0,30,0,0,0,45,0,0,0,22,0,0,0,42,0,0,0,61,0,4,0,6,0,0,0,46,0,0,0,45,0,0,0,133,0,5,0,6,0,0,0,47,0,0,0,44,0,0,0,46,0,0,0,65,0,5,0,30,0,0,0,49,0,0,0,9,0,0,0,48,0,0,0,61,0,4,0,6,0,0,0,50,0,0,0,49,0,0,0,80,0,7,0,7,0,0,0,51,0,0,0,35,0,0,0,41,0,0,0,47,0,0,0,50,0,0,0,62,0,3,0,27,0,0,0,51,0,0,0,253,0,1,0,56,0,1,0};
uint8_t bufshadervertbackov[] = {3,2,35,7,0,0,1,0,10,0,13,0,44,0,0,0,0,0,0,0,17,0,2,0,1,0,0,0,11,0,6,0,1,0,0,0,71,76,83,76,46,115,116,100,46,52,53,48,0,0,0,0,14,0,3,0,0,0,0,0,1,0,0,0,15,0,7,0,0,0,0,0,4,0,0,0,109,97,105,110,0,0,0,0,13,0,0,0,18,0,0,0,3,0,3,0,2,0,0,0,144,1,0,0,4,0,9,0,71,76,95,65,82,66,95,115,101,112,97,114,97,116,101,95,115,104,97,100,101,114,95,111,98,106,101,99,116,115,0,0,4,0,9,0,71,76,95,65,82,66,95,115,104,97,100,105,110,103,95,108,97,110,103,117,97,103,101,95,52,50,48,112,97,99,107,0,4,0,10,0,71,76,95,71,79,79,71,76,69,95,99,112,112,95,115,116,121,108,101,95,108,105,110,101,95,100,105,114,101,99,116,105,118,101,0,0,4,0,8,0,71,76,95,71,79,79,71,76,69,95,105,110,99,108,117,100,101,95,100,105,114,101,99,116,105,118,101,0,5,0,4,0,4,0,0,0,109,97,105,110,0,0,0,0,5,0,6,0,11,0,0,0,103,108,95,80,101,114,86,101,114,116,101,120,0,0,0,0,6,0,6,0,11,0,0,0,0,0,0,0,103,108,95,80,111,115,105,116,105,111,110,0,6,0,7,0,11,0,0,0,1,0,0,0,103,108,95,80,111,105,110,116,83,105,122,101,0,0,0,0,6,0,7,0,11,0,0,0,2,0,0,0,103,108,95,67,108,105,112,68,105,115,116,97,110,99,101,0,5,0,3,0,13,0,0,0,0,0,0,0,5,0,3,0,18,0,0,0,112,111,115,0,5,0,4,0,23,0,0,0,83,99,97,108,101,0,0,0,6,0,4,0,23,0,0,0,0,0,0,0,120,0,0,0,6,0,4,0,23,0,0,0,1,0,0,0,121,0,0,0,5,0,4,0,25,0,0,0,115,99,97,108,101,0,0,0,72,0,5,0,11,0,0,0,0,0,0,0,11,0,0,0,0,0,0,0,72,0,5,0,11,0,0,0,1,0,0,0,11,0,0,0,1,0,0,0,72,0,5,0,11,0,0,0,2,0,0,0,11,0,0,0,3,0,0,0,71,0,3,0,11,0,0,0,2,0,0,0,71,0,4,0,18,0,0,0,30,0,0,0,0,0,0,0,72,0,5,0,23,0,0,0,0,0,0,0,35,0,0,0,0,0,0,0,72,0,5,0,23,0,0,0,1,0,0,0,35,0,0,0,4,0,0,0,71,0,3,0,23,0,0,0,2,0,0,0,19,0,2,0,2,0,0,0,33,0,3,0,3,0,0,0,2,0,0,0,22,0,3,0,6,0,0,0,32,0,0,0,23,0,4,0,7,0,0,0,6,0,0,0,4,0,0,0,21,0,4,0,8,0,0,0,32,0,0,0,0,0,0,0,43,0,4,0,8,0,0,0,9,0,0,0,1,0,0,0,28,0,4,0,10,0,0,0,6,0,0,0,9,0,0,0,30,0,5,0,11,0,0,0,7,0,0,0,6,0,0,0,10,0,0,0,32,0,4,0,12,0,0,0,3,0,0,0,11,0,0,0,59,0,4,0,12,0,0,0,13,0,0,0,3,0,0,0,21,0,4,0,14,0,0,0,32,0,0,0,1,0,0,0,43,0,4,0,14,0,0,0,15,0,0,0,0,0,0,0,23,0,4,0,16,0,0,0,6,0,0,0,2,0,0,0,32,0,4,0,17,0,0,0,1,0,0,0,16,0,0,0,59,0,4,0,17,0,0,0,18,0,0,0,1,0,0,0,43,0,4,0,8,0,0,0,19,0,0,0,0,0,0,0,32,0,4,0,20,0,0,0,1,0,0,0,6,0,0,0,30,0,4,0,23,0,0,0,6,0,0,0,6,0,0,0,32,0,4,0,24,0,0,0,9,0,0,0,23,0,0,0,59,0,4,0,24,0,0,0,25,0,0,0,9,0,0,0,32,0,4,0,26,0,0,0,9,0,0,0,6,0,0,0,43,0,4,0,6,0,0,0,30,0,0,0,0,0,128,63,43,0,4,0,14,0,0,0,34,0,0,0,1,0,0,0,43,0,4,0,6,0,0,0,40,0,0,0,0,0,0,0,32,0,4,0,42,0,0,0,3,0,0,0,7,0,0,0,54,0,5,0,2,0,0,0,4,0,0,0,0,0,0,0,3,0,0,0,248,0,2,0,5,0,0,0,65,0,5,0,20,0,0,0,21,0,0,0,18,0,0,0,19,0,0,0,61,0,4,0,6,0,0,0,22,0,0,0,21,0,0,0,65,0,5,0,26,0,0,0,27,0,0,0,25,0,0,0,15,0,0,0,61,0,4,0,6,0,0,0,28,0,0,0,27,0,0,0,136,0,5,0,6,0,0,0,29,0,0,0,22,0,0,0,28,0,0,0,131,0,5,0,6,0,0,0,31,0,0,0,29,0,0,0,30,0,0,0,65,0,5,0,20,0,0,0,32,0,0,0,18,0,0,0,9,0,0,0,61,0,4,0,6,0,0,0,33,0,0,0,32,0,0,0,65,0,5,0,26,0,0,0,35,0,0,0,25,0,0,0,34,0,0,0,61,0,4,0,6,0,0,0,36,0,0,0,35,0,0,0,136,0,5,0,6,0,0,0,37,0,0,0,33,0,0,0,36,0,0,0,129,0,5,0,6,0,0,0,38,0,0,0,37,0,0,0,30,0,0,0,127,0,4,0,6,0,0,0,39,0,0,0,38,0,0,0,80,0,7,0,7,0,0,0,41,0,0,0,31,0,0,0,39,0,0,0,40,0,0,0,30,0,0,0,65,0,5,0,42,0,0,0,43,0,0,0,13,0,0,0,15,0,0,0,62,0,3,0,43,0,0,0,41,0,0,0,253,0,1,0,56,0,1,0};
uint8_t bufshaderfragbackov[] = {3,2,35,7,0,0,1,0,10,0,13,0,12,0,0,0,0,0,0,0,17,0,2,0,1,0,0,0,11,0,6,0,1,0,0,0,71,76,83,76,46,115,116,100,46,52,53,48,0,0,0,0,14,0,3,0,0,0,0,0,1,0,0,0,15,0,6,0,4,0,0,0,4,0,0,0,109,97,105,110,0,0,0,0,9,0,0,0,16,0,3,0,4,0,0,0,7,0,0,0,3,0,3,0,2,0,0,0,144,1,0,0,4,0,9,0,71,76,95,65,82,66,95,115,101,112,97,114,97,116,101,95,115,104,97,100,101,114,95,111,98,106,101,99,116,115,0,0,4,0,9,0,71,76,95,65,82,66,95,115,104,97,100,105,110,103,95,108,97,110,103,117,97,103,101,95,52,50,48,112,97,99,107,0,4,0,10,0,71,76,95,71,79,79,71,76,69,95,99,112,112,95,115,116,121,108,101,95,108,105,110,101,95,100,105,114,101,99,116,105,118,101,0,0,4,0,8,0,71,76,95,71,79,79,71,76,69,95,105,110,99,108,117,100,101,95,100,105,114,101,99,116,105,118,101,0,5,0,4,0,4,0,0,0,109,97,105,110,0,0,0,0,5,0,5,0,9,0,0,0,117,70,114,97,103,67,111,108,111,114,0,0,71,0,4,0,9,0,0,0,30,0,0,0,0,0,0,0,19,0,2,0,2,0,0,0,33,0,3,0,3,0,0,0,2,0,0,0,22,0,3,0,6,0,0,0,32,0,0,0,23,0,4,0,7,0,0,0,6,0,0,0,4,0,0,0,32,0,4,0,8,0,0,0,3,0,0,0,7,0,0,0,59,0,4,0,8,0,0,0,9,0,0,0,3,0,0,0,43,0,4,0,6,0,0,0,10,0,0,0,0,0,128,63,44,0,7,0,7,0,0,0,11,0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,54,0,5,0,2,0,0,0,4,0,0,0,0,0,0,0,3,0,0,0,248,0,2,0,5,0,0,0,62,0,3,0,9,0,0,0,11,0,0,0,253,0,1,0,56,0,1,0};
uint8_t bufshadervertbtnov[] = {3,2,35,7,0,0,1,0,10,0,13,0,67,0,0,0,0,0,0,0,17,0,2,0,1,0,0,0,11,0,6,0,1,0,0,0,71,76,83,76,46,115,116,100,46,52,53,48,0,0,0,0,14,0,3,0,0,0,0,0,1,0,0,0,15,0,9,0,0,0,0,0,4,0,0,0,109,97,105,110,0,0,0,0,13,0,0,0,18,0,0,0,44,0,0,0,47,0,0,0,3,0,3,0,2,0,0,0,144,1,0,0,4,0,9,0,71,76,95,65,82,66,95,115,101,112,97,114,97,116,101,95,115,104,97,100,101,114,95,111,98,106,101,99,116,115,0,0,4,0,9,0,71,76,95,65,82,66,95,115,104,97,100,105,110,103,95,108,97,110,103,117,97,103,101,95,52,50,48,112,97,99,107,0,4,0,10,0,71,76,95,71,79,79,71,76,69,95,99,112,112,95,115,116,121,108,101,95,108,105,110,101,95,100,105,114,101,99,116,105,118,101,0,0,4,0,8,0,71,76,95,71,79,79,71,76,69,95,105,110,99,108,117,100,101,95,100,105,114,101,99,116,105,118,101,0,5,0,4,0,4,0,0,0,109,97,105,110,0,0,0,0,5,0,6,0,11,0,0,0,103,108,95,80,101,114,86,101,114,116,101,120,0,0,0,0,6,0,6,0,11,0,0,0,0,0,0,0,103,108,95,80,111,115,105,116,105,111,110,0,6,0,7,0,11,0,0,0,1,0,0,0,103,108,95,80,111,105,110,116,83,105,122,101,0,0,0,0,6,0,7,0,11,0,0,0,2,0,0,0,103,108,95,67,108,105,112,68,105,115,116,97,110,99,101,0,5,0,3,0,13,0,0,0,0,0,0,0,5,0,3,0,18,0,0,0,112,111,115,0,5,0,4,0,23,0,0,0,83,99,97,108,101,0,0,0,6,0,4,0,23,0,0,0,0,0,0,0,120,0,0,0,6,0,4,0,23,0,0,0,1,0,0,0,121,0,0,0,5,0,4,0,25,0,0,0,115,99,97,108,101,0,0,0,5,0,4,0,44,0,0,0,108,114,117,100,0,0,0,0,5,0,3,0,47,0,0,0,111,112,112,0,72,0,5,0,11,0,0,0,0,0,0,0,11,0,0,0,0,0,0,0,72,0,5,0,11,0,0,0,1,0,0,0,11,0,0,0,1,0,0,0,72,0,5,0,11,0,0,0,2,0,0,0,11,0,0,0,3,0,0,0,71,0,3,0,11,0,0,0,2,0,0,0,71,0,4,0,18,0,0,0,30,0,0,0,0,0,0,0,72,0,5,0,23,0,0,0,0,0,0,0,35,0,0,0,0,0,0,0,72,0,5,0,23,0,0,0,1,0,0,0,35,0,0,0,4,0,0,0,71,0,3,0,23,0,0,0,2,0,0,0,71,0,4,0,44,0,0,0,30,0,0,0,0,0,0,0,71,0,4,0,47,0,0,0,30,0,0,0,1,0,0,0,19,0,2,0,2,0,0,0,33,0,3,0,3,0,0,0,2,0,0,0,22,0,3,0,6,0,0,0,32,0,0,0,23,0,4,0,7,0,0,0,6,0,0,0,4,0,0,0,21,0,4,0,8,0,0,0,32,0,0,0,0,0,0,0,43,0,4,0,8,0,0,0,9,0,0,0,1,0,0,0,28,0,4,0,10,0,0,0,6,0,0,0,9,0,0,0,30,0,5,0,11,0,0,0,7,0,0,0,6,0,0,0,10,0,0,0,32,0,4,0,12,0,0,0,3,0,0,0,11,0,0,0,59,0,4,0,12,0,0,0,13,0,0,0,3,0,0,0,21,0,4,0,14,0,0,0,32,0,0,0,1,0,0,0,43,0,4,0,14,0,0,0,15,0,0,0,0,0,0,0,23,0,4,0,16,0,0,0,6,0,0,0,2,0,0,0,32,0,4,0,17,0,0,0,1,0,0,0,16,0,0,0,59,0,4,0,17,0,0,0,18,0,0,0,1,0,0,0,43,0,4,0,8,0,0,0,19,0,0,0,0,0,0,0,32,0,4,0,20,0,0,0,1,0,0,0,6,0,0,0,30,0,4,0,23,0,0,0,6,0,0,0,6,0,0,0,32,0,4,0,24,0,0,0,9,0,0,0,23,0,0,0,59,0,4,0,24,0,0,0,25,0,0,0,9,0,0,0,32,0,4,0,26,0,0,0,9,0,0,0,6,0,0,0,43,0,4,0,6,0,0,0,30,0,0,0,0,0,128,63,43,0,4,0,14,0,0,0,34,0,0,0,1,0,0,0,43,0,4,0,6,0,0,0,40,0,0,0,0,0,0,0,32,0,4,0,42,0,0,0,3,0,0,0,7,0,0,0,59,0,4,0,42,0,0,0,44,0,0,0,3,0,0,0,59,0,4,0,17,0,0,0,47,0,0,0,1,0,0,0,54,0,5,0,2,0,0,0,4,0,0,0,0,0,0,0,3,0,0,0,248,0,2,0,5,0,0,0,65,0,5,0,20,0,0,0,21,0,0,0,18,0,0,0,19,0,0,0,61,0,4,0,6,0,0,0,22,0,0,0,21,0,0,0,65,0,5,0,26,0,0,0,27,0,0,0,25,0,0,0,15,0,0,0,61,0,4,0,6,0,0,0,28,0,0,0,27,0,0,0,136,0,5,0,6,0,0,0,29,0,0,0,22,0,0,0,28,0,0,0,131,0,5,0,6,0,0,0,31,0,0,0,29,0,0,0,30,0,0,0,65,0,5,0,20,0,0,0,32,0,0,0,18,0,0,0,9,0,0,0,61,0,4,0,6,0,0,0,33,0,0,0,32,0,0,0,65,0,5,0,26,0,0,0,35,0,0,0,25,0,0,0,34,0,0,0,61,0,4,0,6,0,0,0,36,0,0,0,35,0,0,0,136,0,5,0,6,0,0,0,37,0,0,0,33,0,0,0,36,0,0,0,129,0,5,0,6,0,0,0,38,0,0,0,37,0,0,0,30,0,0,0,127,0,4,0,6,0,0,0,39,0,0,0,38,0,0,0,80,0,7,0,7,0,0,0,41,0,0,0,31,0,0,0,39,0,0,0,40,0,0,0,30,0,0,0,65,0,5,0,42,0,0,0,43,0,0,0,13,0,0,0,15,0,0,0,62,0,3,0,43,0,0,0,41,0,0,0,65,0,5,0,20,0,0,0,45,0,0,0,18,0,0,0,19,0,0,0,61,0,4,0,6,0,0,0,46,0,0,0,45,0,0,0,65,0,5,0,20,0,0,0,48,0,0,0,47,0,0,0,19,0,0,0,61,0,4,0,6,0,0,0,49,0,0,0,48,0,0,0,12,0,7,0,6,0,0,0,50,0,0,0,1,0,0,0,37,0,0,0,46,0,0,0,49,0,0,0,65,0,5,0,20,0,0,0,51,0,0,0,18,0,0,0,19,0,0,0,61,0,4,0,6,0,0,0,52,0,0,0,51,0,0,0,65,0,5,0,20,0,0,0,53,0,0,0,47,0,0,0,19,0,0,0,61,0,4,0,6,0,0,0,54,0,0,0,53,0,0,0,12,0,7,0,6,0,0,0,55,0,0,0,1,0,0,0,40,0,0,0,52,0,0,0,54,0,0,0,65,0,5,0,20,0,0,0,56,0,0,0,18,0,0,0,9,0,0,0,61,0,4,0,6,0,0,0,57,0,0,0,56,0,0,0,65,0,5,0,20,0,0,0,58,0,0,0,47,0,0,0,9,0,0,0,61,0,4,0,6,0,0,0,59,0,0,0,58,0,0,0,12,0,7,0,6,0,0,0,60,0,0,0,1,0,0,0,37,0,0,0,57,0,0,0,59,0,0,0,65,0,5,0,20,0,0,0,61,0,0,0,18,0,0,0,9,0,0,0,61,0,4,0,6,0,0,0,62,0,0,0,61,0,0,0,65,0,5,0,20,0,0,0,63,0,0,0,47,0,0,0,9,0,0,0,61,0,4,0,6,0,0,0,64,0,0,0,63,0,0,0,12,0,7,0,6,0,0,0,65,0,0,0,1,0,0,0,40,0,0,0,62,0,0,0,64,0,0,0,80,0,7,0,7,0,0,0,66,0,0,0,50,0,0,0,55,0,0,0,60,0,0,0,65,0,0,0,62,0,3,0,44,0,0,0,66,0,0,0,253,0,1,0,56,0,1,0};
uint8_t bufshaderfragbtnov[] = {3,2,35,7,0,0,1,0,10,0,13,0,100,0,0,0,0,0,0,0,17,0,2,0,1,0,0,0,11,0,6,0,1,0,0,0,71,76,83,76,46,115,116,100,46,52,53,48,0,0,0,0,14,0,3,0,0,0,0,0,1,0,0,0,15,0,8,0,4,0,0,0,4,0,0,0,109,97,105,110,0,0,0,0,10,0,0,0,18,0,0,0,94,0,0,0,16,0,3,0,4,0,0,0,7,0,0,0,3,0,3,0,2,0,0,0,144,1,0,0,4,0,9,0,71,76,95,65,82,66,95,115,101,112,97,114,97,116,101,95,115,104,97,100,101,114,95,111,98,106,101,99,116,115,0,0,4,0,9,0,71,76,95,65,82,66,95,115,104,97,100,105,110,103,95,108,97,110,103,117,97,103,101,95,52,50,48,112,97,99,107,0,4,0,10,0,71,76,95,71,79,79,71,76,69,95,99,112,112,95,115,116,121,108,101,95,108,105,110,101,95,100,105,114,101,99,116,105,118,101,0,0,4,0,8,0,71,76,95,71,79,79,71,76,69,95,105,110,99,108,117,100,101,95,100,105,114,101,99,116,105,118,101,0,5,0,4,0,4,0,0,0,109,97,105,110,0,0,0,0,5,0,4,0,10,0,0,0,108,114,117,100,0,0,0,0,5,0,6,0,18,0,0,0,103,108,95,70,114,97,103,67,111,111,114,100,0,0,0,0,5,0,5,0,94,0,0,0,117,70,114,97,103,67,111,108,111,114,0,0,71,0,3,0,10,0,0,0,14,0,0,0,71,0,4,0,10,0,0,0,30,0,0,0,0,0,0,0,71,0,4,0,18,0,0,0,11,0,0,0,15,0,0,0,71,0,4,0,94,0,0,0,30,0,0,0,0,0,0,0,19,0,2,0,2,0,0,0,33,0,3,0,3,0,0,0,2,0,0,0,20,0,2,0,6,0,0,0,22,0,3,0,7,0,0,0,32,0,0,0,23,0,4,0,8,0,0,0,7,0,0,0,4,0,0,0,32,0,4,0,9,0,0,0,1,0,0,0,8,0,0,0,59,0,4,0,9,0,0,0,10,0,0,0,1,0,0,0,21,0,4,0,11,0,0,0,32,0,0,0,0,0,0,0,43,0,4,0,11,0,0,0,12,0,0,0,0,0,0,0,32,0,4,0,13,0,0,0,1,0,0,0,7,0,0,0,43,0,4,0,7,0,0,0,16,0,0,0,0,0,0,64,59,0,4,0,9,0,0,0,18,0,0,0,1,0,0,0,43,0,4,0,11,0,0,0,34,0,0,0,1,0,0,0,43,0,4,0,11,0,0,0,54,0,0,0,2,0,0,0,43,0,4,0,11,0,0,0,74,0,0,0,3,0,0,0,32,0,4,0,93,0,0,0,3,0,0,0,8,0,0,0,59,0,4,0,93,0,0,0,94,0,0,0,3,0,0,0,43,0,4,0,7,0,0,0,95,0,0,0,0,0,128,63,44,0,7,0,8,0,0,0,96,0,0,0,95,0,0,0,95,0,0,0,95,0,0,0,95,0,0,0,43,0,4,0,7,0,0,0,98,0,0,0,0,0,0,0,44,0,7,0,8,0,0,0,99,0,0,0,98,0,0,0,98,0,0,0,98,0,0,0,98,0,0,0,54,0,5,0,2,0,0,0,4,0,0,0,0,0,0,0,3,0,0,0,248,0,2,0,5,0,0,0,65,0,5,0,13,0,0,0,14,0,0,0,10,0,0,0,12,0,0,0,61,0,4,0,7,0,0,0,15,0,0,0,14,0,0,0,131,0,5,0,7,0,0,0,17,0,0,0,15,0,0,0,16,0,0,0,65,0,5,0,13,0,0,0,19,0,0,0,18,0,0,0,12,0,0,0,61,0,4,0,7,0,0,0,20,0,0,0,19,0,0,0,184,0,5,0,6,0,0,0,21,0,0,0,17,0,0,0,20,0,0,0,247,0,3,0,23,0,0,0,0,0,0,0,250,0,4,0,21,0,0,0,22,0,0,0,23,0,0,0,248,0,2,0,22,0,0,0,65,0,5,0,13,0,0,0,24,0,0,0,18,0,0,0,12,0,0,0,61,0,4,0,7,0,0,0,25,0,0,0,24,0,0,0,65,0,5,0,13,0,0,0,26,0,0,0,10,0,0,0,12,0,0,0,61,0,4,0,7,0,0,0,27,0,0,0,26,0,0,0,129,0,5,0,7,0,0,0,28,0,0,0,27,0,0,0,16,0,0,0,184,0,5,0,6,0,0,0,29,0,0,0,25,0,0,0,28,0,0,0,249,0,2,0,23,0,0,0,248,0,2,0,23,0,0,0,245,0,7,0,6,0,0,0,30,0,0,0,21,0,0,0,5,0,0,0,29,0,0,0,22,0,0,0,168,0,4,0,6,0,0,0,31,0,0,0,30,0,0,0,247,0,3,0,33,0,0,0,0,0,0,0,250,0,4,0,31,0,0,0,32,0,0,0,33,0,0,0,248,0,2,0,32,0,0,0,65,0,5,0,13,0,0,0,35,0,0,0,10,0,0,0,34,0,0,0,61,0,4,0,7,0,0,0,36,0,0,0,35,0,0,0,131,0,5,0,7,0,0,0,37,0,0,0,36,0,0,0,16,0,0,0,65,0,5,0,13,0,0,0,38,0,0,0,18,0,0,0,12,0,0,0,61,0,4,0,7,0,0,0,39,0,0,0,38,0,0,0,184,0,5,0,6,0,0,0,40,0,0,0,37,0,0,0,39,0,0,0,247,0,3,0,42,0,0,0,0,0,0,0,250,0,4,0,40,0,0,0,41,0,0,0,42,0,0,0,248,0,2,0,41,0,0,0,65,0,5,0,13,0,0,0,43,0,0,0,18,0,0,0,12,0,0,0,61,0,4,0,7,0,0,0,44,0,0,0,43,0,0,0,65,0,5,0,13,0,0,0,45,0,0,0,10,0,0,0,34,0,0,0,61,0,4,0,7,0,0,0,46,0,0,0,45,0,0,0,129,0,5,0,7,0,0,0,47,0,0,0,46,0,0,0,16,0,0,0,184,0,5,0,6,0,0,0,48,0,0,0,44,0,0,0,47,0,0,0,249,0,2,0,42,0,0,0,248,0,2,0,42,0,0,0,245,0,7,0,6,0,0,0,49,0,0,0,40,0,0,0,32,0,0,0,48,0,0,0,41,0,0,0,249,0,2,0,33,0,0,0,248,0,2,0,33,0,0,0,245,0,7,0,6,0,0,0,50,0,0,0,30,0,0,0,23,0,0,0,49,0,0,0,42,0,0,0,168,0,4,0,6,0,0,0,51,0,0,0,50,0,0,0,247,0,3,0,53,0,0,0,0,0,0,0,250,0,4,0,51,0,0,0,52,0,0,0,53,0,0,0,248,0,2,0,52,0,0,0,65,0,5,0,13,0,0,0,55,0,0,0,10,0,0,0,54,0,0,0,61,0,4,0,7,0,0,0,56,0,0,0,55,0,0,0,131,0,5,0,7,0,0,0,57,0,0,0,56,0,0,0,16,0,0,0,65,0,5,0,13,0,0,0,58,0,0,0,18,0,0,0,34,0,0,0,61,0,4,0,7,0,0,0,59,0,0,0,58,0,0,0,184,0,5,0,6,0,0,0,60,0,0,0,57,0,0,0,59,0,0,0,247,0,3,0,62,0,0,0,0,0,0,0,250,0,4,0,60,0,0,0,61,0,0,0,62,0,0,0,248,0,2,0,61,0,0,0,65,0,5,0,13,0,0,0,63,0,0,0,18,0,0,0,34,0,0,0,61,0,4,0,7,0,0,0,64,0,0,0,63,0,0,0,65,0,5,0,13,0,0,0,65,0,0,0,10,0,0,0,54,0,0,0,61,0,4,0,7,0,0,0,66,0,0,0,65,0,0,0,129,0,5,0,7,0,0,0,67,0,0,0,66,0,0,0,16,0,0,0,184,0,5,0,6,0,0,0,68,0,0,0,64,0,0,0,67,0,0,0,249,0,2,0,62,0,0,0,248,0,2,0,62,0,0,0,245,0,7,0,6,0,0,0,69,0,0,0,60,0,0,0,52,0,0,0,68,0,0,0,61,0,0,0,249,0,2,0,53,0,0,0,248,0,2,0,53,0,0,0,245,0,7,0,6,0,0,0,70,0,0,0,50,0,0,0,33,0,0,0,69,0,0,0,62,0,0,0,168,0,4,0,6,0,0,0,71,0,0,0,70,0,0,0,247,0,3,0,73,0,0,0,0,0,0,0,250,0,4,0,71,0,0,0,72,0,0,0,73,0,0,0,248,0,2,0,72,0,0,0,65,0,5,0,13,0,0,0,75,0,0,0,10,0,0,0,74,0,0,0,61,0,4,0,7,0,0,0,76,0,0,0,75,0,0,0,131,0,5,0,7,0,0,0,77,0,0,0,76,0,0,0,16,0,0,0,65,0,5,0,13,0,0,0,78,0,0,0,18,0,0,0,34,0,0,0,61,0,4,0,7,0,0,0,79,0,0,0,78,0,0,0,184,0,5,0,6,0,0,0,80,0,0,0,77,0,0,0,79,0,0,0,247,0,3,0,82,0,0,0,0,0,0,0,250,0,4,0,80,0,0,0,81,0,0,0,82,0,0,0,248,0,2,0,81,0,0,0,65,0,5,0,13,0,0,0,83,0,0,0,18,0,0,0,34,0,0,0,61,0,4,0,7,0,0,0,84,0,0,0,83,0,0,0,65,0,5,0,13,0,0,0,85,0,0,0,10,0,0,0,74,0,0,0,61,0,4,0,7,0,0,0,86,0,0,0,85,0,0,0,129,0,5,0,7,0,0,0,87,0,0,0,86,0,0,0,16,0,0,0,184,0,5,0,6,0,0,0,88,0,0,0,84,0,0,0,87,0,0,0,249,0,2,0,82,0,0,0,248,0,2,0,82,0,0,0,245,0,7,0,6,0,0,0,89,0,0,0,80,0,0,0,72,0,0,0,88,0,0,0,81,0,0,0,249,0,2,0,73,0,0,0,248,0,2,0,73,0,0,0,245,0,7,0,6,0,0,0,90,0,0,0,70,0,0,0,53,0,0,0,89,0,0,0,82,0,0,0,247,0,3,0,92,0,0,0,0,0,0,0,250,0,4,0,90,0,0,0,91,0,0,0,97,0,0,0,248,0,2,0,91,0,0,0,62,0,3,0,94,0,0,0,96,0,0,0,249,0,2,0,92,0,0,0,248,0,2,0,97,0,0,0,62,0,3,0,94,0,0,0,99,0,0,0,249,0,2,0,92,0,0,0,248,0,2,0,92,0,0,0,253,0,1,0,56,0,1,0};
uint8_t bufshadervertselect[] = {3,2,35,7,0,0,1,0,10,0,13,0,44,0,0,0,0,0,0,0,17,0,2,0,1,0,0,0,11,0,6,0,1,0,0,0,71,76,83,76,46,115,116,100,46,52,53,48,0,0,0,0,14,0,3,0,0,0,0,0,1,0,0,0,15,0,7,0,0,0,0,0,4,0,0,0,109,97,105,110,0,0,0,0,13,0,0,0,18,0,0,0,3,0,3,0,2,0,0,0,144,1,0,0,4,0,9,0,71,76,95,65,82,66,95,115,101,112,97,114,97,116,101,95,115,104,97,100,101,114,95,111,98,106,101,99,116,115,0,0,4,0,9,0,71,76,95,65,82,66,95,115,104,97,100,105,110,103,95,108,97,110,103,117,97,103,101,95,52,50,48,112,97,99,107,0,4,0,10,0,71,76,95,71,79,79,71,76,69,95,99,112,112,95,115,116,121,108,101,95,108,105,110,101,95,100,105,114,101,99,116,105,118,101,0,0,4,0,8,0,71,76,95,71,79,79,71,76,69,95,105,110,99,108,117,100,101,95,100,105,114,101,99,116,105,118,101,0,5,0,4,0,4,0,0,0,109,97,105,110,0,0,0,0,5,0,6,0,11,0,0,0,103,108,95,80,101,114,86,101,114,116,101,120,0,0,0,0,6,0,6,0,11,0,0,0,0,0,0,0,103,108,95,80,111,115,105,116,105,111,110,0,6,0,7,0,11,0,0,0,1,0,0,0,103,108,95,80,111,105,110,116,83,105,122,101,0,0,0,0,6,0,7,0,11,0,0,0,2,0,0,0,103,108,95,67,108,105,112,68,105,115,116,97,110,99,101,0,5,0,3,0,13,0,0,0,0,0,0,0,5,0,3,0,18,0,0,0,112,111,115,0,5,0,4,0,23,0,0,0,83,99,97,108,101,0,0,0,6,0,4,0,23,0,0,0,0,0,0,0,120,0,0,0,6,0,4,0,23,0,0,0,1,0,0,0,121,0,0,0,5,0,4,0,25,0,0,0,115,99,97,108,101,0,0,0,72,0,5,0,11,0,0,0,0,0,0,0,11,0,0,0,0,0,0,0,72,0,5,0,11,0,0,0,1,0,0,0,11,0,0,0,1,0,0,0,72,0,5,0,11,0,0,0,2,0,0,0,11,0,0,0,3,0,0,0,71,0,3,0,11,0,0,0,2,0,0,0,71,0,4,0,18,0,0,0,30,0,0,0,0,0,0,0,72,0,5,0,23,0,0,0,0,0,0,0,35,0,0,0,0,0,0,0,72,0,5,0,23,0,0,0,1,0,0,0,35,0,0,0,4,0,0,0,71,0,3,0,23,0,0,0,2,0,0,0,19,0,2,0,2,0,0,0,33,0,3,0,3,0,0,0,2,0,0,0,22,0,3,0,6,0,0,0,32,0,0,0,23,0,4,0,7,0,0,0,6,0,0,0,4,0,0,0,21,0,4,0,8,0,0,0,32,0,0,0,0,0,0,0,43,0,4,0,8,0,0,0,9,0,0,0,1,0,0,0,28,0,4,0,10,0,0,0,6,0,0,0,9,0,0,0,30,0,5,0,11,0,0,0,7,0,0,0,6,0,0,0,10,0,0,0,32,0,4,0,12,0,0,0,3,0,0,0,11,0,0,0,59,0,4,0,12,0,0,0,13,0,0,0,3,0,0,0,21,0,4,0,14,0,0,0,32,0,0,0,1,0,0,0,43,0,4,0,14,0,0,0,15,0,0,0,0,0,0,0,23,0,4,0,16,0,0,0,6,0,0,0,2,0,0,0,32,0,4,0,17,0,0,0,1,0,0,0,16,0,0,0,59,0,4,0,17,0,0,0,18,0,0,0,1,0,0,0,43,0,4,0,8,0,0,0,19,0,0,0,0,0,0,0,32,0,4,0,20,0,0,0,1,0,0,0,6,0,0,0,30,0,4,0,23,0,0,0,6,0,0,0,6,0,0,0,32,0,4,0,24,0,0,0,9,0,0,0,23,0,0,0,59,0,4,0,24,0,0,0,25,0,0,0,9,0,0,0,32,0,4,0,26,0,0,0,9,0,0,0,6,0,0,0,43,0,4,0,6,0,0,0,30,0,0,0,0,0,128,63,43,0,4,0,14,0,0,0,34,0,0,0,1,0,0,0,43,0,4,0,6,0,0,0,40,0,0,0,0,0,0,0,32,0,4,0,42,0,0,0,3,0,0,0,7,0,0,0,54,0,5,0,2,0,0,0,4,0,0,0,0,0,0,0,3,0,0,0,248,0,2,0,5,0,0,0,65,0,5,0,20,0,0,0,21,0,0,0,18,0,0,0,19,0,0,0,61,0,4,0,6,0,0,0,22,0,0,0,21,0,0,0,65,0,5,0,26,0,0,0,27,0,0,0,25,0,0,0,15,0,0,0,61,0,4,0,6,0,0,0,28,0,0,0,27,0,0,0,136,0,5,0,6,0,0,0,29,0,0,0,22,0,0,0,28,0,0,0,131,0,5,0,6,0,0,0,31,0,0,0,29,0,0,0,30,0,0,0,65,0,5,0,20,0,0,0,32,0,0,0,18,0,0,0,9,0,0,0,61,0,4,0,6,0,0,0,33,0,0,0,32,0,0,0,65,0,5,0,26,0,0,0,35,0,0,0,25,0,0,0,34,0,0,0,61,0,4,0,6,0,0,0,36,0,0,0,35,0,0,0,136,0,5,0,6,0,0,0,37,0,0,0,33,0,0,0,36,0,0,0,129,0,5,0,6,0,0,0,38,0,0,0,37,0,0,0,30,0,0,0,127,0,4,0,6,0,0,0,39,0,0,0,38,0,0,0,80,0,7,0,7,0,0,0,41,0,0,0,31,0,0,0,39,0,0,0,40,0,0,0,30,0,0,0,65,0,5,0,42,0,0,0,43,0,0,0,13,0,0,0,15,0,0,0,62,0,3,0,43,0,0,0,41,0,0,0,253,0,1,0,56,0,1,0};
uint8_t bufshaderfragselect[] = {3,2,35,7,0,0,1,0,10,0,13,0,13,0,0,0,0,0,0,0,17,0,2,0,1,0,0,0,11,0,6,0,1,0,0,0,71,76,83,76,46,115,116,100,46,52,53,48,0,0,0,0,14,0,3,0,0,0,0,0,1,0,0,0,15,0,6,0,4,0,0,0,4,0,0,0,109,97,105,110,0,0,0,0,9,0,0,0,16,0,3,0,4,0,0,0,7,0,0,0,3,0,3,0,2,0,0,0,144,1,0,0,4,0,9,0,71,76,95,65,82,66,95,115,101,112,97,114,97,116,101,95,115,104,97,100,101,114,95,111,98,106,101,99,116,115,0,0,4,0,9,0,71,76,95,65,82,66,95,115,104,97,100,105,110,103,95,108,97,110,103,117,97,103,101,95,52,50,48,112,97,99,107,0,4,0,10,0,71,76,95,71,79,79,71,76,69,95,99,112,112,95,115,116,121,108,101,95,108,105,110,101,95,100,105,114,101,99,116,105,118,101,0,0,4,0,8,0,71,76,95,71,79,79,71,76,69,95,105,110,99,108,117,100,101,95,100,105,114,101,99,116,105,118,101,0,5,0,4,0,4,0,0,0,109,97,105,110,0,0,0,0,5,0,5,0,9,0,0,0,117,70,114,97,103,67,111,108,111,114,0,0,71,0,4,0,9,0,0,0,30,0,0,0,0,0,0,0,19,0,2,0,2,0,0,0,33,0,3,0,3,0,0,0,2,0,0,0,22,0,3,0,6,0,0,0,32,0,0,0,23,0,4,0,7,0,0,0,6,0,0,0,4,0,0,0,32,0,4,0,8,0,0,0,3,0,0,0,7,0,0,0,59,0,4,0,8,0,0,0,9,0,0,0,3,0,0,0,43,0,4,0,6,0,0,0,10,0,0,0,154,153,153,62,43,0,4,0,6,0,0,0,11,0,0,0,0,0,128,63,44,0,7,0,7,0,0,0,12,0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,11,0,0,0,54,0,5,0,2,0,0,0,4,0,0,0,0,0,0,0,3,0,0,0,248,0,2,0,5,0,0,0,62,0,3,0,9,0,0,0,12,0,0,0,253,0,1,0,56,0,1,0};
uint8_t bufshadervertexp[] = {3,2,35,7,0,0,1,0,10,0,13,0,89,0,0,0,0,0,0,0,17,0,2,0,1,0,0,0,11,0,6,0,1,0,0,0,71,76,83,76,46,115,116,100,46,52,53,48,0,0,0,0,14,0,3,0,0,0,0,0,1,0,0,0,15,0,10,0,0,0,0,0,4,0,0,0,109,97,105,110,0,0,0,0,13,0,0,0,18,0,0,0,44,0,0,0,47,0,0,0,57,0,0,0,3,0,3,0,2,0,0,0,144,1,0,0,4,0,9,0,71,76,95,65,82,66,95,115,101,112,97,114,97,116,101,95,115,104,97,100,101,114,95,111,98,106,101,99,116,115,0,0,4,0,9,0,71,76,95,65,82,66,95,115,104,97,100,105,110,103,95,108,97,110,103,117,97,103,101,95,52,50,48,112,97,99,107,0,4,0,10,0,71,76,95,71,79,79,71,76,69,95,99,112,112,95,115,116,121,108,101,95,108,105,110,101,95,100,105,114,101,99,116,105,118,101,0,0,4,0,8,0,71,76,95,71,79,79,71,76,69,95,105,110,99,108,117,100,101,95,100,105,114,101,99,116,105,118,101,0,5,0,4,0,4,0,0,0,109,97,105,110,0,0,0,0,5,0,6,0,11,0,0,0,103,108,95,80,101,114,86,101,114,116,101,120,0,0,0,0,6,0,6,0,11,0,0,0,0,0,0,0,103,108,95,80,111,115,105,116,105,111,110,0,6,0,7,0,11,0,0,0,1,0,0,0,103,108,95,80,111,105,110,116,83,105,122,101,0,0,0,0,6,0,7,0,11,0,0,0,2,0,0,0,103,108,95,67,108,105,112,68,105,115,116,97,110,99,101,0,5,0,3,0,13,0,0,0,0,0,0,0,5,0,3,0,18,0,0,0,112,111,115,0,5,0,4,0,23,0,0,0,83,99,97,108,101,0,0,0,6,0,4,0,23,0,0,0,0,0,0,0,120,0,0,0,6,0,4,0,23,0,0,0,1,0,0,0,121,0,0,0,5,0,4,0,25,0,0,0,115,99,97,108,101,0,0,0,5,0,4,0,44,0,0,0,108,114,117,100,0,0,0,0,5,0,3,0,47,0,0,0,111,112,112,0,5,0,5,0,57,0,0,0,98,111,114,100,101,114,117,100,0,0,0,0,72,0,5,0,11,0,0,0,0,0,0,0,11,0,0,0,0,0,0,0,72,0,5,0,11,0,0,0,1,0,0,0,11,0,0,0,1,0,0,0,72,0,5,0,11,0,0,0,2,0,0,0,11,0,0,0,3,0,0,0,71,0,3,0,11,0,0,0,2,0,0,0,71,0,4,0,18,0,0,0,30,0,0,0,0,0,0,0,72,0,5,0,23,0,0,0,0,0,0,0,35,0,0,0,0,0,0,0,72,0,5,0,23,0,0,0,1,0,0,0,35,0,0,0,4,0,0,0,71,0,3,0,23,0,0,0,2,0,0,0,71,0,4,0,44,0,0,0,30,0,0,0,0,0,0,0,71,0,4,0,47,0,0,0,30,0,0,0,1,0,0,0,71,0,4,0,57,0,0,0,30,0,0,0,2,0,0,0,19,0,2,0,2,0,0,0,33,0,3,0,3,0,0,0,2,0,0,0,22,0,3,0,6,0,0,0,32,0,0,0,23,0,4,0,7,0,0,0,6,0,0,0,4,0,0,0,21,0,4,0,8,0,0,0,32,0,0,0,0,0,0,0,43,0,4,0,8,0,0,0,9,0,0,0,1,0,0,0,28,0,4,0,10,0,0,0,6,0,0,0,9,0,0,0,30,0,5,0,11,0,0,0,7,0,0,0,6,0,0,0,10,0,0,0,32,0,4,0,12,0,0,0,3,0,0,0,11,0,0,0,59,0,4,0,12,0,0,0,13,0,0,0,3,0,0,0,21,0,4,0,14,0,0,0,32,0,0,0,1,0,0,0,43,0,4,0,14,0,0,0,15,0,0,0,0,0,0,0,23,0,4,0,16,0,0,0,6,0,0,0,2,0,0,0,32,0,4,0,17,0,0,0,1,0,0,0,16,0,0,0,59,0,4,0,17,0,0,0,18,0,0,0,1,0,0,0,43,0,4,0,8,0,0,0,19,0,0,0,0,0,0,0,32,0,4,0,20,0,0,0,1,0,0,0,6,0,0,0,30,0,4,0,23,0,0,0,6,0,0,0,6,0,0,0,32,0,4,0,24,0,0,0,9,0,0,0,23,0,0,0,59,0,4,0,24,0,0,0,25,0,0,0,9,0,0,0,32,0,4,0,26,0,0,0,9,0,0,0,6,0,0,0,43,0,4,0,6,0,0,0,30,0,0,0,0,0,128,63,43,0,4,0,14,0,0,0,34,0,0,0,1,0,0,0,43,0,4,0,6,0,0,0,40,0,0,0,0,0,0,0,32,0,4,0,42,0,0,0,3,0,0,0,7,0,0,0,59,0,4,0,42,0,0,0,44,0,0,0,3,0,0,0,59,0,4,0,17,0,0,0,47,0,0,0,1,0,0,0,32,0,4,0,56,0,0,0,1,0,0,0,8,0,0,0,59,0,4,0,56,0,0,0,57,0,0,0,1,0,0,0,20,0,2,0,60,0,0,0,32,0,4,0,62,0,0,0,7,0,0,0,6,0,0,0,43,0,4,0,6,0,0,0,72,0,0,0,0,0,128,127,43,0,4,0,8,0,0,0,75,0,0,0,2,0,0,0,54,0,5,0,2,0,0,0,4,0,0,0,0,0,0,0,3,0,0,0,248,0,2,0,5,0,0,0,59,0,4,0,62,0,0,0,63,0,0,0,7,0,0,0,59,0,4,0,62,0,0,0,78,0,0,0,7,0,0,0,65,0,5,0,20,0,0,0,21,0,0,0,18,0,0,0,19,0,0,0,61,0,4,0,6,0,0,0,22,0,0,0,21,0,0,0,65,0,5,0,26,0,0,0,27,0,0,0,25,0,0,0,15,0,0,0,61,0,4,0,6,0,0,0,28,0,0,0,27,0,0,0,136,0,5,0,6,0,0,0,29,0,0,0,22,0,0,0,28,0,0,0,131,0,5,0,6,0,0,0,31,0,0,0,29,0,0,0,30,0,0,0,65,0,5,0,20,0,0,0,32,0,0,0,18,0,0,0,9,0,0,0,61,0,4,0,6,0,0,0,33,0,0,0,32,0,0,0,65,0,5,0,26,0,0,0,35,0,0,0,25,0,0,0,34,0,0,0,61,0,4,0,6,0,0,0,36,0,0,0,35,0,0,0,136,0,5,0,6,0,0,0,37,0,0,0,33,0,0,0,36,0,0,0,129,0,5,0,6,0,0,0,38,0,0,0,37,0,0,0,30,0,0,0,127,0,4,0,6,0,0,0,39,0,0,0,38,0,0,0,80,0,7,0,7,0,0,0,41,0,0,0,31,0,0,0,39,0,0,0,40,0,0,0,30,0,0,0,65,0,5,0,42,0,0,0,43,0,0,0,13,0,0,0,15,0,0,0,62,0,3,0,43,0,0,0,41,0,0,0,65,0,5,0,20,0,0,0,45,0,0,0,18,0,0,0,19,0,0,0,61,0,4,0,6,0,0,0,46,0,0,0,45,0,0,0,65,0,5,0,20,0,0,0,48,0,0,0,47,0,0,0,19,0,0,0,61,0,4,0,6,0,0,0,49,0,0,0,48,0,0,0,12,0,7,0,6,0,0,0,50,0,0,0,1,0,0,0,37,0,0,0,46,0,0,0,49,0,0,0,65,0,5,0,20,0,0,0,51,0,0,0,18,0,0,0,19,0,0,0,61,0,4,0,6,0,0,0,52,0,0,0,51,0,0,0,65,0,5,0,20,0,0,0,53,0,0,0,47,0,0,0,19,0,0,0,61,0,4,0,6,0,0,0,54,0,0,0,53,0,0,0,12,0,7,0,6,0,0,0,55,0,0,0,1,0,0,0,40,0,0,0,52,0,0,0,54,0,0,0,61,0,4,0,8,0,0,0,58,0,0,0,57,0,0,0,199,0,5,0,8,0,0,0,59,0,0,0,58,0,0,0,9,0,0,0,172,0,5,0,60,0,0,0,61,0,0,0,59,0,0,0,19,0,0,0,247,0,3,0,65,0,0,0,0,0,0,0,250,0,4,0,61,0,0,0,64,0,0,0,71,0,0,0,248,0,2,0,64,0,0,0,65,0,5,0,20,0,0,0,66,0,0,0,18,0,0,0,9,0,0,0,61,0,4,0,6,0,0,0,67,0,0,0,66,0,0,0,65,0,5,0,20,0,0,0,68,0,0,0,47,0,0,0,9,0,0,0,61,0,4,0,6,0,0,0,69,0,0,0,68,0,0,0,12,0,7,0,6,0,0,0,70,0,0,0,1,0,0,0,37,0,0,0,67,0,0,0,69,0,0,0,62,0,3,0,63,0,0,0,70,0,0,0,249,0,2,0,65,0,0,0,248,0,2,0,71,0,0,0,62,0,3,0,63,0,0,0,72,0,0,0,249,0,2,0,65,0,0,0,248,0,2,0,65,0,0,0,61,0,4,0,6,0,0,0,73,0,0,0,63,0,0,0,61,0,4,0,8,0,0,0,74,0,0,0,57,0,0,0,199,0,5,0,8,0,0,0,76,0,0,0,74,0,0,0,75,0,0,0,172,0,5,0,60,0,0,0,77,0,0,0,76,0,0,0,19,0,0,0,247,0,3,0,80,0,0,0,0,0,0,0,250,0,4,0,77,0,0,0,79,0,0,0,86,0,0,0,248,0,2,0,79,0,0,0,65,0,5,0,20,0,0,0,81,0,0,0,18,0,0,0,9,0,0,0,61,0,4,0,6,0,0,0,82,0,0,0,81,0,0,0,65,0,5,0,20,0,0,0,83,0,0,0,47,0,0,0,9,0,0,0,61,0,4,0,6,0,0,0,84,0,0,0,83,0,0,0,12,0,7,0,6,0,0,0,85,0,0,0,1,0,0,0,40,0,0,0,82,0,0,0,84,0,0,0,62,0,3,0,78,0,0,0,85,0,0,0,249,0,2,0,80,0,0,0,248,0,2,0,86,0,0,0,62,0,3,0,78,0,0,0,72,0,0,0,249,0,2,0,80,0,0,0,248,0,2,0,80,0,0,0,61,0,4,0,6,0,0,0,87,0,0,0,78,0,0,0,80,0,7,0,7,0,0,0,88,0,0,0,50,0,0,0,55,0,0,0,73,0,0,0,87,0,0,0,62,0,3,0,44,0,0,0,88,0,0,0,253,0,1,0,56,0,1,0};
uint8_t bufshaderfragexp[] = {3,2,35,7,0,0,1,0,10,0,13,0,103,0,0,0,0,0,0,0,17,0,2,0,1,0,0,0,11,0,6,0,1,0,0,0,71,76,83,76,46,115,116,100,46,52,53,48,0,0,0,0,14,0,3,0,0,0,0,0,1,0,0,0,15,0,8,0,4,0,0,0,4,0,0,0,109,97,105,110,0,0,0,0,10,0,0,0,18,0,0,0,94,0,0,0,16,0,3,0,4,0,0,0,7,0,0,0,3,0,3,0,2,0,0,0,144,1,0,0,4,0,9,0,71,76,95,65,82,66,95,115,101,112,97,114,97,116,101,95,115,104,97,100,101,114,95,111,98,106,101,99,116,115,0,0,4,0,9,0,71,76,95,65,82,66,95,115,104,97,100,105,110,103,95,108,97,110,103,117,97,103,101,95,52,50,48,112,97,99,107,0,4,0,10,0,71,76,95,71,79,79,71,76,69,95,99,112,112,95,115,116,121,108,101,95,108,105,110,101,95,100,105,114,101,99,116,105,118,101,0,0,4,0,8,0,71,76,95,71,79,79,71,76,69,95,105,110,99,108,117,100,101,95,100,105,114,101,99,116,105,118,101,0,5,0,4,0,4,0,0,0,109,97,105,110,0,0,0,0,5,0,4,0,10,0,0,0,108,114,117,100,0,0,0,0,5,0,6,0,18,0,0,0,103,108,95,70,114,97,103,67,111,111,114,100,0,0,0,0,5,0,5,0,94,0,0,0,117,70,114,97,103,67,111,108,111,114,0,0,71,0,3,0,10,0,0,0,14,0,0,0,71,0,4,0,10,0,0,0,30,0,0,0,0,0,0,0,71,0,4,0,18,0,0,0,11,0,0,0,15,0,0,0,71,0,4,0,94,0,0,0,30,0,0,0,0,0,0,0,19,0,2,0,2,0,0,0,33,0,3,0,3,0,0,0,2,0,0,0,20,0,2,0,6,0,0,0,22,0,3,0,7,0,0,0,32,0,0,0,23,0,4,0,8,0,0,0,7,0,0,0,4,0,0,0,32,0,4,0,9,0,0,0,1,0,0,0,8,0,0,0,59,0,4,0,9,0,0,0,10,0,0,0,1,0,0,0,21,0,4,0,11,0,0,0,32,0,0,0,0,0,0,0,43,0,4,0,11,0,0,0,12,0,0,0,0,0,0,0,32,0,4,0,13,0,0,0,1,0,0,0,7,0,0,0,43,0,4,0,7,0,0,0,16,0,0,0,0,0,0,64,59,0,4,0,9,0,0,0,18,0,0,0,1,0,0,0,43,0,4,0,11,0,0,0,34,0,0,0,1,0,0,0,43,0,4,0,11,0,0,0,54,0,0,0,2,0,0,0,43,0,4,0,11,0,0,0,74,0,0,0,3,0,0,0,32,0,4,0,93,0,0,0,3,0,0,0,8,0,0,0,59,0,4,0,93,0,0,0,94,0,0,0,3,0,0,0,43,0,4,0,7,0,0,0,95,0,0,0,135,22,89,62,43,0,4,0,7,0,0,0,96,0,0,0,59,223,79,63,43,0,4,0,7,0,0,0,97,0,0,0,92,143,194,62,43,0,4,0,7,0,0,0,98,0,0,0,0,0,128,63,44,0,7,0,8,0,0,0,99,0,0,0,95,0,0,0,96,0,0,0,97,0,0,0,98,0,0,0,43,0,4,0,7,0,0,0,101,0,0,0,0,0,0,0,44,0,7,0,8,0,0,0,102,0,0,0,101,0,0,0,101,0,0,0,101,0,0,0,101,0,0,0,54,0,5,0,2,0,0,0,4,0,0,0,0,0,0,0,3,0,0,0,248,0,2,0,5,0,0,0,65,0,5,0,13,0,0,0,14,0,0,0,10,0,0,0,12,0,0,0,61,0,4,0,7,0,0,0,15,0,0,0,14,0,0,0,131,0,5,0,7,0,0,0,17,0,0,0,15,0,0,0,16,0,0,0,65,0,5,0,13,0,0,0,19,0,0,0,18,0,0,0,12,0,0,0,61,0,4,0,7,0,0,0,20,0,0,0,19,0,0,0,184,0,5,0,6,0,0,0,21,0,0,0,17,0,0,0,20,0,0,0,247,0,3,0,23,0,0,0,0,0,0,0,250,0,4,0,21,0,0,0,22,0,0,0,23,0,0,0,248,0,2,0,22,0,0,0,65,0,5,0,13,0,0,0,24,0,0,0,18,0,0,0,12,0,0,0,61,0,4,0,7,0,0,0,25,0,0,0,24,0,0,0,65,0,5,0,13,0,0,0,26,0,0,0,10,0,0,0,12,0,0,0,61,0,4,0,7,0,0,0,27,0,0,0,26,0,0,0,129,0,5,0,7,0,0,0,28,0,0,0,27,0,0,0,16,0,0,0,184,0,5,0,6,0,0,0,29,0,0,0,25,0,0,0,28,0,0,0,249,0,2,0,23,0,0,0,248,0,2,0,23,0,0,0,245,0,7,0,6,0,0,0,30,0,0,0,21,0,0,0,5,0,0,0,29,0,0,0,22,0,0,0,168,0,4,0,6,0,0,0,31,0,0,0,30,0,0,0,247,0,3,0,33,0,0,0,0,0,0,0,250,0,4,0,31,0,0,0,32,0,0,0,33,0,0,0,248,0,2,0,32,0,0,0,65,0,5,0,13,0,0,0,35,0,0,0,10,0,0,0,34,0,0,0,61,0,4,0,7,0,0,0,36,0,0,0,35,0,0,0,131,0,5,0,7,0,0,0,37,0,0,0,36,0,0,0,16,0,0,0,65,0,5,0,13,0,0,0,38,0,0,0,18,0,0,0,12,0,0,0,61,0,4,0,7,0,0,0,39,0,0,0,38,0,0,0,184,0,5,0,6,0,0,0,40,0,0,0,37,0,0,0,39,0,0,0,247,0,3,0,42,0,0,0,0,0,0,0,250,0,4,0,40,0,0,0,41,0,0,0,42,0,0,0,248,0,2,0,41,0,0,0,65,0,5,0,13,0,0,0,43,0,0,0,18,0,0,0,12,0,0,0,61,0,4,0,7,0,0,0,44,0,0,0,43,0,0,0,65,0,5,0,13,0,0,0,45,0,0,0,10,0,0,0,34,0,0,0,61,0,4,0,7,0,0,0,46,0,0,0,45,0,0,0,129,0,5,0,7,0,0,0,47,0,0,0,46,0,0,0,16,0,0,0,184,0,5,0,6,0,0,0,48,0,0,0,44,0,0,0,47,0,0,0,249,0,2,0,42,0,0,0,248,0,2,0,42,0,0,0,245,0,7,0,6,0,0,0,49,0,0,0,40,0,0,0,32,0,0,0,48,0,0,0,41,0,0,0,249,0,2,0,33,0,0,0,248,0,2,0,33,0,0,0,245,0,7,0,6,0,0,0,50,0,0,0,30,0,0,0,23,0,0,0,49,0,0,0,42,0,0,0,168,0,4,0,6,0,0,0,51,0,0,0,50,0,0,0,247,0,3,0,53,0,0,0,0,0,0,0,250,0,4,0,51,0,0,0,52,0,0,0,53,0,0,0,248,0,2,0,52,0,0,0,65,0,5,0,13,0,0,0,55,0,0,0,10,0,0,0,54,0,0,0,61,0,4,0,7,0,0,0,56,0,0,0,55,0,0,0,131,0,5,0,7,0,0,0,57,0,0,0,56,0,0,0,16,0,0,0,65,0,5,0,13,0,0,0,58,0,0,0,18,0,0,0,34,0,0,0,61,0,4,0,7,0,0,0,59,0,0,0,58,0,0,0,184,0,5,0,6,0,0,0,60,0,0,0,57,0,0,0,59,0,0,0,247,0,3,0,62,0,0,0,0,0,0,0,250,0,4,0,60,0,0,0,61,0,0,0,62,0,0,0,248,0,2,0,61,0,0,0,65,0,5,0,13,0,0,0,63,0,0,0,18,0,0,0,34,0,0,0,61,0,4,0,7,0,0,0,64,0,0,0,63,0,0,0,65,0,5,0,13,0,0,0,65,0,0,0,10,0,0,0,54,0,0,0,61,0,4,0,7,0,0,0,66,0,0,0,65,0,0,0,129,0,5,0,7,0,0,0,67,0,0,0,66,0,0,0,16,0,0,0,184,0,5,0,6,0,0,0,68,0,0,0,64,0,0,0,67,0,0,0,249,0,2,0,62,0,0,0,248,0,2,0,62,0,0,0,245,0,7,0,6,0,0,0,69,0,0,0,60,0,0,0,52,0,0,0,68,0,0,0,61,0,0,0,249,0,2,0,53,0,0,0,248,0,2,0,53,0,0,0,245,0,7,0,6,0,0,0,70,0,0,0,50,0,0,0,33,0,0,0,69,0,0,0,62,0,0,0,168,0,4,0,6,0,0,0,71,0,0,0,70,0,0,0,247,0,3,0,73,0,0,0,0,0,0,0,250,0,4,0,71,0,0,0,72,0,0,0,73,0,0,0,248,0,2,0,72,0,0,0,65,0,5,0,13,0,0,0,75,0,0,0,10,0,0,0,74,0,0,0,61,0,4,0,7,0,0,0,76,0,0,0,75,0,0,0,131,0,5,0,7,0,0,0,77,0,0,0,76,0,0,0,16,0,0,0,65,0,5,0,13,0,0,0,78,0,0,0,18,0,0,0,34,0,0,0,61,0,4,0,7,0,0,0,79,0,0,0,78,0,0,0,184,0,5,0,6,0,0,0,80,0,0,0,77,0,0,0,79,0,0,0,247,0,3,0,82,0,0,0,0,0,0,0,250,0,4,0,80,0,0,0,81,0,0,0,82,0,0,0,248,0,2,0,81,0,0,0,65,0,5,0,13,0,0,0,83,0,0,0,18,0,0,0,34,0,0,0,61,0,4,0,7,0,0,0,84,0,0,0,83,0,0,0,65,0,5,0,13,0,0,0,85,0,0,0,10,0,0,0,74,0,0,0,61,0,4,0,7,0,0,0,86,0,0,0,85,0,0,0,129,0,5,0,7,0,0,0,87,0,0,0,86,0,0,0,16,0,0,0,184,0,5,0,6,0,0,0,88,0,0,0,84,0,0,0,87,0,0,0,249,0,2,0,82,0,0,0,248,0,2,0,82,0,0,0,245,0,7,0,6,0,0,0,89,0,0,0,80,0,0,0,72,0,0,0,88,0,0,0,81,0,0,0,249,0,2,0,73,0,0,0,248,0,2,0,73,0,0,0,245,0,7,0,6,0,0,0,90,0,0,0,70,0,0,0,53,0,0,0,89,0,0,0,82,0,0,0,247,0,3,0,92,0,0,0,0,0,0,0,250,0,4,0,90,0,0,0,91,0,0,0,100,0,0,0,248,0,2,0,91,0,0,0,62,0,3,0,94,0,0,0,99,0,0,0,249,0,2,0,92,0,0,0,248,0,2,0,100,0,0,0,62,0,3,0,94,0,0,0,102,0,0,0,249,0,2,0,92,0,0,0,248,0,2,0,92,0,0,0,253,0,1,0,56,0,1,0};
uint8_t bufshaderverttextkb[] = {3,2,35,7,0,0,1,0,10,0,13,0,48,0,0,0,0,0,0,0,17,0,2,0,1,0,0,0,11,0,6,0,1,0,0,0,71,76,83,76,46,115,116,100,46,52,53,48,0,0,0,0,14,0,3,0,0,0,0,0,1,0,0,0,15,0,9,0,0,0,0,0,4,0,0,0,109,97,105,110,0,0,0,0,9,0,0,0,11,0,0,0,19,0,0,0,22,0,0,0,3,0,3,0,2,0,0,0,144,1,0,0,4,0,9,0,71,76,95,65,82,66,95,115,101,112,97,114,97,116,101,95,115,104,97,100,101,114,95,111,98,106,101,99,116,115,0,0,4,0,9,0,71,76,95,65,82,66,95,115,104,97,100,105,110,103,95,108,97,110,103,117,97,103,101,95,52,50,48,112,97,99,107,0,4,0,10,0,71,76,95,71,79,79,71,76,69,95,99,112,112,95,115,116,121,108,101,95,108,105,110,101,95,100,105,114,101,99,116,105,118,101,0,0,4,0,8,0,71,76,95,71,79,79,71,76,69,95,105,110,99,108,117,100,101,95,100,105,114,101,99,116,105,118,101,0,5,0,4,0,4,0,0,0,109,97,105,110,0,0,0,0,5,0,5,0,9,0,0,0,116,101,120,99,111,111,114,100,111,117,116,0,5,0,5,0,11,0,0,0,116,101,120,99,111,111,114,100,105,110,0,0,5,0,6,0,17,0,0,0,103,108,95,80,101,114,86,101,114,116,101,120,0,0,0,0,6,0,6,0,17,0,0,0,0,0,0,0,103,108,95,80,111,115,105,116,105,111,110,0,6,0,7,0,17,0,0,0,1,0,0,0,103,108,95,80,111,105,110,116,83,105,122,101,0,0,0,0,6,0,7,0,17,0,0,0,2,0,0,0,103,108,95,67,108,105,112,68,105,115,116,97,110,99,101,0,5,0,3,0,19,0,0,0,0,0,0,0,5,0,3,0,22,0,0,0,112,111,115,0,5,0,4,0,27,0,0,0,83,99,97,108,101,0,0,0,6,0,4,0,27,0,0,0,0,0,0,0,120,0,0,0,6,0,4,0,27,0,0,0,1,0,0,0,121,0,0,0,5,0,4,0,29,0,0,0,115,99,97,108,101,0,0,0,71,0,4,0,9,0,0,0,30,0,0,0,0,0,0,0,71,0,4,0,11,0,0,0,30,0,0,0,1,0,0,0,72,0,5,0,17,0,0,0,0,0,0,0,11,0,0,0,0,0,0,0,72,0,5,0,17,0,0,0,1,0,0,0,11,0,0,0,1,0,0,0,72,0,5,0,17,0,0,0,2,0,0,0,11,0,0,0,3,0,0,0,71,0,3,0,17,0,0,0,2,0,0,0,71,0,4,0,22,0,0,0,30,0,0,0,0,0,0,0,72,0,5,0,27,0,0,0,0,0,0,0,35,0,0,0,0,0,0,0,72,0,5,0,27,0,0,0,1,0,0,0,35,0,0,0,4,0,0,0,71,0,3,0,27,0,0,0,2,0,0,0,19,0,2,0,2,0,0,0,33,0,3,0,3,0,0,0,2,0,0,0,22,0,3,0,6,0,0,0,32,0,0,0,23,0,4,0,7,0,0,0,6,0,0,0,2,0,0,0,32,0,4,0,8,0,0,0,3,0,0,0,7,0,0,0,59,0,4,0,8,0,0,0,9,0,0,0,3,0,0,0,32,0,4,0,10,0,0,0,1,0,0,0,7,0,0,0,59,0,4,0,10,0,0,0,11,0,0,0,1,0,0,0,23,0,4,0,13,0,0,0,6,0,0,0,4,0,0,0,21,0,4,0,14,0,0,0,32,0,0,0,0,0,0,0,43,0,4,0,14,0,0,0,15,0,0,0,1,0,0,0,28,0,4,0,16,0,0,0,6,0,0,0,15,0,0,0,30,0,5,0,17,0,0,0,13,0,0,0,6,0,0,0,16,0,0,0,32,0,4,0,18,0,0,0,3,0,0,0,17,0,0,0,59,0,4,0,18,0,0,0,19,0,0,0,3,0,0,0,21,0,4,0,20,0,0,0,32,0,0,0,1,0,0,0,43,0,4,0,20,0,0,0,21,0,0,0,0,0,0,0,59,0,4,0,10,0,0,0,22,0,0,0,1,0,0,0,43,0,4,0,14,0,0,0,23,0,0,0,0,0,0,0,32,0,4,0,24,0,0,0,1,0,0,0,6,0,0,0,30,0,4,0,27,0,0,0,6,0,0,0,6,0,0,0,32,0,4,0,28,0,0,0,9,0,0,0,27,0,0,0,59,0,4,0,28,0,0,0,29,0,0,0,9,0,0,0,32,0,4,0,30,0,0,0,9,0,0,0,6,0,0,0,43,0,4,0,6,0,0,0,34,0,0,0,0,0,128,63,43,0,4,0,20,0,0,0,38,0,0,0,1,0,0,0,43,0,4,0,6,0,0,0,44,0,0,0,0,0,0,0,32,0,4,0,46,0,0,0,3,0,0,0,13,0,0,0,54,0,5,0,2,0,0,0,4,0,0,0,0,0,0,0,3,0,0,0,248,0,2,0,5,0,0,0,61,0,4,0,7,0,0,0,12,0,0,0,11,0,0,0,62,0,3,0,9,0,0,0,12,0,0,0,65,0,5,0,24,0,0,0,25,0,0,0,22,0,0,0,23,0,0,0,61,0,4,0,6,0,0,0,26,0,0,0,25,0,0,0,65,0,5,0,30,0,0,0,31,0,0,0,29,0,0,0,21,0,0,0,61,0,4,0,6,0,0,0,32,0,0,0,31,0,0,0,136,0,5,0,6,0,0,0,33,0,0,0,26,0,0,0,32,0,0,0,131,0,5,0,6,0,0,0,35,0,0,0,33,0,0,0,34,0,0,0,65,0,5,0,24,0,0,0,36,0,0,0,22,0,0,0,15,0,0,0,61,0,4,0,6,0,0,0,37,0,0,0,36,0,0,0,65,0,5,0,30,0,0,0,39,0,0,0,29,0,0,0,38,0,0,0,61,0,4,0,6,0,0,0,40,0,0,0,39,0,0,0,136,0,5,0,6,0,0,0,41,0,0,0,37,0,0,0,40,0,0,0,129,0,5,0,6,0,0,0,42,0,0,0,41,0,0,0,34,0,0,0,127,0,4,0,6,0,0,0,43,0,0,0,42,0,0,0,80,0,7,0,13,0,0,0,45,0,0,0,35,0,0,0,43,0,0,0,44,0,0,0,34,0,0,0,65,0,5,0,46,0,0,0,47,0,0,0,19,0,0,0,21,0,0,0,62,0,3,0,47,0,0,0,45,0,0,0,253,0,1,0,56,0,1,0};
uint8_t bufshaderfragtextkb[] = {3,2,35,7,0,0,1,0,10,0,13,0,52,0,0,0,0,0,0,0,17,0,2,0,1,0,0,0,11,0,6,0,1,0,0,0,71,76,83,76,46,115,116,100,46,52,53,48,0,0,0,0,14,0,3,0,0,0,0,0,1,0,0,0,15,0,7,0,4,0,0,0,4,0,0,0,109,97,105,110,0,0,0,0,17,0,0,0,27,0,0,0,16,0,3,0,4,0,0,0,7,0,0,0,3,0,3,0,2,0,0,0,144,1,0,0,4,0,9,0,71,76,95,65,82,66,95,115,101,112,97,114,97,116,101,95,115,104,97,100,101,114,95,111,98,106,101,99,116,115,0,0,4,0,9,0,71,76,95,65,82,66,95,115,104,97,100,105,110,103,95,108,97,110,103,117,97,103,101,95,52,50,48,112,97,99,107,0,4,0,10,0,71,76,95,71,79,79,71,76,69,95,99,112,112,95,115,116,121,108,101,95,108,105,110,101,95,100,105,114,101,99,116,105,118,101,0,0,4,0,8,0,71,76,95,71,79,79,71,76,69,95,105,110,99,108,117,100,101,95,100,105,114,101,99,116,105,118,101,0,5,0,4,0,4,0,0,0,109,97,105,110,0,0,0,0,5,0,3,0,9,0,0,0,116,101,120,0,5,0,3,0,13,0,0,0,116,101,120,0,5,0,5,0,17,0,0,0,116,101,120,99,111,111,114,100,0,0,0,0,5,0,4,0,22,0,0,0,99,111,108,111,114,0,0,0,5,0,5,0,27,0,0,0,117,70,114,97,103,67,111,108,111,114,0,0,71,0,4,0,13,0,0,0,34,0,0,0,0,0,0,0,71,0,4,0,13,0,0,0,33,0,0,0,0,0,0,0,71,0,4,0,17,0,0,0,30,0,0,0,0,0,0,0,71,0,4,0,27,0,0,0,30,0,0,0,0,0,0,0,19,0,2,0,2,0,0,0,33,0,3,0,3,0,0,0,2,0,0,0,22,0,3,0,6,0,0,0,32,0,0,0,23,0,4,0,7,0,0,0,6,0,0,0,4,0,0,0,32,0,4,0,8,0,0,0,7,0,0,0,7,0,0,0,25,0,9,0,10,0,0,0,6,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,27,0,3,0,11,0,0,0,10,0,0,0,32,0,4,0,12,0,0,0,0,0,0,0,11,0,0,0,59,0,4,0,12,0,0,0,13,0,0,0,0,0,0,0,23,0,4,0,15,0,0,0,6,0,0,0,2,0,0,0,32,0,4,0,16,0,0,0,1,0,0,0,15,0,0,0,59,0,4,0,16,0,0,0,17,0,0,0,1,0,0,0,23,0,4,0,20,0,0,0,6,0,0,0,3,0,0,0,32,0,4,0,21,0,0,0,7,0,0,0,20,0,0,0,43,0,4,0,6,0,0,0,23,0,0,0,0,0,0,0,43,0,4,0,6,0,0,0,24,0,0,0,0,0,128,63,44,0,6,0,20,0,0,0,25,0,0,0,23,0,0,0,23,0,0,0,24,0,0,0,32,0,4,0,26,0,0,0,3,0,0,0,7,0,0,0,59,0,4,0,26,0,0,0,27,0,0,0,3,0,0,0,21,0,4,0,28,0,0,0,32,0,0,0,0,0,0,0,43,0,4,0,28,0,0,0,29,0,0,0,0,0,0,0,32,0,4,0,30,0,0,0,7,0,0,0,6,0,0,0,43,0,4,0,28,0,0,0,36,0,0,0,1,0,0,0,43,0,4,0,28,0,0,0,42,0,0,0,2,0,0,0,43,0,4,0,28,0,0,0,48,0,0,0,3,0,0,0,54,0,5,0,2,0,0,0,4,0,0,0,0,0,0,0,3,0,0,0,248,0,2,0,5,0,0,0,59,0,4,0,8,0,0,0,9,0,0,0,7,0,0,0,59,0,4,0,21,0,0,0,22,0,0,0,7,0,0,0,61,0,4,0,11,0,0,0,14,0,0,0,13,0,0,0,61,0,4,0,15,0,0,0,18,0,0,0,17,0,0,0,87,0,5,0,7,0,0,0,19,0,0,0,14,0,0,0,18,0,0,0,62,0,3,0,9,0,0,0,19,0,0,0,62,0,3,0,22,0,0,0,25,0,0,0,65,0,5,0,30,0,0,0,31,0,0,0,9,0,0,0,29,0,0,0,61,0,4,0,6,0,0,0,32,0,0,0,31,0,0,0,65,0,5,0,30,0,0,0,33,0,0,0,22,0,0,0,29,0,0,0,61,0,4,0,6,0,0,0,34,0,0,0,33,0,0,0,133,0,5,0,6,0,0,0,35,0,0,0,32,0,0,0,34,0,0,0,65,0,5,0,30,0,0,0,37,0,0,0,9,0,0,0,36,0,0,0,61,0,4,0,6,0,0,0,38,0,0,0,37,0,0,0,65,0,5,0,30,0,0,0,39,0,0,0,22,0,0,0,36,0,0,0,61,0,4,0,6,0,0,0,40,0,0,0,39,0,0,0,133,0,5,0,6,0,0,0,41,0,0,0,38,0,0,0,40,0,0,0,65,0,5,0,30,0,0,0,43,0,0,0,9,0,0,0,42,0,0,0,61,0,4,0,6,0,0,0,44,0,0,0,43,0,0,0,65,0,5,0,30,0,0,0,45,0,0,0,22,0,0,0,42,0,0,0,61,0,4,0,6,0,0,0,46,0,0,0,45,0,0,0,133,0,5,0,6,0,0,0,47,0,0,0,44,0,0,0,46,0,0,0,65,0,5,0,30,0,0,0,49,0,0,0,9,0,0,0,48,0,0,0,61,0,4,0,6,0,0,0,50,0,0,0,49,0,0,0,80,0,7,0,7,0,0,0,51,0,0,0,35,0,0,0,41,0,0,0,47,0,0,0,50,0,0,0,62,0,3,0,27,0,0,0,51,0,0,0,253,0,1,0,56,0,1,0};
uint8_t bufshadervertbackkb[] = {3,2,35,7,0,0,1,0,10,0,13,0,44,0,0,0,0,0,0,0,17,0,2,0,1,0,0,0,11,0,6,0,1,0,0,0,71,76,83,76,46,115,116,100,46,52,53,48,0,0,0,0,14,0,3,0,0,0,0,0,1,0,0,0,15,0,7,0,0,0,0,0,4,0,0,0,109,97,105,110,0,0,0,0,13,0,0,0,18,0,0,0,3,0,3,0,2,0,0,0,144,1,0,0,4,0,9,0,71,76,95,65,82,66,95,115,101,112,97,114,97,116,101,95,115,104,97,100,101,114,95,111,98,106,101,99,116,115,0,0,4,0,9,0,71,76,95,65,82,66,95,115,104,97,100,105,110,103,95,108,97,110,103,117,97,103,101,95,52,50,48,112,97,99,107,0,4,0,10,0,71,76,95,71,79,79,71,76,69,95,99,112,112,95,115,116,121,108,101,95,108,105,110,101,95,100,105,114,101,99,116,105,118,101,0,0,4,0,8,0,71,76,95,71,79,79,71,76,69,95,105,110,99,108,117,100,101,95,100,105,114,101,99,116,105,118,101,0,5,0,4,0,4,0,0,0,109,97,105,110,0,0,0,0,5,0,6,0,11,0,0,0,103,108,95,80,101,114,86,101,114,116,101,120,0,0,0,0,6,0,6,0,11,0,0,0,0,0,0,0,103,108,95,80,111,115,105,116,105,111,110,0,6,0,7,0,11,0,0,0,1,0,0,0,103,108,95,80,111,105,110,116,83,105,122,101,0,0,0,0,6,0,7,0,11,0,0,0,2,0,0,0,103,108,95,67,108,105,112,68,105,115,116,97,110,99,101,0,5,0,3,0,13,0,0,0,0,0,0,0,5,0,3,0,18,0,0,0,112,111,115,0,5,0,4,0,23,0,0,0,83,99,97,108,101,0,0,0,6,0,4,0,23,0,0,0,0,0,0,0,120,0,0,0,6,0,4,0,23,0,0,0,1,0,0,0,121,0,0,0,5,0,4,0,25,0,0,0,115,99,97,108,101,0,0,0,72,0,5,0,11,0,0,0,0,0,0,0,11,0,0,0,0,0,0,0,72,0,5,0,11,0,0,0,1,0,0,0,11,0,0,0,1,0,0,0,72,0,5,0,11,0,0,0,2,0,0,0,11,0,0,0,3,0,0,0,71,0,3,0,11,0,0,0,2,0,0,0,71,0,4,0,18,0,0,0,30,0,0,0,0,0,0,0,72,0,5,0,23,0,0,0,0,0,0,0,35,0,0,0,0,0,0,0,72,0,5,0,23,0,0,0,1,0,0,0,35,0,0,0,4,0,0,0,71,0,3,0,23,0,0,0,2,0,0,0,19,0,2,0,2,0,0,0,33,0,3,0,3,0,0,0,2,0,0,0,22,0,3,0,6,0,0,0,32,0,0,0,23,0,4,0,7,0,0,0,6,0,0,0,4,0,0,0,21,0,4,0,8,0,0,0,32,0,0,0,0,0,0,0,43,0,4,0,8,0,0,0,9,0,0,0,1,0,0,0,28,0,4,0,10,0,0,0,6,0,0,0,9,0,0,0,30,0,5,0,11,0,0,0,7,0,0,0,6,0,0,0,10,0,0,0,32,0,4,0,12,0,0,0,3,0,0,0,11,0,0,0,59,0,4,0,12,0,0,0,13,0,0,0,3,0,0,0,21,0,4,0,14,0,0,0,32,0,0,0,1,0,0,0,43,0,4,0,14,0,0,0,15,0,0,0,0,0,0,0,23,0,4,0,16,0,0,0,6,0,0,0,2,0,0,0,32,0,4,0,17,0,0,0,1,0,0,0,16,0,0,0,59,0,4,0,17,0,0,0,18,0,0,0,1,0,0,0,43,0,4,0,8,0,0,0,19,0,0,0,0,0,0,0,32,0,4,0,20,0,0,0,1,0,0,0,6,0,0,0,30,0,4,0,23,0,0,0,6,0,0,0,6,0,0,0,32,0,4,0,24,0,0,0,9,0,0,0,23,0,0,0,59,0,4,0,24,0,0,0,25,0,0,0,9,0,0,0,32,0,4,0,26,0,0,0,9,0,0,0,6,0,0,0,43,0,4,0,6,0,0,0,30,0,0,0,0,0,128,63,43,0,4,0,14,0,0,0,34,0,0,0,1,0,0,0,43,0,4,0,6,0,0,0,40,0,0,0,0,0,0,0,32,0,4,0,42,0,0,0,3,0,0,0,7,0,0,0,54,0,5,0,2,0,0,0,4,0,0,0,0,0,0,0,3,0,0,0,248,0,2,0,5,0,0,0,65,0,5,0,20,0,0,0,21,0,0,0,18,0,0,0,19,0,0,0,61,0,4,0,6,0,0,0,22,0,0,0,21,0,0,0,65,0,5,0,26,0,0,0,27,0,0,0,25,0,0,0,15,0,0,0,61,0,4,0,6,0,0,0,28,0,0,0,27,0,0,0,136,0,5,0,6,0,0,0,29,0,0,0,22,0,0,0,28,0,0,0,131,0,5,0,6,0,0,0,31,0,0,0,29,0,0,0,30,0,0,0,65,0,5,0,20,0,0,0,32,0,0,0,18,0,0,0,9,0,0,0,61,0,4,0,6,0,0,0,33,0,0,0,32,0,0,0,65,0,5,0,26,0,0,0,35,0,0,0,25,0,0,0,34,0,0,0,61,0,4,0,6,0,0,0,36,0,0,0,35,0,0,0,136,0,5,0,6,0,0,0,37,0,0,0,33,0,0,0,36,0,0,0,129,0,5,0,6,0,0,0,38,0,0,0,37,0,0,0,30,0,0,0,127,0,4,0,6,0,0,0,39,0,0,0,38,0,0,0,80,0,7,0,7,0,0,0,41,0,0,0,31,0,0,0,39,0,0,0,40,0,0,0,30,0,0,0,65,0,5,0,42,0,0,0,43,0,0,0,13,0,0,0,15,0,0,0,62,0,3,0,43,0,0,0,41,0,0,0,253,0,1,0,56,0,1,0};
uint8_t bufshaderfragbackkb[] = {3,2,35,7,0,0,1,0,10,0,13,0,12,0,0,0,0,0,0,0,17,0,2,0,1,0,0,0,11,0,6,0,1,0,0,0,71,76,83,76,46,115,116,100,46,52,53,48,0,0,0,0,14,0,3,0,0,0,0,0,1,0,0,0,15,0,6,0,4,0,0,0,4,0,0,0,109,97,105,110,0,0,0,0,9,0,0,0,16,0,3,0,4,0,0,0,7,0,0,0,3,0,3,0,2,0,0,0,144,1,0,0,4,0,9,0,71,76,95,65,82,66,95,115,101,112,97,114,97,116,101,95,115,104,97,100,101,114,95,111,98,106,101,99,116,115,0,0,4,0,9,0,71,76,95,65,82,66,95,115,104,97,100,105,110,103,95,108,97,110,103,117,97,103,101,95,52,50,48,112,97,99,107,0,4,0,10,0,71,76,95,71,79,79,71,76,69,95,99,112,112,95,115,116,121,108,101,95,108,105,110,101,95,100,105,114,101,99,116,105,118,101,0,0,4,0,8,0,71,76,95,71,79,79,71,76,69,95,105,110,99,108,117,100,101,95,100,105,114,101,99,116,105,118,101,0,5,0,4,0,4,0,0,0,109,97,105,110,0,0,0,0,5,0,5,0,9,0,0,0,117,70,114,97,103,67,111,108,111,114,0,0,71,0,4,0,9,0,0,0,30,0,0,0,0,0,0,0,19,0,2,0,2,0,0,0,33,0,3,0,3,0,0,0,2,0,0,0,22,0,3,0,6,0,0,0,32,0,0,0,23,0,4,0,7,0,0,0,6,0,0,0,4,0,0,0,32,0,4,0,8,0,0,0,3,0,0,0,7,0,0,0,59,0,4,0,8,0,0,0,9,0,0,0,3,0,0,0,43,0,4,0,6,0,0,0,10,0,0,0,0,0,128,63,44,0,7,0,7,0,0,0,11,0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,54,0,5,0,2,0,0,0,4,0,0,0,0,0,0,0,3,0,0,0,248,0,2,0,5,0,0,0,62,0,3,0,9,0,0,0,11,0,0,0,253,0,1,0,56,0,1,0};
uint8_t bufshadervertbtnkb[] = {3,2,35,7,0,0,1,0,10,0,13,0,67,0,0,0,0,0,0,0,17,0,2,0,1,0,0,0,11,0,6,0,1,0,0,0,71,76,83,76,46,115,116,100,46,52,53,48,0,0,0,0,14,0,3,0,0,0,0,0,1,0,0,0,15,0,9,0,0,0,0,0,4,0,0,0,109,97,105,110,0,0,0,0,13,0,0,0,18,0,0,0,44,0,0,0,47,0,0,0,3,0,3,0,2,0,0,0,144,1,0,0,4,0,9,0,71,76,95,65,82,66,95,115,101,112,97,114,97,116,101,95,115,104,97,100,101,114,95,111,98,106,101,99,116,115,0,0,4,0,9,0,71,76,95,65,82,66,95,115,104,97,100,105,110,103,95,108,97,110,103,117,97,103,101,95,52,50,48,112,97,99,107,0,4,0,10,0,71,76,95,71,79,79,71,76,69,95,99,112,112,95,115,116,121,108,101,95,108,105,110,101,95,100,105,114,101,99,116,105,118,101,0,0,4,0,8,0,71,76,95,71,79,79,71,76,69,95,105,110,99,108,117,100,101,95,100,105,114,101,99,116,105,118,101,0,5,0,4,0,4,0,0,0,109,97,105,110,0,0,0,0,5,0,6,0,11,0,0,0,103,108,95,80,101,114,86,101,114,116,101,120,0,0,0,0,6,0,6,0,11,0,0,0,0,0,0,0,103,108,95,80,111,115,105,116,105,111,110,0,6,0,7,0,11,0,0,0,1,0,0,0,103,108,95,80,111,105,110,116,83,105,122,101,0,0,0,0,6,0,7,0,11,0,0,0,2,0,0,0,103,108,95,67,108,105,112,68,105,115,116,97,110,99,101,0,5,0,3,0,13,0,0,0,0,0,0,0,5,0,3,0,18,0,0,0,112,111,115,0,5,0,4,0,23,0,0,0,83,99,97,108,101,0,0,0,6,0,4,0,23,0,0,0,0,0,0,0,120,0,0,0,6,0,4,0,23,0,0,0,1,0,0,0,121,0,0,0,5,0,4,0,25,0,0,0,115,99,97,108,101,0,0,0,5,0,4,0,44,0,0,0,108,114,117,100,0,0,0,0,5,0,3,0,47,0,0,0,111,112,112,0,72,0,5,0,11,0,0,0,0,0,0,0,11,0,0,0,0,0,0,0,72,0,5,0,11,0,0,0,1,0,0,0,11,0,0,0,1,0,0,0,72,0,5,0,11,0,0,0,2,0,0,0,11,0,0,0,3,0,0,0,71,0,3,0,11,0,0,0,2,0,0,0,71,0,4,0,18,0,0,0,30,0,0,0,0,0,0,0,72,0,5,0,23,0,0,0,0,0,0,0,35,0,0,0,0,0,0,0,72,0,5,0,23,0,0,0,1,0,0,0,35,0,0,0,4,0,0,0,71,0,3,0,23,0,0,0,2,0,0,0,71,0,4,0,44,0,0,0,30,0,0,0,0,0,0,0,71,0,4,0,47,0,0,0,30,0,0,0,1,0,0,0,19,0,2,0,2,0,0,0,33,0,3,0,3,0,0,0,2,0,0,0,22,0,3,0,6,0,0,0,32,0,0,0,23,0,4,0,7,0,0,0,6,0,0,0,4,0,0,0,21,0,4,0,8,0,0,0,32,0,0,0,0,0,0,0,43,0,4,0,8,0,0,0,9,0,0,0,1,0,0,0,28,0,4,0,10,0,0,0,6,0,0,0,9,0,0,0,30,0,5,0,11,0,0,0,7,0,0,0,6,0,0,0,10,0,0,0,32,0,4,0,12,0,0,0,3,0,0,0,11,0,0,0,59,0,4,0,12,0,0,0,13,0,0,0,3,0,0,0,21,0,4,0,14,0,0,0,32,0,0,0,1,0,0,0,43,0,4,0,14,0,0,0,15,0,0,0,0,0,0,0,23,0,4,0,16,0,0,0,6,0,0,0,2,0,0,0,32,0,4,0,17,0,0,0,1,0,0,0,16,0,0,0,59,0,4,0,17,0,0,0,18,0,0,0,1,0,0,0,43,0,4,0,8,0,0,0,19,0,0,0,0,0,0,0,32,0,4,0,20,0,0,0,1,0,0,0,6,0,0,0,30,0,4,0,23,0,0,0,6,0,0,0,6,0,0,0,32,0,4,0,24,0,0,0,9,0,0,0,23,0,0,0,59,0,4,0,24,0,0,0,25,0,0,0,9,0,0,0,32,0,4,0,26,0,0,0,9,0,0,0,6,0,0,0,43,0,4,0,6,0,0,0,30,0,0,0,0,0,128,63,43,0,4,0,14,0,0,0,34,0,0,0,1,0,0,0,43,0,4,0,6,0,0,0,40,0,0,0,0,0,0,0,32,0,4,0,42,0,0,0,3,0,0,0,7,0,0,0,59,0,4,0,42,0,0,0,44,0,0,0,3,0,0,0,59,0,4,0,17,0,0,0,47,0,0,0,1,0,0,0,54,0,5,0,2,0,0,0,4,0,0,0,0,0,0,0,3,0,0,0,248,0,2,0,5,0,0,0,65,0,5,0,20,0,0,0,21,0,0,0,18,0,0,0,19,0,0,0,61,0,4,0,6,0,0,0,22,0,0,0,21,0,0,0,65,0,5,0,26,0,0,0,27,0,0,0,25,0,0,0,15,0,0,0,61,0,4,0,6,0,0,0,28,0,0,0,27,0,0,0,136,0,5,0,6,0,0,0,29,0,0,0,22,0,0,0,28,0,0,0,131,0,5,0,6,0,0,0,31,0,0,0,29,0,0,0,30,0,0,0,65,0,5,0,20,0,0,0,32,0,0,0,18,0,0,0,9,0,0,0,61,0,4,0,6,0,0,0,33,0,0,0,32,0,0,0,65,0,5,0,26,0,0,0,35,0,0,0,25,0,0,0,34,0,0,0,61,0,4,0,6,0,0,0,36,0,0,0,35,0,0,0,136,0,5,0,6,0,0,0,37,0,0,0,33,0,0,0,36,0,0,0,129,0,5,0,6,0,0,0,38,0,0,0,37,0,0,0,30,0,0,0,127,0,4,0,6,0,0,0,39,0,0,0,38,0,0,0,80,0,7,0,7,0,0,0,41,0,0,0,31,0,0,0,39,0,0,0,40,0,0,0,30,0,0,0,65,0,5,0,42,0,0,0,43,0,0,0,13,0,0,0,15,0,0,0,62,0,3,0,43,0,0,0,41,0,0,0,65,0,5,0,20,0,0,0,45,0,0,0,18,0,0,0,19,0,0,0,61,0,4,0,6,0,0,0,46,0,0,0,45,0,0,0,65,0,5,0,20,0,0,0,48,0,0,0,47,0,0,0,19,0,0,0,61,0,4,0,6,0,0,0,49,0,0,0,48,0,0,0,12,0,7,0,6,0,0,0,50,0,0,0,1,0,0,0,37,0,0,0,46,0,0,0,49,0,0,0,65,0,5,0,20,0,0,0,51,0,0,0,18,0,0,0,19,0,0,0,61,0,4,0,6,0,0,0,52,0,0,0,51,0,0,0,65,0,5,0,20,0,0,0,53,0,0,0,47,0,0,0,19,0,0,0,61,0,4,0,6,0,0,0,54,0,0,0,53,0,0,0,12,0,7,0,6,0,0,0,55,0,0,0,1,0,0,0,40,0,0,0,52,0,0,0,54,0,0,0,65,0,5,0,20,0,0,0,56,0,0,0,18,0,0,0,9,0,0,0,61,0,4,0,6,0,0,0,57,0,0,0,56,0,0,0,65,0,5,0,20,0,0,0,58,0,0,0,47,0,0,0,9,0,0,0,61,0,4,0,6,0,0,0,59,0,0,0,58,0,0,0,12,0,7,0,6,0,0,0,60,0,0,0,1,0,0,0,37,0,0,0,57,0,0,0,59,0,0,0,65,0,5,0,20,0,0,0,61,0,0,0,18,0,0,0,9,0,0,0,61,0,4,0,6,0,0,0,62,0,0,0,61,0,0,0,65,0,5,0,20,0,0,0,63,0,0,0,47,0,0,0,9,0,0,0,61,0,4,0,6,0,0,0,64,0,0,0,63,0,0,0,12,0,7,0,6,0,0,0,65,0,0,0,1,0,0,0,40,0,0,0,62,0,0,0,64,0,0,0,80,0,7,0,7,0,0,0,66,0,0,0,50,0,0,0,55,0,0,0,60,0,0,0,65,0,0,0,62,0,3,0,44,0,0,0,66,0,0,0,253,0,1,0,56,0,1,0};
uint8_t bufshaderfragbtnkb[] = {3,2,35,7,0,0,1,0,10,0,13,0,100,0,0,0,0,0,0,0,17,0,2,0,1,0,0,0,11,0,6,0,1,0,0,0,71,76,83,76,46,115,116,100,46,52,53,48,0,0,0,0,14,0,3,0,0,0,0,0,1,0,0,0,15,0,8,0,4,0,0,0,4,0,0,0,109,97,105,110,0,0,0,0,10,0,0,0,18,0,0,0,94,0,0,0,16,0,3,0,4,0,0,0,7,0,0,0,3,0,3,0,2,0,0,0,144,1,0,0,4,0,9,0,71,76,95,65,82,66,95,115,101,112,97,114,97,116,101,95,115,104,97,100,101,114,95,111,98,106,101,99,116,115,0,0,4,0,9,0,71,76,95,65,82,66,95,115,104,97,100,105,110,103,95,108,97,110,103,117,97,103,101,95,52,50,48,112,97,99,107,0,4,0,10,0,71,76,95,71,79,79,71,76,69,95,99,112,112,95,115,116,121,108,101,95,108,105,110,101,95,100,105,114,101,99,116,105,118,101,0,0,4,0,8,0,71,76,95,71,79,79,71,76,69,95,105,110,99,108,117,100,101,95,100,105,114,101,99,116,105,118,101,0,5,0,4,0,4,0,0,0,109,97,105,110,0,0,0,0,5,0,4,0,10,0,0,0,108,114,117,100,0,0,0,0,5,0,6,0,18,0,0,0,103,108,95,70,114,97,103,67,111,111,114,100,0,0,0,0,5,0,5,0,94,0,0,0,117,70,114,97,103,67,111,108,111,114,0,0,71,0,3,0,10,0,0,0,14,0,0,0,71,0,4,0,10,0,0,0,30,0,0,0,0,0,0,0,71,0,4,0,18,0,0,0,11,0,0,0,15,0,0,0,71,0,4,0,94,0,0,0,30,0,0,0,0,0,0,0,19,0,2,0,2,0,0,0,33,0,3,0,3,0,0,0,2,0,0,0,20,0,2,0,6,0,0,0,22,0,3,0,7,0,0,0,32,0,0,0,23,0,4,0,8,0,0,0,7,0,0,0,4,0,0,0,32,0,4,0,9,0,0,0,1,0,0,0,8,0,0,0,59,0,4,0,9,0,0,0,10,0,0,0,1,0,0,0,21,0,4,0,11,0,0,0,32,0,0,0,0,0,0,0,43,0,4,0,11,0,0,0,12,0,0,0,0,0,0,0,32,0,4,0,13,0,0,0,1,0,0,0,7,0,0,0,43,0,4,0,7,0,0,0,16,0,0,0,0,0,0,64,59,0,4,0,9,0,0,0,18,0,0,0,1,0,0,0,43,0,4,0,11,0,0,0,34,0,0,0,1,0,0,0,43,0,4,0,11,0,0,0,54,0,0,0,2,0,0,0,43,0,4,0,11,0,0,0,74,0,0,0,3,0,0,0,32,0,4,0,93,0,0,0,3,0,0,0,8,0,0,0,59,0,4,0,93,0,0,0,94,0,0,0,3,0,0,0,43,0,4,0,7,0,0,0,95,0,0,0,0,0,128,63,44,0,7,0,8,0,0,0,96,0,0,0,95,0,0,0,95,0,0,0,95,0,0,0,95,0,0,0,43,0,4,0,7,0,0,0,98,0,0,0,0,0,0,0,44,0,7,0,8,0,0,0,99,0,0,0,98,0,0,0,98,0,0,0,98,0,0,0,98,0,0,0,54,0,5,0,2,0,0,0,4,0,0,0,0,0,0,0,3,0,0,0,248,0,2,0,5,0,0,0,65,0,5,0,13,0,0,0,14,0,0,0,10,0,0,0,12,0,0,0,61,0,4,0,7,0,0,0,15,0,0,0,14,0,0,0,131,0,5,0,7,0,0,0,17,0,0,0,15,0,0,0,16,0,0,0,65,0,5,0,13,0,0,0,19,0,0,0,18,0,0,0,12,0,0,0,61,0,4,0,7,0,0,0,20,0,0,0,19,0,0,0,184,0,5,0,6,0,0,0,21,0,0,0,17,0,0,0,20,0,0,0,247,0,3,0,23,0,0,0,0,0,0,0,250,0,4,0,21,0,0,0,22,0,0,0,23,0,0,0,248,0,2,0,22,0,0,0,65,0,5,0,13,0,0,0,24,0,0,0,18,0,0,0,12,0,0,0,61,0,4,0,7,0,0,0,25,0,0,0,24,0,0,0,65,0,5,0,13,0,0,0,26,0,0,0,10,0,0,0,12,0,0,0,61,0,4,0,7,0,0,0,27,0,0,0,26,0,0,0,129,0,5,0,7,0,0,0,28,0,0,0,27,0,0,0,16,0,0,0,184,0,5,0,6,0,0,0,29,0,0,0,25,0,0,0,28,0,0,0,249,0,2,0,23,0,0,0,248,0,2,0,23,0,0,0,245,0,7,0,6,0,0,0,30,0,0,0,21,0,0,0,5,0,0,0,29,0,0,0,22,0,0,0,168,0,4,0,6,0,0,0,31,0,0,0,30,0,0,0,247,0,3,0,33,0,0,0,0,0,0,0,250,0,4,0,31,0,0,0,32,0,0,0,33,0,0,0,248,0,2,0,32,0,0,0,65,0,5,0,13,0,0,0,35,0,0,0,10,0,0,0,34,0,0,0,61,0,4,0,7,0,0,0,36,0,0,0,35,0,0,0,131,0,5,0,7,0,0,0,37,0,0,0,36,0,0,0,16,0,0,0,65,0,5,0,13,0,0,0,38,0,0,0,18,0,0,0,12,0,0,0,61,0,4,0,7,0,0,0,39,0,0,0,38,0,0,0,184,0,5,0,6,0,0,0,40,0,0,0,37,0,0,0,39,0,0,0,247,0,3,0,42,0,0,0,0,0,0,0,250,0,4,0,40,0,0,0,41,0,0,0,42,0,0,0,248,0,2,0,41,0,0,0,65,0,5,0,13,0,0,0,43,0,0,0,18,0,0,0,12,0,0,0,61,0,4,0,7,0,0,0,44,0,0,0,43,0,0,0,65,0,5,0,13,0,0,0,45,0,0,0,10,0,0,0,34,0,0,0,61,0,4,0,7,0,0,0,46,0,0,0,45,0,0,0,129,0,5,0,7,0,0,0,47,0,0,0,46,0,0,0,16,0,0,0,184,0,5,0,6,0,0,0,48,0,0,0,44,0,0,0,47,0,0,0,249,0,2,0,42,0,0,0,248,0,2,0,42,0,0,0,245,0,7,0,6,0,0,0,49,0,0,0,40,0,0,0,32,0,0,0,48,0,0,0,41,0,0,0,249,0,2,0,33,0,0,0,248,0,2,0,33,0,0,0,245,0,7,0,6,0,0,0,50,0,0,0,30,0,0,0,23,0,0,0,49,0,0,0,42,0,0,0,168,0,4,0,6,0,0,0,51,0,0,0,50,0,0,0,247,0,3,0,53,0,0,0,0,0,0,0,250,0,4,0,51,0,0,0,52,0,0,0,53,0,0,0,248,0,2,0,52,0,0,0,65,0,5,0,13,0,0,0,55,0,0,0,10,0,0,0,54,0,0,0,61,0,4,0,7,0,0,0,56,0,0,0,55,0,0,0,131,0,5,0,7,0,0,0,57,0,0,0,56,0,0,0,16,0,0,0,65,0,5,0,13,0,0,0,58,0,0,0,18,0,0,0,34,0,0,0,61,0,4,0,7,0,0,0,59,0,0,0,58,0,0,0,184,0,5,0,6,0,0,0,60,0,0,0,57,0,0,0,59,0,0,0,247,0,3,0,62,0,0,0,0,0,0,0,250,0,4,0,60,0,0,0,61,0,0,0,62,0,0,0,248,0,2,0,61,0,0,0,65,0,5,0,13,0,0,0,63,0,0,0,18,0,0,0,34,0,0,0,61,0,4,0,7,0,0,0,64,0,0,0,63,0,0,0,65,0,5,0,13,0,0,0,65,0,0,0,10,0,0,0,54,0,0,0,61,0,4,0,7,0,0,0,66,0,0,0,65,0,0,0,129,0,5,0,7,0,0,0,67,0,0,0,66,0,0,0,16,0,0,0,184,0,5,0,6,0,0,0,68,0,0,0,64,0,0,0,67,0,0,0,249,0,2,0,62,0,0,0,248,0,2,0,62,0,0,0,245,0,7,0,6,0,0,0,69,0,0,0,60,0,0,0,52,0,0,0,68,0,0,0,61,0,0,0,249,0,2,0,53,0,0,0,248,0,2,0,53,0,0,0,245,0,7,0,6,0,0,0,70,0,0,0,50,0,0,0,33,0,0,0,69,0,0,0,62,0,0,0,168,0,4,0,6,0,0,0,71,0,0,0,70,0,0,0,247,0,3,0,73,0,0,0,0,0,0,0,250,0,4,0,71,0,0,0,72,0,0,0,73,0,0,0,248,0,2,0,72,0,0,0,65,0,5,0,13,0,0,0,75,0,0,0,10,0,0,0,74,0,0,0,61,0,4,0,7,0,0,0,76,0,0,0,75,0,0,0,131,0,5,0,7,0,0,0,77,0,0,0,76,0,0,0,16,0,0,0,65,0,5,0,13,0,0,0,78,0,0,0,18,0,0,0,34,0,0,0,61,0,4,0,7,0,0,0,79,0,0,0,78,0,0,0,184,0,5,0,6,0,0,0,80,0,0,0,77,0,0,0,79,0,0,0,247,0,3,0,82,0,0,0,0,0,0,0,250,0,4,0,80,0,0,0,81,0,0,0,82,0,0,0,248,0,2,0,81,0,0,0,65,0,5,0,13,0,0,0,83,0,0,0,18,0,0,0,34,0,0,0,61,0,4,0,7,0,0,0,84,0,0,0,83,0,0,0,65,0,5,0,13,0,0,0,85,0,0,0,10,0,0,0,74,0,0,0,61,0,4,0,7,0,0,0,86,0,0,0,85,0,0,0,129,0,5,0,7,0,0,0,87,0,0,0,86,0,0,0,16,0,0,0,184,0,5,0,6,0,0,0,88,0,0,0,84,0,0,0,87,0,0,0,249,0,2,0,82,0,0,0,248,0,2,0,82,0,0,0,245,0,7,0,6,0,0,0,89,0,0,0,80,0,0,0,72,0,0,0,88,0,0,0,81,0,0,0,249,0,2,0,73,0,0,0,248,0,2,0,73,0,0,0,245,0,7,0,6,0,0,0,90,0,0,0,70,0,0,0,53,0,0,0,89,0,0,0,82,0,0,0,247,0,3,0,92,0,0,0,0,0,0,0,250,0,4,0,90,0,0,0,91,0,0,0,97,0,0,0,248,0,2,0,91,0,0,0,62,0,3,0,94,0,0,0,96,0,0,0,249,0,2,0,92,0,0,0,248,0,2,0,97,0,0,0,62,0,3,0,94,0,0,0,99,0,0,0,249,0,2,0,92,0,0,0,248,0,2,0,92,0,0,0,253,0,1,0,56,0,1,0};
uint8_t bufshadervertflow[] = {3,2,35,7,0,0,1,0,10,0,13,0,89,0,0,0,0,0,0,0,17,0,2,0,1,0,0,0,11,0,6,0,1,0,0,0,71,76,83,76,46,115,116,100,46,52,53,48,0,0,0,0,14,0,3,0,0,0,0,0,1,0,0,0,15,0,10,0,0,0,0,0,4,0,0,0,109,97,105,110,0,0,0,0,13,0,0,0,18,0,0,0,44,0,0,0,47,0,0,0,57,0,0,0,3,0,3,0,2,0,0,0,144,1,0,0,4,0,9,0,71,76,95,65,82,66,95,115,101,112,97,114,97,116,101,95,115,104,97,100,101,114,95,111,98,106,101,99,116,115,0,0,4,0,9,0,71,76,95,65,82,66,95,115,104,97,100,105,110,103,95,108,97,110,103,117,97,103,101,95,52,50,48,112,97,99,107,0,4,0,10,0,71,76,95,71,79,79,71,76,69,95,99,112,112,95,115,116,121,108,101,95,108,105,110,101,95,100,105,114,101,99,116,105,118,101,0,0,4,0,8,0,71,76,95,71,79,79,71,76,69,95,105,110,99,108,117,100,101,95,100,105,114,101,99,116,105,118,101,0,5,0,4,0,4,0,0,0,109,97,105,110,0,0,0,0,5,0,6,0,11,0,0,0,103,108,95,80,101,114,86,101,114,116,101,120,0,0,0,0,6,0,6,0,11,0,0,0,0,0,0,0,103,108,95,80,111,115,105,116,105,111,110,0,6,0,7,0,11,0,0,0,1,0,0,0,103,108,95,80,111,105,110,116,83,105,122,101,0,0,0,0,6,0,7,0,11,0,0,0,2,0,0,0,103,108,95,67,108,105,112,68,105,115,116,97,110,99,101,0,5,0,3,0,13,0,0,0,0,0,0,0,5,0,3,0,18,0,0,0,112,111,115,0,5,0,4,0,23,0,0,0,83,99,97,108,101,0,0,0,6,0,4,0,23,0,0,0,0,0,0,0,120,0,0,0,6,0,4,0,23,0,0,0,1,0,0,0,121,0,0,0,5,0,4,0,25,0,0,0,115,99,97,108,101,0,0,0,5,0,4,0,44,0,0,0,108,114,117,100,0,0,0,0,5,0,3,0,47,0,0,0,111,112,112,0,5,0,5,0,57,0,0,0,98,111,114,100,101,114,117,100,0,0,0,0,72,0,5,0,11,0,0,0,0,0,0,0,11,0,0,0,0,0,0,0,72,0,5,0,11,0,0,0,1,0,0,0,11,0,0,0,1,0,0,0,72,0,5,0,11,0,0,0,2,0,0,0,11,0,0,0,3,0,0,0,71,0,3,0,11,0,0,0,2,0,0,0,71,0,4,0,18,0,0,0,30,0,0,0,0,0,0,0,72,0,5,0,23,0,0,0,0,0,0,0,35,0,0,0,0,0,0,0,72,0,5,0,23,0,0,0,1,0,0,0,35,0,0,0,4,0,0,0,71,0,3,0,23,0,0,0,2,0,0,0,71,0,4,0,44,0,0,0,30,0,0,0,0,0,0,0,71,0,4,0,47,0,0,0,30,0,0,0,1,0,0,0,71,0,4,0,57,0,0,0,30,0,0,0,2,0,0,0,19,0,2,0,2,0,0,0,33,0,3,0,3,0,0,0,2,0,0,0,22,0,3,0,6,0,0,0,32,0,0,0,23,0,4,0,7,0,0,0,6,0,0,0,4,0,0,0,21,0,4,0,8,0,0,0,32,0,0,0,0,0,0,0,43,0,4,0,8,0,0,0,9,0,0,0,1,0,0,0,28,0,4,0,10,0,0,0,6,0,0,0,9,0,0,0,30,0,5,0,11,0,0,0,7,0,0,0,6,0,0,0,10,0,0,0,32,0,4,0,12,0,0,0,3,0,0,0,11,0,0,0,59,0,4,0,12,0,0,0,13,0,0,0,3,0,0,0,21,0,4,0,14,0,0,0,32,0,0,0,1,0,0,0,43,0,4,0,14,0,0,0,15,0,0,0,0,0,0,0,23,0,4,0,16,0,0,0,6,0,0,0,2,0,0,0,32,0,4,0,17,0,0,0,1,0,0,0,16,0,0,0,59,0,4,0,17,0,0,0,18,0,0,0,1,0,0,0,43,0,4,0,8,0,0,0,19,0,0,0,0,0,0,0,32,0,4,0,20,0,0,0,1,0,0,0,6,0,0,0,30,0,4,0,23,0,0,0,6,0,0,0,6,0,0,0,32,0,4,0,24,0,0,0,9,0,0,0,23,0,0,0,59,0,4,0,24,0,0,0,25,0,0,0,9,0,0,0,32,0,4,0,26,0,0,0,9,0,0,0,6,0,0,0,43,0,4,0,6,0,0,0,30,0,0,0,0,0,128,63,43,0,4,0,14,0,0,0,34,0,0,0,1,0,0,0,43,0,4,0,6,0,0,0,40,0,0,0,0,0,0,0,32,0,4,0,42,0,0,0,3,0,0,0,7,0,0,0,59,0,4,0,42,0,0,0,44,0,0,0,3,0,0,0,59,0,4,0,17,0,0,0,47,0,0,0,1,0,0,0,32,0,4,0,56,0,0,0,1,0,0,0,8,0,0,0,59,0,4,0,56,0,0,0,57,0,0,0,1,0,0,0,20,0,2,0,60,0,0,0,32,0,4,0,62,0,0,0,7,0,0,0,6,0,0,0,43,0,4,0,6,0,0,0,72,0,0,0,0,0,128,127,43,0,4,0,8,0,0,0,75,0,0,0,2,0,0,0,54,0,5,0,2,0,0,0,4,0,0,0,0,0,0,0,3,0,0,0,248,0,2,0,5,0,0,0,59,0,4,0,62,0,0,0,63,0,0,0,7,0,0,0,59,0,4,0,62,0,0,0,78,0,0,0,7,0,0,0,65,0,5,0,20,0,0,0,21,0,0,0,18,0,0,0,19,0,0,0,61,0,4,0,6,0,0,0,22,0,0,0,21,0,0,0,65,0,5,0,26,0,0,0,27,0,0,0,25,0,0,0,15,0,0,0,61,0,4,0,6,0,0,0,28,0,0,0,27,0,0,0,136,0,5,0,6,0,0,0,29,0,0,0,22,0,0,0,28,0,0,0,131,0,5,0,6,0,0,0,31,0,0,0,29,0,0,0,30,0,0,0,65,0,5,0,20,0,0,0,32,0,0,0,18,0,0,0,9,0,0,0,61,0,4,0,6,0,0,0,33,0,0,0,32,0,0,0,65,0,5,0,26,0,0,0,35,0,0,0,25,0,0,0,34,0,0,0,61,0,4,0,6,0,0,0,36,0,0,0,35,0,0,0,136,0,5,0,6,0,0,0,37,0,0,0,33,0,0,0,36,0,0,0,129,0,5,0,6,0,0,0,38,0,0,0,37,0,0,0,30,0,0,0,127,0,4,0,6,0,0,0,39,0,0,0,38,0,0,0,80,0,7,0,7,0,0,0,41,0,0,0,31,0,0,0,39,0,0,0,40,0,0,0,30,0,0,0,65,0,5,0,42,0,0,0,43,0,0,0,13,0,0,0,15,0,0,0,62,0,3,0,43,0,0,0,41,0,0,0,65,0,5,0,20,0,0,0,45,0,0,0,18,0,0,0,19,0,0,0,61,0,4,0,6,0,0,0,46,0,0,0,45,0,0,0,65,0,5,0,20,0,0,0,48,0,0,0,47,0,0,0,19,0,0,0,61,0,4,0,6,0,0,0,49,0,0,0,48,0,0,0,12,0,7,0,6,0,0,0,50,0,0,0,1,0,0,0,37,0,0,0,46,0,0,0,49,0,0,0,65,0,5,0,20,0,0,0,51,0,0,0,18,0,0,0,19,0,0,0,61,0,4,0,6,0,0,0,52,0,0,0,51,0,0,0,65,0,5,0,20,0,0,0,53,0,0,0,47,0,0,0,19,0,0,0,61,0,4,0,6,0,0,0,54,0,0,0,53,0,0,0,12,0,7,0,6,0,0,0,55,0,0,0,1,0,0,0,40,0,0,0,52,0,0,0,54,0,0,0,61,0,4,0,8,0,0,0,58,0,0,0,57,0,0,0,199,0,5,0,8,0,0,0,59,0,0,0,58,0,0,0,9,0,0,0,172,0,5,0,60,0,0,0,61,0,0,0,59,0,0,0,19,0,0,0,247,0,3,0,65,0,0,0,0,0,0,0,250,0,4,0,61,0,0,0,64,0,0,0,71,0,0,0,248,0,2,0,64,0,0,0,65,0,5,0,20,0,0,0,66,0,0,0,18,0,0,0,9,0,0,0,61,0,4,0,6,0,0,0,67,0,0,0,66,0,0,0,65,0,5,0,20,0,0,0,68,0,0,0,47,0,0,0,9,0,0,0,61,0,4,0,6,0,0,0,69,0,0,0,68,0,0,0,12,0,7,0,6,0,0,0,70,0,0,0,1,0,0,0,37,0,0,0,67,0,0,0,69,0,0,0,62,0,3,0,63,0,0,0,70,0,0,0,249,0,2,0,65,0,0,0,248,0,2,0,71,0,0,0,62,0,3,0,63,0,0,0,72,0,0,0,249,0,2,0,65,0,0,0,248,0,2,0,65,0,0,0,61,0,4,0,6,0,0,0,73,0,0,0,63,0,0,0,61,0,4,0,8,0,0,0,74,0,0,0,57,0,0,0,199,0,5,0,8,0,0,0,76,0,0,0,74,0,0,0,75,0,0,0,172,0,5,0,60,0,0,0,77,0,0,0,76,0,0,0,19,0,0,0,247,0,3,0,80,0,0,0,0,0,0,0,250,0,4,0,77,0,0,0,79,0,0,0,86,0,0,0,248,0,2,0,79,0,0,0,65,0,5,0,20,0,0,0,81,0,0,0,18,0,0,0,9,0,0,0,61,0,4,0,6,0,0,0,82,0,0,0,81,0,0,0,65,0,5,0,20,0,0,0,83,0,0,0,47,0,0,0,9,0,0,0,61,0,4,0,6,0,0,0,84,0,0,0,83,0,0,0,12,0,7,0,6,0,0,0,85,0,0,0,1,0,0,0,40,0,0,0,82,0,0,0,84,0,0,0,62,0,3,0,78,0,0,0,85,0,0,0,249,0,2,0,80,0,0,0,248,0,2,0,86,0,0,0,62,0,3,0,78,0,0,0,72,0,0,0,249,0,2,0,80,0,0,0,248,0,2,0,80,0,0,0,61,0,4,0,6,0,0,0,87,0,0,0,78,0,0,0,80,0,7,0,7,0,0,0,88,0,0,0,50,0,0,0,55,0,0,0,73,0,0,0,87,0,0,0,62,0,3,0,44,0,0,0,88,0,0,0,253,0,1,0,56,0,1,0};
uint8_t bufshaderfragflow[] = {3,2,35,7,0,0,1,0,10,0,13,0,103,0,0,0,0,0,0,0,17,0,2,0,1,0,0,0,11,0,6,0,1,0,0,0,71,76,83,76,46,115,116,100,46,52,53,48,0,0,0,0,14,0,3,0,0,0,0,0,1,0,0,0,15,0,8,0,4,0,0,0,4,0,0,0,109,97,105,110,0,0,0,0,10,0,0,0,18,0,0,0,94,0,0,0,16,0,3,0,4,0,0,0,7,0,0,0,3,0,3,0,2,0,0,0,144,1,0,0,4,0,9,0,71,76,95,65,82,66,95,115,101,112,97,114,97,116,101,95,115,104,97,100,101,114,95,111,98,106,101,99,116,115,0,0,4,0,9,0,71,76,95,65,82,66,95,115,104,97,100,105,110,103,95,108,97,110,103,117,97,103,101,95,52,50,48,112,97,99,107,0,4,0,10,0,71,76,95,71,79,79,71,76,69,95,99,112,112,95,115,116,121,108,101,95,108,105,110,101,95,100,105,114,101,99,116,105,118,101,0,0,4,0,8,0,71,76,95,71,79,79,71,76,69,95,105,110,99,108,117,100,101,95,100,105,114,101,99,116,105,118,101,0,5,0,4,0,4,0,0,0,109,97,105,110,0,0,0,0,5,0,4,0,10,0,0,0,108,114,117,100,0,0,0,0,5,0,6,0,18,0,0,0,103,108,95,70,114,97,103,67,111,111,114,100,0,0,0,0,5,0,5,0,94,0,0,0,117,70,114,97,103,67,111,108,111,114,0,0,71,0,3,0,10,0,0,0,14,0,0,0,71,0,4,0,10,0,0,0,30,0,0,0,0,0,0,0,71,0,4,0,18,0,0,0,11,0,0,0,15,0,0,0,71,0,4,0,94,0,0,0,30,0,0,0,0,0,0,0,19,0,2,0,2,0,0,0,33,0,3,0,3,0,0,0,2,0,0,0,20,0,2,0,6,0,0,0,22,0,3,0,7,0,0,0,32,0,0,0,23,0,4,0,8,0,0,0,7,0,0,0,4,0,0,0,32,0,4,0,9,0,0,0,1,0,0,0,8,0,0,0,59,0,4,0,9,0,0,0,10,0,0,0,1,0,0,0,21,0,4,0,11,0,0,0,32,0,0,0,0,0,0,0,43,0,4,0,11,0,0,0,12,0,0,0,0,0,0,0,32,0,4,0,13,0,0,0,1,0,0,0,7,0,0,0,43,0,4,0,7,0,0,0,16,0,0,0,0,0,0,64,59,0,4,0,9,0,0,0,18,0,0,0,1,0,0,0,43,0,4,0,11,0,0,0,34,0,0,0,1,0,0,0,43,0,4,0,11,0,0,0,54,0,0,0,2,0,0,0,43,0,4,0,11,0,0,0,74,0,0,0,3,0,0,0,32,0,4,0,93,0,0,0,3,0,0,0,8,0,0,0,59,0,4,0,93,0,0,0,94,0,0,0,3,0,0,0,43,0,4,0,7,0,0,0,95,0,0,0,177,168,40,63,43,0,4,0,7,0,0,0,96,0,0,0,172,200,72,62,43,0,4,0,7,0,0,0,97,0,0,0,161,160,32,63,43,0,4,0,7,0,0,0,98,0,0,0,0,0,128,63,44,0,7,0,8,0,0,0,99,0,0,0,95,0,0,0,96,0,0,0,97,0,0,0,98,0,0,0,43,0,4,0,7,0,0,0,101,0,0,0,0,0,0,0,44,0,7,0,8,0,0,0,102,0,0,0,101,0,0,0,101,0,0,0,101,0,0,0,101,0,0,0,54,0,5,0,2,0,0,0,4,0,0,0,0,0,0,0,3,0,0,0,248,0,2,0,5,0,0,0,65,0,5,0,13,0,0,0,14,0,0,0,10,0,0,0,12,0,0,0,61,0,4,0,7,0,0,0,15,0,0,0,14,0,0,0,131,0,5,0,7,0,0,0,17,0,0,0,15,0,0,0,16,0,0,0,65,0,5,0,13,0,0,0,19,0,0,0,18,0,0,0,12,0,0,0,61,0,4,0,7,0,0,0,20,0,0,0,19,0,0,0,184,0,5,0,6,0,0,0,21,0,0,0,17,0,0,0,20,0,0,0,247,0,3,0,23,0,0,0,0,0,0,0,250,0,4,0,21,0,0,0,22,0,0,0,23,0,0,0,248,0,2,0,22,0,0,0,65,0,5,0,13,0,0,0,24,0,0,0,18,0,0,0,12,0,0,0,61,0,4,0,7,0,0,0,25,0,0,0,24,0,0,0,65,0,5,0,13,0,0,0,26,0,0,0,10,0,0,0,12,0,0,0,61,0,4,0,7,0,0,0,27,0,0,0,26,0,0,0,129,0,5,0,7,0,0,0,28,0,0,0,27,0,0,0,16,0,0,0,184,0,5,0,6,0,0,0,29,0,0,0,25,0,0,0,28,0,0,0,249,0,2,0,23,0,0,0,248,0,2,0,23,0,0,0,245,0,7,0,6,0,0,0,30,0,0,0,21,0,0,0,5,0,0,0,29,0,0,0,22,0,0,0,168,0,4,0,6,0,0,0,31,0,0,0,30,0,0,0,247,0,3,0,33,0,0,0,0,0,0,0,250,0,4,0,31,0,0,0,32,0,0,0,33,0,0,0,248,0,2,0,32,0,0,0,65,0,5,0,13,0,0,0,35,0,0,0,10,0,0,0,34,0,0,0,61,0,4,0,7,0,0,0,36,0,0,0,35,0,0,0,131,0,5,0,7,0,0,0,37,0,0,0,36,0,0,0,16,0,0,0,65,0,5,0,13,0,0,0,38,0,0,0,18,0,0,0,12,0,0,0,61,0,4,0,7,0,0,0,39,0,0,0,38,0,0,0,184,0,5,0,6,0,0,0,40,0,0,0,37,0,0,0,39,0,0,0,247,0,3,0,42,0,0,0,0,0,0,0,250,0,4,0,40,0,0,0,41,0,0,0,42,0,0,0,248,0,2,0,41,0,0,0,65,0,5,0,13,0,0,0,43,0,0,0,18,0,0,0,12,0,0,0,61,0,4,0,7,0,0,0,44,0,0,0,43,0,0,0,65,0,5,0,13,0,0,0,45,0,0,0,10,0,0,0,34,0,0,0,61,0,4,0,7,0,0,0,46,0,0,0,45,0,0,0,129,0,5,0,7,0,0,0,47,0,0,0,46,0,0,0,16,0,0,0,184,0,5,0,6,0,0,0,48,0,0,0,44,0,0,0,47,0,0,0,249,0,2,0,42,0,0,0,248,0,2,0,42,0,0,0,245,0,7,0,6,0,0,0,49,0,0,0,40,0,0,0,32,0,0,0,48,0,0,0,41,0,0,0,249,0,2,0,33,0,0,0,248,0,2,0,33,0,0,0,245,0,7,0,6,0,0,0,50,0,0,0,30,0,0,0,23,0,0,0,49,0,0,0,42,0,0,0,168,0,4,0,6,0,0,0,51,0,0,0,50,0,0,0,247,0,3,0,53,0,0,0,0,0,0,0,250,0,4,0,51,0,0,0,52,0,0,0,53,0,0,0,248,0,2,0,52,0,0,0,65,0,5,0,13,0,0,0,55,0,0,0,10,0,0,0,54,0,0,0,61,0,4,0,7,0,0,0,56,0,0,0,55,0,0,0,131,0,5,0,7,0,0,0,57,0,0,0,56,0,0,0,16,0,0,0,65,0,5,0,13,0,0,0,58,0,0,0,18,0,0,0,34,0,0,0,61,0,4,0,7,0,0,0,59,0,0,0,58,0,0,0,184,0,5,0,6,0,0,0,60,0,0,0,57,0,0,0,59,0,0,0,247,0,3,0,62,0,0,0,0,0,0,0,250,0,4,0,60,0,0,0,61,0,0,0,62,0,0,0,248,0,2,0,61,0,0,0,65,0,5,0,13,0,0,0,63,0,0,0,18,0,0,0,34,0,0,0,61,0,4,0,7,0,0,0,64,0,0,0,63,0,0,0,65,0,5,0,13,0,0,0,65,0,0,0,10,0,0,0,54,0,0,0,61,0,4,0,7,0,0,0,66,0,0,0,65,0,0,0,129,0,5,0,7,0,0,0,67,0,0,0,66,0,0,0,16,0,0,0,184,0,5,0,6,0,0,0,68,0,0,0,64,0,0,0,67,0,0,0,249,0,2,0,62,0,0,0,248,0,2,0,62,0,0,0,245,0,7,0,6,0,0,0,69,0,0,0,60,0,0,0,52,0,0,0,68,0,0,0,61,0,0,0,249,0,2,0,53,0,0,0,248,0,2,0,53,0,0,0,245,0,7,0,6,0,0,0,70,0,0,0,50,0,0,0,33,0,0,0,69,0,0,0,62,0,0,0,168,0,4,0,6,0,0,0,71,0,0,0,70,0,0,0,247,0,3,0,73,0,0,0,0,0,0,0,250,0,4,0,71,0,0,0,72,0,0,0,73,0,0,0,248,0,2,0,72,0,0,0,65,0,5,0,13,0,0,0,75,0,0,0,10,0,0,0,74,0,0,0,61,0,4,0,7,0,0,0,76,0,0,0,75,0,0,0,131,0,5,0,7,0,0,0,77,0,0,0,76,0,0,0,16,0,0,0,65,0,5,0,13,0,0,0,78,0,0,0,18,0,0,0,34,0,0,0,61,0,4,0,7,0,0,0,79,0,0,0,78,0,0,0,184,0,5,0,6,0,0,0,80,0,0,0,77,0,0,0,79,0,0,0,247,0,3,0,82,0,0,0,0,0,0,0,250,0,4,0,80,0,0,0,81,0,0,0,82,0,0,0,248,0,2,0,81,0,0,0,65,0,5,0,13,0,0,0,83,0,0,0,18,0,0,0,34,0,0,0,61,0,4,0,7,0,0,0,84,0,0,0,83,0,0,0,65,0,5,0,13,0,0,0,85,0,0,0,10,0,0,0,74,0,0,0,61,0,4,0,7,0,0,0,86,0,0,0,85,0,0,0,129,0,5,0,7,0,0,0,87,0,0,0,86,0,0,0,16,0,0,0,184,0,5,0,6,0,0,0,88,0,0,0,84,0,0,0,87,0,0,0,249,0,2,0,82,0,0,0,248,0,2,0,82,0,0,0,245,0,7,0,6,0,0,0,89,0,0,0,80,0,0,0,72,0,0,0,88,0,0,0,81,0,0,0,249,0,2,0,73,0,0,0,248,0,2,0,73,0,0,0,245,0,7,0,6,0,0,0,90,0,0,0,70,0,0,0,53,0,0,0,89,0,0,0,82,0,0,0,247,0,3,0,92,0,0,0,0,0,0,0,250,0,4,0,90,0,0,0,91,0,0,0,100,0,0,0,248,0,2,0,91,0,0,0,62,0,3,0,94,0,0,0,99,0,0,0,249,0,2,0,92,0,0,0,248,0,2,0,100,0,0,0,62,0,3,0,94,0,0,0,102,0,0,0,249,0,2,0,92,0,0,0,248,0,2,0,92,0,0,0,253,0,1,0,56,0,1,0};
//ENDGEN

#define LOGE0(...) ((void)printf(__VA_ARGS__))
#define LOGI0(...) ((void)printf(__VA_ARGS__))
char debug = 0;
FILE *fdf = NULL;
int ndf = 0;
void
df(char *errfmt, ...)
{
	//return;
	va_list argp;
	va_start(argp, errfmt);
	vfprintf(fdf, errfmt, argp);
	va_end(argp);
	fputc('\n', fdf);
	fflush(fdf);
	ndf++;
}
void
dfnl(char *errfmt, ...)
{
	//return;
	va_list argp;
	va_start(argp, errfmt);
	vfprintf(fdf, errfmt, argp);
	va_end(argp);
	fflush(fdf);
}



//////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////
////
////   INTEGRATION WITH YOUR CODEBASE
////
////   The following sections allow you to supply alternate definitions
////   of C library functions used by stb_truetype, e.g. if you don't
////   link with the C runtime library.
// #define your own (u)stbtt_int8/16/32 before including to override this
#ifndef stbtt_uint8
typedef unsigned char   stbtt_uint8;
typedef signed   char   stbtt_int8;
typedef unsigned short  stbtt_uint16;
typedef signed   short  stbtt_int16;
typedef unsigned int    stbtt_uint32;
typedef signed   int    stbtt_int32;
#endif
typedef char stbtt__check_size32[sizeof(stbtt_int32)==4 ? 1 : -1];
typedef char stbtt__check_size16[sizeof(stbtt_int16)==2 ? 1 : -1];
// e.g. #define your own STBTT_ifloor/STBTT_iceil() to avoid math.h
#ifndef STBTT_ifloor
#include <math.h>
#define STBTT_ifloor(x)   ((int) floor(x))
#define STBTT_iceil(x)    ((int) ceil(x))
#endif
#ifndef STBTT_sqrt
#include <math.h>
#define STBTT_sqrt(x)      sqrt(x)
#define STBTT_pow(x,y)     pow(x,y)
#endif
#ifndef STBTT_fmod
#include <math.h>
#define STBTT_fmod(x,y)    fmod(x,y)
#endif
#ifndef STBTT_cos
#include <math.h>
#define STBTT_cos(x)       cos(x)
#define STBTT_acos(x)      acos(x)
#endif
#ifndef STBTT_fabs
#include <math.h>
#define STBTT_fabs(x)      fabs(x)
#endif
// #define your own functions "STBTT_malloc" / "STBTT_free" to avoid malloc.h
#ifndef STBTT_malloc
#include <stdlib.h>
#define STBTT_malloc(x,u)  ((void)(u),malloc(x))
#define STBTT_free(x,u)    ((void)(u),free(x))
#endif
#ifndef STBTT_assert
#include <assert.h>
#define STBTT_assert(x)    assert(x)
#endif
#ifndef STBTT_strlen
#include <string.h>
#define STBTT_strlen(x)    strlen(x)
#endif
#ifndef STBTT_memcpy
#include <string.h>
#define STBTT_memcpy       memcpy
#define STBTT_memset       memset
#endif

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
////
////   INTERFACE
////
////
#ifndef __STB_INCLUDE_STB_TRUETYPE_H__
#define __STB_INCLUDE_STB_TRUETYPE_H__
#ifdef STBTT_STATIC
#define STBTT_DEF static
#else
#define STBTT_DEF extern
#endif
#ifdef __cplusplus
extern "C" {
#endif
// private structure
typedef struct
{
	unsigned char *data;
	int cursor;
	int size;
} stbtt__buf;
//////////////////////////////////////////////////////////////////////////////
//
// TEXTURE BAKING API
//
// If you use this API, you only have to call two functions ever.
//
typedef struct
{
	unsigned short x0,y0,x1,y1; // coordinates of bbox in bitmap
	float xoff,yoff,xadvance;
} stbtt_bakedchar;
STBTT_DEF int stbtt_BakeFontBitmap(const unsigned char *data, int offset,  // font location (use offset=0 for plain .ttf)
										  float pixel_height,                     // height of font in pixels
										  unsigned char *pixels, int pw, int ph,  // bitmap to be filled in
										  int first_char, int num_chars,          // characters to bake
										  stbtt_bakedchar *chardata);             // you allocate this, it's num_chars long
// if return is positive, the first unused row of the bitmap
// if return is negative, returns the negative of the number of characters that fit
// if return is 0, no characters fit and no rows were used
// This uses a very crappy packing.
typedef struct
{
	float x0,y0,s0,t0; // top-left
	float x1,y1,s1,t1; // bottom-right
} stbtt_aligned_quad;
STBTT_DEF void stbtt_GetBakedQuad(const stbtt_bakedchar *chardata, int pw, int ph,  // same data as above
										 int char_index,             // character to display
										 float *xpos, float *ypos,   // pointers to current position in screen pixel space
										 stbtt_aligned_quad *q,      // output: quad to draw
										 int opengl_fillrule);       // true if opengl fill rule; false if DX9 or earlier
// Call GetBakedQuad with char_index = 'character - first_char', and it
// creates the quad you need to draw and advances the current position.
//
// The coordinate system used assumes y increases downwards.
//
// Characters will extend both above and below the current position;
// see discussion of "BASELINE" above.
//
// It's inefficient; you might want to c&p it and optimize it.
STBTT_DEF void stbtt_GetScaledFontVMetrics(const unsigned char *fontdata, int index, float size, float *ascent, float *descent, float *lineGap);
// Query the font vertical metrics without having to create a font first.
//////////////////////////////////////////////////////////////////////////////
//
// NEW TEXTURE BAKING API
//
// This provides options for packing multiple fonts into one atlas, not
// perfectly but better than nothing.
typedef struct
{
	unsigned short x0,y0,x1,y1; // coordinates of bbox in bitmap
	float xoff,yoff,xadvance;
	float xoff2,yoff2;
} stbtt_packedchar;
typedef struct stbtt_pack_context stbtt_pack_context;
typedef struct stbtt_fontinfo stbtt_fontinfo;
#ifndef STB_RECT_PACK_VERSION
typedef struct stbrp_rect stbrp_rect;
#endif
STBTT_DEF int  stbtt_PackBegin(stbtt_pack_context *spc, unsigned char *pixels, int width, int height, int stride_in_bytes, int padding, void *alloc_context);
// Initializes a packing context stored in the passed-in stbtt_pack_context.
// Future calls using this context will pack characters into the bitmap passed
// in here: a 1-channel bitmap that is width * height. stride_in_bytes is
// the distance from one row to the next (or 0 to mean they are packed tightly
// together). "padding" is the amount of padding to leave between each
// character (normally you want '1' for bitmaps you'll use as textures with
// bilinear filtering).
//
// Returns 0 on failure, 1 on success.
STBTT_DEF void stbtt_PackEnd  (stbtt_pack_context *spc);
// Cleans up the packing context and frees all memory.
#define STBTT_POINT_SIZE(x)   (-(x))
STBTT_DEF int  stbtt_PackFontRange(stbtt_pack_context *spc, const unsigned char *fontdata, int font_index, float font_size,
										  int first_unicode_char_in_range, int num_chars_in_range, stbtt_packedchar *chardata_for_range);
// Creates character bitmaps from the font_index'th font found in fontdata (use
// font_index=0 if you don't know what that is). It creates num_chars_in_range
// bitmaps for characters with unicode values starting at first_unicode_char_in_range
// and increasing. Data for how to render them is stored in chardata_for_range;
// pass these to stbtt_GetPackedQuad to get back renderable quads.
//
// font_size is the full height of the character from ascender to descender,
// as computed by stbtt_ScaleForPixelHeight. To use a point size as computed
// by stbtt_ScaleForMappingEmToPixels, wrap the point size in STBTT_POINT_SIZE()
// and pass that result as 'font_size':
//       ...,                  20 , ... // font max minus min y is 20 pixels tall
//       ..., STBTT_POINT_SIZE(20), ... // 'M' is 20 pixels tall
typedef struct
{
	float font_size;
	int first_unicode_codepoint_in_range;  // if non-zero, then the chars are continuous, and this is the first codepoint
	int *array_of_unicode_codepoints;       // if non-zero, then this is an array of unicode codepoints
	int num_chars;
	stbtt_packedchar *chardata_for_range; // output
	unsigned char h_oversample, v_oversample; // don't set these, they're used internally
} stbtt_pack_range;
STBTT_DEF int  stbtt_PackFontRanges(stbtt_pack_context *spc, const unsigned char *fontdata, int font_index, stbtt_pack_range *ranges, int num_ranges);
// Creates character bitmaps from multiple ranges of characters stored in
// ranges. This will usually create a better-packed bitmap than multiple
// calls to stbtt_PackFontRange. Note that you can call this multiple
// times within a single PackBegin/PackEnd.
STBTT_DEF void stbtt_PackSetOversampling(stbtt_pack_context *spc, unsigned int h_oversample, unsigned int v_oversample);
// Oversampling a font increases the quality by allowing higher-quality subpixel
// positioning, and is especially valuable at smaller text sizes.
//
// This function sets the amount of oversampling for all following calls to
// stbtt_PackFontRange(s) or stbtt_PackFontRangesGatherRects for a given
// pack context. The default (no oversampling) is achieved by h_oversample=1
// and v_oversample=1. The total number of pixels required is
// h_oversample*v_oversample larger than the default; for example, 2x2
// oversampling requires 4x the storage of 1x1. For best results, render
// oversampled textures with bilinear filtering. Look at the readme in
// stb/tests/oversample for information about oversampled fonts
//
// To use with PackFontRangesGather etc., you must set it before calls
// call to PackFontRangesGatherRects.
STBTT_DEF void stbtt_PackSetSkipMissingCodepoints(stbtt_pack_context *spc, int skip);
// If skip != 0, this tells stb_truetype to skip any codepoints for which
// there is no corresponding glyph. If skip=0, which is the default, then
// codepoints without a glyph recived the font's "missing character" glyph,
// typically an empty box by convention.
STBTT_DEF void stbtt_GetPackedQuad(const stbtt_packedchar *chardata, int pw, int ph,  // same data as above
										 int char_index,             // character to display
										 float *xpos, float *ypos,   // pointers to current position in screen pixel space
										 stbtt_aligned_quad *q,      // output: quad to draw
										 int align_to_integer);
STBTT_DEF int  stbtt_PackFontRangesGatherRects(stbtt_pack_context *spc, const stbtt_fontinfo *info, stbtt_pack_range *ranges, int num_ranges, stbrp_rect *rects);
STBTT_DEF void stbtt_PackFontRangesPackRects(stbtt_pack_context *spc, stbrp_rect *rects, int num_rects);
STBTT_DEF int  stbtt_PackFontRangesRenderIntoRects(stbtt_pack_context *spc, const stbtt_fontinfo *info, stbtt_pack_range *ranges, int num_ranges, stbrp_rect *rects);
// Calling these functions in sequence is roughly equivalent to calling
// stbtt_PackFontRanges(). If you more control over the packing of multiple
// fonts, or if you want to pack custom data into a font texture, take a look
// at the source to of stbtt_PackFontRanges() and create a custom version
// using these functions, e.g. call GatherRects multiple times,
// building up a single array of rects, then call PackRects once,
// then call RenderIntoRects repeatedly. This may result in a
// better packing than calling PackFontRanges multiple times
// (or it may not).
// this is an opaque structure that you shouldn't mess with which holds
// all the context needed from PackBegin to PackEnd.
struct stbtt_pack_context {
	void *user_allocator_context;
	void *pack_info;
	int   width;
	int   height;
	int   stride_in_bytes;
	int   padding;
	int   skip_missing;
	unsigned int   h_oversample, v_oversample;
	unsigned char *pixels;
	void  *nodes;
};
//////////////////////////////////////////////////////////////////////////////
//
// FONT LOADING
//
//
STBTT_DEF int stbtt_GetNumberOfFonts(const unsigned char *data);
// This function will determine the number of fonts in a font file.  TrueType
// collection (.ttc) files may contain multiple fonts, while TrueType font
// (.ttf) files only contain one font. The number of fonts can be used for
// indexing with the previous function where the index is between zero and one
// less than the total fonts. If an error occurs, -1 is returned.
STBTT_DEF int stbtt_GetFontOffsetForIndex(const unsigned char *data, int index);
// Each .ttf/.ttc file may have more than one font. Each font has a sequential
// index number starting from 0. Call this function to get the font offset for
// a given index; it returns -1 if the index is out of range. A regular .ttf
// file will only define one font and it always be at offset 0, so it will
// return '0' for index 0, and -1 for all other indices.
// The following structure is defined publicly so you can declare one on
// the stack or as a global or etc, but you should treat it as opaque.
struct stbtt_fontinfo
{
	void           * userdata;
	unsigned char  * data;              // pointer to .ttf file
	int              fontstart;         // offset of start of font
	int numGlyphs;                     // number of glyphs, needed for range checking

	int loca,head,glyf,hhea,hmtx,kern,gpos,svg; // table locations as offset from start of .ttf
	int index_map;                     // a cmap mapping for our chosen character encoding
	int indexToLocFormat;              // format needed to map from glyph index to glyph

	stbtt__buf cff;                    // cff font data
	stbtt__buf charstrings;            // the charstring index
	stbtt__buf gsubrs;                 // global charstring subroutines index
	stbtt__buf subrs;                  // private charstring subroutines index
	stbtt__buf fontdicts;              // array of font dicts
	stbtt__buf fdselect;               // map from glyph to fontdict
};
STBTT_DEF int stbtt_InitFont(stbtt_fontinfo *info, const unsigned char *data, int offset);
// Given an offset into the file that defines a font, this function builds
// the necessary cached info for the rest of the system. You must allocate
// the stbtt_fontinfo yourself, and stbtt_InitFont will fill it out. You don't
// need to do anything special to free it, because the contents are pure
// value data with no additional data structures. Returns 0 on failure.
//////////////////////////////////////////////////////////////////////////////
//
// CHARACTER TO GLYPH-INDEX CONVERSIOn
STBTT_DEF int stbtt_FindGlyphIndex(const stbtt_fontinfo *info, int unicode_codepoint);
// If you're going to perform multiple operations on the same character
// and you want a speed-up, call this function with the character you're
// going to process, then use glyph-based functions instead of the
// codepoint-based functions.
// Returns 0 if the character codepoint is not defined in the font.
//////////////////////////////////////////////////////////////////////////////
//
// CHARACTER PROPERTIES
//
STBTT_DEF float stbtt_ScaleForPixelHeight(const stbtt_fontinfo *info, float pixels);
// computes a scale factor to produce a font whose "height" is 'pixels' tall.
// Height is measured as the distance from the highest ascender to the lowest
// descender; in other words, it's equivalent to calling stbtt_GetFontVMetrics
// and computing:
//       scale = pixels / (ascent - descent)
// so if you prefer to measure height by the ascent only, use a similar calculation.
STBTT_DEF float stbtt_ScaleForMappingEmToPixels(const stbtt_fontinfo *info, float pixels);
// computes a scale factor to produce a font whose EM size is mapped to
// 'pixels' tall. This is probably what traditional APIs compute, but
// I'm not positive.
STBTT_DEF void stbtt_GetFontVMetrics(const stbtt_fontinfo *info, int *ascent, int *descent, int *lineGap);
// ascent is the coordinate above the baseline the font extends; descent
// is the coordinate below the baseline the font extends (i.e. it is typically negative)
// lineGap is the spacing between one row's descent and the next row's ascent...
// so you should advance the vertical position by "*ascent - *descent + *lineGap"
//   these are expressed in unscaled coordinates, so you must multiply by
//   the scale factor for a given size
STBTT_DEF int  stbtt_GetFontVMetricsOS2(const stbtt_fontinfo *info, int *typoAscent, int *typoDescent, int *typoLineGap);
// analogous to GetFontVMetrics, but returns the "typographic" values from the OS/2
// table (specific to MS/Windows TTF files).
//
// Returns 1 on success (table present), 0 on failure.
STBTT_DEF void stbtt_GetFontBoundingBox(const stbtt_fontinfo *info, int *x0, int *y0, int *x1, int *y1);
// the bounding box around all possible characters
STBTT_DEF void stbtt_GetCodepointHMetrics(const stbtt_fontinfo *info, int codepoint, int *advanceWidth, int *leftSideBearing);
// leftSideBearing is the offset from the current horizontal position to the left edge of the character
// advanceWidth is the offset from the current horizontal position to the next horizontal position
//   these are expressed in unscaled coordinates
STBTT_DEF int  stbtt_GetCodepointKernAdvance(const stbtt_fontinfo *info, int ch1, int ch2);
// an additional amount to add to the 'advance' value between ch1 and ch2
STBTT_DEF int stbtt_GetCodepointBox(const stbtt_fontinfo *info, int codepoint, int *x0, int *y0, int *x1, int *y1);
// Gets the bounding box of the visible part of the glyph, in unscaled coordinates
STBTT_DEF void stbtt_GetGlyphHMetrics(const stbtt_fontinfo *info, int glyph_index, int *advanceWidth, int *leftSideBearing);
STBTT_DEF int  stbtt_GetGlyphKernAdvance(const stbtt_fontinfo *info, int glyph1, int glyph2);
STBTT_DEF int  stbtt_GetGlyphBox(const stbtt_fontinfo *info, int glyph_index, int *x0, int *y0, int *x1, int *y1);
// as above, but takes one or more glyph indices for greater efficiency
typedef struct stbtt_kerningentry
{
	int glyph1; // use stbtt_FindGlyphIndex
	int glyph2;
	int advance;
} stbtt_kerningentry;
STBTT_DEF int  stbtt_GetKerningTableLength(const stbtt_fontinfo *info);
STBTT_DEF int  stbtt_GetKerningTable(const stbtt_fontinfo *info, stbtt_kerningentry* table, int table_length);
// Retrieves a complete list of all of the kerning pairs provided by the font
// stbtt_GetKerningTable never writes more than table_length entries and returns how many entries it did write.
// The table will be sorted by (a.glyph1 == b.glyph1)?(a.glyph2 < b.glyph2):(a.glyph1 < b.glyph1)
//////////////////////////////////////////////////////////////////////////////
//
// GLYPH SHAPES (you probably don't need these, but they have to go before
// the bitmaps for C declaration-order reasons)
//
#ifndef STBTT_vmove // you can predefine these to use different values (but why?)
	enum {
		STBTT_vmove=1,
		STBTT_vline,
		STBTT_vcurve,
		STBTT_vcubic
	};
#endif
#ifndef stbtt_vertex // you can predefine this to use different values
						 // (we share this with other code at RAD)
	#define stbtt_vertex_type short // can't use stbtt_int16 because that's not visible in the header file
	typedef struct
	{
		stbtt_vertex_type x,y,cx,cy,cx1,cy1;
		unsigned char type,padding;
	} stbtt_vertex;
#endif
STBTT_DEF int stbtt_IsGlyphEmpty(const stbtt_fontinfo *info, int glyph_index);
// returns non-zero if nothing is drawn for this glyph
STBTT_DEF int stbtt_GetCodepointShape(const stbtt_fontinfo *info, int unicode_codepoint, stbtt_vertex **vertices);
STBTT_DEF int stbtt_GetGlyphShape(const stbtt_fontinfo *info, int glyph_index, stbtt_vertex **vertices);
// returns # of vertices and fills *vertices with the pointer to them
//   these are expressed in "unscaled" coordinates
//
// The shape is a series of contours. Each one starts with
// a STBTT_moveto, then consists of a series of mixed
// STBTT_lineto and STBTT_curveto segments. A lineto
// draws a line from previous endpoint to its x,y; a curveto
// draws a quadratic bezier from previous endpoint to
// its x,y, using cx,cy as the bezier control point.
STBTT_DEF void stbtt_FreeShape(const stbtt_fontinfo *info, stbtt_vertex *vertices);
// frees the data allocated above
STBTT_DEF int stbtt_GetCodepointSVG(const stbtt_fontinfo *info, int unicode_codepoint, const char **svg);
STBTT_DEF int stbtt_GetGlyphSVG(const stbtt_fontinfo *info, int gl, const char **svg);
// fills svg with the character's SVG data.
// returns data size or 0 if SVG not found.
//////////////////////////////////////////////////////////////////////////////
//
// BITMAP RENDERING
//
STBTT_DEF void stbtt_FreeBitmap(unsigned char *bitmap, void *userdata);
// frees the bitmap allocated below
STBTT_DEF unsigned char *stbtt_GetCodepointBitmap(const stbtt_fontinfo *info, float scale_x, float scale_y, int codepoint, int *width, int *height, int *xoff, int *yoff);
// allocates a large-enough single-channel 8bpp bitmap and renders the
// specified character/glyph at the specified scale into it, with
// antialiasing. 0 is no coverage (transparent), 255 is fully covered (opaque).
// *width & *height are filled out with the width & height of the bitmap,
// which is stored left-to-right, top-to-bottom.
//
// xoff/yoff are the offset it pixel space from the glyph origin to the top-left of the bitmap
STBTT_DEF unsigned char *stbtt_GetCodepointBitmapSubpixel(const stbtt_fontinfo *info, float scale_x, float scale_y, float shift_x, float shift_y, int codepoint, int *width, int *height, int *xoff, int *yoff);
// the same as stbtt_GetCodepoitnBitmap, but you can specify a subpixel
// shift for the character
STBTT_DEF void stbtt_MakeCodepointBitmap(const stbtt_fontinfo *info, unsigned char *output, int out_w, int out_h, int out_stride, float scale_x, float scale_y, int codepoint);
// the same as stbtt_GetCodepointBitmap, but you pass in storage for the bitmap
// in the form of 'output', with row spacing of 'out_stride' bytes. the bitmap
// is clipped to out_w/out_h bytes. Call stbtt_GetCodepointBitmapBox to get the
// width and height and positioning info for it first.
STBTT_DEF void stbtt_MakeCodepointBitmapSubpixel(const stbtt_fontinfo *info, unsigned char *output, int out_w, int out_h, int out_stride, float scale_x, float scale_y, float shift_x, float shift_y, int codepoint);
// same as stbtt_MakeCodepointBitmap, but you can specify a subpixel
// shift for the character
STBTT_DEF void stbtt_MakeCodepointBitmapSubpixelPrefilter(const stbtt_fontinfo *info, unsigned char *output, int out_w, int out_h, int out_stride, float scale_x, float scale_y, float shift_x, float shift_y, int oversample_x, int oversample_y, float *sub_x, float *sub_y, int codepoint);
// same as stbtt_MakeCodepointBitmapSubpixel, but prefiltering
// is performed (see stbtt_PackSetOversampling)
STBTT_DEF void stbtt_GetCodepointBitmapBox(const stbtt_fontinfo *font, int codepoint, float scale_x, float scale_y, int *ix0, int *iy0, int *ix1, int *iy1);
// get the bbox of the bitmap centered around the glyph origin; so the
// bitmap width is ix1-ix0, height is iy1-iy0, and location to place
// the bitmap top left is (leftSideBearing*scale,iy0).
// (Note that the bitmap uses y-increases-down, but the shape uses
// y-increases-up, so CodepointBitmapBox and CodepointBox are inverted.)
STBTT_DEF void stbtt_GetCodepointBitmapBoxSubpixel(const stbtt_fontinfo *font, int codepoint, float scale_x, float scale_y, float shift_x, float shift_y, int *ix0, int *iy0, int *ix1, int *iy1);
// same as stbtt_GetCodepointBitmapBox, but you can specify a subpixel
// shift for the character
// the following functions are equivalent to the above functions, but operate
// on glyph indices instead of Unicode codepoints (for efficiency)
STBTT_DEF unsigned char *stbtt_GetGlyphBitmap(const stbtt_fontinfo *info, float scale_x, float scale_y, int glyph, int *width, int *height, int *xoff, int *yoff);
STBTT_DEF unsigned char *stbtt_GetGlyphBitmapSubpixel(const stbtt_fontinfo *info, float scale_x, float scale_y, float shift_x, float shift_y, int glyph, int *width, int *height, int *xoff, int *yoff);
STBTT_DEF void stbtt_MakeGlyphBitmap(const stbtt_fontinfo *info, unsigned char *output, int out_w, int out_h, int out_stride, float scale_x, float scale_y, int glyph);
STBTT_DEF void stbtt_MakeGlyphBitmapSubpixel(const stbtt_fontinfo *info, unsigned char *output, int out_w, int out_h, int out_stride, float scale_x, float scale_y, float shift_x, float shift_y, int glyph);
STBTT_DEF void stbtt_MakeGlyphBitmapSubpixelPrefilter(const stbtt_fontinfo *info, unsigned char *output, int out_w, int out_h, int out_stride, float scale_x, float scale_y, float shift_x, float shift_y, int oversample_x, int oversample_y, float *sub_x, float *sub_y, int glyph);
STBTT_DEF void stbtt_GetGlyphBitmapBox(const stbtt_fontinfo *font, int glyph, float scale_x, float scale_y, int *ix0, int *iy0, int *ix1, int *iy1);
STBTT_DEF void stbtt_GetGlyphBitmapBoxSubpixel(const stbtt_fontinfo *font, int glyph, float scale_x, float scale_y,float shift_x, float shift_y, int *ix0, int *iy0, int *ix1, int *iy1);
// @TODO: don't expose this structure
typedef struct
{
	int w,h,stride;
	unsigned char *pixels;
} stbtt__bitmap;
// rasterize a shape with quadratic beziers into a bitmap
STBTT_DEF void stbtt_Rasterize(stbtt__bitmap *result,        // 1-channel bitmap to draw into
										 float flatness_in_pixels,     // allowable error of curve in pixels
										 stbtt_vertex *vertices,       // array of vertices defining shape
										 int num_verts,                // number of vertices in above array
										 float scale_x, float scale_y, // scale applied to input vertices
										 float shift_x, float shift_y, // translation applied to input vertices
										 int x_off, int y_off,         // another translation applied to input
										 int invert,                   // if non-zero, vertically flip shape
										 void *userdata);              // context for to STBTT_MALLOC
//////////////////////////////////////////////////////////////////////////////
//
// Signed Distance Function (or Field) rendering
STBTT_DEF void stbtt_FreeSDF(unsigned char *bitmap, void *userdata);
// frees the SDF bitmap allocated below
STBTT_DEF unsigned char * stbtt_GetGlyphSDF(const stbtt_fontinfo *info, float scale, int glyph, int padding, unsigned char onedge_value, float pixel_dist_scale, int *width, int *height, int *xoff, int *yoff);
STBTT_DEF unsigned char * stbtt_GetCodepointSDF(const stbtt_fontinfo *info, float scale, int codepoint, int padding, unsigned char onedge_value, float pixel_dist_scale, int *width, int *height, int *xoff, int *yoff);
// These functions compute a discretized SDF field for a single character, suitable for storing
// in a single-channel texture, sampling with bilinear filtering, and testing against
// larger than some threshold to produce scalable fonts.
//        info              --  the font
//        scale             --  controls the size of the resulting SDF bitmap, same as it would be creating a regular bitmap
//        glyph/codepoint   --  the character to generate the SDF for
//        padding           --  extra "pixels" around the character which are filled with the distance to the character (not 0),
//                                 which allows effects like bit outlines
//        onedge_value      --  value 0-255 to test the SDF against to reconstruct the character (i.e. the isocontour of the character)
//        pixel_dist_scale  --  what value the SDF should increase by when moving one SDF "pixel" away from the edge (on the 0..255 scale)
//                                 if positive, > onedge_value is inside; if negative, < onedge_value is inside
//        width,height      --  output height & width of the SDF bitmap (including padding)
//        xoff,yoff         --  output origin of the character
//        return value      --  a 2D array of bytes 0..255, width*height in size
//
// pixel_dist_scale & onedge_value are a scale & bias that allows you to make
// optimal use of the limited 0..255 for your application, trading off precision
// and special effects. SDF values outside the range 0..255 are clamped to 0..255.
//
// Example:
//      scale = stbtt_ScaleForPixelHeight(22)
//      padding = 5
//      onedge_value = 180
//      pixel_dist_scale = 180/5.0 = 36.0
//
//      This will create an SDF bitmap in which the character is about 22 pixels
//      high but the whole bitmap is about 22+5+5=32 pixels high. To produce a filled
//      shape, sample the SDF at each pixel and fill the pixel if the SDF value
//      is greater than or equal to 180/255. (You'll actually want to antialias,
//      which is beyond the scope of this example.) Additionally, you can compute
//      offset outlines (e.g. to stroke the character border inside & outside,
//      or only outside). For example, to fill outside the character up to 3 SDF
//      pixels, you would compare against (180-36.0*3)/255 = 72/255. The above
//      choice of variables maps a range from 5 pixels outside the shape to
//      2 pixels inside the shape to 0..255; this is intended primarily for apply
//      outside effects only (the interior range is needed to allow proper
//      antialiasing of the font at *smaller* sizes)
//
// The function computes the SDF analytically at each SDF pixel, not by e.g.
// building a higher-res bitmap and approximating it. In theory the quality
// should be as high as possible for an SDF of this size & representation, but
// unclear if this is true in practice (perhaps building a higher-res bitmap
// and computing from that can allow drop-out prevention).
//
// The algorithm has not been optimized at all, so expect it to be slow
// if computing lots of characters or very large sizes.
//////////////////////////////////////////////////////////////////////////////
//
// Finding the right font...
//
// You should really just solve this offline, keep your own tables
// of what font is what, and don't try to get it out of the .ttf file.
// That's because getting it out of the .ttf file is really hard, because
// the names in the file can appear in many possible encodings, in many
// possible languages, and e.g. if you need a case-insensitive comparison,
// the details of that depend on the encoding & language in a complex way
// (actually underspecified in truetype, but also gigantic).
//
// But you can use the provided functions in two possible ways:
//     stbtt_FindMatchingFont() will use *case-sensitive* comparisons on
//             unicode-encoded names to try to find the font you want;
//             you can run this before calling stbtt_InitFont()
//
//     stbtt_GetFontNameString() lets you get any of the various strings
//             from the file yourself and do your own comparisons on them.
//             You have to have called stbtt_InitFont() first.
STBTT_DEF int stbtt_FindMatchingFont(const unsigned char *fontdata, const char *name, int flags);
// returns the offset (not index) of the font that matches, or -1 if none
//   if you use STBTT_MACSTYLE_DONTCARE, use a font name like "Arial Bold".
//   if you use any other flag, use a font name like "Arial"; this checks
//     the 'macStyle' header field; i don't know if fonts set this consistently
#define STBTT_MACSTYLE_DONTCARE     0
#define STBTT_MACSTYLE_BOLD         1
#define STBTT_MACSTYLE_ITALIC       2
#define STBTT_MACSTYLE_UNDERSCORE   4
#define STBTT_MACSTYLE_NONE         8   // <= not same as 0, this makes us check the bitfield is 0
STBTT_DEF int stbtt_CompareUTF8toUTF16_bigendian(const char *s1, int len1, const char *s2, int len2);
// returns 1/0 whether the first string interpreted as utf8 is identical to
// the second string interpreted as big-endian utf16... useful for strings from next func
STBTT_DEF const char *stbtt_GetFontNameString(const stbtt_fontinfo *font, int *length, int platformID, int encodingID, int languageID, int nameID);
// returns the string (which may be big-endian double byte, e.g. for unicode)
// and puts the length in bytes in *length.
//
// some of the values for the IDs are below; for more see the truetype spec:
//     http://developer.apple.com/textfonts/TTRefMan/RM06/Chap6name.html
//     http://www.microsoft.com/typography/otspec/name.htm
enum { // platformID
	STBTT_PLATFORM_ID_UNICODE   =0,
	STBTT_PLATFORM_ID_MAC       =1,
	STBTT_PLATFORM_ID_ISO       =2,
	STBTT_PLATFORM_ID_MICROSOFT =3
};
enum { // encodingID for STBTT_PLATFORM_ID_UNICODE
	STBTT_UNICODE_EID_UNICODE_1_0    =0,
	STBTT_UNICODE_EID_UNICODE_1_1    =1,
	STBTT_UNICODE_EID_ISO_10646      =2,
	STBTT_UNICODE_EID_UNICODE_2_0_BMP=3,
	STBTT_UNICODE_EID_UNICODE_2_0_FULL=4
};
enum { // encodingID for STBTT_PLATFORM_ID_MICROSOFT
	STBTT_MS_EID_SYMBOL        =0,
	STBTT_MS_EID_UNICODE_BMP   =1,
	STBTT_MS_EID_SHIFTJIS      =2,
	STBTT_MS_EID_UNICODE_FULL  =10
};
enum { // encodingID for STBTT_PLATFORM_ID_MAC; same as Script Manager codes
	STBTT_MAC_EID_ROMAN        =0,   STBTT_MAC_EID_ARABIC       =4,
	STBTT_MAC_EID_JAPANESE     =1,   STBTT_MAC_EID_HEBREW       =5,
	STBTT_MAC_EID_CHINESE_TRAD =2,   STBTT_MAC_EID_GREEK        =6,
	STBTT_MAC_EID_KOREAN       =3,   STBTT_MAC_EID_RUSSIAN      =7
};
enum { // languageID for STBTT_PLATFORM_ID_MICROSOFT; same as LCID...
		 // problematic because there are e.g. 16 english LCIDs and 16 arabic LCIDs
	STBTT_MS_LANG_ENGLISH     =0x0409,   STBTT_MS_LANG_ITALIAN     =0x0410,
	STBTT_MS_LANG_CHINESE     =0x0804,   STBTT_MS_LANG_JAPANESE    =0x0411,
	STBTT_MS_LANG_DUTCH       =0x0413,   STBTT_MS_LANG_KOREAN      =0x0412,
	STBTT_MS_LANG_FRENCH      =0x040c,   STBTT_MS_LANG_RUSSIAN     =0x0419,
	STBTT_MS_LANG_GERMAN      =0x0407,   STBTT_MS_LANG_SPANISH     =0x0409,
	STBTT_MS_LANG_HEBREW      =0x040d,   STBTT_MS_LANG_SWEDISH     =0x041D
};
enum { // languageID for STBTT_PLATFORM_ID_MAC
	STBTT_MAC_LANG_ENGLISH      =0 ,   STBTT_MAC_LANG_JAPANESE     =11,
	STBTT_MAC_LANG_ARABIC       =12,   STBTT_MAC_LANG_KOREAN       =23,
	STBTT_MAC_LANG_DUTCH        =4 ,   STBTT_MAC_LANG_RUSSIAN      =32,
	STBTT_MAC_LANG_FRENCH       =1 ,   STBTT_MAC_LANG_SPANISH      =6 ,
	STBTT_MAC_LANG_GERMAN       =2 ,   STBTT_MAC_LANG_SWEDISH      =5 ,
	STBTT_MAC_LANG_HEBREW       =10,   STBTT_MAC_LANG_CHINESE_SIMPLIFIED =33,
	STBTT_MAC_LANG_ITALIAN      =3 ,   STBTT_MAC_LANG_CHINESE_TRAD =19
};
#ifdef __cplusplus
}
#endif
#endif // __STB_INCLUDE_STB_TRUETYPE_H__

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
////
////   IMPLEMENTATION
////
////
#ifndef STBTT_MAX_OVERSAMPLE
#define STBTT_MAX_OVERSAMPLE   8
#endif
#if STBTT_MAX_OVERSAMPLE > 255
#error "STBTT_MAX_OVERSAMPLE cannot be > 255"
#endif
typedef int stbtt__test_oversample_pow2[(STBTT_MAX_OVERSAMPLE & (STBTT_MAX_OVERSAMPLE-1)) == 0 ? 1 : -1];
#ifndef STBTT_RASTERIZER_VERSION
#define STBTT_RASTERIZER_VERSION 2
#endif
#ifdef _MSC_VER
#define STBTT__NOTUSED(v)  (void)(v)
#else
#define STBTT__NOTUSED(v)  (void)sizeof(v)
#endif

//////////////////////////////////////////////////////////////////////////
//
// stbtt__buf helpers to parse data from file
//
static stbtt_uint8 stbtt__buf_get8(stbtt__buf *b)
{
	if (b->cursor >= b->size)
		return 0;
	return b->data[b->cursor++];
}

static stbtt_uint8 stbtt__buf_peek8(stbtt__buf *b)
{
	if (b->cursor >= b->size)
		return 0;
	return b->data[b->cursor];
}

static void stbtt__buf_seek(stbtt__buf *b, int o)
{
	STBTT_assert(!(o > b->size || o < 0));
	b->cursor = (o > b->size || o < 0) ? b->size : o;
}

static void stbtt__buf_skip(stbtt__buf *b, int o)
{
	stbtt__buf_seek(b, b->cursor + o);
}

static stbtt_uint32 stbtt__buf_get(stbtt__buf *b, int n)
{
	stbtt_uint32 v = 0;
	int i;
	STBTT_assert(n >= 1 && n <= 4);
	for (i = 0; i < n; i++)
		v = (v << 8) | stbtt__buf_get8(b);
	return v;
}

static stbtt__buf stbtt__new_buf(const void *p, size_t size)
{
	stbtt__buf r;
	STBTT_assert(size < 0x40000000);
	r.data = (stbtt_uint8*) p;
	r.size = (int) size;
	r.cursor = 0;
	return r;
}

#define stbtt__buf_get16(b)  stbtt__buf_get((b), 2)
#define stbtt__buf_get32(b)  stbtt__buf_get((b), 4)

static stbtt__buf stbtt__buf_range(const stbtt__buf *b, int o, int s)
{
	stbtt__buf r = stbtt__new_buf(NULL, 0);
	if (o < 0 || s < 0 || o > b->size || s > b->size - o) return r;
	r.data = b->data + o;
	r.size = s;
	return r;
}

static stbtt__buf stbtt__cff_get_index(stbtt__buf *b)
{
	int count, start, offsize;
	start = b->cursor;
	count = stbtt__buf_get16(b);
	if (count) {
		offsize = stbtt__buf_get8(b);
		STBTT_assert(offsize >= 1 && offsize <= 4);
		stbtt__buf_skip(b, offsize * count);
		stbtt__buf_skip(b, stbtt__buf_get(b, offsize) - 1);
	}
	return stbtt__buf_range(b, start, b->cursor - start);
}

static stbtt_uint32 stbtt__cff_int(stbtt__buf *b)
{
	int b0 = stbtt__buf_get8(b);
	if (b0 >= 32 && b0 <= 246)       return b0 - 139;
	else if (b0 >= 247 && b0 <= 250) return (b0 - 247)*256 + stbtt__buf_get8(b) + 108;
	else if (b0 >= 251 && b0 <= 254) return -(b0 - 251)*256 - stbtt__buf_get8(b) - 108;
	else if (b0 == 28)               return stbtt__buf_get16(b);
	else if (b0 == 29)               return stbtt__buf_get32(b);
	STBTT_assert(0);
	return 0;
}

static void stbtt__cff_skip_operand(stbtt__buf *b) {
	int v, b0 = stbtt__buf_peek8(b);
	STBTT_assert(b0 >= 28);
	if (b0 == 30) {
		stbtt__buf_skip(b, 1);
		while (b->cursor < b->size) {
			v = stbtt__buf_get8(b);
			if ((v & 0xF) == 0xF || (v >> 4) == 0xF)
				break;
		}
	} else {
		stbtt__cff_int(b);
	}
}

static stbtt__buf stbtt__dict_get(stbtt__buf *b, int key)
{
	stbtt__buf_seek(b, 0);
	while (b->cursor < b->size) {
		int start = b->cursor, end, op;
		while (stbtt__buf_peek8(b) >= 28)
			stbtt__cff_skip_operand(b);
		end = b->cursor;
		op = stbtt__buf_get8(b);
		if (op == 12)  op = stbtt__buf_get8(b) | 0x100;
		if (op == key) return stbtt__buf_range(b, start, end-start);
	}
	return stbtt__buf_range(b, 0, 0);
}

static void stbtt__dict_get_ints(stbtt__buf *b, int key, int outcount, stbtt_uint32 *out)
{
	int i;
	stbtt__buf operands = stbtt__dict_get(b, key);
	for (i = 0; i < outcount && operands.cursor < operands.size; i++)
		out[i] = stbtt__cff_int(&operands);
}

static int stbtt__cff_index_count(stbtt__buf *b)
{
	stbtt__buf_seek(b, 0);
	return stbtt__buf_get16(b);
}

static stbtt__buf stbtt__cff_index_get(stbtt__buf b, int i)
{
	int count, offsize, start, end;
	stbtt__buf_seek(&b, 0);
	count = stbtt__buf_get16(&b);
	offsize = stbtt__buf_get8(&b);
	STBTT_assert(i >= 0 && i < count);
	STBTT_assert(offsize >= 1 && offsize <= 4);
	stbtt__buf_skip(&b, i*offsize);
	start = stbtt__buf_get(&b, offsize);
	end = stbtt__buf_get(&b, offsize);
	return stbtt__buf_range(&b, 2+(count+1)*offsize+start, end - start);
}

//////////////////////////////////////////////////////////////////////////
//
// accessors to parse data from file
//
// on platforms that don't allow misaligned reads, if we want to allow
// truetype fonts that aren't padded to alignment, define ALLOW_UNALIGNED_TRUETYPE
#define ttBYTE(p)     (* (stbtt_uint8 *) (p))
#define ttCHAR(p)     (* (stbtt_int8 *) (p))
#define ttFixed(p)    ttLONG(p)

static stbtt_uint16 ttUSHORT(stbtt_uint8 *p) { return p[0]*256 + p[1]; }
static stbtt_int16 ttSHORT(stbtt_uint8 *p)   { return p[0]*256 + p[1]; }
static stbtt_uint32 ttULONG(stbtt_uint8 *p)  { return (p[0]<<24) + (p[1]<<16) + (p[2]<<8) + p[3]; }
static stbtt_int32 ttLONG(stbtt_uint8 *p)    { return (p[0]<<24) + (p[1]<<16) + (p[2]<<8) + p[3]; }

#define stbtt_tag4(p,c0,c1,c2,c3) ((p)[0] == (c0) && (p)[1] == (c1) && (p)[2] == (c2) && (p)[3] == (c3))
#define stbtt_tag(p,str)           stbtt_tag4(p,str[0],str[1],str[2],str[3])

static int stbtt__isfont(stbtt_uint8 *font)
{
	// check the version number
	if (stbtt_tag4(font, '1',0,0,0))  return 1; // TrueType 1
	if (stbtt_tag(font, "typ1"))   return 1; // TrueType with type 1 font -- we don't support this!
	if (stbtt_tag(font, "OTTO"))   return 1; // OpenType with CFF
	if (stbtt_tag4(font, 0,1,0,0)) return 1; // OpenType 1.0
	if (stbtt_tag(font, "true"))   return 1; // Apple specification for TrueType fonts
	return 0;
}

// @OPTIMIZE: binary search
static stbtt_uint32 stbtt__find_table(stbtt_uint8 *data, stbtt_uint32 fontstart, const char *tag)
{
	stbtt_int32 num_tables = ttUSHORT(data+fontstart+4);
	stbtt_uint32 tabledir = fontstart + 12;
	stbtt_int32 i;
	for (i=0; i < num_tables; ++i) {
		stbtt_uint32 loc = tabledir + 16*i;
		if (stbtt_tag(data+loc+0, tag))
			return ttULONG(data+loc+8);
	}
	return 0;
}

static int stbtt_GetFontOffsetForIndex_internal(unsigned char *font_collection, int index)
{
	// if it's just a font, there's only one valid index
	if (stbtt__isfont(font_collection))
		return index == 0 ? 0 : -1;

	// check if it's a TTC
	if (stbtt_tag(font_collection, "ttcf")) {
		// version 1?
		if (ttULONG(font_collection+4) == 0x00010000 || ttULONG(font_collection+4) == 0x00020000) {
			stbtt_int32 n = ttLONG(font_collection+8);
			if (index >= n)
				return -1;
			return ttULONG(font_collection+12+index*4);
		}
	}
	return -1;
}

static int stbtt_GetNumberOfFonts_internal(unsigned char *font_collection)
{
	// if it's just a font, there's only one valid font
	if (stbtt__isfont(font_collection))
		return 1;

	// check if it's a TTC
	if (stbtt_tag(font_collection, "ttcf")) {
		// version 1?
		if (ttULONG(font_collection+4) == 0x00010000 || ttULONG(font_collection+4) == 0x00020000) {
			return ttLONG(font_collection+8);
		}
	}
	return 0;
}

static stbtt__buf stbtt__get_subrs(stbtt__buf cff, stbtt__buf fontdict)
{
	stbtt_uint32 subrsoff = 0, private_loc[2] = { 0, 0 };
	stbtt__buf pdict;
	stbtt__dict_get_ints(&fontdict, 18, 2, private_loc);
	if (!private_loc[1] || !private_loc[0]) return stbtt__new_buf(NULL, 0);
	pdict = stbtt__buf_range(&cff, private_loc[1], private_loc[0]);
	stbtt__dict_get_ints(&pdict, 19, 1, &subrsoff);
	if (!subrsoff) return stbtt__new_buf(NULL, 0);
	stbtt__buf_seek(&cff, private_loc[1]+subrsoff);
	return stbtt__cff_get_index(&cff);
}

// since most people won't use this, find this table the first time it's needed
static int stbtt__get_svg(stbtt_fontinfo *info)
{
	stbtt_uint32 t;
	if (info->svg < 0) {
		t = stbtt__find_table(info->data, info->fontstart, "SVG ");
		if (t) {
			stbtt_uint32 offset = ttULONG(info->data + t + 2);
			info->svg = t + offset;
		} else {
			info->svg = 0;
		}
	}
	return info->svg;
}

static int stbtt_InitFont_internal(stbtt_fontinfo *info, unsigned char *data, int fontstart)
{
	stbtt_uint32 cmap, t;
	stbtt_int32 i,numTables;

	info->data = data;
	info->fontstart = fontstart;
	info->cff = stbtt__new_buf(NULL, 0);

	cmap = stbtt__find_table(data, fontstart, "cmap");       // required
	info->loca = stbtt__find_table(data, fontstart, "loca"); // required
	info->head = stbtt__find_table(data, fontstart, "head"); // required
	info->glyf = stbtt__find_table(data, fontstart, "glyf"); // required
	info->hhea = stbtt__find_table(data, fontstart, "hhea"); // required
	info->hmtx = stbtt__find_table(data, fontstart, "hmtx"); // required
	info->kern = stbtt__find_table(data, fontstart, "kern"); // not required
	info->gpos = stbtt__find_table(data, fontstart, "GPOS"); // not required

	if (!cmap || !info->head || !info->hhea || !info->hmtx) {
		df("initfont missing required info");
		return 0;
	}
	if (info->glyf) {
		// required for truetype
		if (!info->loca) {
			df("initfont missing loca");
			return 0;
		}
	} else {
		// initialization for CFF / Type2 fonts (OTF)
		stbtt__buf b, topdict, topdictidx;
		stbtt_uint32 cstype = 2, charstrings = 0, fdarrayoff = 0, fdselectoff = 0;
		stbtt_uint32 cff;

		cff = stbtt__find_table(data, fontstart, "CFF ");
		if (!cff) {
			df("initfont missing cff");
			return 0;
		}

		info->fontdicts = stbtt__new_buf(NULL, 0);
		info->fdselect = stbtt__new_buf(NULL, 0);

		// @TODO this should use size from table (not 512MB)
		info->cff = stbtt__new_buf(data+cff, 512*1024*1024);
		b = info->cff;

		// read the header
		stbtt__buf_skip(&b, 2);
		stbtt__buf_seek(&b, stbtt__buf_get8(&b)); // hdrsize

		// @TODO the name INDEX could list multiple fonts,
		// but we just use the first one.
		stbtt__cff_get_index(&b);  // name INDEX
		topdictidx = stbtt__cff_get_index(&b);
		topdict = stbtt__cff_index_get(topdictidx, 0);
		stbtt__cff_get_index(&b);  // string INDEX
		info->gsubrs = stbtt__cff_get_index(&b);

		stbtt__dict_get_ints(&topdict, 17, 1, &charstrings);
		stbtt__dict_get_ints(&topdict, 0x100 | 6, 1, &cstype);
		stbtt__dict_get_ints(&topdict, 0x100 | 36, 1, &fdarrayoff);
		stbtt__dict_get_ints(&topdict, 0x100 | 37, 1, &fdselectoff);
		info->subrs = stbtt__get_subrs(b, topdict);

		// we only support Type 2 charstrings
		if (cstype != 2) {
			df("initfont cstype %u", cstype);
			return 0;
		}
		if (charstrings == 0) {
			df("initfont charstrings 0");
			return 0;
		}

		if (fdarrayoff) {
			// looks like a CID font
			if (!fdselectoff) {
				df("initdont fdselectoff 0");
				return 0;
			}
			stbtt__buf_seek(&b, fdarrayoff);
			info->fontdicts = stbtt__cff_get_index(&b);
			info->fdselect = stbtt__buf_range(&b, fdselectoff, b.size-fdselectoff);
		}

		stbtt__buf_seek(&b, charstrings);
		info->charstrings = stbtt__cff_get_index(&b);
	}

	t = stbtt__find_table(data, fontstart, "maxp");
	if (t)
		info->numGlyphs = ttUSHORT(data+t+4);
	else
		info->numGlyphs = 0xffff;

	info->svg = -1;

	// find a cmap encoding table we understand *now* to avoid searching
	// later. (todo: could make this installable)
	// the same regardless of glyph.
	numTables = ttUSHORT(data + cmap + 2);
	info->index_map = 0;
	for (i=0; i < numTables; ++i) {
		stbtt_uint32 encoding_record = cmap + 4 + 8 * i;
		// find an encoding we understand:
		switch(ttUSHORT(data+encoding_record)) {
			case STBTT_PLATFORM_ID_MICROSOFT:
				switch (ttUSHORT(data+encoding_record+2)) {
					case STBTT_MS_EID_UNICODE_BMP:
					case STBTT_MS_EID_UNICODE_FULL:
						// MS/Unicode
						info->index_map = cmap + ttULONG(data+encoding_record+4);
						break;
				}
				break;
		  case STBTT_PLATFORM_ID_UNICODE:
				// Mac/iOS has these
				// all the encodingIDs are unicode, so we don't bother to check it
				info->index_map = cmap + ttULONG(data+encoding_record+4);
				break;
		}
	}
	if (info->index_map == 0) {
		df("initfont index_map 0");
		return 0;
	}

	info->indexToLocFormat = ttUSHORT(data+info->head + 50);
	return 1;
}

STBTT_DEF int stbtt_FindGlyphIndex(const stbtt_fontinfo *info, int unicode_codepoint)
{
	stbtt_uint8 *data = info->data;
	stbtt_uint32 index_map = info->index_map;

	stbtt_uint16 format = ttUSHORT(data + index_map + 0);
	if (format == 0) { // apple byte encoding
		stbtt_int32 bytes = ttUSHORT(data + index_map + 2);
		if (unicode_codepoint < bytes-6)
			return ttBYTE(data + index_map + 6 + unicode_codepoint);
		return 0;
	} else if (format == 6) {
		stbtt_uint32 first = ttUSHORT(data + index_map + 6);
		stbtt_uint32 count = ttUSHORT(data + index_map + 8);
		if ((stbtt_uint32) unicode_codepoint >= first && (stbtt_uint32) unicode_codepoint < first+count)
			return ttUSHORT(data + index_map + 10 + (unicode_codepoint - first)*2);
		return 0;
	} else if (format == 2) {
		STBTT_assert(0); // @TODO: high-byte mapping for japanese/chinese/korean
		return 0;
	} else if (format == 4) { // standard mapping for windows fonts: binary search collection of ranges
		stbtt_uint16 segcount = ttUSHORT(data+index_map+6) >> 1;
		stbtt_uint16 searchRange = ttUSHORT(data+index_map+8) >> 1;
		stbtt_uint16 entrySelector = ttUSHORT(data+index_map+10);
		stbtt_uint16 rangeShift = ttUSHORT(data+index_map+12) >> 1;

		// do a binary search of the segments
		stbtt_uint32 endCount = index_map + 14;
		stbtt_uint32 search = endCount;

		if (unicode_codepoint > 0xffff)
			return 0;

		// they lie from endCount .. endCount + segCount
		// but searchRange is the nearest power of two, so...
		if (unicode_codepoint >= ttUSHORT(data + search + rangeShift*2))
			search += rangeShift*2;

		// now decrement to bias correctly to find smallest
		search -= 2;
		while (entrySelector) {
			stbtt_uint16 end;
			searchRange >>= 1;
			end = ttUSHORT(data + search + searchRange*2);
			if (unicode_codepoint > end)
				search += searchRange*2;
			--entrySelector;
		}
		search += 2;

		{
			stbtt_uint16 offset, start;
			stbtt_uint16 item = (stbtt_uint16) ((search - endCount) >> 1);

			STBTT_assert(unicode_codepoint <= ttUSHORT(data + endCount + 2*item));
			start = ttUSHORT(data + index_map + 14 + segcount*2 + 2 + 2*item);
			if (unicode_codepoint < start)
				return 0;

			offset = ttUSHORT(data + index_map + 14 + segcount*6 + 2 + 2*item);
			if (offset == 0)
				return (stbtt_uint16) (unicode_codepoint + ttSHORT(data + index_map + 14 + segcount*4 + 2 + 2*item));

			return ttUSHORT(data + offset + (unicode_codepoint-start)*2 + index_map + 14 + segcount*6 + 2 + 2*item);
		}
	} else if (format == 12 || format == 13) {
		stbtt_uint32 ngroups = ttULONG(data+index_map+12);
		stbtt_int32 low,high;
		low = 0; high = (stbtt_int32)ngroups;
		// Binary search the right group.
		while (low < high) {
			stbtt_int32 mid = low + ((high-low) >> 1); // rounds down, so low <= mid < high
			stbtt_uint32 start_char = ttULONG(data+index_map+16+mid*12);
			stbtt_uint32 end_char = ttULONG(data+index_map+16+mid*12+4);
			if ((stbtt_uint32) unicode_codepoint < start_char)
				high = mid;
			else if ((stbtt_uint32) unicode_codepoint > end_char)
				low = mid+1;
			else {
				stbtt_uint32 start_glyph = ttULONG(data+index_map+16+mid*12+8);
				if (format == 12)
					return start_glyph + unicode_codepoint-start_char;
				else // format == 13
					return start_glyph;
			}
		}
		return 0; // not found
	}
	// @TODO
	STBTT_assert(0);
	return 0;
}

STBTT_DEF int stbtt_GetCodepointShape(const stbtt_fontinfo *info, int unicode_codepoint, stbtt_vertex **vertices)
{
	return stbtt_GetGlyphShape(info, stbtt_FindGlyphIndex(info, unicode_codepoint), vertices);
}

static void stbtt_setvertex(stbtt_vertex *v, stbtt_uint8 type, stbtt_int32 x, stbtt_int32 y, stbtt_int32 cx, stbtt_int32 cy)
{
	v->type = type;
	v->x = (stbtt_int16) x;
	v->y = (stbtt_int16) y;
	v->cx = (stbtt_int16) cx;
	v->cy = (stbtt_int16) cy;
}

static int stbtt__GetGlyfOffset(const stbtt_fontinfo *info, int glyph_index)
{
	int g1,g2;

	STBTT_assert(!info->cff.size);

	if (glyph_index >= info->numGlyphs) return -1; // glyph index out of range
	if (info->indexToLocFormat >= 2)    return -1; // unknown index->glyph map format

	if (info->indexToLocFormat == 0) {
		g1 = info->glyf + ttUSHORT(info->data + info->loca + glyph_index * 2) * 2;
		g2 = info->glyf + ttUSHORT(info->data + info->loca + glyph_index * 2 + 2) * 2;
	} else {
		g1 = info->glyf + ttULONG (info->data + info->loca + glyph_index * 4);
		g2 = info->glyf + ttULONG (info->data + info->loca + glyph_index * 4 + 4);
	}

	return g1==g2 ? -1 : g1; // if length is 0, return -1
}

static int stbtt__GetGlyphInfoT2(const stbtt_fontinfo *info, int glyph_index, int *x0, int *y0, int *x1, int *y1);

STBTT_DEF int stbtt_GetGlyphBox(const stbtt_fontinfo *info, int glyph_index, int *x0, int *y0, int *x1, int *y1)
{
	if (info->cff.size) {
		stbtt__GetGlyphInfoT2(info, glyph_index, x0, y0, x1, y1);
	} else {
		int g = stbtt__GetGlyfOffset(info, glyph_index);
		if (g < 0) return 0;

		if (x0) *x0 = ttSHORT(info->data + g + 2);
		if (y0) *y0 = ttSHORT(info->data + g + 4);
		if (x1) *x1 = ttSHORT(info->data + g + 6);
		if (y1) *y1 = ttSHORT(info->data + g + 8);
	}
	return 1;
}

STBTT_DEF int stbtt_GetCodepointBox(const stbtt_fontinfo *info, int codepoint, int *x0, int *y0, int *x1, int *y1)
{
	return stbtt_GetGlyphBox(info, stbtt_FindGlyphIndex(info,codepoint), x0,y0,x1,y1);
}

STBTT_DEF int stbtt_IsGlyphEmpty(const stbtt_fontinfo *info, int glyph_index)
{
	stbtt_int16 numberOfContours;
	int g;
	if (info->cff.size)
		return stbtt__GetGlyphInfoT2(info, glyph_index, NULL, NULL, NULL, NULL) == 0;
	g = stbtt__GetGlyfOffset(info, glyph_index);
	if (g < 0) return 1;
	numberOfContours = ttSHORT(info->data + g);
	return numberOfContours == 0;
}

static int stbtt__close_shape(stbtt_vertex *vertices, int num_vertices, int was_off, int start_off,
	 stbtt_int32 sx, stbtt_int32 sy, stbtt_int32 scx, stbtt_int32 scy, stbtt_int32 cx, stbtt_int32 cy)
{
	if (start_off) {
		if (was_off)
			stbtt_setvertex(&vertices[num_vertices++], STBTT_vcurve, (cx+scx)>>1, (cy+scy)>>1, cx,cy);
		stbtt_setvertex(&vertices[num_vertices++], STBTT_vcurve, sx,sy,scx,scy);
	} else {
		if (was_off)
			stbtt_setvertex(&vertices[num_vertices++], STBTT_vcurve,sx,sy,cx,cy);
		else
			stbtt_setvertex(&vertices[num_vertices++], STBTT_vline,sx,sy,0,0);
	}
	return num_vertices;
}

static int stbtt__GetGlyphShapeTT(const stbtt_fontinfo *info, int glyph_index, stbtt_vertex **pvertices)
{
	stbtt_int16 numberOfContours;
	stbtt_uint8 *endPtsOfContours;
	stbtt_uint8 *data = info->data;
	stbtt_vertex *vertices=0;
	int num_vertices=0;
	int g = stbtt__GetGlyfOffset(info, glyph_index);

	*pvertices = NULL;

	if (g < 0) return 0;

	numberOfContours = ttSHORT(data + g);

	if (numberOfContours > 0) {
		stbtt_uint8 flags=0,flagcount;
		stbtt_int32 ins, i,j=0,m,n, next_move, was_off=0, off, start_off=0;
		stbtt_int32 x,y,cx,cy,sx,sy, scx,scy;
		stbtt_uint8 *points;
		endPtsOfContours = (data + g + 10);
		ins = ttUSHORT(data + g + 10 + numberOfContours * 2);
		points = data + g + 10 + numberOfContours * 2 + 2 + ins;

		n = 1+ttUSHORT(endPtsOfContours + numberOfContours*2-2);

		m = n + 2*numberOfContours;  // a loose bound on how many vertices we might need
		vertices = (stbtt_vertex *) STBTT_malloc(m * sizeof(vertices[0]), info->userdata);
		if (vertices == 0)
			return 0;

		next_move = 0;
		flagcount=0;

		// in first pass, we load uninterpreted data into the allocated array
		// above, shifted to the end of the array so we won't overwrite it when
		// we create our final data starting from the front

		off = m - n; // starting offset for uninterpreted data, regardless of how m ends up being calculated

		// first load flags

		for (i=0; i < n; ++i) {
			if (flagcount == 0) {
				flags = *points++;
				if (flags & 8)
					flagcount = *points++;
			} else
				--flagcount;
			vertices[off+i].type = flags;
		}

		// now load x coordinates
		x=0;
		for (i=0; i < n; ++i) {
			flags = vertices[off+i].type;
			if (flags & 2) {
				stbtt_int16 dx = *points++;
				x += (flags & 16) ? dx : -dx; // ???
			} else {
				if (!(flags & 16)) {
					x = x + (stbtt_int16) (points[0]*256 + points[1]);
					points += 2;
				}
			}
			vertices[off+i].x = (stbtt_int16) x;
		}

		// now load y coordinates
		y=0;
		for (i=0; i < n; ++i) {
			flags = vertices[off+i].type;
			if (flags & 4) {
				stbtt_int16 dy = *points++;
				y += (flags & 32) ? dy : -dy; // ???
			} else {
				if (!(flags & 32)) {
					y = y + (stbtt_int16) (points[0]*256 + points[1]);
					points += 2;
				}
			}
			vertices[off+i].y = (stbtt_int16) y;
		}

		// now convert them to our format
		num_vertices=0;
		sx = sy = cx = cy = scx = scy = 0;
		for (i=0; i < n; ++i) {
			flags = vertices[off+i].type;
			x     = (stbtt_int16) vertices[off+i].x;
			y     = (stbtt_int16) vertices[off+i].y;

			if (next_move == i) {
				if (i != 0)
					num_vertices = stbtt__close_shape(vertices, num_vertices, was_off, start_off, sx,sy,scx,scy,cx,cy);

				// now start the new one
				start_off = !(flags & 1);
				if (start_off) {
					// if we start off with an off-curve point, then when we need to find a point on the curve
					// where we can start, and we need to save some state for when we wraparound.
					scx = x;
					scy = y;
					if (!(vertices[off+i+1].type & 1)) {
						// next point is also a curve point, so interpolate an on-point curve
						sx = (x + (stbtt_int32) vertices[off+i+1].x) >> 1;
						sy = (y + (stbtt_int32) vertices[off+i+1].y) >> 1;
					} else {
						// otherwise just use the next point as our start point
						sx = (stbtt_int32) vertices[off+i+1].x;
						sy = (stbtt_int32) vertices[off+i+1].y;
						++i; // we're using point i+1 as the starting point, so skip it
					}
				} else {
					sx = x;
					sy = y;
				}
				stbtt_setvertex(&vertices[num_vertices++], STBTT_vmove,sx,sy,0,0);
				was_off = 0;
				next_move = 1 + ttUSHORT(endPtsOfContours+j*2);
				++j;
			} else {
				if (!(flags & 1)) { // if it's a curve
					if (was_off) // two off-curve control points in a row means interpolate an on-curve midpoint
						stbtt_setvertex(&vertices[num_vertices++], STBTT_vcurve, (cx+x)>>1, (cy+y)>>1, cx, cy);
					cx = x;
					cy = y;
					was_off = 1;
				} else {
					if (was_off)
						stbtt_setvertex(&vertices[num_vertices++], STBTT_vcurve, x,y, cx, cy);
					else
						stbtt_setvertex(&vertices[num_vertices++], STBTT_vline, x,y,0,0);
					was_off = 0;
				}
			}
		}
		num_vertices = stbtt__close_shape(vertices, num_vertices, was_off, start_off, sx,sy,scx,scy,cx,cy);
	} else if (numberOfContours < 0) {
		// Compound shapes.
		int more = 1;
		stbtt_uint8 *comp = data + g + 10;
		num_vertices = 0;
		vertices = 0;
		while (more) {
			stbtt_uint16 flags, gidx;
			int comp_num_verts = 0, i;
			stbtt_vertex *comp_verts = 0, *tmp = 0;
			float mtx[6] = {1,0,0,1,0,0}, m, n;

			flags = ttSHORT(comp); comp+=2;
			gidx = ttSHORT(comp); comp+=2;

			if (flags & 2) { // XY values
				if (flags & 1) { // shorts
					mtx[4] = ttSHORT(comp); comp+=2;
					mtx[5] = ttSHORT(comp); comp+=2;
				} else {
					mtx[4] = ttCHAR(comp); comp+=1;
					mtx[5] = ttCHAR(comp); comp+=1;
				}
			}
			else {
				// @TODO handle matching point
				STBTT_assert(0);
			}
			if (flags & (1<<3)) { // WE_HAVE_A_SCALE
				mtx[0] = mtx[3] = ttSHORT(comp)/16384.0f; comp+=2;
				mtx[1] = mtx[2] = 0;
			} else if (flags & (1<<6)) { // WE_HAVE_AN_X_AND_YSCALE
				mtx[0] = ttSHORT(comp)/16384.0f; comp+=2;
				mtx[1] = mtx[2] = 0;
				mtx[3] = ttSHORT(comp)/16384.0f; comp+=2;
			} else if (flags & (1<<7)) { // WE_HAVE_A_TWO_BY_TWO
				mtx[0] = ttSHORT(comp)/16384.0f; comp+=2;
				mtx[1] = ttSHORT(comp)/16384.0f; comp+=2;
				mtx[2] = ttSHORT(comp)/16384.0f; comp+=2;
				mtx[3] = ttSHORT(comp)/16384.0f; comp+=2;
			}

			// Find transformation scales.
			m = (float) STBTT_sqrt(mtx[0]*mtx[0] + mtx[1]*mtx[1]);
			n = (float) STBTT_sqrt(mtx[2]*mtx[2] + mtx[3]*mtx[3]);

			// Get indexed glyph.
			comp_num_verts = stbtt_GetGlyphShape(info, gidx, &comp_verts);
			if (comp_num_verts > 0) {
				// Transform vertices.
				for (i = 0; i < comp_num_verts; ++i) {
					stbtt_vertex* v = &comp_verts[i];
					stbtt_vertex_type x,y;
					x=v->x; y=v->y;
					v->x = (stbtt_vertex_type)(m * (mtx[0]*x + mtx[2]*y + mtx[4]));
					v->y = (stbtt_vertex_type)(n * (mtx[1]*x + mtx[3]*y + mtx[5]));
					x=v->cx; y=v->cy;
					v->cx = (stbtt_vertex_type)(m * (mtx[0]*x + mtx[2]*y + mtx[4]));
					v->cy = (stbtt_vertex_type)(n * (mtx[1]*x + mtx[3]*y + mtx[5]));
				}
				// Append vertices.
				tmp = (stbtt_vertex*)STBTT_malloc((num_vertices+comp_num_verts)*sizeof(stbtt_vertex), info->userdata);
				if (!tmp) {
					if (vertices) STBTT_free(vertices, info->userdata);
					if (comp_verts) STBTT_free(comp_verts, info->userdata);
					return 0;
				}
				if (num_vertices > 0) STBTT_memcpy(tmp, vertices, num_vertices*sizeof(stbtt_vertex));
				STBTT_memcpy(tmp+num_vertices, comp_verts, comp_num_verts*sizeof(stbtt_vertex));
				if (vertices) STBTT_free(vertices, info->userdata);
				vertices = tmp;
				STBTT_free(comp_verts, info->userdata);
				num_vertices += comp_num_verts;
			}
			// More components ?
			more = flags & (1<<5);
		}
	} else {
		// numberOfCounters == 0, do nothing
	}

	*pvertices = vertices;
	return num_vertices;
}

typedef struct
{
	int bounds;
	int started;
	float first_x, first_y;
	float x, y;
	stbtt_int32 min_x, max_x, min_y, max_y;

	stbtt_vertex *pvertices;
	int num_vertices;
} stbtt__csctx;

#define STBTT__CSCTX_INIT(bounds) {bounds,0, 0,0, 0,0, 0,0,0,0, NULL, 0}

static void stbtt__track_vertex(stbtt__csctx *c, stbtt_int32 x, stbtt_int32 y)
{
	if (x > c->max_x || !c->started) c->max_x = x;
	if (y > c->max_y || !c->started) c->max_y = y;
	if (x < c->min_x || !c->started) c->min_x = x;
	if (y < c->min_y || !c->started) c->min_y = y;
	c->started = 1;
}

static void stbtt__csctx_v(stbtt__csctx *c, stbtt_uint8 type, stbtt_int32 x, stbtt_int32 y, stbtt_int32 cx, stbtt_int32 cy, stbtt_int32 cx1, stbtt_int32 cy1)
{
	if (c->bounds) {
		stbtt__track_vertex(c, x, y);
		if (type == STBTT_vcubic) {
			stbtt__track_vertex(c, cx, cy);
			stbtt__track_vertex(c, cx1, cy1);
		}
	} else {
		stbtt_setvertex(&c->pvertices[c->num_vertices], type, x, y, cx, cy);
		c->pvertices[c->num_vertices].cx1 = (stbtt_int16) cx1;
		c->pvertices[c->num_vertices].cy1 = (stbtt_int16) cy1;
	}
	c->num_vertices++;
}

static void stbtt__csctx_close_shape(stbtt__csctx *ctx)
{
	if (ctx->first_x != ctx->x || ctx->first_y != ctx->y)
		stbtt__csctx_v(ctx, STBTT_vline, (int)ctx->first_x, (int)ctx->first_y, 0, 0, 0, 0);
}

static void stbtt__csctx_rmove_to(stbtt__csctx *ctx, float dx, float dy)
{
	stbtt__csctx_close_shape(ctx);
	ctx->first_x = ctx->x = ctx->x + dx;
	ctx->first_y = ctx->y = ctx->y + dy;
	stbtt__csctx_v(ctx, STBTT_vmove, (int)ctx->x, (int)ctx->y, 0, 0, 0, 0);
}

static void stbtt__csctx_rline_to(stbtt__csctx *ctx, float dx, float dy)
{
	ctx->x += dx;
	ctx->y += dy;
	stbtt__csctx_v(ctx, STBTT_vline, (int)ctx->x, (int)ctx->y, 0, 0, 0, 0);
}

static void stbtt__csctx_rccurve_to(stbtt__csctx *ctx, float dx1, float dy1, float dx2, float dy2, float dx3, float dy3)
{
	float cx1 = ctx->x + dx1;
	float cy1 = ctx->y + dy1;
	float cx2 = cx1 + dx2;
	float cy2 = cy1 + dy2;
	ctx->x = cx2 + dx3;
	ctx->y = cy2 + dy3;
	stbtt__csctx_v(ctx, STBTT_vcubic, (int)ctx->x, (int)ctx->y, (int)cx1, (int)cy1, (int)cx2, (int)cy2);
}

static stbtt__buf stbtt__get_subr(stbtt__buf idx, int n)
{
	int count = stbtt__cff_index_count(&idx);
	int bias = 107;
	if (count >= 33900)
		bias = 32768;
	else if (count >= 1240)
		bias = 1131;
	n += bias;
	if (n < 0 || n >= count)
		return stbtt__new_buf(NULL, 0);
	return stbtt__cff_index_get(idx, n);
}

static stbtt__buf stbtt__cid_get_glyph_subrs(const stbtt_fontinfo *info, int glyph_index)
{
	stbtt__buf fdselect = info->fdselect;
	int nranges, start, end, v, fmt, fdselector = -1, i;

	stbtt__buf_seek(&fdselect, 0);
	fmt = stbtt__buf_get8(&fdselect);
	if (fmt == 0) {
		// untested
		stbtt__buf_skip(&fdselect, glyph_index);
		fdselector = stbtt__buf_get8(&fdselect);
	} else if (fmt == 3) {
		nranges = stbtt__buf_get16(&fdselect);
		start = stbtt__buf_get16(&fdselect);
		for (i = 0; i < nranges; i++) {
			v = stbtt__buf_get8(&fdselect);
			end = stbtt__buf_get16(&fdselect);
			if (glyph_index >= start && glyph_index < end) {
				fdselector = v;
				break;
			}
			start = end;
		}
	}
	if (fdselector == -1) stbtt__new_buf(NULL, 0);
	return stbtt__get_subrs(info->cff, stbtt__cff_index_get(info->fontdicts, fdselector));
}

static int stbtt__run_charstring(const stbtt_fontinfo *info, int glyph_index, stbtt__csctx *c)
{
	int in_header = 1, maskbits = 0, subr_stack_height = 0, sp = 0, v, i, b0;
	int has_subrs = 0, clear_stack;
	float s[48];
	stbtt__buf subr_stack[10], subrs = info->subrs, b;
	float f;

#define STBTT__CSERR(s) (0)

	// this currently ignores the initial width value, which isn't needed if we have hmtx
	b = stbtt__cff_index_get(info->charstrings, glyph_index);
	while (b.cursor < b.size) {
		i = 0;
		clear_stack = 1;
		b0 = stbtt__buf_get8(&b);
		switch (b0) {
		// @TODO implement hinting
		case 0x13: // hintmask
		case 0x14: // cntrmask
			if (in_header)
				maskbits += (sp / 2); // implicit "vstem"
			in_header = 0;
			stbtt__buf_skip(&b, (maskbits + 7) / 8);
			break;

		case 0x01: // hstem
		case 0x03: // vstem
		case 0x12: // hstemhm
		case 0x17: // vstemhm
			maskbits += (sp / 2);
			break;

		case 0x15: // rmoveto
			in_header = 0;
			if (sp < 2) return STBTT__CSERR("rmoveto stack");
			stbtt__csctx_rmove_to(c, s[sp-2], s[sp-1]);
			break;
		case 0x04: // vmoveto
			in_header = 0;
			if (sp < 1) return STBTT__CSERR("vmoveto stack");
			stbtt__csctx_rmove_to(c, 0, s[sp-1]);
			break;
		case 0x16: // hmoveto
			in_header = 0;
			if (sp < 1) return STBTT__CSERR("hmoveto stack");
			stbtt__csctx_rmove_to(c, s[sp-1], 0);
			break;

		case 0x05: // rlineto
			if (sp < 2) return STBTT__CSERR("rlineto stack");
			for (; i + 1 < sp; i += 2)
				stbtt__csctx_rline_to(c, s[i], s[i+1]);
			break;

		// hlineto/vlineto and vhcurveto/hvcurveto alternate horizontal and vertical
		// starting from a different place.

		case 0x07: // vlineto
			if (sp < 1) return STBTT__CSERR("vlineto stack");
			goto vlineto;
		case 0x06: // hlineto
			if (sp < 1) return STBTT__CSERR("hlineto stack");
			for (;;) {
				if (i >= sp) break;
				stbtt__csctx_rline_to(c, s[i], 0);
				i++;
		vlineto:
				if (i >= sp) break;
				stbtt__csctx_rline_to(c, 0, s[i]);
				i++;
			}
			break;

		case 0x1F: // hvcurveto
			if (sp < 4) return STBTT__CSERR("hvcurveto stack");
			goto hvcurveto;
		case 0x1E: // vhcurveto
			if (sp < 4) return STBTT__CSERR("vhcurveto stack");
			for (;;) {
				if (i + 3 >= sp) break;
				stbtt__csctx_rccurve_to(c, 0, s[i], s[i+1], s[i+2], s[i+3], (sp - i == 5) ? s[i + 4] : 0.0f);
				i += 4;
		hvcurveto:
				if (i + 3 >= sp) break;
				stbtt__csctx_rccurve_to(c, s[i], 0, s[i+1], s[i+2], (sp - i == 5) ? s[i+4] : 0.0f, s[i+3]);
				i += 4;
			}
			break;

		case 0x08: // rrcurveto
			if (sp < 6) return STBTT__CSERR("rcurveline stack");
			for (; i + 5 < sp; i += 6)
				stbtt__csctx_rccurve_to(c, s[i], s[i+1], s[i+2], s[i+3], s[i+4], s[i+5]);
			break;

		case 0x18: // rcurveline
			if (sp < 8) return STBTT__CSERR("rcurveline stack");
			for (; i + 5 < sp - 2; i += 6)
				stbtt__csctx_rccurve_to(c, s[i], s[i+1], s[i+2], s[i+3], s[i+4], s[i+5]);
			if (i + 1 >= sp) return STBTT__CSERR("rcurveline stack");
			stbtt__csctx_rline_to(c, s[i], s[i+1]);
			break;

		case 0x19: // rlinecurve
			if (sp < 8) return STBTT__CSERR("rlinecurve stack");
			for (; i + 1 < sp - 6; i += 2)
				stbtt__csctx_rline_to(c, s[i], s[i+1]);
			if (i + 5 >= sp) return STBTT__CSERR("rlinecurve stack");
			stbtt__csctx_rccurve_to(c, s[i], s[i+1], s[i+2], s[i+3], s[i+4], s[i+5]);
			break;

		case 0x1A: // vvcurveto
		case 0x1B: // hhcurveto
			if (sp < 4) return STBTT__CSERR("(vv|hh)curveto stack");
			f = 0.0;
			if (sp & 1) { f = s[i]; i++; }
			for (; i + 3 < sp; i += 4) {
				if (b0 == 0x1B)
					stbtt__csctx_rccurve_to(c, s[i], f, s[i+1], s[i+2], s[i+3], 0.0);
				else
					stbtt__csctx_rccurve_to(c, f, s[i], s[i+1], s[i+2], 0.0, s[i+3]);
				f = 0.0;
			}
			break;

		case 0x0A: // callsubr
			if (!has_subrs) {
				if (info->fdselect.size)
					subrs = stbtt__cid_get_glyph_subrs(info, glyph_index);
				has_subrs = 1;
			}
			// fallthrough
		case 0x1D: // callgsubr
			if (sp < 1) return STBTT__CSERR("call(g|)subr stack");
			v = (int) s[--sp];
			if (subr_stack_height >= 10) return STBTT__CSERR("recursion limit");
			subr_stack[subr_stack_height++] = b;
			b = stbtt__get_subr(b0 == 0x0A ? subrs : info->gsubrs, v);
			if (b.size == 0) return STBTT__CSERR("subr not found");
			b.cursor = 0;
			clear_stack = 0;
			break;

		case 0x0B: // return
			if (subr_stack_height <= 0) return STBTT__CSERR("return outside subr");
			b = subr_stack[--subr_stack_height];
			clear_stack = 0;
			break;

		case 0x0E: // endchar
			stbtt__csctx_close_shape(c);
			return 1;

		case 0x0C: { // two-byte escape
			float dx1, dx2, dx3, dx4, dx5, dx6, dy1, dy2, dy3, dy4, dy5, dy6;
			float dx, dy;
			int b1 = stbtt__buf_get8(&b);
			switch (b1) {
			// @TODO These "flex" implementations ignore the flex-depth and resolution,
			// and always draw beziers.
			case 0x22: // hflex
				if (sp < 7) return STBTT__CSERR("hflex stack");
				dx1 = s[0];
				dx2 = s[1];
				dy2 = s[2];
				dx3 = s[3];
				dx4 = s[4];
				dx5 = s[5];
				dx6 = s[6];
				stbtt__csctx_rccurve_to(c, dx1, 0, dx2, dy2, dx3, 0);
				stbtt__csctx_rccurve_to(c, dx4, 0, dx5, -dy2, dx6, 0);
				break;

			case 0x23: // flex
				if (sp < 13) return STBTT__CSERR("flex stack");
				dx1 = s[0];
				dy1 = s[1];
				dx2 = s[2];
				dy2 = s[3];
				dx3 = s[4];
				dy3 = s[5];
				dx4 = s[6];
				dy4 = s[7];
				dx5 = s[8];
				dy5 = s[9];
				dx6 = s[10];
				dy6 = s[11];
				//fd is s[12]
				stbtt__csctx_rccurve_to(c, dx1, dy1, dx2, dy2, dx3, dy3);
				stbtt__csctx_rccurve_to(c, dx4, dy4, dx5, dy5, dx6, dy6);
				break;

			case 0x24: // hflex1
				if (sp < 9) return STBTT__CSERR("hflex1 stack");
				dx1 = s[0];
				dy1 = s[1];
				dx2 = s[2];
				dy2 = s[3];
				dx3 = s[4];
				dx4 = s[5];
				dx5 = s[6];
				dy5 = s[7];
				dx6 = s[8];
				stbtt__csctx_rccurve_to(c, dx1, dy1, dx2, dy2, dx3, 0);
				stbtt__csctx_rccurve_to(c, dx4, 0, dx5, dy5, dx6, -(dy1+dy2+dy5));
				break;

			case 0x25: // flex1
				if (sp < 11) return STBTT__CSERR("flex1 stack");
				dx1 = s[0];
				dy1 = s[1];
				dx2 = s[2];
				dy2 = s[3];
				dx3 = s[4];
				dy3 = s[5];
				dx4 = s[6];
				dy4 = s[7];
				dx5 = s[8];
				dy5 = s[9];
				dx6 = dy6 = s[10];
				dx = dx1+dx2+dx3+dx4+dx5;
				dy = dy1+dy2+dy3+dy4+dy5;
				if (STBTT_fabs(dx) > STBTT_fabs(dy))
					dy6 = -dy;
				else
					dx6 = -dx;
				stbtt__csctx_rccurve_to(c, dx1, dy1, dx2, dy2, dx3, dy3);
				stbtt__csctx_rccurve_to(c, dx4, dy4, dx5, dy5, dx6, dy6);
				break;

			default:
				return STBTT__CSERR("unimplemented");
			}
		} break;

		default:
			if (b0 != 255 && b0 != 28 && (b0 < 32 || b0 > 254))
				return STBTT__CSERR("reserved operator");

			// push immediate
			if (b0 == 255) {
				f = (float)(stbtt_int32)stbtt__buf_get32(&b) / 0x10000;
			} else {
				stbtt__buf_skip(&b, -1);
				f = (float)(stbtt_int16)stbtt__cff_int(&b);
			}
			if (sp >= 48) return STBTT__CSERR("push stack overflow");
			s[sp++] = f;
			clear_stack = 0;
			break;
		}
		if (clear_stack) sp = 0;
	}
	return STBTT__CSERR("no endchar");

#undef STBTT__CSERR
}

static int stbtt__GetGlyphShapeT2(const stbtt_fontinfo *info, int glyph_index, stbtt_vertex **pvertices)
{
	// runs the charstring twice, once to count and once to output (to avoid realloc)
	stbtt__csctx count_ctx = STBTT__CSCTX_INIT(1);
	stbtt__csctx output_ctx = STBTT__CSCTX_INIT(0);
	if (stbtt__run_charstring(info, glyph_index, &count_ctx)) {
		*pvertices = (stbtt_vertex*)STBTT_malloc(count_ctx.num_vertices*sizeof(stbtt_vertex), info->userdata);
		output_ctx.pvertices = *pvertices;
		if (stbtt__run_charstring(info, glyph_index, &output_ctx)) {
			STBTT_assert(output_ctx.num_vertices == count_ctx.num_vertices);
			return output_ctx.num_vertices;
		}
	}
	*pvertices = NULL;
	return 0;
}

static int stbtt__GetGlyphInfoT2(const stbtt_fontinfo *info, int glyph_index, int *x0, int *y0, int *x1, int *y1)
{
	stbtt__csctx c = STBTT__CSCTX_INIT(1);
	int r = stbtt__run_charstring(info, glyph_index, &c);
	if (x0)  *x0 = r ? c.min_x : 0;
	if (y0)  *y0 = r ? c.min_y : 0;
	if (x1)  *x1 = r ? c.max_x : 0;
	if (y1)  *y1 = r ? c.max_y : 0;
	return r ? c.num_vertices : 0;
}

STBTT_DEF int stbtt_GetGlyphShape(const stbtt_fontinfo *info, int glyph_index, stbtt_vertex **pvertices)
{
	if (!info->cff.size)
		return stbtt__GetGlyphShapeTT(info, glyph_index, pvertices);
	else
		return stbtt__GetGlyphShapeT2(info, glyph_index, pvertices);
}

STBTT_DEF void stbtt_GetGlyphHMetrics(const stbtt_fontinfo *info, int glyph_index, int *advanceWidth, int *leftSideBearing)
{
	stbtt_uint16 numOfLongHorMetrics = ttUSHORT(info->data+info->hhea + 34);
	if (glyph_index < numOfLongHorMetrics) {
		if (advanceWidth)     *advanceWidth    = ttSHORT(info->data + info->hmtx + 4*glyph_index);
		if (leftSideBearing)  *leftSideBearing = ttSHORT(info->data + info->hmtx + 4*glyph_index + 2);
	} else {
		if (advanceWidth)     *advanceWidth    = ttSHORT(info->data + info->hmtx + 4*(numOfLongHorMetrics-1));
		if (leftSideBearing)  *leftSideBearing = ttSHORT(info->data + info->hmtx + 4*numOfLongHorMetrics + 2*(glyph_index - numOfLongHorMetrics));
	}
}

STBTT_DEF int  stbtt_GetKerningTableLength(const stbtt_fontinfo *info)
{
	stbtt_uint8 *data = info->data + info->kern;

	// we only look at the first table. it must be 'horizontal' and format 0.
	if (!info->kern)
		return 0;
	if (ttUSHORT(data+2) < 1) // number of tables, need at least 1
		return 0;
	if (ttUSHORT(data+8) != 1) // horizontal flag must be set in format
		return 0;

	return ttUSHORT(data+10);
}

STBTT_DEF int stbtt_GetKerningTable(const stbtt_fontinfo *info, stbtt_kerningentry* table, int table_length)
{
	stbtt_uint8 *data = info->data + info->kern;
	int k, length;

	// we only look at the first table. it must be 'horizontal' and format 0.
	if (!info->kern)
		return 0;
	if (ttUSHORT(data+2) < 1) // number of tables, need at least 1
		return 0;
	if (ttUSHORT(data+8) != 1) // horizontal flag must be set in format
		return 0;

	length = ttUSHORT(data+10);
	if (table_length < length)
		length = table_length;

	for (k = 0; k < length; k++)
	{
		table[k].glyph1 = ttUSHORT(data+18+(k*6));
		table[k].glyph2 = ttUSHORT(data+20+(k*6));
		table[k].advance = ttSHORT(data+22+(k*6));
	}

	return length;
}

static int  stbtt__GetGlyphKernInfoAdvance(const stbtt_fontinfo *info, int glyph1, int glyph2)
{
	stbtt_uint8 *data = info->data + info->kern;
	stbtt_uint32 needle, straw;
	int l, r, m;

	// we only look at the first table. it must be 'horizontal' and format 0.
	if (!info->kern)
		return 0;
	if (ttUSHORT(data+2) < 1) // number of tables, need at least 1
		return 0;
	if (ttUSHORT(data+8) != 1) // horizontal flag must be set in format
		return 0;

	l = 0;
	r = ttUSHORT(data+10) - 1;
	needle = glyph1 << 16 | glyph2;
	while (l <= r) {
		m = (l + r) >> 1;
		straw = ttULONG(data+18+(m*6)); // note: unaligned read
		if (needle < straw)
			r = m - 1;
		else if (needle > straw)
			l = m + 1;
		else
			return ttSHORT(data+22+(m*6));
	}
	return 0;
}

static stbtt_int32  stbtt__GetCoverageIndex(stbtt_uint8 *coverageTable, int glyph)
{
	 stbtt_uint16 coverageFormat = ttUSHORT(coverageTable);
	 switch(coverageFormat) {
		  case 1: {
				stbtt_uint16 glyphCount = ttUSHORT(coverageTable + 2);

				// Binary search.
				stbtt_int32 l=0, r=glyphCount-1, m;
				int straw, needle=glyph;
				while (l <= r) {
					 stbtt_uint8 *glyphArray = coverageTable + 4;
					 stbtt_uint16 glyphID;
					 m = (l + r) >> 1;
					 glyphID = ttUSHORT(glyphArray + 2 * m);
					 straw = glyphID;
					 if (needle < straw)
						  r = m - 1;
					 else if (needle > straw)
						  l = m + 1;
					 else {
							return m;
					 }
				}
		  } break;

		  case 2: {
				stbtt_uint16 rangeCount = ttUSHORT(coverageTable + 2);
				stbtt_uint8 *rangeArray = coverageTable + 4;

				// Binary search.
				stbtt_int32 l=0, r=rangeCount-1, m;
				int strawStart, strawEnd, needle=glyph;
				while (l <= r) {
					 stbtt_uint8 *rangeRecord;
					 m = (l + r) >> 1;
					 rangeRecord = rangeArray + 6 * m;
					 strawStart = ttUSHORT(rangeRecord);
					 strawEnd = ttUSHORT(rangeRecord + 2);
					 if (needle < strawStart)
						  r = m - 1;
					 else if (needle > strawEnd)
						  l = m + 1;
					 else {
						  stbtt_uint16 startCoverageIndex = ttUSHORT(rangeRecord + 4);
						  return startCoverageIndex + glyph - strawStart;
					 }
				}
		  } break;

		  default: {
				// There are no other cases.
				STBTT_assert(0);
		  } break;
	 }

	 return -1;
}

static stbtt_int32  stbtt__GetGlyphClass(stbtt_uint8 *classDefTable, int glyph)
{
	 stbtt_uint16 classDefFormat = ttUSHORT(classDefTable);
	 switch(classDefFormat)
	 {
		  case 1: {
				stbtt_uint16 startGlyphID = ttUSHORT(classDefTable + 2);
				stbtt_uint16 glyphCount = ttUSHORT(classDefTable + 4);
				stbtt_uint8 *classDef1ValueArray = classDefTable + 6;

				if (glyph >= startGlyphID && glyph < startGlyphID + glyphCount)
					 return (stbtt_int32)ttUSHORT(classDef1ValueArray + 2 * (glyph - startGlyphID));

				classDefTable = classDef1ValueArray + 2 * glyphCount;
		  } break;

		  case 2: {
				stbtt_uint16 classRangeCount = ttUSHORT(classDefTable + 2);
				stbtt_uint8 *classRangeRecords = classDefTable + 4;

				// Binary search.
				stbtt_int32 l=0, r=classRangeCount-1, m;
				int strawStart, strawEnd, needle=glyph;
				while (l <= r) {
					 stbtt_uint8 *classRangeRecord;
					 m = (l + r) >> 1;
					 classRangeRecord = classRangeRecords + 6 * m;
					 strawStart = ttUSHORT(classRangeRecord);
					 strawEnd = ttUSHORT(classRangeRecord + 2);
					 if (needle < strawStart)
						  r = m - 1;
					 else if (needle > strawEnd)
						  l = m + 1;
					 else
						  return (stbtt_int32)ttUSHORT(classRangeRecord + 4);
				}

				classDefTable = classRangeRecords + 6 * classRangeCount;
		  } break;

		  default: {
				// There are no other cases.
				STBTT_assert(0);
		  } break;
	 }

	 return -1;
}

// Define to STBTT_assert(x) if you want to break on unimplemented formats.
#define STBTT_GPOS_TODO_assert(x)

static stbtt_int32  stbtt__GetGlyphGPOSInfoAdvance(const stbtt_fontinfo *info, int glyph1, int glyph2)
{
	 stbtt_uint16 lookupListOffset;
	 stbtt_uint8 *lookupList;
	 stbtt_uint16 lookupCount;
	 stbtt_uint8 *data;
	 stbtt_int32 i;

	 if (!info->gpos) return 0;

	 data = info->data + info->gpos;

	 if (ttUSHORT(data+0) != 1) return 0; // Major version 1
	 if (ttUSHORT(data+2) != 0) return 0; // Minor version 0

	 lookupListOffset = ttUSHORT(data+8);
	 lookupList = data + lookupListOffset;
	 lookupCount = ttUSHORT(lookupList);

	 for (i=0; i<lookupCount; ++i) {
		  stbtt_uint16 lookupOffset = ttUSHORT(lookupList + 2 + 2 * i);
		  stbtt_uint8 *lookupTable = lookupList + lookupOffset;

		  stbtt_uint16 lookupType = ttUSHORT(lookupTable);
		  stbtt_uint16 subTableCount = ttUSHORT(lookupTable + 4);
		  stbtt_uint8 *subTableOffsets = lookupTable + 6;
		  switch(lookupType) {
				case 2: { // Pair Adjustment Positioning Subtable
					 stbtt_int32 sti;
					 for (sti=0; sti<subTableCount; sti++) {
						  stbtt_uint16 subtableOffset = ttUSHORT(subTableOffsets + 2 * sti);
						  stbtt_uint8 *table = lookupTable + subtableOffset;
						  stbtt_uint16 posFormat = ttUSHORT(table);
						  stbtt_uint16 coverageOffset = ttUSHORT(table + 2);
						  stbtt_int32 coverageIndex = stbtt__GetCoverageIndex(table + coverageOffset, glyph1);
						  if (coverageIndex == -1) continue;

						  switch (posFormat) {
								case 1: {
									 stbtt_int32 l, r, m;
									 int straw, needle;
									 stbtt_uint16 valueFormat1 = ttUSHORT(table + 4);
									 stbtt_uint16 valueFormat2 = ttUSHORT(table + 6);
									 stbtt_int32 valueRecordPairSizeInBytes = 2;
									 stbtt_uint16 pairSetCount = ttUSHORT(table + 8);
									 stbtt_uint16 pairPosOffset = ttUSHORT(table + 10 + 2 * coverageIndex);
									 stbtt_uint8 *pairValueTable = table + pairPosOffset;
									 stbtt_uint16 pairValueCount = ttUSHORT(pairValueTable);
									 stbtt_uint8 *pairValueArray = pairValueTable + 2;
									 // TODO: Support more formats.
									 STBTT_GPOS_TODO_assert(valueFormat1 == 4);
									 if (valueFormat1 != 4) return 0;
									 STBTT_GPOS_TODO_assert(valueFormat2 == 0);
									 if (valueFormat2 != 0) return 0;

									 STBTT_assert(coverageIndex < pairSetCount);
									 STBTT__NOTUSED(pairSetCount);

									 needle=glyph2;
									 r=pairValueCount-1;
									 l=0;

									 // Binary search.
									 while (l <= r) {
										  stbtt_uint16 secondGlyph;
										  stbtt_uint8 *pairValue;
										  m = (l + r) >> 1;
										  pairValue = pairValueArray + (2 + valueRecordPairSizeInBytes) * m;
										  secondGlyph = ttUSHORT(pairValue);
										  straw = secondGlyph;
										  if (needle < straw)
												r = m - 1;
										  else if (needle > straw)
												l = m + 1;
										  else {
												stbtt_int16 xAdvance = ttSHORT(pairValue + 2);
												return xAdvance;
										  }
									 }
								} break;

								case 2: {
									 stbtt_uint16 valueFormat1 = ttUSHORT(table + 4);
									 stbtt_uint16 valueFormat2 = ttUSHORT(table + 6);

									 stbtt_uint16 classDef1Offset = ttUSHORT(table + 8);
									 stbtt_uint16 classDef2Offset = ttUSHORT(table + 10);
									 int glyph1class = stbtt__GetGlyphClass(table + classDef1Offset, glyph1);
									 int glyph2class = stbtt__GetGlyphClass(table + classDef2Offset, glyph2);

									 stbtt_uint16 class1Count = ttUSHORT(table + 12);
									 stbtt_uint16 class2Count = ttUSHORT(table + 14);
									 STBTT_assert(glyph1class < class1Count);
									 STBTT_assert(glyph2class < class2Count);

									 // TODO: Support more formats.
									 STBTT_GPOS_TODO_assert(valueFormat1 == 4);
									 if (valueFormat1 != 4) return 0;
									 STBTT_GPOS_TODO_assert(valueFormat2 == 0);
									 if (valueFormat2 != 0) return 0;

									 if (glyph1class >= 0 && glyph1class < class1Count && glyph2class >= 0 && glyph2class < class2Count) {
										  stbtt_uint8 *class1Records = table + 16;
										  stbtt_uint8 *class2Records = class1Records + 2 * (glyph1class * class2Count);
										  stbtt_int16 xAdvance = ttSHORT(class2Records + 2 * glyph2class);
										  return xAdvance;
									 }
								} break;

								default: {
									 // There are no other cases.
									 STBTT_assert(0);
									 break;
								};
						  }
					 }
					 break;
				};

				default:
					 // TODO: Implement other stuff.
					 break;
		  }
	 }

	 return 0;
}

STBTT_DEF int  stbtt_GetGlyphKernAdvance(const stbtt_fontinfo *info, int g1, int g2)
{
	int xAdvance = 0;

	if (info->gpos)
		xAdvance += stbtt__GetGlyphGPOSInfoAdvance(info, g1, g2);
	else if (info->kern)
		xAdvance += stbtt__GetGlyphKernInfoAdvance(info, g1, g2);

	return xAdvance;
}

STBTT_DEF int  stbtt_GetCodepointKernAdvance(const stbtt_fontinfo *info, int ch1, int ch2)
{
	if (!info->kern && !info->gpos) // if no kerning table, don't waste time looking up both codepoint->glyphs
		return 0;
	return stbtt_GetGlyphKernAdvance(info, stbtt_FindGlyphIndex(info,ch1), stbtt_FindGlyphIndex(info,ch2));
}

STBTT_DEF void stbtt_GetCodepointHMetrics(const stbtt_fontinfo *info, int codepoint, int *advanceWidth, int *leftSideBearing)
{
	stbtt_GetGlyphHMetrics(info, stbtt_FindGlyphIndex(info,codepoint), advanceWidth, leftSideBearing);
}

STBTT_DEF void stbtt_GetFontVMetrics(const stbtt_fontinfo *info, int *ascent, int *descent, int *lineGap)
{
	if (ascent ) *ascent  = ttSHORT(info->data+info->hhea + 4);
	if (descent) *descent = ttSHORT(info->data+info->hhea + 6);
	if (lineGap) *lineGap = ttSHORT(info->data+info->hhea + 8);
}

STBTT_DEF int  stbtt_GetFontVMetricsOS2(const stbtt_fontinfo *info, int *typoAscent, int *typoDescent, int *typoLineGap)
{
	int tab = stbtt__find_table(info->data, info->fontstart, "OS/2");
	if (!tab)
		return 0;
	if (typoAscent ) *typoAscent  = ttSHORT(info->data+tab + 68);
	if (typoDescent) *typoDescent = ttSHORT(info->data+tab + 70);
	if (typoLineGap) *typoLineGap = ttSHORT(info->data+tab + 72);
	return 1;
}

STBTT_DEF void stbtt_GetFontBoundingBox(const stbtt_fontinfo *info, int *x0, int *y0, int *x1, int *y1)
{
	*x0 = ttSHORT(info->data + info->head + 36);
	*y0 = ttSHORT(info->data + info->head + 38);
	*x1 = ttSHORT(info->data + info->head + 40);
	*y1 = ttSHORT(info->data + info->head + 42);
}

STBTT_DEF float stbtt_ScaleForPixelHeight(const stbtt_fontinfo *info, float height)
{
	int fheight = ttSHORT(info->data + info->hhea + 4) - ttSHORT(info->data + info->hhea + 6);
	return (float) height / fheight;
}

STBTT_DEF float stbtt_ScaleForMappingEmToPixels(const stbtt_fontinfo *info, float pixels)
{
	int unitsPerEm = ttUSHORT(info->data + info->head + 18);
	return pixels / unitsPerEm;
}

STBTT_DEF void stbtt_FreeShape(const stbtt_fontinfo *info, stbtt_vertex *v)
{
	STBTT_free(v, info->userdata);
}

STBTT_DEF stbtt_uint8 *stbtt_FindSVGDoc(const stbtt_fontinfo *info, int gl)
{
	int i;
	stbtt_uint8 *data = info->data;
	stbtt_uint8 *svg_doc_list = data + stbtt__get_svg((stbtt_fontinfo *) info);

	int numEntries = ttUSHORT(svg_doc_list);
	stbtt_uint8 *svg_docs = svg_doc_list + 2;

	for(i=0; i<numEntries; i++) {
		stbtt_uint8 *svg_doc = svg_docs + (12 * i);
		if ((gl >= ttUSHORT(svg_doc)) && (gl <= ttUSHORT(svg_doc + 2)))
			return svg_doc;
	}
	return 0;
}

STBTT_DEF int stbtt_GetGlyphSVG(const stbtt_fontinfo *info, int gl, const char **svg)
{
	stbtt_uint8 *data = info->data;
	stbtt_uint8 *svg_doc;

	if (info->svg == 0)
		return 0;

	svg_doc = stbtt_FindSVGDoc(info, gl);
	if (svg_doc != NULL) {
		*svg = (char *) data + info->svg + ttULONG(svg_doc + 4);
		return ttULONG(svg_doc + 8);
	} else {
		return 0;
	}
}

STBTT_DEF int stbtt_GetCodepointSVG(const stbtt_fontinfo *info, int unicode_codepoint, const char **svg)
{
	return stbtt_GetGlyphSVG(info, stbtt_FindGlyphIndex(info, unicode_codepoint), svg);
}

//////////////////////////////////////////////////////////////////////////////
//
// antialiasing software rasterizer
//
STBTT_DEF void stbtt_GetGlyphBitmapBoxSubpixel(const stbtt_fontinfo *font, int glyph, float scale_x, float scale_y,float shift_x, float shift_y, int *ix0, int *iy0, int *ix1, int *iy1)
{
	int x0=0,y0=0,x1,y1; // =0 suppresses compiler warning
	if (!stbtt_GetGlyphBox(font, glyph, &x0,&y0,&x1,&y1)) {
		// e.g. space character
		if (ix0) *ix0 = 0;
		if (iy0) *iy0 = 0;
		if (ix1) *ix1 = 0;
		if (iy1) *iy1 = 0;
	} else {
		// move to integral bboxes (treating pixels as little squares, what pixels get touched)?
			//fprintf(stderr, "GlyphBox %d,%d %d,%d x(%f,%f)\n", x0,y0,x1,y1,scale_x,scale_y);
		if (ix0) *ix0 = STBTT_ifloor( x0 * scale_x + shift_x);
		if (iy0) *iy0 = STBTT_ifloor(-y1 * scale_y + shift_y);
		if (ix1) *ix1 = STBTT_iceil ( x1 * scale_x + shift_x);
		if (iy1) *iy1 = STBTT_iceil (-y0 * scale_y + shift_y);
	}
}

STBTT_DEF void stbtt_GetGlyphBitmapBox(const stbtt_fontinfo *font, int glyph, float scale_x, float scale_y, int *ix0, int *iy0, int *ix1, int *iy1)
{
	stbtt_GetGlyphBitmapBoxSubpixel(font, glyph, scale_x, scale_y,0.0f,0.0f, ix0, iy0, ix1, iy1);
}

STBTT_DEF void stbtt_GetCodepointBitmapBoxSubpixel(const stbtt_fontinfo *font, int codepoint, float scale_x, float scale_y, float shift_x, float shift_y, int *ix0, int *iy0, int *ix1, int *iy1)
{
	stbtt_GetGlyphBitmapBoxSubpixel(font, stbtt_FindGlyphIndex(font,codepoint), scale_x, scale_y,shift_x,shift_y, ix0,iy0,ix1,iy1);
}

STBTT_DEF void stbtt_GetCodepointBitmapBox(const stbtt_fontinfo *font, int codepoint, float scale_x, float scale_y, int *ix0, int *iy0, int *ix1, int *iy1)
{
	stbtt_GetCodepointBitmapBoxSubpixel(font, codepoint, scale_x, scale_y,0.0f,0.0f, ix0,iy0,ix1,iy1);
}

//////////////////////////////////////////////////////////////////////////////
//
//  Rasterizer
typedef struct stbtt__hheap_chunk
{
	struct stbtt__hheap_chunk *next;
} stbtt__hheap_chunk;

typedef struct stbtt__hheap
{
	struct stbtt__hheap_chunk *head;
	void   *first_free;
	int    num_remaining_in_head_chunk;
} stbtt__hheap;

static void *stbtt__hheap_alloc(stbtt__hheap *hh, size_t size, void *userdata)
{
	if (hh->first_free) {
		void *p = hh->first_free;
		hh->first_free = * (void **) p;
		return p;
	} else {
		if (hh->num_remaining_in_head_chunk == 0) {
			int count = (size < 32 ? 2000 : size < 128 ? 800 : 100);
			stbtt__hheap_chunk *c = (stbtt__hheap_chunk *) STBTT_malloc(sizeof(stbtt__hheap_chunk) + size * count, userdata);
			if (c == NULL)
				return NULL;
			c->next = hh->head;
			hh->head = c;
			hh->num_remaining_in_head_chunk = count;
		}
		--hh->num_remaining_in_head_chunk;
		return (char *) (hh->head) + sizeof(stbtt__hheap_chunk) + size * hh->num_remaining_in_head_chunk;
	}
}

static void stbtt__hheap_free(stbtt__hheap *hh, void *p)
{
	*(void **) p = hh->first_free;
	hh->first_free = p;
}

static void stbtt__hheap_cleanup(stbtt__hheap *hh, void *userdata)
{
	stbtt__hheap_chunk *c = hh->head;
	while (c) {
		stbtt__hheap_chunk *n = c->next;
		STBTT_free(c, userdata);
		c = n;
	}
}

typedef struct stbtt__edge {
	float x0,y0, x1,y1;
	int invert;
} stbtt__edge;


typedef struct stbtt__active_edge
{
	struct stbtt__active_edge *next;
	#if STBTT_RASTERIZER_VERSION==1
	int x,dx;
	float ey;
	int direction;
	#elif STBTT_RASTERIZER_VERSION==2
	float fx,fdx,fdy;
	float direction;
	float sy;
	float ey;
	#else
	#error "Unrecognized value of STBTT_RASTERIZER_VERSION"
	#endif
} stbtt__active_edge;

#if STBTT_RASTERIZER_VERSION == 1
#define STBTT_FIXSHIFT   10
#define STBTT_FIX        (1 << STBTT_FIXSHIFT)
#define STBTT_FIXMASK    (STBTT_FIX-1)

static stbtt__active_edge *stbtt__new_active(stbtt__hheap *hh, stbtt__edge *e, int off_x, float start_point, void *userdata)
{
	stbtt__active_edge *z = (stbtt__active_edge *) stbtt__hheap_alloc(hh, sizeof(*z), userdata);
	float dxdy = (e->x1 - e->x0) / (e->y1 - e->y0);
	STBTT_assert(z != NULL);
	if (!z) return z;

	// round dx down to avoid overshooting
	if (dxdy < 0)
		z->dx = -STBTT_ifloor(STBTT_FIX * -dxdy);
	else
		z->dx = STBTT_ifloor(STBTT_FIX * dxdy);

	z->x = STBTT_ifloor(STBTT_FIX * e->x0 + z->dx * (start_point - e->y0)); // use z->dx so when we offset later it's by the same amount
	z->x -= off_x * STBTT_FIX;

	z->ey = e->y1;
	z->next = 0;
	z->direction = e->invert ? 1 : -1;
	return z;
}
#elif STBTT_RASTERIZER_VERSION == 2
static stbtt__active_edge *stbtt__new_active(stbtt__hheap *hh, stbtt__edge *e, int off_x, float start_point, void *userdata)
{
	stbtt__active_edge *z = (stbtt__active_edge *) stbtt__hheap_alloc(hh, sizeof(*z), userdata);
	float dxdy = (e->x1 - e->x0) / (e->y1 - e->y0);
	STBTT_assert(z != NULL);
	//STBTT_assert(e->y0 <= start_point);
	if (!z) return z;
	z->fdx = dxdy;
	z->fdy = dxdy != 0.0f ? (1.0f/dxdy) : 0.0f;
	z->fx = e->x0 + dxdy * (start_point - e->y0);
	z->fx -= off_x;
	z->direction = e->invert ? 1.0f : -1.0f;
	z->sy = e->y0;
	z->ey = e->y1;
	z->next = 0;
	return z;
}
#else
#error "Unrecognized value of STBTT_RASTERIZER_VERSION"
#endif

#if STBTT_RASTERIZER_VERSION == 1
// note: this routine clips fills that extend off the edges... ideally this
// wouldn't happen, but it could happen if the truetype glyph bounding boxes
// are wrong, or if the user supplies a too-small bitmap
static void stbtt__fill_active_edges(unsigned char *scanline, int len, stbtt__active_edge *e, int max_weight)
{
	// non-zero winding fill
	int x0=0, w=0;

	while (e) {
		if (w == 0) {
			// if we're currently at zero, we need to record the edge start point
			x0 = e->x; w += e->direction;
		} else {
			int x1 = e->x; w += e->direction;
			// if we went to zero, we need to draw
			if (w == 0) {
				int i = x0 >> STBTT_FIXSHIFT;
				int j = x1 >> STBTT_FIXSHIFT;

				if (i < len && j >= 0) {
					if (i == j) {
						// x0,x1 are the same pixel, so compute combined coverage
						scanline[i] = scanline[i] + (stbtt_uint8) ((x1 - x0) * max_weight >> STBTT_FIXSHIFT);
					} else {
						if (i >= 0) // add antialiasing for x0
							scanline[i] = scanline[i] + (stbtt_uint8) (((STBTT_FIX - (x0 & STBTT_FIXMASK)) * max_weight) >> STBTT_FIXSHIFT);
						else
							i = -1; // clip

						if (j < len) // add antialiasing for x1
							scanline[j] = scanline[j] + (stbtt_uint8) (((x1 & STBTT_FIXMASK) * max_weight) >> STBTT_FIXSHIFT);
						else
							j = len; // clip

						for (++i; i < j; ++i) // fill pixels between x0 and x1
							scanline[i] = scanline[i] + (stbtt_uint8) max_weight;
					}
				}
			}
		}

		e = e->next;
	}
}

static void stbtt__rasterize_sorted_edges(stbtt__bitmap *result, stbtt__edge *e, int n, int vsubsample, int off_x, int off_y, void *userdata)
{
	stbtt__hheap hh = { 0, 0, 0 };
	stbtt__active_edge *active = NULL;
	int y,j=0;
	int max_weight = (255 / vsubsample);  // weight per vertical scanline
	int s; // vertical subsample index
	unsigned char scanline_data[512], *scanline;

	if (result->w > 512)
		scanline = (unsigned char *) STBTT_malloc(result->w, userdata);
	else
		scanline = scanline_data;

	y = off_y * vsubsample;
	e[n].y0 = (off_y + result->h) * (float) vsubsample + 1;

	while (j < result->h) {
		STBTT_memset(scanline, 0, result->w);
		for (s=0; s < vsubsample; ++s) {
			// find center of pixel for this scanline
			float scan_y = y + 0.5f;
			stbtt__active_edge **step = &active;

			// update all active edges;
			// remove all active edges that terminate before the center of this scanline
			while (*step) {
				stbtt__active_edge * z = *step;
				if (z->ey <= scan_y) {
					*step = z->next; // delete from list
					STBTT_assert(z->direction);
					z->direction = 0;
					stbtt__hheap_free(&hh, z);
				} else {
					z->x += z->dx; // advance to position for current scanline
					step = &((*step)->next); // advance through list
				}
			}

			// resort the list if needed
			for(;;) {
				int changed=0;
				step = &active;
				while (*step && (*step)->next) {
					if ((*step)->x > (*step)->next->x) {
						stbtt__active_edge *t = *step;
						stbtt__active_edge *q = t->next;

						t->next = q->next;
						q->next = t;
						*step = q;
						changed = 1;
					}
					step = &(*step)->next;
				}
				if (!changed) break;
			}

			// insert all edges that start before the center of this scanline -- omit ones that also end on this scanline
			while (e->y0 <= scan_y) {
				if (e->y1 > scan_y) {
					stbtt__active_edge *z = stbtt__new_active(&hh, e, off_x, scan_y, userdata);
					if (z != NULL) {
						// find insertion point
						if (active == NULL)
							active = z;
						else if (z->x < active->x) {
							// insert at front
							z->next = active;
							active = z;
						} else {
							// find thing to insert AFTER
							stbtt__active_edge *p = active;
							while (p->next && p->next->x < z->x)
								p = p->next;
							// at this point, p->next->x is NOT < z->x
							z->next = p->next;
							p->next = z;
						}
					}
				}
				++e;
			}

			// now process all active edges in XOR fashion
			if (active)
				stbtt__fill_active_edges(scanline, result->w, active, max_weight);

			++y;
		}
		STBTT_memcpy(result->pixels + j * result->stride, scanline, result->w);
		++j;
	}

	stbtt__hheap_cleanup(&hh, userdata);

	if (scanline != scanline_data)
		STBTT_free(scanline, userdata);
}

#elif STBTT_RASTERIZER_VERSION == 2

// the edge passed in here does not cross the vertical line at x or the vertical line at x+1
// (i.e. it has already been clipped to those)
static void stbtt__handle_clipped_edge(float *scanline, int x, stbtt__active_edge *e, float x0, float y0, float x1, float y1)
{
	if (y0 == y1) return;
	STBTT_assert(y0 < y1);
	STBTT_assert(e->sy <= e->ey);
	if (y0 > e->ey) return;
	if (y1 < e->sy) return;
	if (y0 < e->sy) {
		x0 += (x1-x0) * (e->sy - y0) / (y1-y0);
		y0 = e->sy;
	}
	if (y1 > e->ey) {
		x1 += (x1-x0) * (e->ey - y1) / (y1-y0);
		y1 = e->ey;
	}

	if (x0 == x)
		STBTT_assert(x1 <= x+1);
	else if (x0 == x+1)
		STBTT_assert(x1 >= x);
	else if (x0 <= x)
		STBTT_assert(x1 <= x);
	else if (x0 >= x+1)
		STBTT_assert(x1 >= x+1);
	else
		STBTT_assert(x1 >= x && x1 <= x+1);

	if (x0 <= x && x1 <= x)
		scanline[x] += e->direction * (y1-y0);
	else if (x0 >= x+1 && x1 >= x+1)
		;
	else {
		STBTT_assert(x0 >= x && x0 <= x+1 && x1 >= x && x1 <= x+1);
		scanline[x] += e->direction * (y1-y0) * (1-((x0-x)+(x1-x))/2); // coverage = 1 - average x position
	}
}

static void stbtt__fill_active_edges_new(float *scanline, float *scanline_fill, int len, stbtt__active_edge *e, float y_top)
{
	float y_bottom = y_top+1;

	while (e) {
		// brute force every pixel

		// compute intersection points with top & bottom
		STBTT_assert(e->ey >= y_top);

		if (e->fdx == 0) {
			float x0 = e->fx;
			if (x0 < len) {
				if (x0 >= 0) {
					stbtt__handle_clipped_edge(scanline,(int) x0,e, x0,y_top, x0,y_bottom);
					stbtt__handle_clipped_edge(scanline_fill-1,(int) x0+1,e, x0,y_top, x0,y_bottom);
				} else {
					stbtt__handle_clipped_edge(scanline_fill-1,0,e, x0,y_top, x0,y_bottom);
				}
			}
		} else {
			float x0 = e->fx;
			float dx = e->fdx;
			float xb = x0 + dx;
			float x_top, x_bottom;
			float sy0,sy1;
			float dy = e->fdy;
			STBTT_assert(e->sy <= y_bottom && e->ey >= y_top);

			// compute endpoints of line segment clipped to this scanline (if the
			// line segment starts on this scanline. x0 is the intersection of the
			// line with y_top, but that may be off the line segment.
			if (e->sy > y_top) {
				x_top = x0 + dx * (e->sy - y_top);
				sy0 = e->sy;
			} else {
				x_top = x0;
				sy0 = y_top;
			}
			if (e->ey < y_bottom) {
				x_bottom = x0 + dx * (e->ey - y_top);
				sy1 = e->ey;
			} else {
				x_bottom = xb;
				sy1 = y_bottom;
			}

			if (x_top >= 0 && x_bottom >= 0 && x_top < len && x_bottom < len) {
				// from here on, we don't have to range check x values

				if ((int) x_top == (int) x_bottom) {
					float height;
					// simple case, only spans one pixel
					int x = (int) x_top;
					height = sy1 - sy0;
					STBTT_assert(x >= 0 && x < len);
					scanline[x] += e->direction * (1-((x_top - x) + (x_bottom-x))/2)  * height;
					scanline_fill[x] += e->direction * height; // everything right of this pixel is filled
				} else {
					int x,x1,x2;
					float y_crossing, step, sign, area;
					// covers 2+ pixels
					if (x_top > x_bottom) {
						// flip scanline vertically; signed area is the same
						float t;
						sy0 = y_bottom - (sy0 - y_top);
						sy1 = y_bottom - (sy1 - y_top);
						t = sy0, sy0 = sy1, sy1 = t;
						t = x_bottom, x_bottom = x_top, x_top = t;
						dx = -dx;
						dy = -dy;
						t = x0, x0 = xb, xb = t;
					}

					x1 = (int) x_top;
					x2 = (int) x_bottom;
					// compute intersection with y axis at x1+1
					y_crossing = (x1+1 - x0) * dy + y_top;

					sign = e->direction;
					// area of the rectangle covered from y0..y_crossing
					area = sign * (y_crossing-sy0);
					// area of the triangle (x_top,y0), (x+1,y0), (x+1,y_crossing)
					scanline[x1] += area * (1-((x_top - x1)+(x1+1-x1))/2);

					step = sign * dy;
					for (x = x1+1; x < x2; ++x) {
						scanline[x] += area + step/2;
						area += step;
					}
					y_crossing += dy * (x2 - (x1+1));

					STBTT_assert(STBTT_fabs(area) <= 1.01f);

					scanline[x2] += area + sign * (1-((x2-x2)+(x_bottom-x2))/2) * (sy1-y_crossing);

					scanline_fill[x2] += sign * (sy1-sy0);
				}
			} else {
				// if edge goes outside of box we're drawing, we require
				// clipping logic. since this does not match the intended use
				// of this library, we use a different, very slow brute
				// force implementation
				int x;
				for (x=0; x < len; ++x) {
					// cases:
					//
					// there can be up to two intersections with the pixel. any intersection
					// with left or right edges can be handled by splitting into two (or three)
					// regions. intersections with top & bottom do not necessitate case-wise logic.
					//
					// the old way of doing this found the intersections with the left & right edges,
					// then used some simple logic to produce up to three segments in sorted order
					// from top-to-bottom. however, this had a problem: if an x edge was epsilon
					// across the x border, then the corresponding y position might not be distinct
					// from the other y segment, and it might ignored as an empty segment. to avoid
					// that, we need to explicitly produce segments based on x positions.

					// rename variables to clearly-defined pairs
					float y0 = y_top;
					float x1 = (float) (x);
					float x2 = (float) (x+1);
					float x3 = xb;
					float y3 = y_bottom;

					// x = e->x + e->dx * (y-y_top)
					// (y-y_top) = (x - e->x) / e->dx
					// y = (x - e->x) / e->dx + y_top
					float y1 = (x - x0) / dx + y_top;
					float y2 = (x+1 - x0) / dx + y_top;

					if (x0 < x1 && x3 > x2) {         // three segments descending down-right
						stbtt__handle_clipped_edge(scanline,x,e, x0,y0, x1,y1);
						stbtt__handle_clipped_edge(scanline,x,e, x1,y1, x2,y2);
						stbtt__handle_clipped_edge(scanline,x,e, x2,y2, x3,y3);
					} else if (x3 < x1 && x0 > x2) {  // three segments descending down-left
						stbtt__handle_clipped_edge(scanline,x,e, x0,y0, x2,y2);
						stbtt__handle_clipped_edge(scanline,x,e, x2,y2, x1,y1);
						stbtt__handle_clipped_edge(scanline,x,e, x1,y1, x3,y3);
					} else if (x0 < x1 && x3 > x1) {  // two segments across x, down-right
						stbtt__handle_clipped_edge(scanline,x,e, x0,y0, x1,y1);
						stbtt__handle_clipped_edge(scanline,x,e, x1,y1, x3,y3);
					} else if (x3 < x1 && x0 > x1) {  // two segments across x, down-left
						stbtt__handle_clipped_edge(scanline,x,e, x0,y0, x1,y1);
						stbtt__handle_clipped_edge(scanline,x,e, x1,y1, x3,y3);
					} else if (x0 < x2 && x3 > x2) {  // two segments across x+1, down-right
						stbtt__handle_clipped_edge(scanline,x,e, x0,y0, x2,y2);
						stbtt__handle_clipped_edge(scanline,x,e, x2,y2, x3,y3);
					} else if (x3 < x2 && x0 > x2) {  // two segments across x+1, down-left
						stbtt__handle_clipped_edge(scanline,x,e, x0,y0, x2,y2);
						stbtt__handle_clipped_edge(scanline,x,e, x2,y2, x3,y3);
					} else {  // one segment
						stbtt__handle_clipped_edge(scanline,x,e, x0,y0, x3,y3);
					}
				}
			}
		}
		e = e->next;
	}
}

// directly AA rasterize edges w/o supersampling
static void stbtt__rasterize_sorted_edges(stbtt__bitmap *result, stbtt__edge *e, int n, int vsubsample, int off_x, int off_y, void *userdata)
{
	stbtt__hheap hh = { 0, 0, 0 };
	stbtt__active_edge *active = NULL;
	int y,j=0, i;
	float scanline_data[129], *scanline, *scanline2;

	STBTT__NOTUSED(vsubsample);

	if (result->w > 64)
		scanline = (float *) STBTT_malloc((result->w*2+1) * sizeof(float), userdata);
	else
		scanline = scanline_data;

	scanline2 = scanline + result->w;

	y = off_y;
	e[n].y0 = (float) (off_y + result->h) + 1;

	while (j < result->h) {
		// find center of pixel for this scanline
		float scan_y_top    = y + 0.0f;
		float scan_y_bottom = y + 1.0f;
		stbtt__active_edge **step = &active;

		STBTT_memset(scanline , 0, result->w*sizeof(scanline[0]));
		STBTT_memset(scanline2, 0, (result->w+1)*sizeof(scanline[0]));

		// update all active edges;
		// remove all active edges that terminate before the top of this scanline
		while (*step) {
			stbtt__active_edge * z = *step;
			if (z->ey <= scan_y_top) {
				*step = z->next; // delete from list
				STBTT_assert(z->direction);
				z->direction = 0;
				stbtt__hheap_free(&hh, z);
			} else {
				step = &((*step)->next); // advance through list
			}
		}

		// insert all edges that start before the bottom of this scanline
		while (e->y0 <= scan_y_bottom) {
			if (e->y0 != e->y1) {
				stbtt__active_edge *z = stbtt__new_active(&hh, e, off_x, scan_y_top, userdata);
				if (z != NULL) {
					if (j == 0 && off_y != 0) {
						if (z->ey < scan_y_top) {
							// this can happen due to subpixel positioning and some kind of fp rounding error i think
							z->ey = scan_y_top;
						}
					}
					STBTT_assert(z->ey >= scan_y_top); // if we get really unlucky a tiny bit of an edge can be out of bounds
					// insert at front
					z->next = active;
					active = z;
				}
			}
			++e;
		}

		// now process all active edges
		if (active)
			stbtt__fill_active_edges_new(scanline, scanline2+1, result->w, active, scan_y_top);

		{
			float sum = 0;
			for (i=0; i < result->w; ++i) {
				float k;
				int m;
				sum += scanline2[i];
				k = scanline[i] + sum;
				k = (float) STBTT_fabs(k)*255 + 0.5f;
				m = (int) k;
				if (m > 255) m = 255;
				result->pixels[j*result->stride + i] = (unsigned char) m;
			}
		}
		// advance all the edges
		step = &active;
		while (*step) {
			stbtt__active_edge *z = *step;
			z->fx += z->fdx; // advance to position for current scanline
			step = &((*step)->next); // advance through list
		}

		++y;
		++j;
	}

	stbtt__hheap_cleanup(&hh, userdata);

	if (scanline != scanline_data)
		STBTT_free(scanline, userdata);
}
#else
#error "Unrecognized value of STBTT_RASTERIZER_VERSION"
#endif

#define STBTT__COMPARE(a,b)  ((a)->y0 < (b)->y0)

static void stbtt__sort_edges_ins_sort(stbtt__edge *p, int n)
{
	int i,j;
	for (i=1; i < n; ++i) {
		stbtt__edge t = p[i], *a = &t;
		j = i;
		while (j > 0) {
			stbtt__edge *b = &p[j-1];
			int c = STBTT__COMPARE(a,b);
			if (!c) break;
			p[j] = p[j-1];
			--j;
		}
		if (i != j)
			p[j] = t;
	}
}

static void stbtt__sort_edges_quicksort(stbtt__edge *p, int n)
{
	/* threshold for transitioning to insertion sort */
	while (n > 12) {
		stbtt__edge t;
		int c01,c12,c,m,i,j;

		/* compute median of three */
		m = n >> 1;
		c01 = STBTT__COMPARE(&p[0],&p[m]);
		c12 = STBTT__COMPARE(&p[m],&p[n-1]);
		/* if 0 >= mid >= end, or 0 < mid < end, then use mid */
		if (c01 != c12) {
			/* otherwise, we'll need to swap something else to middle */
			int z;
			c = STBTT__COMPARE(&p[0],&p[n-1]);
			/* 0>mid && mid<n:  0>n => n; 0<n => 0 */
			/* 0<mid && mid>n:  0>n => 0; 0<n => n */
			z = (c == c12) ? 0 : n-1;
			t = p[z];
			p[z] = p[m];
			p[m] = t;
		}
		/* now p[m] is the median-of-three */
		/* swap it to the beginning so it won't move around */
		t = p[0];
		p[0] = p[m];
		p[m] = t;

		/* partition loop */
		i=1;
		j=n-1;
		for(;;) {
			/* handling of equality is crucial here */
			/* for sentinels & efficiency with duplicates */
			for (;;++i) {
				if (!STBTT__COMPARE(&p[i], &p[0])) break;
			}
			for (;;--j) {
				if (!STBTT__COMPARE(&p[0], &p[j])) break;
			}
			/* make sure we haven't crossed */
			if (i >= j) break;
			t = p[i];
			p[i] = p[j];
			p[j] = t;

			++i;
			--j;
		}
		/* recurse on smaller side, iterate on larger */
		if (j < (n-i)) {
			stbtt__sort_edges_quicksort(p,j);
			p = p+i;
			n = n-i;
		} else {
			stbtt__sort_edges_quicksort(p+i, n-i);
			n = j;
		}
	}
}

static void stbtt__sort_edges(stbtt__edge *p, int n)
{
	stbtt__sort_edges_quicksort(p, n);
	stbtt__sort_edges_ins_sort(p, n);
}

typedef struct
{
	float x,y;
} stbtt__point;

static void stbtt__rasterize(stbtt__bitmap *result, stbtt__point *pts, int *wcount, int windings, float scale_x, float scale_y, float shift_x, float shift_y, int off_x, int off_y, int invert, void *userdata)
{
	float y_scale_inv = invert ? -scale_y : scale_y;
	stbtt__edge *e;
	int n,i,j,k,m;
#if STBTT_RASTERIZER_VERSION == 1
	int vsubsample = result->h < 8 ? 15 : 5;
#elif STBTT_RASTERIZER_VERSION == 2
	int vsubsample = 1;
#else
	#error "Unrecognized value of STBTT_RASTERIZER_VERSION"
#endif
	// vsubsample should divide 255 evenly; otherwise we won't reach full opacity

	// now we have to blow out the windings into explicit edge lists
	n = 0;
	for (i=0; i < windings; ++i)
		n += wcount[i];

	e = (stbtt__edge *) STBTT_malloc(sizeof(*e) * (n+1), userdata); // add an extra one as a sentinel
	if (e == 0) return;
	n = 0;

	m=0;
	for (i=0; i < windings; ++i) {
		stbtt__point *p = pts + m;
		m += wcount[i];
		j = wcount[i]-1;
		for (k=0; k < wcount[i]; j=k++) {
			int a=k,b=j;
			// skip the edge if horizontal
			if (p[j].y == p[k].y)
				continue;
			// add edge from j to k to the list
			e[n].invert = 0;
			if (invert ? p[j].y > p[k].y : p[j].y < p[k].y) {
				e[n].invert = 1;
				a=j,b=k;
			}
			e[n].x0 = p[a].x * scale_x + shift_x;
			e[n].y0 = (p[a].y * y_scale_inv + shift_y) * vsubsample;
			e[n].x1 = p[b].x * scale_x + shift_x;
			e[n].y1 = (p[b].y * y_scale_inv + shift_y) * vsubsample;
			++n;
		}
	}

	// now sort the edges by their highest point (should snap to integer, and then by x)
	//STBTT_sort(e, n, sizeof(e[0]), stbtt__edge_compare);
	stbtt__sort_edges(e, n);

	// now, traverse the scanlines and find the intersections on each scanline, use xor winding rule
	stbtt__rasterize_sorted_edges(result, e, n, vsubsample, off_x, off_y, userdata);

	STBTT_free(e, userdata);
}

static void stbtt__add_point(stbtt__point *points, int n, float x, float y)
{
	if (!points) return; // during first pass, it's unallocated
	points[n].x = x;
	points[n].y = y;
}

// tessellate until threshold p is happy... @TODO warped to compensate for non-linear stretching
static int stbtt__tesselate_curve(stbtt__point *points, int *num_points, float x0, float y0, float x1, float y1, float x2, float y2, float objspace_flatness_squared, int n)
{
	// midpoint
	float mx = (x0 + 2*x1 + x2)/4;
	float my = (y0 + 2*y1 + y2)/4;
	// versus directly drawn line
	float dx = (x0+x2)/2 - mx;
	float dy = (y0+y2)/2 - my;
	if (n > 16) // 65536 segments on one curve better be enough!
		return 1;
	if (dx*dx+dy*dy > objspace_flatness_squared) { // half-pixel error allowed... need to be smaller if AA
		stbtt__tesselate_curve(points, num_points, x0,y0, (x0+x1)/2.0f,(y0+y1)/2.0f, mx,my, objspace_flatness_squared,n+1);
		stbtt__tesselate_curve(points, num_points, mx,my, (x1+x2)/2.0f,(y1+y2)/2.0f, x2,y2, objspace_flatness_squared,n+1);
	} else {
		stbtt__add_point(points, *num_points,x2,y2);
		*num_points = *num_points+1;
	}
	return 1;
}

static void stbtt__tesselate_cubic(stbtt__point *points, int *num_points, float x0, float y0, float x1, float y1, float x2, float y2, float x3, float y3, float objspace_flatness_squared, int n)
{
	// @TODO this "flatness" calculation is just made-up nonsense that seems to work well enough
	float dx0 = x1-x0;
	float dy0 = y1-y0;
	float dx1 = x2-x1;
	float dy1 = y2-y1;
	float dx2 = x3-x2;
	float dy2 = y3-y2;
	float dx = x3-x0;
	float dy = y3-y0;
	float longlen = (float) (STBTT_sqrt(dx0*dx0+dy0*dy0)+STBTT_sqrt(dx1*dx1+dy1*dy1)+STBTT_sqrt(dx2*dx2+dy2*dy2));
	float shortlen = (float) STBTT_sqrt(dx*dx+dy*dy);
	float flatness_squared = longlen*longlen-shortlen*shortlen;

	if (n > 16) // 65536 segments on one curve better be enough!
		return;

	if (flatness_squared > objspace_flatness_squared) {
		float x01 = (x0+x1)/2;
		float y01 = (y0+y1)/2;
		float x12 = (x1+x2)/2;
		float y12 = (y1+y2)/2;
		float x23 = (x2+x3)/2;
		float y23 = (y2+y3)/2;

		float xa = (x01+x12)/2;
		float ya = (y01+y12)/2;
		float xb = (x12+x23)/2;
		float yb = (y12+y23)/2;

		float mx = (xa+xb)/2;
		float my = (ya+yb)/2;

		stbtt__tesselate_cubic(points, num_points, x0,y0, x01,y01, xa,ya, mx,my, objspace_flatness_squared,n+1);
		stbtt__tesselate_cubic(points, num_points, mx,my, xb,yb, x23,y23, x3,y3, objspace_flatness_squared,n+1);
	} else {
		stbtt__add_point(points, *num_points,x3,y3);
		*num_points = *num_points+1;
	}
}

// returns number of contours
static stbtt__point *stbtt_FlattenCurves(stbtt_vertex *vertices, int num_verts, float objspace_flatness, int **contour_lengths, int *num_contours, void *userdata)
{
	stbtt__point *points=0;
	int num_points=0;

	float objspace_flatness_squared = objspace_flatness * objspace_flatness;
	int i,n=0,start=0, pass;

	// count how many "moves" there are to get the contour count
	for (i=0; i < num_verts; ++i)
		if (vertices[i].type == STBTT_vmove)
			++n;

	*num_contours = n;
	if (n == 0) return 0;

	*contour_lengths = (int *) STBTT_malloc(sizeof(**contour_lengths) * n, userdata);

	if (*contour_lengths == 0) {
		*num_contours = 0;
		return 0;
	}

	// make two passes through the points so we don't need to realloc
	for (pass=0; pass < 2; ++pass) {
		float x=0,y=0;
		if (pass == 1) {
			points = (stbtt__point *) STBTT_malloc(num_points * sizeof(points[0]), userdata);
			if (points == NULL) goto error;
		}
		num_points = 0;
		n= -1;
		for (i=0; i < num_verts; ++i) {
			switch (vertices[i].type) {
				case STBTT_vmove:
					// start the next contour
					if (n >= 0)
						(*contour_lengths)[n] = num_points - start;
					++n;
					start = num_points;

					x = vertices[i].x, y = vertices[i].y;
					stbtt__add_point(points, num_points++, x,y);
					break;
				case STBTT_vline:
					x = vertices[i].x, y = vertices[i].y;
					stbtt__add_point(points, num_points++, x, y);
					break;
				case STBTT_vcurve:
					stbtt__tesselate_curve(points, &num_points, x,y,
													 vertices[i].cx, vertices[i].cy,
													 vertices[i].x,  vertices[i].y,
													 objspace_flatness_squared, 0);
					x = vertices[i].x, y = vertices[i].y;
					break;
				case STBTT_vcubic:
					stbtt__tesselate_cubic(points, &num_points, x,y,
													 vertices[i].cx, vertices[i].cy,
													 vertices[i].cx1, vertices[i].cy1,
													 vertices[i].x,  vertices[i].y,
													 objspace_flatness_squared, 0);
					x = vertices[i].x, y = vertices[i].y;
					break;
			}
		}
		(*contour_lengths)[n] = num_points - start;
	}

	return points;
error:
	STBTT_free(points, userdata);
	STBTT_free(*contour_lengths, userdata);
	*contour_lengths = 0;
	*num_contours = 0;
	return NULL;
}

STBTT_DEF void stbtt_Rasterize(stbtt__bitmap *result, float flatness_in_pixels, stbtt_vertex *vertices, int num_verts, float scale_x, float scale_y, float shift_x, float shift_y, int x_off, int y_off, int invert, void *userdata)
{
	float scale            = scale_x > scale_y ? scale_y : scale_x;
	int winding_count      = 0;
	int *winding_lengths   = NULL;
	stbtt__point *windings = stbtt_FlattenCurves(vertices, num_verts, flatness_in_pixels / scale, &winding_lengths, &winding_count, userdata);
	if (windings) {
		stbtt__rasterize(result, windings, winding_lengths, winding_count, scale_x, scale_y, shift_x, shift_y, x_off, y_off, invert, userdata);
		STBTT_free(winding_lengths, userdata);
		STBTT_free(windings, userdata);
	}
}

STBTT_DEF void stbtt_FreeBitmap(unsigned char *bitmap, void *userdata)
{
	STBTT_free(bitmap, userdata);
}

STBTT_DEF unsigned char *stbtt_GetGlyphBitmapSubpixel(const stbtt_fontinfo *info, float scale_x, float scale_y, float shift_x, float shift_y, int glyph, int *width, int *height, int *xoff, int *yoff)
{
	int ix0,iy0,ix1,iy1;
	stbtt__bitmap gbm;
	stbtt_vertex *vertices;
	int num_verts = stbtt_GetGlyphShape(info, glyph, &vertices);

	if (scale_x == 0) scale_x = scale_y;
	if (scale_y == 0) {
		if (scale_x == 0) {
			STBTT_free(vertices, info->userdata);
			return NULL;
		}
		scale_y = scale_x;
	}

	stbtt_GetGlyphBitmapBoxSubpixel(info, glyph, scale_x, scale_y, shift_x, shift_y, &ix0,&iy0,&ix1,&iy1);

	// now we get the size
	gbm.w = (ix1 - ix0);
	gbm.h = (iy1 - iy0);
	gbm.pixels = NULL; // in case we error

	if (width ) *width  = gbm.w;
	if (height) *height = gbm.h;
	if (xoff  ) *xoff   = ix0;
	if (yoff  ) *yoff   = iy0;

	if (gbm.w && gbm.h) {
		gbm.pixels = (unsigned char *) STBTT_malloc(gbm.w * gbm.h, info->userdata);
		if (gbm.pixels) {
			gbm.stride = gbm.w;

			stbtt_Rasterize(&gbm, 0.35f, vertices, num_verts, scale_x, scale_y, shift_x, shift_y, ix0, iy0, 1, info->userdata);
		}
	}
	STBTT_free(vertices, info->userdata);
	return gbm.pixels;
}

STBTT_DEF unsigned char *stbtt_GetGlyphBitmap(const stbtt_fontinfo *info, float scale_x, float scale_y, int glyph, int *width, int *height, int *xoff, int *yoff)
{
	return stbtt_GetGlyphBitmapSubpixel(info, scale_x, scale_y, 0.0f, 0.0f, glyph, width, height, xoff, yoff);
}

STBTT_DEF void stbtt_MakeGlyphBitmapSubpixel(const stbtt_fontinfo *info, unsigned char *output, int out_w, int out_h, int out_stride, float scale_x, float scale_y, float shift_x, float shift_y, int glyph)
{
	int ix0,iy0;
	stbtt_vertex *vertices;
	int num_verts = stbtt_GetGlyphShape(info, glyph, &vertices);
	stbtt__bitmap gbm;

	stbtt_GetGlyphBitmapBoxSubpixel(info, glyph, scale_x, scale_y, shift_x, shift_y, &ix0,&iy0,0,0);
	gbm.pixels = output;
	gbm.w = out_w;
	gbm.h = out_h;
	gbm.stride = out_stride;

	if (gbm.w && gbm.h)
		stbtt_Rasterize(&gbm, 0.35f, vertices, num_verts, scale_x, scale_y, shift_x, shift_y, ix0,iy0, 1, info->userdata);

	STBTT_free(vertices, info->userdata);
}

STBTT_DEF void stbtt_MakeGlyphBitmap(const stbtt_fontinfo *info, unsigned char *output, int out_w, int out_h, int out_stride, float scale_x, float scale_y, int glyph)
{
	stbtt_MakeGlyphBitmapSubpixel(info, output, out_w, out_h, out_stride, scale_x, scale_y, 0.0f,0.0f, glyph);
}

STBTT_DEF unsigned char *stbtt_GetCodepointBitmapSubpixel(const stbtt_fontinfo *info, float scale_x, float scale_y, float shift_x, float shift_y, int codepoint, int *width, int *height, int *xoff, int *yoff)
{
	return stbtt_GetGlyphBitmapSubpixel(info, scale_x, scale_y,shift_x,shift_y, stbtt_FindGlyphIndex(info,codepoint), width,height,xoff,yoff);
}

STBTT_DEF void stbtt_MakeCodepointBitmapSubpixelPrefilter(const stbtt_fontinfo *info, unsigned char *output, int out_w, int out_h, int out_stride, float scale_x, float scale_y, float shift_x, float shift_y, int oversample_x, int oversample_y, float *sub_x, float *sub_y, int codepoint)
{
	stbtt_MakeGlyphBitmapSubpixelPrefilter(info, output, out_w, out_h, out_stride, scale_x, scale_y, shift_x, shift_y, oversample_x, oversample_y, sub_x, sub_y, stbtt_FindGlyphIndex(info,codepoint));
}

STBTT_DEF void stbtt_MakeCodepointBitmapSubpixel(const stbtt_fontinfo *info, unsigned char *output, int out_w, int out_h, int out_stride, float scale_x, float scale_y, float shift_x, float shift_y, int codepoint)
{
	stbtt_MakeGlyphBitmapSubpixel(info, output, out_w, out_h, out_stride, scale_x, scale_y, shift_x, shift_y, stbtt_FindGlyphIndex(info,codepoint));
}

STBTT_DEF unsigned char *stbtt_GetCodepointBitmap(const stbtt_fontinfo *info, float scale_x, float scale_y, int codepoint, int *width, int *height, int *xoff, int *yoff)
{
	return stbtt_GetCodepointBitmapSubpixel(info, scale_x, scale_y, 0.0f,0.0f, codepoint, width,height,xoff,yoff);
}

STBTT_DEF void stbtt_MakeCodepointBitmap(const stbtt_fontinfo *info, unsigned char *output, int out_w, int out_h, int out_stride, float scale_x, float scale_y, int codepoint)
{
	stbtt_MakeCodepointBitmapSubpixel(info, output, out_w, out_h, out_stride, scale_x, scale_y, 0.0f,0.0f, codepoint);
}

//////////////////////////////////////////////////////////////////////////////
//
// bitmap baking
//
// This is SUPER-CRAPPY packing to keep source code small
static int stbtt_BakeFontBitmap_internal(unsigned char *data, int offset,  // font location (use offset=0 for plain .ttf)
										  float pixel_height,                     // height of font in pixels
										  unsigned char *pixels, int pw, int ph,  // bitmap to be filled in
										  int first_char, int num_chars,          // characters to bake
										  stbtt_bakedchar *chardata)
{
	float scale;
	int x,y,bottom_y, i;
	stbtt_fontinfo f;
	f.userdata = NULL;
	if (!stbtt_InitFont(&f, data, offset))
		return -1;
	STBTT_memset(pixels, 0, pw*ph); // background of 0 around pixels
	x=y=1;
	bottom_y = 1;

	scale = stbtt_ScaleForPixelHeight(&f, pixel_height);

	for (i=0; i < num_chars; ++i) {
		int advance, lsb, x0,y0,x1,y1,gw,gh;
		int g = stbtt_FindGlyphIndex(&f, first_char + i);
		stbtt_GetGlyphHMetrics(&f, g, &advance, &lsb);
		stbtt_GetGlyphBitmapBox(&f, g, scale,scale, &x0,&y0,&x1,&y1);
		gw = x1-x0;
		gh = y1-y0;
		if (x + gw + 1 >= pw)
			y = bottom_y, x = 1; // advance to next row
		if (y + gh + 1 >= ph) // check if it fits vertically AFTER potentially moving to next row
			return -i;
		STBTT_assert(x+gw < pw);
		STBTT_assert(y+gh < ph);
		stbtt_MakeGlyphBitmap(&f, pixels+x+y*pw, gw,gh,pw, scale,scale, g);
		chardata[i].x0 = (stbtt_int16) x;
		chardata[i].y0 = (stbtt_int16) y;
		chardata[i].x1 = (stbtt_int16) (x + gw);
		chardata[i].y1 = (stbtt_int16) (y + gh);
		chardata[i].xadvance = scale * advance;
		chardata[i].xoff     = (float) x0;
		chardata[i].yoff     = (float) y0;
		x = x + gw + 1;
		if (y+gh+1 > bottom_y)
			bottom_y = y+gh+1;
	}
	return bottom_y;
}

STBTT_DEF void stbtt_GetBakedQuad(const stbtt_bakedchar *chardata, int pw, int ph, int char_index, float *xpos, float *ypos, stbtt_aligned_quad *q, int opengl_fillrule)
{
	float d3d_bias = opengl_fillrule ? 0 : -0.5f;
	float ipw = 1.0f / pw, iph = 1.0f / ph;
	const stbtt_bakedchar *b = chardata + char_index;
	int round_x = STBTT_ifloor((*xpos + b->xoff) + 0.5f);
	int round_y = STBTT_ifloor((*ypos + b->yoff) + 0.5f);

	q->x0 = round_x + d3d_bias;
	q->y0 = round_y + d3d_bias;
	q->x1 = round_x + b->x1 - b->x0 + d3d_bias;
	q->y1 = round_y + b->y1 - b->y0 + d3d_bias;

	q->s0 = b->x0 * ipw;
	q->t0 = b->y0 * iph;
	q->s1 = b->x1 * ipw;
	q->t1 = b->y1 * iph;

	*xpos += b->xadvance;
}

//////////////////////////////////////////////////////////////////////////////
//
// rectangle packing replacement routines if you don't have stb_rect_pack.h
//
#ifndef STB_RECT_PACK_VERSION
typedef int stbrp_coord;

////////////////////////////////////////////////////////////////////////////////////
//                                                                                //
//                                                                                //
// COMPILER WARNING ?!?!?                                                         //
//                                                                                //
//                                                                                //
// if you get a compile warning due to these symbols being defined more than      //
// once, move #include "stb_rect_pack.h" before #include "stb_truetype.h"         //
//                                                                                //
////////////////////////////////////////////////////////////////////////////////////
typedef struct
{
	int width,height;
	int x,y,bottom_y;
} stbrp_context;
typedef struct
{
	unsigned char x;
} stbrp_node;
struct stbrp_rect
{
	stbrp_coord x,y;
	int id,w,h,was_packed;
};

static void stbrp_init_target(stbrp_context *con, int pw, int ph, stbrp_node *nodes, int num_nodes)
{
	con->width  = pw;
	con->height = ph;
	con->x = 0;
	con->y = 0;
	con->bottom_y = 0;
	STBTT__NOTUSED(nodes);
	STBTT__NOTUSED(num_nodes);
}

static void stbrp_pack_rects(stbrp_context *con, stbrp_rect *rects, int num_rects)
{
	int i;
	for (i=0; i < num_rects; ++i) {
		if (con->x + rects[i].w > con->width) {
				fprintf(stderr, "rect %d too wide\n", i);
			con->x = 0;
			con->y = con->bottom_y;
		}
		if (con->y + rects[i].h > con->height) {
				fprintf(stderr, "rect %d too tall\n", i);
			break;
				 }
		rects[i].x = con->x;
		rects[i].y = con->y;
		rects[i].was_packed = 1;
		con->x += rects[i].w;
		if (con->y + rects[i].h > con->bottom_y)
			con->bottom_y = con->y + rects[i].h;
	}
	for (   ; i < num_rects; ++i)
		rects[i].was_packed = 0;
}
#endif

//////////////////////////////////////////////////////////////////////////////
//
// bitmap baking
//
// This is SUPER-AWESOME (tm Ryan Gordon) packing using stb_rect_pack.h. If
// stb_rect_pack.h isn't available, it uses the BakeFontBitmap strategy.
STBTT_DEF int stbtt_PackBegin(stbtt_pack_context *spc, unsigned char *pixels, int pw, int ph, int stride_in_bytes, int padding, void *alloc_context)
{
	stbrp_context *context = (stbrp_context *) STBTT_malloc(sizeof(*context)            ,alloc_context);
	int            num_nodes = pw - padding;
	stbrp_node    *nodes   = (stbrp_node    *) STBTT_malloc(sizeof(*nodes  ) * num_nodes,alloc_context);

	if (context == NULL || nodes == NULL) {
		if (context != NULL) STBTT_free(context, alloc_context);
		if (nodes   != NULL) STBTT_free(nodes  , alloc_context);
		return 0;
	}

	spc->user_allocator_context = alloc_context;
	spc->width = pw;
	spc->height = ph;
	spc->pixels = pixels;
	spc->pack_info = context;
	spc->nodes = nodes;
	spc->padding = padding;
	spc->stride_in_bytes = stride_in_bytes != 0 ? stride_in_bytes : pw;
	spc->h_oversample = 1;
	spc->v_oversample = 1;
	spc->skip_missing = 0;

	stbrp_init_target(context, pw-padding, ph-padding, nodes, num_nodes);

	if (pixels)
		STBTT_memset(pixels, 0, pw*ph); // background of 0 around pixels

	return 1;
}

STBTT_DEF void stbtt_PackEnd  (stbtt_pack_context *spc)
{
	STBTT_free(spc->nodes    , spc->user_allocator_context);
	STBTT_free(spc->pack_info, spc->user_allocator_context);
}

STBTT_DEF void stbtt_PackSetOversampling(stbtt_pack_context *spc, unsigned int h_oversample, unsigned int v_oversample)
{
	STBTT_assert(h_oversample <= STBTT_MAX_OVERSAMPLE);
	STBTT_assert(v_oversample <= STBTT_MAX_OVERSAMPLE);
	if (h_oversample <= STBTT_MAX_OVERSAMPLE)
		spc->h_oversample = h_oversample;
	if (v_oversample <= STBTT_MAX_OVERSAMPLE)
		spc->v_oversample = v_oversample;
}

STBTT_DEF void stbtt_PackSetSkipMissingCodepoints(stbtt_pack_context *spc, int skip)
{
	spc->skip_missing = skip;
}

#define STBTT__OVER_MASK  (STBTT_MAX_OVERSAMPLE-1)

static void stbtt__h_prefilter(unsigned char *pixels, int w, int h, int stride_in_bytes, unsigned int kernel_width)
{
	unsigned char buffer[STBTT_MAX_OVERSAMPLE];
	int safe_w = w - kernel_width;
	int j;
	STBTT_memset(buffer, 0, STBTT_MAX_OVERSAMPLE); // suppress bogus warning from VS2013 -analyze
	for (j=0; j < h; ++j) {
		int i;
		unsigned int total;
		STBTT_memset(buffer, 0, kernel_width);

		total = 0;

		// make kernel_width a constant in common cases so compiler can optimize out the divide
		switch (kernel_width) {
			case 2:
				for (i=0; i <= safe_w; ++i) {
					total += pixels[i] - buffer[i & STBTT__OVER_MASK];
					buffer[(i+kernel_width) & STBTT__OVER_MASK] = pixels[i];
					pixels[i] = (unsigned char) (total / 2);
				}
				break;
			case 3:
				for (i=0; i <= safe_w; ++i) {
					total += pixels[i] - buffer[i & STBTT__OVER_MASK];
					buffer[(i+kernel_width) & STBTT__OVER_MASK] = pixels[i];
					pixels[i] = (unsigned char) (total / 3);
				}
				break;
			case 4:
				for (i=0; i <= safe_w; ++i) {
					total += pixels[i] - buffer[i & STBTT__OVER_MASK];
					buffer[(i+kernel_width) & STBTT__OVER_MASK] = pixels[i];
					pixels[i] = (unsigned char) (total / 4);
				}
				break;
			case 5:
				for (i=0; i <= safe_w; ++i) {
					total += pixels[i] - buffer[i & STBTT__OVER_MASK];
					buffer[(i+kernel_width) & STBTT__OVER_MASK] = pixels[i];
					pixels[i] = (unsigned char) (total / 5);
				}
				break;
			default:
				for (i=0; i <= safe_w; ++i) {
					total += pixels[i] - buffer[i & STBTT__OVER_MASK];
					buffer[(i+kernel_width) & STBTT__OVER_MASK] = pixels[i];
					pixels[i] = (unsigned char) (total / kernel_width);
				}
				break;
		}

		for (; i < w; ++i) {
			STBTT_assert(pixels[i] == 0);
			total -= buffer[i & STBTT__OVER_MASK];
			pixels[i] = (unsigned char) (total / kernel_width);
		}

		pixels += stride_in_bytes;
	}
}

static void stbtt__v_prefilter(unsigned char *pixels, int w, int h, int stride_in_bytes, unsigned int kernel_width)
{
	unsigned char buffer[STBTT_MAX_OVERSAMPLE];
	int safe_h = h - kernel_width;
	int j;
	STBTT_memset(buffer, 0, STBTT_MAX_OVERSAMPLE); // suppress bogus warning from VS2013 -analyze
	for (j=0; j < w; ++j) {
		int i;
		unsigned int total;
		STBTT_memset(buffer, 0, kernel_width);

		total = 0;

		// make kernel_width a constant in common cases so compiler can optimize out the divide
		switch (kernel_width) {
			case 2:
				for (i=0; i <= safe_h; ++i) {
					total += pixels[i*stride_in_bytes] - buffer[i & STBTT__OVER_MASK];
					buffer[(i+kernel_width) & STBTT__OVER_MASK] = pixels[i*stride_in_bytes];
					pixels[i*stride_in_bytes] = (unsigned char) (total / 2);
				}
				break;
			case 3:
				for (i=0; i <= safe_h; ++i) {
					total += pixels[i*stride_in_bytes] - buffer[i & STBTT__OVER_MASK];
					buffer[(i+kernel_width) & STBTT__OVER_MASK] = pixels[i*stride_in_bytes];
					pixels[i*stride_in_bytes] = (unsigned char) (total / 3);
				}
				break;
			case 4:
				for (i=0; i <= safe_h; ++i) {
					total += pixels[i*stride_in_bytes] - buffer[i & STBTT__OVER_MASK];
					buffer[(i+kernel_width) & STBTT__OVER_MASK] = pixels[i*stride_in_bytes];
					pixels[i*stride_in_bytes] = (unsigned char) (total / 4);
				}
				break;
			case 5:
				for (i=0; i <= safe_h; ++i) {
					total += pixels[i*stride_in_bytes] - buffer[i & STBTT__OVER_MASK];
					buffer[(i+kernel_width) & STBTT__OVER_MASK] = pixels[i*stride_in_bytes];
					pixels[i*stride_in_bytes] = (unsigned char) (total / 5);
				}
				break;
			default:
				for (i=0; i <= safe_h; ++i) {
					total += pixels[i*stride_in_bytes] - buffer[i & STBTT__OVER_MASK];
					buffer[(i+kernel_width) & STBTT__OVER_MASK] = pixels[i*stride_in_bytes];
					pixels[i*stride_in_bytes] = (unsigned char) (total / kernel_width);
				}
				break;
		}

		for (; i < h; ++i) {
			STBTT_assert(pixels[i*stride_in_bytes] == 0);
			total -= buffer[i & STBTT__OVER_MASK];
			pixels[i*stride_in_bytes] = (unsigned char) (total / kernel_width);
		}

		pixels += 1;
	}
}

static float stbtt__oversample_shift(int oversample)
{
	if (!oversample)
		return 0.0f;

	// The prefilter is a box filter of width "oversample",
	// which shifts phase by (oversample - 1)/2 pixels in
	// oversampled space. We want to shift in the opposite
	// direction to counter this.
	return (float)-(oversample - 1) / (2.0f * (float)oversample);
}

// rects array must be big enough to accommodate all characters in the given ranges
STBTT_DEF int stbtt_PackFontRangesGatherRects(stbtt_pack_context *spc, const stbtt_fontinfo *info, stbtt_pack_range *ranges, int num_ranges, stbrp_rect *rects)
{
	int i,j,k;
	int missing_glyph_added = 0;

	k=0;
	for (i=0; i < num_ranges; ++i) {
		float fh = ranges[i].font_size;
		float scale = fh > 0 ? stbtt_ScaleForPixelHeight(info, fh) : stbtt_ScaleForMappingEmToPixels(info, -fh);
		ranges[i].h_oversample = (unsigned char) spc->h_oversample;
		ranges[i].v_oversample = (unsigned char) spc->v_oversample;
		for (j=0; j < ranges[i].num_chars; ++j) {
			int x0,y0,x1,y1;
			int codepoint = ranges[i].array_of_unicode_codepoints == NULL ? ranges[i].first_unicode_codepoint_in_range + j : ranges[i].array_of_unicode_codepoints[j];
			int glyph = stbtt_FindGlyphIndex(info, codepoint);
			if (glyph == 0 && (spc->skip_missing || missing_glyph_added)) {
				rects[k].w = rects[k].h = 0;
			} else {
				stbtt_GetGlyphBitmapBoxSubpixel(info,glyph,
														  scale * spc->h_oversample,
														  scale * spc->v_oversample,
														  0,0,
														  &x0,&y0,&x1,&y1);
						//fprintf(stderr, "%c %d,%d -> %d,%d\n", codepoint, x0, y0, x1, y1);
				rects[k].w = (stbrp_coord) (x1-x0 + spc->padding + spc->h_oversample-1);
				rects[k].h = (stbrp_coord) (y1-y0 + spc->padding + spc->v_oversample-1);
						//fprintf(stderr, "%c %dx%d\n", codepoint, rects[k].w, rects[k].h);
				if (glyph == 0)
					missing_glyph_added = 1;
			}
			++k;
		}
	}

	return k;
}

STBTT_DEF void stbtt_MakeGlyphBitmapSubpixelPrefilter(const stbtt_fontinfo *info, unsigned char *output, int out_w, int out_h, int out_stride, float scale_x, float scale_y, float shift_x, float shift_y, int prefilter_x, int prefilter_y, float *sub_x, float *sub_y, int glyph)
{
	stbtt_MakeGlyphBitmapSubpixel(info,
											output,
											out_w - (prefilter_x - 1),
											out_h - (prefilter_y - 1),
											out_stride,
											scale_x,
											scale_y,
											shift_x,
											shift_y,
											glyph);

	if (prefilter_x > 1)
		stbtt__h_prefilter(output, out_w, out_h, out_stride, prefilter_x);

	if (prefilter_y > 1)
		stbtt__v_prefilter(output, out_w, out_h, out_stride, prefilter_y);

	*sub_x = stbtt__oversample_shift(prefilter_x);
	*sub_y = stbtt__oversample_shift(prefilter_y);
}

// rects array must be big enough to accommodate all characters in the given ranges
STBTT_DEF int stbtt_PackFontRangesRenderIntoRects(stbtt_pack_context *spc, const stbtt_fontinfo *info, stbtt_pack_range *ranges, int num_ranges, stbrp_rect *rects)
{
	int i,j,k, missing_glyph = -1, return_value = 1;

	// save current values
	int old_h_over = spc->h_oversample;
	int old_v_over = spc->v_oversample;

	k = 0;
	for (i=0; i < num_ranges; ++i) {
		float fh = ranges[i].font_size;
		float scale = fh > 0 ? stbtt_ScaleForPixelHeight(info, fh) : stbtt_ScaleForMappingEmToPixels(info, -fh);
		float recip_h,recip_v,sub_x,sub_y;
		spc->h_oversample = ranges[i].h_oversample;
		spc->v_oversample = ranges[i].v_oversample;
		recip_h = 1.0f / spc->h_oversample;
		recip_v = 1.0f / spc->v_oversample;
		sub_x = stbtt__oversample_shift(spc->h_oversample);
		sub_y = stbtt__oversample_shift(spc->v_oversample);
		for (j=0; j < ranges[i].num_chars; ++j) {
			stbrp_rect *r = &rects[k];
			if (r->was_packed && r->w != 0 && r->h != 0) {
				stbtt_packedchar *bc = &ranges[i].chardata_for_range[j];
				int advance, lsb, x0,y0,x1,y1;
				int codepoint = ranges[i].array_of_unicode_codepoints == NULL ? ranges[i].first_unicode_codepoint_in_range + j : ranges[i].array_of_unicode_codepoints[j];
				int glyph = stbtt_FindGlyphIndex(info, codepoint);
				stbrp_coord pad = (stbrp_coord) spc->padding;

				// pad on left and top
				r->x += pad;
				r->y += pad;
				r->w -= pad;
				r->h -= pad;
				stbtt_GetGlyphHMetrics(info, glyph, &advance, &lsb);
				stbtt_GetGlyphBitmapBox(info, glyph,
												scale * spc->h_oversample,
												scale * spc->v_oversample,
												&x0,&y0,&x1,&y1);
				stbtt_MakeGlyphBitmapSubpixel(info,
														spc->pixels + r->x + r->y*spc->stride_in_bytes,
														r->w - spc->h_oversample+1,
														r->h - spc->v_oversample+1,
														spc->stride_in_bytes,
														scale * spc->h_oversample,
														scale * spc->v_oversample,
														0,0,
														glyph);

				if (spc->h_oversample > 1)
					stbtt__h_prefilter(spc->pixels + r->x + r->y*spc->stride_in_bytes,
											 r->w, r->h, spc->stride_in_bytes,
											 spc->h_oversample);

				if (spc->v_oversample > 1)
					stbtt__v_prefilter(spc->pixels + r->x + r->y*spc->stride_in_bytes,
											 r->w, r->h, spc->stride_in_bytes,
											 spc->v_oversample);

				bc->x0       = (stbtt_int16)  r->x;
				bc->y0       = (stbtt_int16)  r->y;
				bc->x1       = (stbtt_int16) (r->x + r->w);
				bc->y1       = (stbtt_int16) (r->y + r->h);
				bc->xadvance =                scale * advance;
				bc->xoff     =       (float)  x0 * recip_h + sub_x;
				bc->yoff     =       (float)  y0 * recip_v + sub_y;
				bc->xoff2    =                (x0 + r->w) * recip_h + sub_x;
				bc->yoff2    =                (y0 + r->h) * recip_v + sub_y;

				if (glyph == 0)
					missing_glyph = j;
			} else if (spc->skip_missing) {
				return_value = 0;
			} else if (r->was_packed && r->w == 0 && r->h == 0 && missing_glyph >= 0) {
				ranges[i].chardata_for_range[j] = ranges[i].chardata_for_range[missing_glyph];
			} else {
				return_value = 0; // if any fail, report failure
			}

			++k;
		}
	}

	// restore original values
	spc->h_oversample = old_h_over;
	spc->v_oversample = old_v_over;

	return return_value;
}

STBTT_DEF void stbtt_PackFontRangesPackRects(stbtt_pack_context *spc, stbrp_rect *rects, int num_rects)
{
	stbrp_pack_rects((stbrp_context *) spc->pack_info, rects, num_rects);
}

STBTT_DEF int stbtt_PackFontRanges(stbtt_pack_context *spc, const unsigned char *fontdata, int font_index, stbtt_pack_range *ranges, int num_ranges)
{
	stbtt_fontinfo info;
	int i,j,n, return_value = 1;
	//stbrp_context *context = (stbrp_context *) spc->pack_info;
	stbrp_rect    *rects;

	// flag all characters as NOT packed
	for (i=0; i < num_ranges; ++i)
		for (j=0; j < ranges[i].num_chars; ++j)
			ranges[i].chardata_for_range[j].x0 =
			ranges[i].chardata_for_range[j].y0 =
			ranges[i].chardata_for_range[j].x1 =
			ranges[i].chardata_for_range[j].y1 = 0;

	n = 0;
	for (i=0; i < num_ranges; ++i)
		n += ranges[i].num_chars;

	rects = (stbrp_rect *) STBTT_malloc(sizeof(*rects) * n, spc->user_allocator_context);
	if (rects == NULL)
		return 0;

	info.userdata = spc->user_allocator_context;
	stbtt_InitFont(&info, fontdata, stbtt_GetFontOffsetForIndex(fontdata,font_index));

	//fputs("gathering rects\n", stderr);
	n = stbtt_PackFontRangesGatherRects(spc, &info, ranges, num_ranges, rects);

	//fputs("packing rects\n", stderr);
	stbtt_PackFontRangesPackRects(spc, rects, n);

	//fputs("rendering rects\n", stderr);
	return_value = stbtt_PackFontRangesRenderIntoRects(spc, &info, ranges, num_ranges, rects);

	STBTT_free(rects, spc->user_allocator_context);
	return return_value;
}

STBTT_DEF int stbtt_PackFontRange(stbtt_pack_context *spc, const unsigned char *fontdata, int font_index, float font_size,
				int first_unicode_codepoint_in_range, int num_chars_in_range, stbtt_packedchar *chardata_for_range)
{
	stbtt_pack_range range;
	range.first_unicode_codepoint_in_range = first_unicode_codepoint_in_range;
	range.array_of_unicode_codepoints = NULL;
	range.num_chars                   = num_chars_in_range;
	range.chardata_for_range          = chardata_for_range;
	range.font_size                   = font_size;
	return stbtt_PackFontRanges(spc, fontdata, font_index, &range, 1);
}

STBTT_DEF void stbtt_GetScaledFontVMetrics(const unsigned char *fontdata, int index, float size, float *ascent, float *descent, float *lineGap)
{
	int i_ascent, i_descent, i_lineGap;
	float scale;
	stbtt_fontinfo info;
	stbtt_InitFont(&info, fontdata, stbtt_GetFontOffsetForIndex(fontdata, index));
	scale = size > 0 ? stbtt_ScaleForPixelHeight(&info, size) : stbtt_ScaleForMappingEmToPixels(&info, -size);
	stbtt_GetFontVMetrics(&info, &i_ascent, &i_descent, &i_lineGap);
	*ascent  = (float) i_ascent  * scale;
	*descent = (float) i_descent * scale;
	*lineGap = (float) i_lineGap * scale;
}

STBTT_DEF void stbtt_GetPackedQuad(const stbtt_packedchar *chardata, int pw, int ph, int char_index, float *xpos, float *ypos, stbtt_aligned_quad *q, int align_to_integer)
{
	float ipw = 1.0f / pw, iph = 1.0f / ph;
	const stbtt_packedchar *b = chardata + char_index;

	if (align_to_integer) {
		float x = (float) STBTT_ifloor((*xpos + b->xoff) + 0.5f);
		float y = (float) STBTT_ifloor((*ypos + b->yoff) + 0.5f);
		q->x0 = x;
		q->y0 = y;
		q->x1 = x + b->xoff2 - b->xoff;
		q->y1 = y + b->yoff2 - b->yoff;
	} else {
		q->x0 = *xpos + b->xoff;
		q->y0 = *ypos + b->yoff;
		q->x1 = *xpos + b->xoff2;
		q->y1 = *ypos + b->yoff2;
	}

	q->s0 = b->x0 * ipw;
	q->t0 = b->y0 * iph;
	q->s1 = b->x1 * ipw;
	q->t1 = b->y1 * iph;

	*xpos += b->xadvance;
}

//////////////////////////////////////////////////////////////////////////////
//
// sdf computation
//
#define STBTT_min(a,b)  ((a) < (b) ? (a) : (b))
#define STBTT_max(a,b)  ((a) < (b) ? (b) : (a))

static int stbtt__ray_intersect_bezier(float orig[2], float ray[2], float q0[2], float q1[2], float q2[2], float hits[2][2])
{
	float q0perp = q0[1]*ray[0] - q0[0]*ray[1];
	float q1perp = q1[1]*ray[0] - q1[0]*ray[1];
	float q2perp = q2[1]*ray[0] - q2[0]*ray[1];
	float roperp = orig[1]*ray[0] - orig[0]*ray[1];

	float a = q0perp - 2*q1perp + q2perp;
	float b = q1perp - q0perp;
	float c = q0perp - roperp;

	float s0 = 0., s1 = 0.;
	int num_s = 0;

	if (a != 0.0) {
		float discr = b*b - a*c;
		if (discr > 0.0) {
			float rcpna = -1 / a;
			float d = (float) STBTT_sqrt(discr);
			s0 = (b+d) * rcpna;
			s1 = (b-d) * rcpna;
			if (s0 >= 0.0 && s0 <= 1.0)
				num_s = 1;
			if (d > 0.0 && s1 >= 0.0 && s1 <= 1.0) {
				if (num_s == 0) s0 = s1;
				++num_s;
			}
		}
	} else {
		// 2*b*s + c = 0
		// s = -c / (2*b)
		s0 = c / (-2 * b);
		if (s0 >= 0.0 && s0 <= 1.0)
			num_s = 1;
	}

	if (num_s == 0)
		return 0;
	else {
		float rcp_len2 = 1 / (ray[0]*ray[0] + ray[1]*ray[1]);
		float rayn_x = ray[0] * rcp_len2, rayn_y = ray[1] * rcp_len2;

		float q0d =   q0[0]*rayn_x +   q0[1]*rayn_y;
		float q1d =   q1[0]*rayn_x +   q1[1]*rayn_y;
		float q2d =   q2[0]*rayn_x +   q2[1]*rayn_y;
		float rod = orig[0]*rayn_x + orig[1]*rayn_y;

		float q10d = q1d - q0d;
		float q20d = q2d - q0d;
		float q0rd = q0d - rod;

		hits[0][0] = q0rd + s0*(2.0f - 2.0f*s0)*q10d + s0*s0*q20d;
		hits[0][1] = a*s0+b;

		if (num_s > 1) {
			hits[1][0] = q0rd + s1*(2.0f - 2.0f*s1)*q10d + s1*s1*q20d;
			hits[1][1] = a*s1+b;
			return 2;
		} else {
			return 1;
		}
	}
}

static int equal(float *a, float *b)
{
	return (a[0] == b[0] && a[1] == b[1]);
}

static int stbtt__compute_crossings_x(float x, float y, int nverts, stbtt_vertex *verts)
{
	int i;
	float orig[2], ray[2] = { 1, 0 };
	float y_frac;
	int winding = 0;

	orig[0] = x;
	orig[1] = y;

	// make sure y never passes through a vertex of the shape
	y_frac = (float) STBTT_fmod(y, 1.0f);
	if (y_frac < 0.01f)
		y += 0.01f;
	else if (y_frac > 0.99f)
		y -= 0.01f;
	orig[1] = y;

	// test a ray from (-infinity,y) to (x,y)
	for (i=0; i < nverts; ++i) {
		if (verts[i].type == STBTT_vline) {
			int x0 = (int) verts[i-1].x, y0 = (int) verts[i-1].y;
			int x1 = (int) verts[i  ].x, y1 = (int) verts[i  ].y;
			if (y > STBTT_min(y0,y1) && y < STBTT_max(y0,y1) && x > STBTT_min(x0,x1)) {
				float x_inter = (y - y0) / (y1 - y0) * (x1-x0) + x0;
				if (x_inter < x)
					winding += (y0 < y1) ? 1 : -1;
			}
		}
		if (verts[i].type == STBTT_vcurve) {
			int x0 = (int) verts[i-1].x , y0 = (int) verts[i-1].y ;
			int x1 = (int) verts[i  ].cx, y1 = (int) verts[i  ].cy;
			int x2 = (int) verts[i  ].x , y2 = (int) verts[i  ].y ;
			int ax = STBTT_min(x0,STBTT_min(x1,x2)), ay = STBTT_min(y0,STBTT_min(y1,y2));
			int by = STBTT_max(y0,STBTT_max(y1,y2));
			if (y > ay && y < by && x > ax) {
				float q0[2],q1[2],q2[2];
				float hits[2][2];
				q0[0] = (float)x0;
				q0[1] = (float)y0;
				q1[0] = (float)x1;
				q1[1] = (float)y1;
				q2[0] = (float)x2;
				q2[1] = (float)y2;
				if (equal(q0,q1) || equal(q1,q2)) {
					x0 = (int)verts[i-1].x;
					y0 = (int)verts[i-1].y;
					x1 = (int)verts[i  ].x;
					y1 = (int)verts[i  ].y;
					if (y > STBTT_min(y0,y1) && y < STBTT_max(y0,y1) && x > STBTT_min(x0,x1)) {
						float x_inter = (y - y0) / (y1 - y0) * (x1-x0) + x0;
						if (x_inter < x)
							winding += (y0 < y1) ? 1 : -1;
					}
				} else {
					int num_hits = stbtt__ray_intersect_bezier(orig, ray, q0, q1, q2, hits);
					if (num_hits >= 1)
						if (hits[0][0] < 0)
							winding += (hits[0][1] < 0 ? -1 : 1);
					if (num_hits >= 2)
						if (hits[1][0] < 0)
							winding += (hits[1][1] < 0 ? -1 : 1);
				}
			}
		}
	}
	return winding;
}

static float stbtt__cuberoot( float x )
{
	if (x<0)
		return -(float) STBTT_pow(-x,1.0f/3.0f);
	else
		return  (float) STBTT_pow( x,1.0f/3.0f);
}

// x^3 + c*x^2 + b*x + a = 0
static int stbtt__solve_cubic(float a, float b, float c, float* r)
{
	float s = -a / 3;
	float p = b - a*a / 3;
	float q = a * (2*a*a - 9*b) / 27 + c;
	float p3 = p*p*p;
	float d = q*q + 4*p3 / 27;
	if (d >= 0) {
		float z = (float) STBTT_sqrt(d);
		float u = (-q + z) / 2;
		float v = (-q - z) / 2;
		u = stbtt__cuberoot(u);
		v = stbtt__cuberoot(v);
		r[0] = s + u + v;
		return 1;
	} else {
		float u = (float) STBTT_sqrt(-p/3);
		float v = (float) STBTT_acos(-STBTT_sqrt(-27/p3) * q / 2) / 3; // p3 must be negative, since d is negative
		float m = (float) STBTT_cos(v);
		float n = (float) STBTT_cos(v-3.141592/2)*1.732050808f;
		r[0] = s + u * 2 * m;
		r[1] = s - u * (m + n);
		r[2] = s - u * (m - n);

		//STBTT_assert( STBTT_fabs(((r[0]+a)*r[0]+b)*r[0]+c) < 0.05f);  // these asserts may not be safe at all scales, though they're in bezier t parameter units so maybe?
		//STBTT_assert( STBTT_fabs(((r[1]+a)*r[1]+b)*r[1]+c) < 0.05f);
		//STBTT_assert( STBTT_fabs(((r[2]+a)*r[2]+b)*r[2]+c) < 0.05f);
		return 3;
	}
}

STBTT_DEF unsigned char * stbtt_GetGlyphSDF(const stbtt_fontinfo *info, float scale, int glyph, int padding, unsigned char onedge_value, float pixel_dist_scale, int *width, int *height, int *xoff, int *yoff)
{
	float scale_x = scale, scale_y = scale;
	int ix0,iy0,ix1,iy1;
	int w,h;
	unsigned char *data;

	if (scale == 0) return NULL;

	stbtt_GetGlyphBitmapBoxSubpixel(info, glyph, scale, scale, 0.0f,0.0f, &ix0,&iy0,&ix1,&iy1);

	// if empty, return NULL
	if (ix0 == ix1 || iy0 == iy1)
		return NULL;

	ix0 -= padding;
	iy0 -= padding;
	ix1 += padding;
	iy1 += padding;

	w = (ix1 - ix0);
	h = (iy1 - iy0);

	if (width ) *width  = w;
	if (height) *height = h;
	if (xoff  ) *xoff   = ix0;
	if (yoff  ) *yoff   = iy0;

	// invert for y-downwards bitmaps
	scale_y = -scale_y;

	{
		int x,y,i,j;
		float *precompute;
		stbtt_vertex *verts;
		int num_verts = stbtt_GetGlyphShape(info, glyph, &verts);
		data = (unsigned char *) STBTT_malloc(w * h, info->userdata);
		precompute = (float *) STBTT_malloc(num_verts * sizeof(float), info->userdata);

		for (i=0,j=num_verts-1; i < num_verts; j=i++) {
			if (verts[i].type == STBTT_vline) {
				float x0 = verts[i].x*scale_x, y0 = verts[i].y*scale_y;
				float x1 = verts[j].x*scale_x, y1 = verts[j].y*scale_y;
				float dist = (float) STBTT_sqrt((x1-x0)*(x1-x0) + (y1-y0)*(y1-y0));
				precompute[i] = (dist == 0) ? 0.0f : 1.0f / dist;
			} else if (verts[i].type == STBTT_vcurve) {
				float x2 = verts[j].x *scale_x, y2 = verts[j].y *scale_y;
				float x1 = verts[i].cx*scale_x, y1 = verts[i].cy*scale_y;
				float x0 = verts[i].x *scale_x, y0 = verts[i].y *scale_y;
				float bx = x0 - 2*x1 + x2, by = y0 - 2*y1 + y2;
				float len2 = bx*bx + by*by;
				if (len2 != 0.0f)
					precompute[i] = 1.0f / (bx*bx + by*by);
				else
					precompute[i] = 0.0f;
			} else
				precompute[i] = 0.0f;
		}

		for (y=iy0; y < iy1; ++y) {
			for (x=ix0; x < ix1; ++x) {
				float val;
				float min_dist = 999999.0f;
				float sx = (float) x + 0.5f;
				float sy = (float) y + 0.5f;
				float x_gspace = (sx / scale_x);
				float y_gspace = (sy / scale_y);

				int winding = stbtt__compute_crossings_x(x_gspace, y_gspace, num_verts, verts); // @OPTIMIZE: this could just be a rasterization, but needs to be line vs. non-tesselated curves so a new path

				for (i=0; i < num_verts; ++i) {
					float x0 = verts[i].x*scale_x, y0 = verts[i].y*scale_y;

					// check against every point here rather than inside line/curve primitives -- @TODO: wrong if multiple 'moves' in a row produce a garbage point, and given culling, probably more efficient to do within line/curve
					float dist2 = (x0-sx)*(x0-sx) + (y0-sy)*(y0-sy);
					if (dist2 < min_dist*min_dist)
						min_dist = (float) STBTT_sqrt(dist2);

					if (verts[i].type == STBTT_vline) {
						float x1 = verts[i-1].x*scale_x, y1 = verts[i-1].y*scale_y;

						// coarse culling against bbox
						//if (sx > STBTT_min(x0,x1)-min_dist && sx < STBTT_max(x0,x1)+min_dist &&
						//    sy > STBTT_min(y0,y1)-min_dist && sy < STBTT_max(y0,y1)+min_dist)
						float dist = (float) STBTT_fabs((x1-x0)*(y0-sy) - (y1-y0)*(x0-sx)) * precompute[i];
						STBTT_assert(i != 0);
						if (dist < min_dist) {
							// check position along line
							// x' = x0 + t*(x1-x0), y' = y0 + t*(y1-y0)
							// minimize (x'-sx)*(x'-sx)+(y'-sy)*(y'-sy)
							float dx = x1-x0, dy = y1-y0;
							float px = x0-sx, py = y0-sy;
							// minimize (px+t*dx)^2 + (py+t*dy)^2 = px*px + 2*px*dx*t + t^2*dx*dx + py*py + 2*py*dy*t + t^2*dy*dy
							// derivative: 2*px*dx + 2*py*dy + (2*dx*dx+2*dy*dy)*t, set to 0 and solve
							float t = -(px*dx + py*dy) / (dx*dx + dy*dy);
							if (t >= 0.0f && t <= 1.0f)
								min_dist = dist;
						}
					} else if (verts[i].type == STBTT_vcurve) {
						float x2 = verts[i-1].x *scale_x, y2 = verts[i-1].y *scale_y;
						float x1 = verts[i  ].cx*scale_x, y1 = verts[i  ].cy*scale_y;
						float box_x0 = STBTT_min(STBTT_min(x0,x1),x2);
						float box_y0 = STBTT_min(STBTT_min(y0,y1),y2);
						float box_x1 = STBTT_max(STBTT_max(x0,x1),x2);
						float box_y1 = STBTT_max(STBTT_max(y0,y1),y2);
						// coarse culling against bbox to avoid computing cubic unnecessarily
						if (sx > box_x0-min_dist && sx < box_x1+min_dist && sy > box_y0-min_dist && sy < box_y1+min_dist) {
							int num=0;
							float ax = x1-x0, ay = y1-y0;
							float bx = x0 - 2*x1 + x2, by = y0 - 2*y1 + y2;
							float mx = x0 - sx, my = y0 - sy;
							float res[3],px,py,t,it;
							float a_inv = precompute[i];
							if (a_inv == 0.0) { // if a_inv is 0, it's 2nd degree so use quadratic formula
								float a = 3*(ax*bx + ay*by);
								float b = 2*(ax*ax + ay*ay) + (mx*bx+my*by);
								float c = mx*ax+my*ay;
								if (a == 0.0) { // if a is 0, it's linear
									if (b != 0.0) {
										res[num++] = -c/b;
									}
								} else {
									float discriminant = b*b - 4*a*c;
									if (discriminant < 0)
										num = 0;
									else {
										float root = (float) STBTT_sqrt(discriminant);
										res[0] = (-b - root)/(2*a);
										res[1] = (-b + root)/(2*a);
										num = 2; // don't bother distinguishing 1-solution case, as code below will still work
									}
								}
							} else {
								float b = 3*(ax*bx + ay*by) * a_inv; // could precompute this as it doesn't depend on sample point
								float c = (2*(ax*ax + ay*ay) + (mx*bx+my*by)) * a_inv;
								float d = (mx*ax+my*ay) * a_inv;
								num = stbtt__solve_cubic(b, c, d, res);
							}
							if (num >= 1 && res[0] >= 0.0f && res[0] <= 1.0f) {
								t = res[0], it = 1.0f - t;
								px = it*it*x0 + 2*t*it*x1 + t*t*x2;
								py = it*it*y0 + 2*t*it*y1 + t*t*y2;
								dist2 = (px-sx)*(px-sx) + (py-sy)*(py-sy);
								if (dist2 < min_dist * min_dist)
									min_dist = (float) STBTT_sqrt(dist2);
							}
							if (num >= 2 && res[1] >= 0.0f && res[1] <= 1.0f) {
								t = res[1], it = 1.0f - t;
								px = it*it*x0 + 2*t*it*x1 + t*t*x2;
								py = it*it*y0 + 2*t*it*y1 + t*t*y2;
								dist2 = (px-sx)*(px-sx) + (py-sy)*(py-sy);
								if (dist2 < min_dist * min_dist)
									min_dist = (float) STBTT_sqrt(dist2);
							}
							if (num >= 3 && res[2] >= 0.0f && res[2] <= 1.0f) {
								t = res[2], it = 1.0f - t;
								px = it*it*x0 + 2*t*it*x1 + t*t*x2;
								py = it*it*y0 + 2*t*it*y1 + t*t*y2;
								dist2 = (px-sx)*(px-sx) + (py-sy)*(py-sy);
								if (dist2 < min_dist * min_dist)
									min_dist = (float) STBTT_sqrt(dist2);
							}
						}
					}
				}
				if (winding == 0)
					min_dist = -min_dist;  // if outside the shape, value is negative
				val = onedge_value + pixel_dist_scale * min_dist;
				if (val < 0)
					val = 0;
				else if (val > 255)
					val = 255;
				data[(y-iy0)*w+(x-ix0)] = (unsigned char) val;
			}
		}
		STBTT_free(precompute, info->userdata);
		STBTT_free(verts, info->userdata);
	}
	return data;
}

STBTT_DEF unsigned char * stbtt_GetCodepointSDF(const stbtt_fontinfo *info, float scale, int codepoint, int padding, unsigned char onedge_value, float pixel_dist_scale, int *width, int *height, int *xoff, int *yoff)
{
	return stbtt_GetGlyphSDF(info, scale, stbtt_FindGlyphIndex(info, codepoint), padding, onedge_value, pixel_dist_scale, width, height, xoff, yoff);
}

STBTT_DEF void stbtt_FreeSDF(unsigned char *bitmap, void *userdata)
{
	STBTT_free(bitmap, userdata);
}

//////////////////////////////////////////////////////////////////////////////
//
// font name matching -- recommended not to use this
//
// check if a utf8 string contains a prefix which is the utf16 string; if so return length of matching utf8 string
static stbtt_int32 stbtt__CompareUTF8toUTF16_bigendian_prefix(stbtt_uint8 *s1, stbtt_int32 len1, stbtt_uint8 *s2, stbtt_int32 len2)
{
	stbtt_int32 i=0;

	// convert utf16 to utf8 and compare the results while converting
	while (len2) {
		stbtt_uint16 ch = s2[0]*256 + s2[1];
		if (ch < 0x80) {
			if (i >= len1) return -1;
			if (s1[i++] != ch) return -1;
		} else if (ch < 0x800) {
			if (i+1 >= len1) return -1;
			if (s1[i++] != 0xc0 + (ch >> 6)) return -1;
			if (s1[i++] != 0x80 + (ch & 0x3f)) return -1;
		} else if (ch >= 0xd800 && ch < 0xdc00) {
			stbtt_uint32 c;
			stbtt_uint16 ch2 = s2[2]*256 + s2[3];
			if (i+3 >= len1) return -1;
			c = ((ch - 0xd800) << 10) + (ch2 - 0xdc00) + 0x10000;
			if (s1[i++] != 0xf0 + (c >> 18)) return -1;
			if (s1[i++] != 0x80 + ((c >> 12) & 0x3f)) return -1;
			if (s1[i++] != 0x80 + ((c >>  6) & 0x3f)) return -1;
			if (s1[i++] != 0x80 + ((c      ) & 0x3f)) return -1;
			s2 += 2; // plus another 2 below
			len2 -= 2;
		} else if (ch >= 0xdc00 && ch < 0xe000) {
			return -1;
		} else {
			if (i+2 >= len1) return -1;
			if (s1[i++] != 0xe0 + (ch >> 12)) return -1;
			if (s1[i++] != 0x80 + ((ch >> 6) & 0x3f)) return -1;
			if (s1[i++] != 0x80 + ((ch     ) & 0x3f)) return -1;
		}
		s2 += 2;
		len2 -= 2;
	}
	return i;
}

static int stbtt_CompareUTF8toUTF16_bigendian_internal(char *s1, int len1, char *s2, int len2)
{
	return len1 == stbtt__CompareUTF8toUTF16_bigendian_prefix((stbtt_uint8*) s1, len1, (stbtt_uint8*) s2, len2);
}

// returns results in whatever encoding you request... but note that 2-byte encodings
// will be BIG-ENDIAN... use stbtt_CompareUTF8toUTF16_bigendian() to compare
STBTT_DEF const char *stbtt_GetFontNameString(const stbtt_fontinfo *font, int *length, int platformID, int encodingID, int languageID, int nameID)
{
	stbtt_int32 i,count,stringOffset;
	stbtt_uint8 *fc = font->data;
	stbtt_uint32 offset = font->fontstart;
	stbtt_uint32 nm = stbtt__find_table(fc, offset, "name");
	if (!nm) return NULL;

	count = ttUSHORT(fc+nm+2);
	stringOffset = nm + ttUSHORT(fc+nm+4);
	for (i=0; i < count; ++i) {
		stbtt_uint32 loc = nm + 6 + 12 * i;
		if (platformID == ttUSHORT(fc+loc+0) && encodingID == ttUSHORT(fc+loc+2)
			 && languageID == ttUSHORT(fc+loc+4) && nameID == ttUSHORT(fc+loc+6)) {
			*length = ttUSHORT(fc+loc+8);
			return (const char *) (fc+stringOffset+ttUSHORT(fc+loc+10));
		}
	}
	return NULL;
}

static int stbtt__matchpair(stbtt_uint8 *fc, stbtt_uint32 nm, stbtt_uint8 *name, stbtt_int32 nlen, stbtt_int32 target_id, stbtt_int32 next_id)
{
	stbtt_int32 i;
	stbtt_int32 count = ttUSHORT(fc+nm+2);
	stbtt_int32 stringOffset = nm + ttUSHORT(fc+nm+4);

	for (i=0; i < count; ++i) {
		stbtt_uint32 loc = nm + 6 + 12 * i;
		stbtt_int32 id = ttUSHORT(fc+loc+6);
		if (id == target_id) {
			// find the encoding
			stbtt_int32 platform = ttUSHORT(fc+loc+0), encoding = ttUSHORT(fc+loc+2), language = ttUSHORT(fc+loc+4);

			// is this a Unicode encoding?
			if (platform == 0 || (platform == 3 && encoding == 1) || (platform == 3 && encoding == 10)) {
				stbtt_int32 slen = ttUSHORT(fc+loc+8);
				stbtt_int32 off = ttUSHORT(fc+loc+10);

				// check if there's a prefix match
				stbtt_int32 matchlen = stbtt__CompareUTF8toUTF16_bigendian_prefix(name, nlen, fc+stringOffset+off,slen);
				if (matchlen >= 0) {
					// check for target_id+1 immediately following, with same encoding & language
					if (i+1 < count && ttUSHORT(fc+loc+12+6) == next_id && ttUSHORT(fc+loc+12) == platform && ttUSHORT(fc+loc+12+2) == encoding && ttUSHORT(fc+loc+12+4) == language) {
						slen = ttUSHORT(fc+loc+12+8);
						off = ttUSHORT(fc+loc+12+10);
						if (slen == 0) {
							if (matchlen == nlen)
								return 1;
						} else if (matchlen < nlen && name[matchlen] == ' ') {
							++matchlen;
							if (stbtt_CompareUTF8toUTF16_bigendian_internal((char*) (name+matchlen), nlen-matchlen, (char*)(fc+stringOffset+off),slen))
								return 1;
						}
					} else {
						// if nothing immediately following
						if (matchlen == nlen)
							return 1;
					}
				}
			}

			// @TODO handle other encodings
		}
	}
	return 0;
}

static int stbtt__matches(stbtt_uint8 *fc, stbtt_uint32 offset, stbtt_uint8 *name, stbtt_int32 flags)
{
	stbtt_int32 nlen = (stbtt_int32) STBTT_strlen((char *) name);
	stbtt_uint32 nm,hd;
	if (!stbtt__isfont(fc+offset)) return 0;

	// check italics/bold/underline flags in macStyle...
	if (flags) {
		hd = stbtt__find_table(fc, offset, "head");
		if ((ttUSHORT(fc+hd+44) & 7) != (flags & 7)) return 0;
	}

	nm = stbtt__find_table(fc, offset, "name");
	if (!nm) return 0;

	if (flags) {
		// if we checked the macStyle flags, then just check the family and ignore the subfamily
		if (stbtt__matchpair(fc, nm, name, nlen, 16, -1))  return 1;
		if (stbtt__matchpair(fc, nm, name, nlen,  1, -1))  return 1;
		if (stbtt__matchpair(fc, nm, name, nlen,  3, -1))  return 1;
	} else {
		if (stbtt__matchpair(fc, nm, name, nlen, 16, 17))  return 1;
		if (stbtt__matchpair(fc, nm, name, nlen,  1,  2))  return 1;
		if (stbtt__matchpair(fc, nm, name, nlen,  3, -1))  return 1;
	}

	return 0;
}

static int stbtt_FindMatchingFont_internal(unsigned char *font_collection, char *name_utf8, stbtt_int32 flags)
{
	stbtt_int32 i;
	for (i=0;;++i) {
		stbtt_int32 off = stbtt_GetFontOffsetForIndex(font_collection, i);
		if (off < 0) return off;
		if (stbtt__matches((stbtt_uint8 *) font_collection, off, (stbtt_uint8*) name_utf8, flags))
			return off;
	}
}

#if defined(__GNUC__) || defined(__clang__)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wcast-qual"
#endif

STBTT_DEF int stbtt_BakeFontBitmap(const unsigned char *data, int offset,
										  float pixel_height, unsigned char *pixels, int pw, int ph,
										  int first_char, int num_chars, stbtt_bakedchar *chardata)
{
	return stbtt_BakeFontBitmap_internal((unsigned char *) data, offset, pixel_height, pixels, pw, ph, first_char, num_chars, chardata);
}

STBTT_DEF int stbtt_GetFontOffsetForIndex(const unsigned char *data, int index)
{
	return stbtt_GetFontOffsetForIndex_internal((unsigned char *) data, index);
}

STBTT_DEF int stbtt_GetNumberOfFonts(const unsigned char *data)
{
	return stbtt_GetNumberOfFonts_internal((unsigned char *) data);
}

STBTT_DEF int stbtt_InitFont(stbtt_fontinfo *info, const unsigned char *data, int offset)
{
	return stbtt_InitFont_internal(info, (unsigned char *) data, offset);
}

STBTT_DEF int stbtt_FindMatchingFont(const unsigned char *fontdata, const char *name, int flags)
{
	return stbtt_FindMatchingFont_internal((unsigned char *) fontdata, (char *) name, flags);
}

STBTT_DEF int stbtt_CompareUTF8toUTF16_bigendian(const char *s1, int len1, const char *s2, int len2)
{
	return stbtt_CompareUTF8toUTF16_bigendian_internal((char *) s1, len1, (char *) s2, len2);
}

#if defined(__GNUC__) || defined(__clang__)
#pragma GCC diagnostic pop
#endif

// Fonts
size_t nfonts = 0;
struct font {
	char *path;
	stbtt_fontinfo font;
	double scale;
} *fonts = NULL;
int wbmfont=4096, hbmfont, xnextbmfont=/*wbmfont*/4096+1, ynextbmfont=0, ynextrowbmfont=0;
uint8_t *bmfont = NULL;
size_t nglyphss = 0;
struct arrglyphs {
	size_t n;
	uint32_t *cps;
	struct glyph {
		int x0, x1, y0, y1, offx, offy;
		double adv;
	} *glyphs;
} *glyphss = NULL;
size_t ncpsstodo=0;
struct arrcps { size_t n,size; uint32_t *cps; } *cpsstodo = NULL;
int sizeimagetex = 0;
size_t nglyphstex = 0;


#define __android_log_print(level,tag,...) (__android_log_print(level,tag,__VA_ARGS__),df(__VA_ARGS__))
#define Fprintf(stderr,...) fprintf(fdf,__VA_ARGS__)
#define Fputs(s,stderr) fputs(s,fdf)


void
printblocks(size_t nblks, struct block *blks, FILE *f)
{
	return;
	df("printblocks");
	int indent = 0;
	size_t ib = 0;
	size_t i = 0;
	size_t nb = nblks;
	struct block *b = blks;
	while (b!=blocks || ib<nb) {
		//if (i > ntext) break;
		fprintf(f, "%*s%zu/%zu: %zu %zu (%zu)\n", indent, "", 1+ib, nb, i, b[ib].n, b[ib].nblocks);
		for (size_t j=0; j<b[ib].nblocks; j++) if (b[ib].blocks[j].parent != b+ib) fprintf(f, "%*s BAD CHILD %zu\n", indent+2, "", j+1);
		if (b[ib].nblocks) {
			indent += 2;
			nb = b[ib].nblocks;
			i += b[ib].iblocks;
			b = b[ib].blocks;
			ib = 0;
		} else if (ib+1 < nb) {
			i+=b[ib++].n;
		} else if (b == blks) break;
		else {
			while (b!=blks && ib+1==nb) {
				//printf("%*sib%zu nb%zu i%zu\n", indent, "", ib, nb, i);
				b = b->parent;
				ib = b - (b->parent?b->parent->blocks:blks);
				b -= ib;
				i -= b[ib].iblocks;
				for (size_t j=0; j+1<b[ib].nblocks; j++) i-=b[ib].blocks[j].n;
				indent -= 2;
				nb = b->parent ? b->parent->nblocks : nblks;
			}
			i += b[ib].n;
			ib++;
		}
	}
}

struct at
attop(void)
{
	return (struct at){.x=padwin, .y=ytop, .i=itop};
}

struct cp {
	uint32_t c;
	char n;
	char valid;
}
utf8(size_t nbuf, uint8_t *buf, size_t i)
{

	// Handle end of buf
	if (i == nbuf)
		return (struct cp){.c=UINT32_MAX};

	// ASCII shortcut
	uint8_t c0 = buf[i];
	if (c0 <= 0x7f)
		return (struct cp){.c=c0, .n=1, .valid=1};

	// Get UTF-8 octet length
	struct cp c = {.valid = 1};
	size_t nleft = nbuf - i;
	if (!(c0&0x80)) c.n=1;
	else if (nleft>=2 && ((c0&0xE0) == 0xC0)) c.n=2;
	else if (nleft>=3 && ((c0&0xF0) == 0xE0)) c.n=3;
	else if (nleft>=4 && ((c0&0xF8) == 0xF0)) c.n=4;
	else return (struct cp){.c=UINT32_MAX, .n=1};

	// Check valid octets
	for (int ic=1; ic<c.n; ic++)
		if ((buf[i+ic]&0xC0) != 0x80)
			return (struct cp){.c=UINT32_MAX, .n=1};

	// Decode into codepoint
	c.c = c.n == 1
		? c0 & 0x7F
		: (c0&(0x7F>>c.n)) << 6*(c.n-1);
	for (int ic=1; ic<c.n; ic++)
		c.c += (buf[i+ic]&0x3F) << 6*(c.n-1-ic);

	// Invalid sequence
	if (

			// Overlong
			(c.n==2 && c.c<0x80)
			|| (c.n>2 && (c.c < (1 << (5*c.n - 4))))

			// UTF-16 surrogate
			|| (c.c>=0xD800 && c.c<=0xDFFF)

			// Unencodable by UTF-16
			|| (c.c > 0x10FFFF))
		return (struct cp){.c=UINT32_MAX, .n=1};

	// Valid
	return c;
}

struct cp
utf8prev(size_t nbuf, uint8_t *buf, size_t i)
{
	struct cp c;
	if (i>=4 && (c=utf8(nbuf,buf,i-4)).n==4);
	else if (i>=3 && (c=utf8(nbuf,buf,i-3)).n==3);
	else if (i>=2 && (c=utf8(nbuf,buf,i-2)).n==2);
	else if (i>=1 && (c=utf8(nbuf,buf,i-1)).n==1);
	else c=(struct cp){.c=UINT32_MAX};
	return c;
}

/* ranges is an array of start and end, nranges
is the number of such pairs (so half its length),
and c is a character to return whether its within
any of those ranges. */
char
contains(size_t nranges, const uint32_t *ranges, uint32_t c)
{

	// Binary search for it
	size_t lo=0, hi=nranges-1;
	while (hi-lo > 1) {
		size_t mid = (hi-lo)/2 + lo;

		// Too high
		if (c < ranges[mid*2])
			hi = mid-1;

		// Too low
		else if (c > ranges[mid*2+1])
			lo = mid+1;

		// Match
		else return 1;
	}

	// Check last two
	return (ranges[lo*2]<=c && c<=ranges[lo*2+1])
		|| (ranges[hi*2]<=c && c<=ranges[hi*2+1]);
}

// based on UAX29§3.1.1 © 2019 Unicode, Inc.
int
graphbreak(struct cp a, struct cp b, uint8_t *buf,
	size_t i)
{

	// Break if either invalid
	if (!a.valid || !b.valid) return 1;
	
	// ASCII shortcut: always break
	if (a.c<=0x7f && b.c<=0x7f) return 1;

	// Do not break between a CR and LF.
	// Otherwise, break before and after controls.
#define IN(cu, ranges) contains(sizeof(ranges)/(sizeof(uint32_t)*2), ranges, cu.c)
	if (IN(a, gbpControl)
			|| a.c == 0xd
			|| IN(b, gbpControl)
			|| b.c == 0xd)
		return 1;

	// Do not break Hangul syllable sequences.
	if (IN(a, gbpL)) {
		if (IN(b, gbpL)
				|| IN(b, gbpV)
				|| IN(b, gbpLV)
				|| IN(b, gbpLVT))
			return 0;
	} else if (IN(a,gbpLV) || IN(a,gbpV)) {
		if (IN(b,gbpV) || IN(b,gbpT)) return 0;
	} else if ((IN(a,gbpLVT) || IN(a,gbpT))
			&& IN(b, gbpT))
		return 0;

	// Do not break before extending characters
	// or ZWJ.
	if (IN(b,gbpExtend) || b.c==0xe2808d)
		return 0;

	// Do not break before SpacingMarks, or
	// after Prepend characters.
	if (IN(b,gbpSpacingMark) || IN(a,gbpPrepend))
		return 0;

	// Do not break within emoji modifier
	// sequences or emoji zwj sequences.
	if (a.c == 0xe2808d
			&& IN(b, Extended_Pictographic))
		for (size_t j=i-a.n;;) {
			if (!j) goto endemojizwj;
			struct cp c = utf8prev(i, buf, j);
			if (IN(c, Extended_Pictographic)) return 0;
			if (!IN(c, gbpExtend)) goto endemojizwj;
			j -= c.n;
		}
endemojizwj:;

	// Do not break within emoji flag sequences.
	// That is, do not break between regional
	// indicator (RI) symbols if there is an odd
	// number of RI characters before the break point.
	if (IN(a, Regional_Indicator)
			&& IN(b, Regional_Indicator)
			&& (i == a.n
				|| !IN(utf8prev(i,buf,i-a.n),Regional_Indicator)
			))
		return 0;

	// Otherwise, break everywhere.
	return 1;
}

size_t
igraphprev(size_t nbuf, uint8_t *buf, size_t i)
{

	// Find the preceding grapheme cluster
	// boundary
	// based on UAX29§3.1.1 © 2019 Unicode, Inc.
	// but backwards
	struct cp c = utf8prev(nbuf, buf, i);
	size_t n = c.n;
	for (struct cp b=c,a;; n+=a.n,b=a) {

		// Break at the start and end of text,
		// unless the text is empty.
		if (i == n) break;

		// Follow UAX29§3.1.1
		a = utf8prev(nbuf, buf, i-n);
		if (graphbreak(a, b, buf, i-n)) break;
	}
	return i - n;
}

void
getbufcur(size_t *pn, uint8_t **pbuf)
{
	switch (cur) {
	case CURTEXT: *pn=ntext, *pbuf=text; break;
	case CURSEARCH: *pn=nsearch, *pbuf=bufsearch; break;
	case CURMULTI: *pn=nbufmulti, *pbuf=bufmulti; break;
	case CURREPLACE0: *pn=nbufreplace0, *pbuf=bufreplace0; break;
	case CURREPLACE1: *pn=nbufreplace1, *pbuf=bufreplace1; break;
	}
}

size_t
igraphprevcur(size_t i)
{
	size_t nbuf; uint8_t *buf; getbufcur(&nbuf,&buf);
	return igraphprev(nbuf, buf, i);
}

char
hexc0(uint8_t n)
{
	return "0123456789ABCDEF"[(n>>4)&0xf];
}

char
hexc1(uint8_t n)
{
	return "0123456789ABCDEF"[n&0xf];
}

size_t
getibsu32(uint32_t i, size_t n, uint32_t *is)
{
	size_t lo=0, hi1=n;
	while (lo < hi1) {
		size_t mid = (hi1-lo)/2 + lo;
		int cmp = i - is[mid];
		if (!cmp) return mid;
		else if (cmp < 0) hi1=mid;
		else if (cmp > 0) lo=mid+1;
	}
	return lo;
}

size_t
getibsnu32(size_t nn, uint32_t *x, size_t n, uint32_t *ns)
{
	size_t lo=0, hi1=n;
	while (lo < hi1) {
		size_t mid = (hi1-lo)/2 + lo;
		int cmp; for (size_t in=0; in<nn; in++) if (cmp = x[in]-ns[mid*nn+in]) break;
		if (!cmp) return mid;
		else if (cmp < 0) hi1=mid;
		else if (cmp > 0) lo=mid+1;
	}
	return lo;
}

struct glyph*
getglyph(size_t ncps, uint32_t *cps)
{
	if (nglyphss < ncps) return NULL;
	struct arrglyphs *arr = glyphss + ncps-1;
	size_t ibs = getibsnu32(ncps, cps, arr->n, arr->cps);
	return ibs>=arr->n||memcmp(arr->cps+ibs*ncps,cps,ncps*sizeof(*cps)) ? NULL : arr->glyphs+ibs;
}

/* Returns the advance in pixels */
double
adv(uint32_t cp)
{
	struct glyph *g = getglyph(1, (uint32_t[1]){cp});
	return g ? g->adv : 1.0;
}

double
advs(char *s)
{
	double a=0; while (*s) a+=adv(*s++);
	return a;
}

/* w = advance */
#define GGD_HEX 0x01
#define GGD_STR0 0x02
uint8_t*
getgraphdisplay(size_t nbuf, uint8_t *buf, size_t i,
	uint8_t *pn, double *pw, uint8_t *pflags)
{
	//D("getgraphdisplay")
	uint8_t dummyflags;
	if (!pflags) pflags=&dummyflags;
	*pflags = 0;

	// Handle end of buf
	if (i == nbuf) {
		*pn = *pw = *pflags = 0;
		return NULL;
	}

	// Follow til end of grapheme cluster
	// based on UAX29§3.1.1 © 2019 Unicode, Inc.
	//D("getfgraphdisplay utf8")
	struct cp c = utf8(nbuf, buf, i);
	//D("getgraphdisplay utf8 end")
	uint8_t n = c.n;
	for (struct cp a=c,b;; a=b,n+=b.n) {

		// Break at the start and end of text,
		// unless the text is empty.
		if (i+n == nbuf) break;

		// Break based on UAX29§3.1.1
		b = utf8(nbuf, buf, i+n);
		if (graphbreak(a, b, buf, i+n)) break;
	}
	//D("getgraphdisplay n%"PRIu8, n)
	*pn = n;

	// Show invalid as hex
	char hex = !c.valid;

	// Individually-handled-width characters
	if (!hex && n==c.n) switch(c.c) {

	// Null
	case 0x00:
		*pw = adv('^') + adv('0');
		*pflags |= GGD_STR0;
		return (uint8_t*)"^0";

	// Tab
	case 0x09:
		*pw = wtab;
		*pflags |= GGD_STR0;
		return (uint8_t*)"  ";
	}  // add more individual characters above here

	// Show tricky stuff as hex
	if (!hex) for (int ic=0; ic<n;) {
		struct cp cp = ic ? utf8(nbuf,buf,i+ic) : c;
		if (IN(cp, ZlZpCcCfCsCoCn)) {
			hex=1; break;
		}
		ic += cp.n;
	}
	
	// Rest of ASCII has width 1
	if (hex);
	else if (n == 1) *pw=adv(buf[i]);

	// Get non-ASCII width
	else {
		uint32_t cps[n]; size_t ncps=0; for (size_t j=0;j<n;) {
			struct cp cj = utf8(n, buf+i, j);
			cps[ncps++] = cj.c;
			j += cj.n;
		}
		struct glyph *g = getglyph(ncps, cps);
		*pw = g ? g->adv : 1.0;

#if 0
		// Initialize array of widths indexed
		// by number of bytes in grapheme
		static struct widths {
			uint8_t *buf;
			uint8_t *w;
			size_t n;
			size_t size;
		} *sizewidths = NULL;
		static size_t nsizewidths = 0;
		if (!sizewidths)
			sizewidths = Calloc(nsizewidths=5, sizeof(struct widths));
		
		// Create this size if it doesn't exist
		if (n >= nsizewidths) {
			size_t n0 = nsizewidths;
			while ((nsizewidths*=2) <= n);
			sizewidths = Realloc(sizewidths, nsizewidths*(sizeof(struct widths)));
			memset(sizewidths+n0, 0, (nsizewidths-n0)*sizeof(struct widths));
		}
		struct widths *ws = sizewidths + n;

		// Binary search for where this grapheme
		// would be
		size_t lo=0, hi1=ws->n;
		//D("getgraphdisplay searching width spot")
		while (lo < hi1) {
			size_t mid = (hi1-lo)/2 + lo;
			int cmp = memcmp(buf+i, ws->buf+mid*n, n);
			if (!cmp) { lo=mid; break; }
			else if (cmp < 0) hi1=mid;
			else if (cmp > 0) lo=mid+1;
		}
		//D("getgraphdisplay lo%zu hi%zu", lo, hi1)

		// Insert if not found
		if (lo == hi1) {

			// Print this invisibly at the top left,
			// ask for cursor position, then return
			printf("\0337\033[H\033[8m%.*s\033[6n\033[28m\0338",
				n, buf+i);
			fflush(stdout);

			// Indicate that the screen will have to be
			// redrawn
			needsredraw = 1;

			// Read the cursor position response, storing
			// other input if there is any
			uint8_t col1, row1;
			//D("getgraphdisplay reading width resp")
			while (1) {
				size_t icpr = ninput;

				// Read until R
				while (1) {
					if (sizeinput==ninput) input=Realloc(input,sizeinput*=2);
					hear(1, input+ninput++);
					if (input[ninput-1] == 'R') break;
				}

				// Try every spot to read a CPR
				for (char b[2]; ninput-icpr>=6; icpr++) {
					if (sscanf((char*)input+icpr,"\033[%"SCNu8";%"SCNu8"%1[R]",&row1,&col1,b) == 3) {
						ninput = icpr;
						goto gotcpr;
					}
				}
			}
gotcpr:

			// Calculate the width from the end col
			*pw = col1 - 1;

			// If the row changed, set width to 0
			if (row1 != 1) *pw=0;
			//D("getgraphdisplay w%"PRIu8, *pw)

			// Save this width
			ws->n++;
			ws->buf = Realloc(ws->buf, n*ws->n);
			ws->w = Realloc(ws->w, ws->n);
			memmove(ws->buf+n*(lo+1), ws->buf+n*lo, n*(ws->n-1-lo));
			memmove(ws->w+lo+1, ws->w+lo, ws->n-1-lo);
			memcpy(ws->buf+n*lo, buf+i, n);
			ws->w[lo] = *pw;
		}

		// Get the width
		*pw = ws->w[lo];
#endif
	}

	// If the width is zero, or too wide, say it in
	// hex
	if (!hex && (!*pw || *pw>displaySize_.width-2)) hex=1;
	if (hex) {
		*pflags |= GGD_HEX;
		*pw = *pn>1 ? adv('[')+adv(']') : 0;
		for (int j=0; j<*pn; j++) *pw+=adv(hexc0(buf[i+j]))+adv(hexc1(buf[i+j]));
	}
	return buf+i;
}

size_t
getilinebuf(size_t i, uint8_t *buf)
{
	while (i && buf[i-1]!='\n') i--;
	return i;
}

size_t
getiline(size_t i)
{
	return getilinebuf(i, text);
}

size_t
getilinenext(size_t i)
{
	if (i >= ntext) return i;
	i++;
	while (i<ntext && text[i-1]!='\n') i++;
	return i;
}

size_t
getibs(size_t i, size_t n, size_t *is)
{
	size_t lo=0, hi1=n;
	while (lo < hi1) {
		size_t mid = (hi1-lo)/2 + lo;
		int cmp = i - is[mid];
		if (!cmp) return mid;
		else if (cmp < 0) hi1=mid;
		else if (cmp > 0) lo=mid+1;
	}
	return lo;
}

/* Return the index this number would be in, regardless
of whether it actually is. */
size_t
getiilexpbs(size_t i)
{
	return getibs(i, nilexps, ilexps);
}

/* Return the index this number would be in, regardless
of whether it actually is. */
size_t
getiflowbs(size_t i)
{
	return getibs(i, nflow, isflow);
}

size_t
getiflow(size_t il)
{
	size_t ibs = getiflowbs(il);
	return ibs<nflow&&isflow[ibs]==il ? ibs : SIZE_MAX;
}

/* Removes this index of the flows array */
void
removeflowi(size_t i)
{
	if (i < nflow-1) memmove(isflow+i,isflow+i+1,sizeof(size_t)*(nflow-i-1));
	nflow--;
}

void*
Realloc(void* pold, size_t n)
{
	void* pnew = realloc(pold, n);
	if (!pnew) { fprintf(stderr, "D3D12HelloTexture: realloc %zu: %s\n", n, strerror(errno)); exit(EXIT_FAILURE); }
	return pnew;
}

void*
Malloc(size_t n)
{
	void* p = malloc(n);
	if (!p) { fprintf(stderr, "D3D12HelloTexture: malloc %zu: %s", n, strerror(errno)); exit(EXIT_FAILURE); }
	return p;
}

/* Make sure l's buf can hold at least n bytes.
If *psize is 0, a new buf is allocated with
len bytes copied over from *pbuf. */
void
ensuren(size_t* psize, size_t len, void** pbuf,
	size_t n)
{

	// Allocate its first buf
	if (!*psize) {
		*psize = 128;
		if (n < len) n = len;
		while (*psize < n) *psize *= 2;
		void* bufnew = Malloc(*psize);
		memcpy(bufnew, *pbuf, len);
		*pbuf = bufnew;

		// Resize current buf
	}
	else if (*psize < n) {
		while (*psize < n) *psize *= 2;
		*pbuf = Realloc(*pbuf, *psize);
	}
	//return *pbuf + n;
}

/* Puts this index directly in the flow list at
iflow; assumes it's correct as far as sorted */
void
insertflowat(size_t itext, size_t iflow)
{
	ensuren(&sizeflows,0,(void**)&isflow,sizeof(size_t)*(iflow+1));
	if (iflow < nflow) memmove(isflow+iflow+1,isflow+iflow,sizeof(size_t)*(nflow-iflow));
	isflow[iflow] = itext;
	nflow++;
}

size_t
getiilexpfrombs(size_t itext, size_t iexpbs)
{
	if (iexpbs<nilexps && ilexps[iexpbs]==itext) return iexpbs;
	if (iexpbs && ilexps[iexpbs-1]+exps[iexpbs-1].n>itext) return iexpbs-1;
	return SIZE_MAX;
}

/* Returns index of expansion line this index is inside of,
or SIZE_MAX if none. */
size_t
getiilexp(size_t i)
{
	return getiilexpfrombs(i, getiilexpbs(i));
}

char
getislexpandedfrombs(size_t itext, size_t iexpbs)
{
	return getiilexpfrombs(itext,iexpbs) != SIZE_MAX;
}

char
getislexpanded(size_t i)
{
	return getislexpandedfrombs(i, getiilexpbs(i));
}

/* Almost equal or less than equal (within 0.0001) */
char
fle(double a, double b)
{
	return a <= b+0.0001;
}

void
getsyn(size_t i, char *psyn, size_t *pi1)
{
	char *puncs = "\n \t'\"\\[](){}.&*+-~!/%<>^|?:;=,#";
	*psyn = 0;

	// Space
	if (isspace(text[i])) {
		*pi1=i+1; while (*pi1<ntext && isspace(text[*pi1])) (*pi1)++;
		return;
	}

	// #include
	if (ntext-i>=9 && !memcmp(text+i,"#include",8) && isspace(text[i+8])) {
		*psyn=4, *pi1=i+8;
		return;
	}
	
	// <header.h> with #include before
	if (i && text[i]=='<' && isspace(text[i-1])) {
		size_t j=i-1; while (j && isspace(text[j])) j--;
		if (j>=7 && !memcmp(text+j-7,"#include",8)) {
			size_t ntok=0; for (;i+1+ntok<ntext && text[i+1+ntok]!='\n' && text[i+1+ntok]!='>'; ntok++);
			if (i+1+ntok<ntext && text[i+1+ntok]=='>') {
				//ntok++;

				// Match against C11 headers
				if (0);
				// Generated: unset next; printf '\t\t\t\telse if ('; for h in assert.h complex.h ctype.h errno.h fenv.h float.h inttypes.h iso646.h limits.h locale.h math.h setjmp.h signal.h stdalign.h stdarg.h stdatomic.h stdbool.h stddef.h stdint.h stdio.h stdlib.h string.h tgmath.h threads.h time.h uchar.h wchar.h wctype.h; do printf '%s(ntok==%s&&!memcmp(text+i+1,"%s",%s))' "${next+||}" ${#h} $h ${#h}; next=1; done; echo ') *psyn=3;'
				else if ((ntok==8&&!memcmp(text+i+1,"assert.h",8))||(ntok==9&&!memcmp(text+i+1,"complex.h",9))||(ntok==7&&!memcmp(text+i+1,"ctype.h",7))||(ntok==7&&!memcmp(text+i+1,"errno.h",7))||(ntok==6&&!memcmp(text+i+1,"fenv.h",6))||(ntok==7&&!memcmp(text+i+1,"float.h",7))||(ntok==10&&!memcmp(text+i+1,"inttypes.h",10))||(ntok==8&&!memcmp(text+i+1,"iso646.h",8))||(ntok==8&&!memcmp(text+i+1,"limits.h",8))||(ntok==8&&!memcmp(text+i+1,"locale.h",8))||(ntok==6&&!memcmp(text+i+1,"math.h",6))||(ntok==8&&!memcmp(text+i+1,"setjmp.h",8))||(ntok==8&&!memcmp(text+i+1,"signal.h",8))||(ntok==10&&!memcmp(text+i+1,"stdalign.h",10))||(ntok==8&&!memcmp(text+i+1,"stdarg.h",8))||(ntok==11&&!memcmp(text+i+1,"stdatomic.h",11))||(ntok==9&&!memcmp(text+i+1,"stdbool.h",9))||(ntok==8&&!memcmp(text+i+1,"stddef.h",8))||(ntok==8&&!memcmp(text+i+1,"stdint.h",8))||(ntok==7&&!memcmp(text+i+1,"stdio.h",7))||(ntok==8&&!memcmp(text+i+1,"stdlib.h",8))||(ntok==8&&!memcmp(text+i+1,"string.h",8))||(ntok==8&&!memcmp(text+i+1,"tgmath.h",8))||(ntok==9&&!memcmp(text+i+1,"threads.h",9))||(ntok==6&&!memcmp(text+i+1,"time.h",6))||(ntok==7&&!memcmp(text+i+1,"uchar.h",7))||(ntok==7&&!memcmp(text+i+1,"wchar.h",7))||(ntok==8&&!memcmp(text+i+1,"wctype.h",8))) *psyn=3;

				// Match against POSIX 2018 headers
				// (with CX, IP6, and RS)
				// minus C11
				// Generated: unset next; printf '\t\t\t\telse if ('; for h in aio.h arpa/inet.h cpio.h dirent.h dlfcn.h fcntl.h fnmatch.h glob.h grp.h iconv.h langinfo.h monetary.h net/if.h netdb.h netinet/in.h netinet/tcp.h nl_types.h poll.h pthread.h pwd.h regex.h sched.h semaphore.h strings.h sys/mman.h sys/select.h sys/socket.h sys/stat.h sys/statvfs.h sys/times.h sys/types.h sys/un.h sys/utsname.h sys/wait.h tar.h termios.h unistd.h wordexp.h; do printf '%s(ntok==%s&&!memcmp(text+i+1,"%s",%s))' "${next+||}" ${#h} $h ${#h}; next=1; done; echo ') *psyn=3;'
				else if ((ntok==5&&!memcmp(text+i+1,"aio.h",5))||(ntok==11&&!memcmp(text+i+1,"arpa/inet.h",11))||(ntok==6&&!memcmp(text+i+1,"cpio.h",6))||(ntok==8&&!memcmp(text+i+1,"dirent.h",8))||(ntok==7&&!memcmp(text+i+1,"dlfcn.h",7))||(ntok==7&&!memcmp(text+i+1,"fcntl.h",7))||(ntok==9&&!memcmp(text+i+1,"fnmatch.h",9))||(ntok==6&&!memcmp(text+i+1,"glob.h",6))||(ntok==5&&!memcmp(text+i+1,"grp.h",5))||(ntok==7&&!memcmp(text+i+1,"iconv.h",7))||(ntok==10&&!memcmp(text+i+1,"langinfo.h",10))||(ntok==10&&!memcmp(text+i+1,"monetary.h",10))||(ntok==8&&!memcmp(text+i+1,"net/if.h",8))||(ntok==7&&!memcmp(text+i+1,"netdb.h",7))||(ntok==12&&!memcmp(text+i+1,"netinet/in.h",12))||(ntok==13&&!memcmp(text+i+1,"netinet/tcp.h",13))||(ntok==10&&!memcmp(text+i+1,"nl_types.h",10))||(ntok==6&&!memcmp(text+i+1,"poll.h",6))||(ntok==9&&!memcmp(text+i+1,"pthread.h",9))||(ntok==5&&!memcmp(text+i+1,"pwd.h",5))||(ntok==7&&!memcmp(text+i+1,"regex.h",7))||(ntok==7&&!memcmp(text+i+1,"sched.h",7))||(ntok==11&&!memcmp(text+i+1,"semaphore.h",11))||(ntok==9&&!memcmp(text+i+1,"strings.h",9))||(ntok==10&&!memcmp(text+i+1,"sys/mman.h",10))||(ntok==12&&!memcmp(text+i+1,"sys/select.h",12))||(ntok==12&&!memcmp(text+i+1,"sys/socket.h",12))||(ntok==10&&!memcmp(text+i+1,"sys/stat.h",10))||(ntok==13&&!memcmp(text+i+1,"sys/statvfs.h",13))||(ntok==11&&!memcmp(text+i+1,"sys/times.h",11))||(ntok==11&&!memcmp(text+i+1,"sys/types.h",11))||(ntok==8&&!memcmp(text+i+1,"sys/un.h",8))||(ntok==13&&!memcmp(text+i+1,"sys/utsname.h",13))||(ntok==10&&!memcmp(text+i+1,"sys/wait.h",10))||(ntok==5&&!memcmp(text+i+1,"tar.h",5))||(ntok==9&&!memcmp(text+i+1,"termios.h",9))||(ntok==8&&!memcmp(text+i+1,"unistd.h",8))||(ntok==9&&!memcmp(text+i+1,"wordexp.h",9))) *psyn=3;

				// Unknown header
				else *psyn=0;
			} else *psyn=0;
			*pi1 = i + 1 + ntok + 1;
			return;
		}
	}
	
	// //
	if (ntext-i>=2 && !memcmp(text+i,"//",2)) {
		*psyn = 2;
		for (*pi1=i+2; *pi1<ntext && text[*pi1]!='\n'; (*pi1)++);

	// /*
	} else if (ntext-i>=2 && !memcmp(text+i,"/*",2)) {
		*psyn = 2;
		for (*pi1=i+2; *pi1<ntext; (*pi1)++)
			if (ntext-*pi1>=2 && !memcmp(text+*pi1,"*/",2)) {
				*pi1 += 2;
				return;
			}

	// '
	} else if (text[i] == '\'') {
		*psyn = 3;
		char esc = 0;
		for (*pi1=i+1; *pi1<ntext && text[*pi1]!='\n' && (esc||text[*pi1]!='\''); (*pi1)++)
			esc = !esc && text[*pi1]=='\\';
		(*pi1)++;

	// "
	} else if (text[i] == '"') {
		*psyn = 3;
		char esc = 0;
		for (*pi1=i+1; *pi1<ntext && text[*pi1]!='\n' && (esc||text[*pi1]!='"'); (*pi1)++)
			esc = !esc && text[*pi1]=='\\';
		(*pi1)++;

	// Number constant, relaxed
	} else if (isdigit(text[i])) {
		*psyn = 3;
		for (*pi1=i+1; *pi1<ntext && (!strchr(puncs,text[*pi1])||text[*pi1]=='.'); (*pi1)++);

	// Token matches
	} else {
		size_t ntok = text[i] == '#';
		for (; i+ntok<ntext && !strchr(puncs,text[i+ntok]); ntok++);
		if (!ntok) ntok=1;
		*pi1 = i + ntok;

		// Match against C11 tokens
		switch(ntok) {
		// Generated: printf '\t\t'; python3 -c 'kws=["#if","#ifdef","#ifndef","#elif","#else","#endif","#include","#define","#undef","#line","#error","#pragma","alignof","break","case","continue","default","do","else","for","goto","if","return","sizeof","switch","while","_Generic","_Static_assert"];types=["auto","char","const","double","enum","extern","float","inline","int","long","register","restrict","short","signed","static","struct","typedef","union","unsigned","void","volatile","_Alignas","_Atomic","_Bool","_Complex","_Imaginary","_Noreturn","_Thread_local","ATOMIC_ADDRESS_LOCK_FREE","ATOMIC_CHAR16_T_LOCK_FREE","ATOMIC_CHAR32_T_LOCK_FREE","ATOMIC_CHAR_LOCK_FREE","ATOMIC_INT_LOCK_FREE","ATOMIC_LLONG_LOCK_FREE","ATOMIC_LONG_LOCK_FREE","ATOMIC_SHORT_LOCK_FREE","ATOMIC_WCHAR_T_LOCK_FREE","FILE","atomic_address","atomic_bool","atomic_char","atomic_char16_t","atomic_char32_t","atomic_flag","atomic_int","atomic_int_fast16_t","atomic_int_fast32_t","atomic_int_fast64_t","atomic_int_fast8_t","atomic_int_least16_t","atomic_int_least32_t","atomic_int_least64_t","atomic_int_least8_t","atomic_intmax_t","atomic_intptr_t","atomic_llong","atomic_long","atomic_ptrdiff_t","atomic_schar","atomic_short","atomic_size_t","atomic_uchar","atomic_uint","atomic_uint_fast16_t","atomic_uint_fast32_t","atomic_uint_fast64_t","atomic_uint_fast8_t","atomic_uint_least16_t","atomic_uint_least32_t","atomic_uint_least64_t","atomic_uint_least8_t","atomic_uintmax_t","atomic_uintptr_t","atomic_ullong","atomic_ulong","atomic_ushort","atomic_wchar_t","bool","char16_t","char32_t","clock_t","cnd_t","complex","constraint_handler_t","div_t","double_t","errno_t","fenv_t","fexcept_t","float_t","fpos_t","imaginary","imaxdiv_t","int16_t","int32_t","int64_t","int8_t","int_fast16_t","int_fast32_t","int_fast64_t","int_fast8_t","int_least16_t","int_least32_t","int_least64_t","int_least8_t","intmax_t","intptr_t","jmp_buf","ldiv_t","lldiv_t","max_align_t","mbstate_t","memory_order","mtx_t","once_flag","ptrdiff_t","rsize_t","sig_atomic_t","size_t","thrd_start_t","thrd_t","time_t","tss_dtor_t","tss_t","uint16_t","uint32_t","uint64_t","uint8_t","uint_fast16_t","uint_fast32_t","uint_fast64_t","uint_fast8_t","uint_least16_t","uint_least32_t","uint_least64_t","uint_least8_t","uintmax_t","uintptr_t","va_list","wchar_t","wctrans_t","wctype_t","wint_t","xtime"];consts=["ATOMIC_FLAG_INIT","BUFSIZ","CHAR_BIT","CHAR_MAX","CHAR_MIN","CLOCKS_PER_SEC","DBL_DECIMAL_DIG","DBL_DIG","DBL_EPSILON","DBL_HAS_SUBNORM","DBL_MANT_DIG","DBL_MAX","DBL_MAX_10_EXP","DBL_MAX_EXP","DBL_MIN","DBL_MIN_10_EXP","DBL_MIN_EXP","DBL_TRUE_MIN","DECIMAL_DIG","EDOM","EILSEQ","EOF","ERANGE","EXIT_FAILURE","EXIT_SUCCESS","FE_ALL_EXCEPT","FE_DFL_ENV","FE_DIVBYZERO","FE_DOWNWARD","FE_INEXACT","FE_INVALID","FE_OVERFLOW","FE_TONEAREST","FE_TOWARDZERO","FE_UNDERFLOW","FE_UPWARD","FLT_DECIMAL_DIG","FLT_DIG","FLT_EPSILON","FLT_EVAL_METHOD","FLT_HAS_SUBNORM","FLT_MANT_DIG","FLT_MAX","FLT_MAX_10_EXP","FLT_MAX_EXP","FLT_MIN","FLT_MIN_10_EXP","FLT_MIN_EXP","FLT_RADIX","FLT_ROUNDS","FLT_TRUE_MIN","FOPEN_MAX","FP_FAST_FMA","FP_FAST_FMAF","FP_FAST_FMAL","FP_ILOGB0","FP_ILOGBNAN","FP_INFINITE","FP_NAN","FP_NORMAL","FP_SUBNORMAL","FP_ZERO","HUGE_VAL","HUGE_VALF","HUGE_VALL","I","INFINITY","INT16_MAX","INT16_MIN","INT32_MAX","INT32_MIN","INT64_MAX","INT64_MIN","INT8_MAX","INT8_MIN","INTMAX_MAX","INTMAX_MIN","INTPTR_MAX","INTPTR_MIN","INT_FAST16_MAX","INT_FAST16_MIN","INT_FAST32_MAX","INT_FAST32_MIN","INT_FAST64_MAX","INT_FAST64_MIN","INT_FAST8_MAX","INT_FAST8_MIN","INT_LEAST16_MAX","INT_LEAST16_MIN","INT_LEAST32_MAX","INT_LEAST32_MIN","INT_LEAST64_MAX","INT_LEAST64_MIN","INT_LEAST8_MAX","INT_LEAST8_MIN","INT_MAX","INT_MIN","LC_ALL","LC_COLLATE","LC_CTYPE","LC_MONETARY","LC_NUMERIC","LC_TIME","LDBL_DECIMAL_DIG","LDBL_DIG","LDBL_EPSILON","LDBL_HAS_SUBNORM","LDBL_MANT_DIG","LDBL_MAX","LDBL_MAX_10_EXP","LDBL_MAX_EXP","LDBL_MIN","LDBL_MIN_10_EXP","LDBL_MIN_EXP","LDBL_TRUE_MIN","LLONG_MAX","LLONG_MIN","LONG_MAX","LONG_MIN","L_tmpnam","L_tmpnam_s","MATH_ERREXCEPT","MATH_ERRNO","MB_CUR_MAX","MB_LEN_MAX","NAN","NULL","ONCE_FLAG_INIT","PRIX16","PRIX32","PRIX64","PRIX8","PRIXFAST16","PRIXFAST32","PRIXFAST64","PRIXFAST8","PRIXLEAST16","PRIXLEAST32","PRIXLEAST64","PRIXLEAST8","PRIXMAX","PRIXPTR","PRId16","PRId32","PRId64","PRId8","PRIdFAST16","PRIdFAST32","PRIdFAST64","PRIdFAST8","PRIdLEAST16","PRIdLEAST32","PRIdLEAST64","PRIdLEAST8","PRIdMAX","PRIdPTR","PRIi16","PRIi32","PRIi64","PRIi8","PRIiFAST16","PRIiFAST32","PRIiFAST64","PRIiFAST8","PRIiLEAST16","PRIiLEAST32","PRIiLEAST64","PRIiLEAST8","PRIiMAX","PRIiPTR","PRIo16","PRIo32","PRIo64","PRIo8","PRIoFAST16","PRIoFAST32","PRIoFAST64","PRIoFAST8","PRIoLEAST16","PRIoLEAST32","PRIoLEAST64","PRIoLEAST8","PRIoMAX","PRIoPTR","PRIu16","PRIu32","PRIu64","PRIu8","PRIuFAST16","PRIuFAST32","PRIuFAST64","PRIuFAST8","PRIuLEAST16","PRIuLEAST32","PRIuLEAST64","PRIuLEAST8","PRIuMAX","PRIuPTR","PRIx16","PRIx32","PRIx64","PRIx8","PRIxFAST16","PRIxFAST32","PRIxFAST64","PRIxFAST8","PRIxLEAST16","PRIxLEAST32","PRIxLEAST64","PRIxLEAST8","PRIxMAX","PRIxPTR","PTRDIFF_MAX","PTRDIFF_MIN","RAND_MAX","RSIZE_MAX","SCHAR_MAX","SCHAR_MIN","SCNd16","SCNd32","SCNd64","SCNd8","SCNdFAST16","SCNdFAST32","SCNdFAST64","SCNdFAST8","SCNdLEAST16","SCNdLEAST32","SCNdLEAST64","SCNdLEAST8","SCNdMAX","SCNdPTR","SCNi16","SCNi32","SCNi64","SCNi8","SCNiFAST16","SCNiFAST32","SCNiFAST64","SCNiFAST8","SCNiLEAST16","SCNiLEAST32","SCNiLEAST64","SCNiLEAST8","SCNiMAX","SCNiPTR","SCNo16","SCNo32","SCNo64","SCNo8","SCNoFAST16","SCNoFAST32","SCNoFAST64","SCNoFAST8","SCNoLEAST16","SCNoLEAST32","SCNoLEAST64","SCNoLEAST8","SCNoMAX","SCNoPTR","SCNu16","SCNu32","SCNu64","SCNu8","SCNuFAST16","SCNuFAST32","SCNuFAST64","SCNuFAST8","SCNuLEAST16","SCNuLEAST32","SCNuLEAST64","SCNuLEAST8","SCNuMAX","SCNuPTR","SCNx16","SCNx32","SCNx64","SCNx8","SCNxFAST16","SCNxFAST32","SCNxFAST64","SCNxFAST8","SCNxLEAST16","SCNxLEAST32","SCNxLEAST64","SCNxLEAST8","SCNxMAX","SCNxPTR","SEEK_CUR","SEEK_END","SEEK_SET","SHRT_MAX","SHRT_MIN","SIGABRT","SIGFPE","SIGILL","SIGINT","SIGSEGV","SIGTERM","SIG_ATOMIC_MAX","SIG_ATOMIC_MIN","SIG_DFL","SIG_ERR","SIG_IGN","SIZE_MAX","TMP_MAX","TMP_MAX_S","TSS_DTOR_ITERATIONS","UCHAR_MAX","UINT16_MAX","UINT32_MAX","UINT64_MAX","UINT8_MAX","UINTMAX_MAX","UINTPTR_MAX","UINT_FAST16_MAX","UINT_FAST32_MAX","UINT_FAST64_MAX","UINT_FAST8_MAX","UINT_LEAST16_MAX","UINT_LEAST32_MAX","UINT_LEAST64_MAX","UINT_LEAST8_MAX","UINT_MAX","ULLONG_MAX","ULONG_MAX","USHRT_MAX","WCHAR_MAX","WCHAR_MIN","WEOF","WINT_MAX","WINT_MIN","_Complex_I","_IOFBF","_IOLBF","_IONBF","_Imaginary_I","__STDC_NO_COMPLEX__","__STDC_WANT_LIB_EXT1__","__alignas_is_defined","and","and_eq","bitand","bitor","compl","false","math_errhandling","mtx_plain","mtx_recursive","not","not_eq","or","or_eq","static_assert","stderr","stdin","stdout","thrd_busy","thrd_error","thrd_nomem","thrd_success","true","xor","xor_eq"];all=kws+types+consts;lens=set(map(len,all));print("".join(map(lambda n: "case {}:{}break;".format(n,"".join(map(lambda tok:"if(!memcmp(text+i,\"{}\",ntok)){{*psyn={};return;}}".format(tok,4 if tok in kws else 5 if tok in types else 3),filter(lambda tok:len(tok)==n,all)))),lens)))'
		case 1:if(!memcmp(text+i,"I",ntok)){*psyn=3;return;}break;case 2:if(!memcmp(text+i,"do",ntok)){*psyn=4;return;}if(!memcmp(text+i,"if",ntok)){*psyn=4;return;}if(!memcmp(text+i,"or",ntok)){*psyn=3;return;}break;case 3:if(!memcmp(text+i,"#if",ntok)){*psyn=4;return;}if(!memcmp(text+i,"for",ntok)){*psyn=4;return;}if(!memcmp(text+i,"int",ntok)){*psyn=5;return;}if(!memcmp(text+i,"EOF",ntok)){*psyn=3;return;}if(!memcmp(text+i,"NAN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"and",ntok)){*psyn=3;return;}if(!memcmp(text+i,"not",ntok)){*psyn=3;return;}if(!memcmp(text+i,"xor",ntok)){*psyn=3;return;}break;case 4:if(!memcmp(text+i,"case",ntok)){*psyn=4;return;}if(!memcmp(text+i,"else",ntok)){*psyn=4;return;}if(!memcmp(text+i,"goto",ntok)){*psyn=4;return;}if(!memcmp(text+i,"auto",ntok)){*psyn=5;return;}if(!memcmp(text+i,"char",ntok)){*psyn=5;return;}if(!memcmp(text+i,"enum",ntok)){*psyn=5;return;}if(!memcmp(text+i,"long",ntok)){*psyn=5;return;}if(!memcmp(text+i,"void",ntok)){*psyn=5;return;}if(!memcmp(text+i,"FILE",ntok)){*psyn=5;return;}if(!memcmp(text+i,"bool",ntok)){*psyn=5;return;}if(!memcmp(text+i,"EDOM",ntok)){*psyn=3;return;}if(!memcmp(text+i,"NULL",ntok)){*psyn=3;return;}if(!memcmp(text+i,"WEOF",ntok)){*psyn=3;return;}if(!memcmp(text+i,"true",ntok)){*psyn=3;return;}break;case 5:if(!memcmp(text+i,"#elif",ntok)){*psyn=4;return;}if(!memcmp(text+i,"#else",ntok)){*psyn=4;return;}if(!memcmp(text+i,"#line",ntok)){*psyn=4;return;}if(!memcmp(text+i,"break",ntok)){*psyn=4;return;}if(!memcmp(text+i,"while",ntok)){*psyn=4;return;}if(!memcmp(text+i,"const",ntok)){*psyn=5;return;}if(!memcmp(text+i,"float",ntok)){*psyn=5;return;}if(!memcmp(text+i,"short",ntok)){*psyn=5;return;}if(!memcmp(text+i,"union",ntok)){*psyn=5;return;}if(!memcmp(text+i,"_Bool",ntok)){*psyn=5;return;}if(!memcmp(text+i,"cnd_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"div_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"mtx_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"tss_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"xtime",ntok)){*psyn=5;return;}if(!memcmp(text+i,"PRIX8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRId8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIi8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIo8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIu8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIx8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNd8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNi8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNo8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNu8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNx8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"bitor",ntok)){*psyn=3;return;}if(!memcmp(text+i,"compl",ntok)){*psyn=3;return;}if(!memcmp(text+i,"false",ntok)){*psyn=3;return;}if(!memcmp(text+i,"or_eq",ntok)){*psyn=3;return;}if(!memcmp(text+i,"stdin",ntok)){*psyn=3;return;}break;case 6:if(!memcmp(text+i,"#ifdef",ntok)){*psyn=4;return;}if(!memcmp(text+i,"#endif",ntok)){*psyn=4;return;}if(!memcmp(text+i,"#undef",ntok)){*psyn=4;return;}if(!memcmp(text+i,"#error",ntok)){*psyn=4;return;}if(!memcmp(text+i,"return",ntok)){*psyn=4;return;}if(!memcmp(text+i,"sizeof",ntok)){*psyn=4;return;}if(!memcmp(text+i,"switch",ntok)){*psyn=4;return;}if(!memcmp(text+i,"double",ntok)){*psyn=5;return;}if(!memcmp(text+i,"extern",ntok)){*psyn=5;return;}if(!memcmp(text+i,"inline",ntok)){*psyn=5;return;}if(!memcmp(text+i,"signed",ntok)){*psyn=5;return;}if(!memcmp(text+i,"static",ntok)){*psyn=5;return;}if(!memcmp(text+i,"struct",ntok)){*psyn=5;return;}if(!memcmp(text+i,"fenv_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"fpos_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"int8_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"ldiv_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"size_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"thrd_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"time_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"wint_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"BUFSIZ",ntok)){*psyn=3;return;}if(!memcmp(text+i,"EILSEQ",ntok)){*psyn=3;return;}if(!memcmp(text+i,"ERANGE",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FP_NAN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"LC_ALL",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIX16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIX32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIX64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRId16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRId32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRId64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIi16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIi32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIi64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIo16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIo32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIo64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIu16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIu32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIu64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIx16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIx32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIx64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNd16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNd32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNd64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNi16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNi32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNi64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNo16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNo32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNo64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNu16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNu32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNu64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNx16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNx32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNx64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SIGFPE",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SIGILL",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SIGINT",ntok)){*psyn=3;return;}if(!memcmp(text+i,"_IOFBF",ntok)){*psyn=3;return;}if(!memcmp(text+i,"_IOLBF",ntok)){*psyn=3;return;}if(!memcmp(text+i,"_IONBF",ntok)){*psyn=3;return;}if(!memcmp(text+i,"and_eq",ntok)){*psyn=3;return;}if(!memcmp(text+i,"bitand",ntok)){*psyn=3;return;}if(!memcmp(text+i,"not_eq",ntok)){*psyn=3;return;}if(!memcmp(text+i,"stderr",ntok)){*psyn=3;return;}if(!memcmp(text+i,"stdout",ntok)){*psyn=3;return;}if(!memcmp(text+i,"xor_eq",ntok)){*psyn=3;return;}break;case 7:if(!memcmp(text+i,"#ifndef",ntok)){*psyn=4;return;}if(!memcmp(text+i,"#define",ntok)){*psyn=4;return;}if(!memcmp(text+i,"#pragma",ntok)){*psyn=4;return;}if(!memcmp(text+i,"alignof",ntok)){*psyn=4;return;}if(!memcmp(text+i,"default",ntok)){*psyn=4;return;}if(!memcmp(text+i,"typedef",ntok)){*psyn=5;return;}if(!memcmp(text+i,"_Atomic",ntok)){*psyn=5;return;}if(!memcmp(text+i,"clock_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"complex",ntok)){*psyn=5;return;}if(!memcmp(text+i,"errno_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"float_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"int16_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"int32_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"int64_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"jmp_buf",ntok)){*psyn=5;return;}if(!memcmp(text+i,"lldiv_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"rsize_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"uint8_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"va_list",ntok)){*psyn=5;return;}if(!memcmp(text+i,"wchar_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"DBL_DIG",ntok)){*psyn=3;return;}if(!memcmp(text+i,"DBL_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"DBL_MIN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FLT_DIG",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FLT_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FLT_MIN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FP_ZERO",ntok)){*psyn=3;return;}if(!memcmp(text+i,"INT_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"INT_MIN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"LC_TIME",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIXMAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIXPTR",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIdMAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIdPTR",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIiMAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIiPTR",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIoMAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIoPTR",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIuMAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIuPTR",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIxMAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIxPTR",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNdMAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNdPTR",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNiMAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNiPTR",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNoMAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNoPTR",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNuMAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNuPTR",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNxMAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNxPTR",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SIGABRT",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SIGSEGV",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SIGTERM",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SIG_DFL",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SIG_ERR",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SIG_IGN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"TMP_MAX",ntok)){*psyn=3;return;}break;case 8:if(!memcmp(text+i,"#include",ntok)){*psyn=4;return;}if(!memcmp(text+i,"continue",ntok)){*psyn=4;return;}if(!memcmp(text+i,"_Generic",ntok)){*psyn=4;return;}if(!memcmp(text+i,"register",ntok)){*psyn=5;return;}if(!memcmp(text+i,"restrict",ntok)){*psyn=5;return;}if(!memcmp(text+i,"unsigned",ntok)){*psyn=5;return;}if(!memcmp(text+i,"volatile",ntok)){*psyn=5;return;}if(!memcmp(text+i,"_Alignas",ntok)){*psyn=5;return;}if(!memcmp(text+i,"_Complex",ntok)){*psyn=5;return;}if(!memcmp(text+i,"char16_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"char32_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"double_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"intmax_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"intptr_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"uint16_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"uint32_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"uint64_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"wctype_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"CHAR_BIT",ntok)){*psyn=3;return;}if(!memcmp(text+i,"CHAR_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"CHAR_MIN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"HUGE_VAL",ntok)){*psyn=3;return;}if(!memcmp(text+i,"INFINITY",ntok)){*psyn=3;return;}if(!memcmp(text+i,"INT8_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"INT8_MIN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"LC_CTYPE",ntok)){*psyn=3;return;}if(!memcmp(text+i,"LDBL_DIG",ntok)){*psyn=3;return;}if(!memcmp(text+i,"LDBL_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"LDBL_MIN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"LONG_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"LONG_MIN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"L_tmpnam",ntok)){*psyn=3;return;}if(!memcmp(text+i,"RAND_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SEEK_CUR",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SEEK_END",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SEEK_SET",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SHRT_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SHRT_MIN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SIZE_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"UINT_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"WINT_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"WINT_MIN",ntok)){*psyn=3;return;}break;case 9:if(!memcmp(text+i,"_Noreturn",ntok)){*psyn=5;return;}if(!memcmp(text+i,"fexcept_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"imaginary",ntok)){*psyn=5;return;}if(!memcmp(text+i,"imaxdiv_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"mbstate_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"once_flag",ntok)){*psyn=5;return;}if(!memcmp(text+i,"ptrdiff_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"uintmax_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"uintptr_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"wctrans_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"FE_UPWARD",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FLT_RADIX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FOPEN_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FP_ILOGB0",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FP_NORMAL",ntok)){*psyn=3;return;}if(!memcmp(text+i,"HUGE_VALF",ntok)){*psyn=3;return;}if(!memcmp(text+i,"HUGE_VALL",ntok)){*psyn=3;return;}if(!memcmp(text+i,"INT16_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"INT16_MIN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"INT32_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"INT32_MIN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"INT64_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"INT64_MIN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"LLONG_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"LLONG_MIN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIXFAST8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIdFAST8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIiFAST8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIoFAST8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIuFAST8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIxFAST8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"RSIZE_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCHAR_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCHAR_MIN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNdFAST8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNiFAST8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNoFAST8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNuFAST8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNxFAST8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"TMP_MAX_S",ntok)){*psyn=3;return;}if(!memcmp(text+i,"UCHAR_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"UINT8_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"ULONG_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"USHRT_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"WCHAR_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"WCHAR_MIN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"mtx_plain",ntok)){*psyn=3;return;}if(!memcmp(text+i,"thrd_busy",ntok)){*psyn=3;return;}break;case 10:if(!memcmp(text+i,"_Imaginary",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_int",ntok)){*psyn=5;return;}if(!memcmp(text+i,"tss_dtor_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"FE_DFL_ENV",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FE_INEXACT",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FE_INVALID",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FLT_ROUNDS",ntok)){*psyn=3;return;}if(!memcmp(text+i,"INTMAX_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"INTMAX_MIN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"INTPTR_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"INTPTR_MIN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"LC_COLLATE",ntok)){*psyn=3;return;}if(!memcmp(text+i,"LC_NUMERIC",ntok)){*psyn=3;return;}if(!memcmp(text+i,"L_tmpnam_s",ntok)){*psyn=3;return;}if(!memcmp(text+i,"MATH_ERRNO",ntok)){*psyn=3;return;}if(!memcmp(text+i,"MB_CUR_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"MB_LEN_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIXFAST16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIXFAST32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIXFAST64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIXLEAST8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIdFAST16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIdFAST32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIdFAST64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIdLEAST8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIiFAST16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIiFAST32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIiFAST64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIiLEAST8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIoFAST16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIoFAST32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIoFAST64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIoLEAST8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIuFAST16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIuFAST32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIuFAST64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIuLEAST8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIxFAST16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIxFAST32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIxFAST64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIxLEAST8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNdFAST16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNdFAST32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNdFAST64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNdLEAST8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNiFAST16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNiFAST32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNiFAST64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNiLEAST8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNoFAST16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNoFAST32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNoFAST64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNoLEAST8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNuFAST16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNuFAST32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNuFAST64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNuLEAST8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNxFAST16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNxFAST32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNxFAST64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNxLEAST8",ntok)){*psyn=3;return;}if(!memcmp(text+i,"UINT16_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"UINT32_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"UINT64_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"ULLONG_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"_Complex_I",ntok)){*psyn=3;return;}if(!memcmp(text+i,"thrd_error",ntok)){*psyn=3;return;}if(!memcmp(text+i,"thrd_nomem",ntok)){*psyn=3;return;}break;case 11:if(!memcmp(text+i,"atomic_bool",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_char",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_flag",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_long",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_uint",ntok)){*psyn=5;return;}if(!memcmp(text+i,"int_fast8_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"max_align_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"DBL_EPSILON",ntok)){*psyn=3;return;}if(!memcmp(text+i,"DBL_MAX_EXP",ntok)){*psyn=3;return;}if(!memcmp(text+i,"DBL_MIN_EXP",ntok)){*psyn=3;return;}if(!memcmp(text+i,"DECIMAL_DIG",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FE_DOWNWARD",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FE_OVERFLOW",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FLT_EPSILON",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FLT_MAX_EXP",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FLT_MIN_EXP",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FP_FAST_FMA",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FP_ILOGBNAN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FP_INFINITE",ntok)){*psyn=3;return;}if(!memcmp(text+i,"LC_MONETARY",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIXLEAST16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIXLEAST32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIXLEAST64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIdLEAST16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIdLEAST32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIdLEAST64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIiLEAST16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIiLEAST32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIiLEAST64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIoLEAST16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIoLEAST32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIoLEAST64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIuLEAST16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIuLEAST32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIuLEAST64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIxLEAST16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIxLEAST32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PRIxLEAST64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PTRDIFF_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"PTRDIFF_MIN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNdLEAST16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNdLEAST32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNdLEAST64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNiLEAST16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNiLEAST32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNiLEAST64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNoLEAST16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNoLEAST32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNoLEAST64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNuLEAST16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNuLEAST32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNuLEAST64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNxLEAST16",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNxLEAST32",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SCNxLEAST64",ntok)){*psyn=3;return;}if(!memcmp(text+i,"UINTMAX_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"UINTPTR_MAX",ntok)){*psyn=3;return;}break;case 12:if(!memcmp(text+i,"atomic_llong",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_schar",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_short",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_uchar",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_ulong",ntok)){*psyn=5;return;}if(!memcmp(text+i,"int_fast16_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"int_fast32_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"int_fast64_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"int_least8_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"memory_order",ntok)){*psyn=5;return;}if(!memcmp(text+i,"sig_atomic_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"thrd_start_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"uint_fast8_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"DBL_MANT_DIG",ntok)){*psyn=3;return;}if(!memcmp(text+i,"DBL_TRUE_MIN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"EXIT_FAILURE",ntok)){*psyn=3;return;}if(!memcmp(text+i,"EXIT_SUCCESS",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FE_DIVBYZERO",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FE_TONEAREST",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FE_UNDERFLOW",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FLT_MANT_DIG",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FLT_TRUE_MIN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FP_FAST_FMAF",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FP_FAST_FMAL",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FP_SUBNORMAL",ntok)){*psyn=3;return;}if(!memcmp(text+i,"LDBL_EPSILON",ntok)){*psyn=3;return;}if(!memcmp(text+i,"LDBL_MAX_EXP",ntok)){*psyn=3;return;}if(!memcmp(text+i,"LDBL_MIN_EXP",ntok)){*psyn=3;return;}if(!memcmp(text+i,"_Imaginary_I",ntok)){*psyn=3;return;}if(!memcmp(text+i,"thrd_success",ntok)){*psyn=3;return;}break;case 13:if(!memcmp(text+i,"_Thread_local",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_size_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_ullong",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_ushort",ntok)){*psyn=5;return;}if(!memcmp(text+i,"int_least16_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"int_least32_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"int_least64_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"uint_fast16_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"uint_fast32_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"uint_fast64_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"uint_least8_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"FE_ALL_EXCEPT",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FE_TOWARDZERO",ntok)){*psyn=3;return;}if(!memcmp(text+i,"INT_FAST8_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"INT_FAST8_MIN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"LDBL_MANT_DIG",ntok)){*psyn=3;return;}if(!memcmp(text+i,"LDBL_TRUE_MIN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"mtx_recursive",ntok)){*psyn=3;return;}if(!memcmp(text+i,"static_assert",ntok)){*psyn=3;return;}break;case 14:if(!memcmp(text+i,"_Static_assert",ntok)){*psyn=4;return;}if(!memcmp(text+i,"atomic_address",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_wchar_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"uint_least16_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"uint_least32_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"uint_least64_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"CLOCKS_PER_SEC",ntok)){*psyn=3;return;}if(!memcmp(text+i,"DBL_MAX_10_EXP",ntok)){*psyn=3;return;}if(!memcmp(text+i,"DBL_MIN_10_EXP",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FLT_MAX_10_EXP",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FLT_MIN_10_EXP",ntok)){*psyn=3;return;}if(!memcmp(text+i,"INT_FAST16_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"INT_FAST16_MIN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"INT_FAST32_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"INT_FAST32_MIN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"INT_FAST64_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"INT_FAST64_MIN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"INT_LEAST8_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"INT_LEAST8_MIN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"MATH_ERREXCEPT",ntok)){*psyn=3;return;}if(!memcmp(text+i,"ONCE_FLAG_INIT",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SIG_ATOMIC_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"SIG_ATOMIC_MIN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"UINT_FAST8_MAX",ntok)){*psyn=3;return;}break;case 15:if(!memcmp(text+i,"atomic_char16_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_char32_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_intmax_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_intptr_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"DBL_DECIMAL_DIG",ntok)){*psyn=3;return;}if(!memcmp(text+i,"DBL_HAS_SUBNORM",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FLT_DECIMAL_DIG",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FLT_EVAL_METHOD",ntok)){*psyn=3;return;}if(!memcmp(text+i,"FLT_HAS_SUBNORM",ntok)){*psyn=3;return;}if(!memcmp(text+i,"INT_LEAST16_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"INT_LEAST16_MIN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"INT_LEAST32_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"INT_LEAST32_MIN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"INT_LEAST64_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"INT_LEAST64_MIN",ntok)){*psyn=3;return;}if(!memcmp(text+i,"LDBL_MAX_10_EXP",ntok)){*psyn=3;return;}if(!memcmp(text+i,"LDBL_MIN_10_EXP",ntok)){*psyn=3;return;}if(!memcmp(text+i,"UINT_FAST16_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"UINT_FAST32_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"UINT_FAST64_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"UINT_LEAST8_MAX",ntok)){*psyn=3;return;}break;case 16:if(!memcmp(text+i,"atomic_ptrdiff_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_uintmax_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_uintptr_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"ATOMIC_FLAG_INIT",ntok)){*psyn=3;return;}if(!memcmp(text+i,"LDBL_DECIMAL_DIG",ntok)){*psyn=3;return;}if(!memcmp(text+i,"LDBL_HAS_SUBNORM",ntok)){*psyn=3;return;}if(!memcmp(text+i,"UINT_LEAST16_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"UINT_LEAST32_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"UINT_LEAST64_MAX",ntok)){*psyn=3;return;}if(!memcmp(text+i,"math_errhandling",ntok)){*psyn=3;return;}break;case 18:if(!memcmp(text+i,"atomic_int_fast8_t",ntok)){*psyn=5;return;}break;case 19:if(!memcmp(text+i,"atomic_int_fast16_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_int_fast32_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_int_fast64_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_int_least8_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_uint_fast8_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"TSS_DTOR_ITERATIONS",ntok)){*psyn=3;return;}if(!memcmp(text+i,"__STDC_NO_COMPLEX__",ntok)){*psyn=3;return;}break;case 20:if(!memcmp(text+i,"ATOMIC_INT_LOCK_FREE",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_int_least16_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_int_least32_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_int_least64_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_uint_fast16_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_uint_fast32_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_uint_fast64_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_uint_least8_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"constraint_handler_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"__alignas_is_defined",ntok)){*psyn=3;return;}break;case 21:if(!memcmp(text+i,"ATOMIC_CHAR_LOCK_FREE",ntok)){*psyn=5;return;}if(!memcmp(text+i,"ATOMIC_LONG_LOCK_FREE",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_uint_least16_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_uint_least32_t",ntok)){*psyn=5;return;}if(!memcmp(text+i,"atomic_uint_least64_t",ntok)){*psyn=5;return;}break;case 22:if(!memcmp(text+i,"ATOMIC_LLONG_LOCK_FREE",ntok)){*psyn=5;return;}if(!memcmp(text+i,"ATOMIC_SHORT_LOCK_FREE",ntok)){*psyn=5;return;}if(!memcmp(text+i,"__STDC_WANT_LIB_EXT1__",ntok)){*psyn=3;return;}break;case 24:if(!memcmp(text+i,"ATOMIC_ADDRESS_LOCK_FREE",ntok)){*psyn=5;return;}if(!memcmp(text+i,"ATOMIC_WCHAR_T_LOCK_FREE",ntok)){*psyn=5;return;}break;case 25:if(!memcmp(text+i,"ATOMIC_CHAR16_T_LOCK_FREE",ntok)){*psyn=5;return;}if(!memcmp(text+i,"ATOMIC_CHAR32_T_LOCK_FREE",ntok)){*psyn=5;return;}break;
		}

		// Match against POSIX 2018 tokens
		// (with CX, IP6, and RS)
		// minus C11
		switch(ntok) {
		// Generated: printf '\t\t'; python3 -c 'types=["DIR","blkcnt_t","blksize_t","cc_t","clockid_t","dev_t","fd_set","fsblkcnt_t","fsfilcnt_t","gid_t","glob_t","iconv_t","id_t","idtype_t","in_addr_t","in_port_t","ino_t","locale_t","mcontext_t","mode_t","nfds_t","nl_catd","nl_item","nlink_t","off_t","pid_t","pthread_attr_t","pthread_barrier_t","pthread_barrierattr_t","pthread_cond_t","pthread_condattr_t","pthread_key_t","pthread_mutex_t","pthread_mutexattr_t","pthread_once_t","pthread_rwlock_t","pthread_rwlockattr_t","pthread_spinlock_t","pthread_t","regex_t","regmatch_t","regoff_t","sa_family_t","sem_t","siginfo_t","sigjmp_buf","sigset_t","socklen_t","speed_t","ssize_t","stack_t","suseconds_t","tcflag_t","timer_t","ucontext_t","uid_t","wordexp_t"];consts=["ABDAY_1","ABDAY_2","ABDAY_3","ABDAY_4","ABDAY_5","ABDAY_6","ABDAY_7","ABMON_1","ABMON_10","ABMON_11","ABMON_12","ABMON_2","ABMON_3","ABMON_4","ABMON_5","ABMON_6","ABMON_7","ABMON_8","ABMON_9","AF_INET","AF_INET6","AF_UNIX","AF_UNSPEC","AIO_ALLDONE","AIO_CANCELED","AIO_LISTIO_MAX","AIO_MAX","AIO_NOTCANCELED","AIO_PRIO_DELTA_MAX","AI_ADDRCONFIG","AI_ALL","AI_CANONNAME","AI_NUMERICHOST","AI_NUMERICSERV","AI_PASSIVE","AI_V4MAPPED","ALT_DIGITS","AM_STR","AREGTYPE","ARG_MAX","ATEXIT_MAX","AT_EACCESS","AT_FDCWD","AT_REMOVEDIR","AT_SYMLINK_FOLLOW","AT_SYMLINK_NOFOLLOW","B0","B110","B1200","B134","B150","B1800","B19200","B200","B2400","B300","B38400","B4800","B50","B600","B75","B9600","BC_BASE_MAX","BC_DIM_MAX","BC_SCALE_MAX","BC_STRING_MAX","BLKTYPE","BRKINT","BUS_ADRALN","BUS_ADRERR","BUS_OBJERR","CHARCLASS_NAME_MAX","CHILD_MAX","CHRTYPE","CLD_CONTINUED","CLD_DUMPED","CLD_EXITED","CLD_KILLED","CLD_STOPPED","CLD_TRAPPED","CLOCAL","CLOCK_REALTIME","CODESET","COLL_WEIGHTS_MAX","CONTTYPE","CREAD","CRNCYSTR","CS5","CS6","CS7","CS8","CSIZE","CSTOPB","C_IRGRP","C_IROTH","C_IRUSR","C_ISBLK","C_ISCHR","C_ISCTG","C_ISDIR","C_ISFIFO","C_ISGID","C_ISLNK","C_ISREG","C_ISSOCK","C_ISUID","C_ISVTX","C_IWGRP","C_IWOTH","C_IWUSR","C_IXGRP","C_IXOTH","C_IXUSR","DAY_1","DAY_2","DAY_3","DAY_4","DAY_5","DAY_6","DAY_7","DELAYTIMER_MAX","DIRTYPE","D_FMT","D_T_FMT","E2BIG","EACCES","EADDRINUSE","EADDRNOTAVAIL","EAFNOSUPPORT","EAGAIN","EAI_AGAIN","EAI_BADFLAGS","EAI_FAIL","EAI_FAMILY","EAI_MEMORY","EAI_NONAME","EAI_OVERFLOW","EAI_SERVICE","EAI_SOCKTYPE","EAI_SYSTEM","EALREADY","EBADF","EBADMSG","EBUSY","ECANCELED","ECHILD","ECHO","ECHOE","ECHOK","ECHONL","ECONNABORTED","ECONNREFUSED","ECONNRESET","EDEADLK","EDESTADDRREQ","EDQUOT","EEXIST","EFAULT","EFBIG","EHOSTUNREACH","EIDRM","EINPROGRESS","EINTR","EINVAL","EIO","EISCONN","EISDIR","ELOOP","EMFILE","EMLINK","EMSGSIZE","EMULTIHOP","ENAMETOOLONG","ENETDOWN","ENETRESET","ENETUNREACH","ENFILE","ENOBUFS","ENODEV","ENOENT","ENOEXEC","ENOLCK","ENOLINK","ENOMEM","ENOMSG","ENOPROTOOPT","ENOSPC","ENOSYS","ENOTCONN","ENOTDIR","ENOTEMPTY","ENOTRECOVERABLE","ENOTSOCK","ENOTSUP","ENOTTY","ENXIO","EOPNOTSUPP","EOVERFLOW","EOWNERDEAD","EPERM","EPIPE","EPROTO","EPROTONOSUPPORT","EPROTOTYPE","ERA","ERA_D_FMT","ERA_D_T_FMT","ERA_T_FMT","EROFS","ESPIPE","ESRCH","ESTALE","ETIMEDOUT","ETXTBSY","EWOULDBLOCK","EXDEV","EXPR_NEST_MAX","FD_CLOEXEC","FD_SETSIZE","FIFOTYPE","FILESIZEBITS","FNM_NOESCAPE","FNM_NOMATCH","FNM_PATHNAME","FNM_PERIOD","FPE_FLTDIV","FPE_FLTINV","FPE_FLTOVF","FPE_FLTRES","FPE_FLTSUB","FPE_FLTUND","FPE_INTDIV","FPE_INTOVF","F_DUPFD","F_DUPFD_CLOEXEC","F_GETFD","F_GETFL","F_GETLK","F_GETOWN","F_OK","F_RDLCK","F_SETFD","F_SETFL","F_SETLK","F_SETLKW","F_SETOWN","F_UNLCK","F_WRLCK","GLOB_ABORTED","GLOB_APPEND","GLOB_DOOFFS","GLOB_ERR","GLOB_MARK","GLOB_NOCHECK","GLOB_NOESCAPE","GLOB_NOMATCH","GLOB_NOSORT","GLOB_NOSPACE","HOST_NAME_MAX","HUPCL","ICANON","ICRNL","IEXTEN","IF_NAMESIZE","IGNBRK","IGNCR","IGNPAR","ILL_BADSTK","ILL_COPROC","ILL_ILLADR","ILL_ILLOPC","ILL_ILLOPN","ILL_ILLTRP","ILL_PRVOPC","ILL_PRVREG","IN6_IS_ADDR_LINKLOCAL","IN6_IS_ADDR_LOOPBACK","IN6_IS_ADDR_MC_GLOBAL","IN6_IS_ADDR_MC_LINKLOCAL","IN6_IS_ADDR_MC_NODELOCAL","IN6_IS_ADDR_MC_ORGLOCAL","IN6_IS_ADDR_MC_SITELOCAL","IN6_IS_ADDR_MULTICAST","IN6_IS_ADDR_SITELOCAL","IN6_IS_ADDR_UNSPECIFIED","IN6_IS_ADDR_V4COMPAT","IN6_IS_ADDR_V4MAPPED","INADDR_ANY","INADDR_BROADCAST","INET_ADDRSTRLEN","INLCR","INPCK","IPPROTO_ICMP","IPPROTO_IP","IPPROTO_IPV6","IPPROTO_RAW","IPPROTO_TCP","IPPROTO_UDP","IPV6_JOIN_GROUP","IPV6_LEAVE_GROUP","IPV6_MULTICAST_HOPS","IPV6_MULTICAST_IF","IPV6_MULTICAST_LOOP","IPV6_UNICAST_HOPS","IPV6_V6ONLY","ISIG","ISTRIP","IXANY","IXOFF","IXON","LC_ALL_MASK","LC_COLLATE_MASK","LC_CTYPE_MASK","LC_GLOBAL_LOCALE","LC_MESSAGES","LC_MESSAGES_MASK","LC_MONETARY_MASK","LC_NUMERIC_MASK","LC_TIME_MASK","LINE_MAX","LINK_MAX","LIO_NOP","LIO_NOWAIT","LIO_READ","LIO_WAIT","LIO_WRITE","LNKTYPE","LOGIN_NAME_MAX","LONG_BIT","L_ctermid","MAGIC","MAP_FAILED","MAP_FIXED","MAP_PRIVATE","MAP_SHARED","MAX_CANON","MAX_INPUT","MON_1","MON_10","MON_11","MON_12","MON_2","MON_3","MON_4","MON_5","MON_6","MON_7","MON_8","MON_9","MSG_CTRUNC","MSG_DONTROUTE","MSG_EOR","MSG_NOSIGNAL","MSG_OOB","MSG_PEEK","MSG_TRUNC","MSG_WAITALL","NAME_MAX","NCCS","NGROUPS_MAX","NI_DGRAM","NI_NAMEREQD","NI_NOFQDN","NI_NUMERICHOST","NI_NUMERICSCOPE","NI_NUMERICSERV","NL_ARGMAX","NL_CAT_LOCALE","NL_MSGMAX","NL_SETD","NL_SETMAX","NL_TEXTMAX","NOEXPR","NOFLSH","OPEN_MAX","OPOST","O_ACCMODE","O_APPEND","O_CLOEXEC","O_CREAT","O_DIRECTORY","O_EXCL","O_EXEC","O_NOCTTY","O_NOFOLLOW","O_NONBLOCK","O_RDONLY","O_RDWR","O_SEARCH","O_SYNC","O_TRUNC","O_TTY_INIT","O_WRONLY","PAGESIZE","PARENB","PARMRK","PARODD","PATH_MAX","PIPE_BUF","PM_STR","POLLERR","POLLHUP","POLLIN","POLLNVAL","POLLOUT","POLLPRI","POLLRDBAND","POLLRDNORM","POLLWRBAND","POLLWRNORM","PROT_EXEC","PROT_NONE","PROT_READ","PROT_WRITE","PTHREAD_BARRIER_SERIAL_THREAD","PTHREAD_CANCELED","PTHREAD_CANCEL_ASYNCHRONOUS","PTHREAD_CANCEL_DEFERRED","PTHREAD_CANCEL_DISABLE","PTHREAD_CANCEL_ENABLE","PTHREAD_COND_INITIALIZER","PTHREAD_CREATE_DETACHED","PTHREAD_CREATE_JOINABLE","PTHREAD_DESTRUCTOR_ITERATIONS","PTHREAD_KEYS_MAX","PTHREAD_MUTEX_DEFAULT","PTHREAD_MUTEX_ERRORCHECK","PTHREAD_MUTEX_INITIALIZER","PTHREAD_MUTEX_NORMAL","PTHREAD_MUTEX_RECURSIVE","PTHREAD_MUTEX_ROBUST","PTHREAD_MUTEX_STALLED","PTHREAD_ONCE_INIT","PTHREAD_PROCESS_PRIVATE","PTHREAD_PROCESS_SHARED","PTHREAD_RWLOCK_INITIALIZER","PTHREAD_STACK_MIN","PTHREAD_THREADS_MAX","P_ALL","P_PGID","P_PID","RADIXCHAR","REGTYPE","REG_BADBR","REG_BADPAT","REG_BADRPT","REG_EBRACE","REG_EBRACK","REG_ECOLLATE","REG_ECTYPE","REG_EESCAPE","REG_EPAREN","REG_ERANGE","REG_ESPACE","REG_ESUBREG","REG_EXTENDED","REG_ICASE","REG_NEWLINE","REG_NOMATCH","REG_NOSUB","REG_NOTBOL","REG_NOTEOL","RE_DUP_MAX","RTLD_GLOBAL","RTLD_LAZY","RTLD_LOCAL","RTLD_NOW","RTSIG_MAX","R_OK","SA_NOCLDSTOP","SA_NODEFER","SA_RESETHAND","SA_RESTART","SA_SIGINFO","SCM_RIGHTS","SEGV_ACCERR","SEGV_MAPERR","SEM_FAILED","SEM_NSEMS_MAX","SEM_VALUE_MAX","SHUT_RD","SHUT_RDWR","SHUT_WR","SIGALRM","SIGBUS","SIGCHLD","SIGCONT","SIGEV_NONE","SIGEV_SIGNAL","SIGEV_THREAD","SIGHUP","SIGKILL","SIGPIPE","SIGQUEUE_MAX","SIGQUIT","SIGRTMAX","SIGRTMIN","SIGSTOP","SIGTRAP","SIGTSTP","SIGTTIN","SIGTTOU","SIGURG","SIGUSR1","SIGUSR2","SIG_BLOCK","SIG_SETMASK","SIG_UNBLOCK","SI_ASYNCIO","SI_MESGQ","SI_QUEUE","SI_TIMER","SI_USER","SOCK_DGRAM","SOCK_RAW","SOCK_SEQPACKET","SOCK_STREAM","SOL_SOCKET","SOMAXCONN","SO_ACCEPTCONN","SO_BROADCAST","SO_DEBUG","SO_DONTROUTE","SO_ERROR","SO_KEEPALIVE","SO_LINGER","SO_OOBINLINE","SO_RCVBUF","SO_RCVLOWAT","SO_RCVTIMEO","SO_REUSEADDR","SO_SNDBUF","SO_SNDLOWAT","SO_SNDTIMEO","SO_TYPE","SSIZE_MAX","STDERR_FILENO","STDIN_FILENO","STDOUT_FILENO","STREAM_MAX","ST_NOSUID","ST_RDONLY","SYMLINK_MAX","SYMLOOP_MAX","SYMTYPE","S_IRGRP","S_IROTH","S_IRUSR","S_IRWXG","S_IRWXO","S_IRWXU","S_ISGID","S_ISUID","S_IWGRP","S_IWOTH","S_IWUSR","S_IXGRP","S_IXOTH","S_IXUSR","TCIFLUSH","TCIOFF","TCIOFLUSH","TCION","TCOFLUSH","TCOOFF","TCOON","TCP_NODELAY","TCSADRAIN","TCSAFLUSH","TCSANOW","TGEXEC","TGREAD","TGWRITE","THOUSEP","TIMER_ABSTIME","TIMER_MAX","TMAGIC","TMAGLEN","TOEXEC","TOREAD","TOSTOP","TOWRITE","TSGID","TSUID","TTY_NAME_MAX","TUEXEC","TUREAD","TUWRITE","TVERSION","TVERSLEN","TZNAME_MAX","T_FMT","T_FMT_AMPM","UTIME_NOW","UTIME_OMIT","VEOF","VEOL","VERASE","VINTR","VKILL","VMIN","VQUIT","VSTART","VSTOP","VSUSP","VTIME","WEXITED","WNOHANG","WNOWAIT","WORD_BIT","WRDE_APPEND","WRDE_BADCHAR","WRDE_BADVAL","WRDE_CMDSUB","WRDE_DOOFFS","WRDE_NOCMD","WRDE_NOSPACE","WRDE_REUSE","WRDE_SHOWERR","WRDE_SYNTAX","WRDE_UNDEF","WSTOPPED","WUNTRACED","W_OK","X_OK","YESEXPR","_CS_PATH","_CS_POSIX_V7_ILP32_OFF32_CFLAGS","_CS_POSIX_V7_ILP32_OFF32_LDFLAGS","_CS_POSIX_V7_ILP32_OFF32_LIBS","_CS_POSIX_V7_ILP32_OFFBIG_CFLAGS","_CS_POSIX_V7_ILP32_OFFBIG_LDFLAGS","_CS_POSIX_V7_ILP32_OFFBIG_LIBS","_CS_POSIX_V7_LP64_OFF64_CFLAGS","_CS_POSIX_V7_LP64_OFF64_LDFLAGS","_CS_POSIX_V7_LP64_OFF64_LIBS","_CS_POSIX_V7_LPBIG_OFFBIG_CFLAGS","_CS_POSIX_V7_LPBIG_OFFBIG_LDFLAGS","_CS_POSIX_V7_LPBIG_OFFBIG_LIBS","_CS_POSIX_V7_THREADS_CFLAGS","_CS_POSIX_V7_THREADS_LDFLAGS","_CS_POSIX_V7_WIDTH_RESTRICTED_ENVS","_CS_V7_ENV","_PC_2_SYMLINKS","_PC_ALLOC_SIZE_MIN","_PC_ASYNC_IO","_PC_CHOWN_RESTRICTED","_PC_FILESIZEBITS","_PC_LINK_MAX","_PC_MAX_CANON","_PC_MAX_INPUT","_PC_NAME_MAX","_PC_NO_TRUNC","_PC_PATH_MAX","_PC_PIPE_BUF","_PC_PRIO_IO","_PC_REC_INCR_XFER_SIZE","_PC_REC_MAX_XFER_SIZE","_PC_REC_MIN_XFER_SIZE","_PC_REC_XFER_ALIGN","_PC_SYMLINK_MAX","_PC_SYNC_IO","_PC_TIMESTAMP_RESOLUTION","_PC_VDISABLE","_POSIX2_BC_BASE_MAX","_POSIX2_BC_DIM_MAX","_POSIX2_BC_SCALE_MAX","_POSIX2_BC_STRING_MAX","_POSIX2_CHARCLASS_NAME_MAX","_POSIX2_CHAR_TERM","_POSIX2_COLL_WEIGHTS_MAX","_POSIX2_C_BIND","_POSIX2_EXPR_NEST_MAX","_POSIX2_LINE_MAX","_POSIX2_LOCALEDEF","_POSIX2_RE_DUP_MAX","_POSIX2_SYMLINKS","_POSIX2_VERSION","_POSIX_AIO_LISTIO_MAX","_POSIX_AIO_MAX","_POSIX_ARG_MAX","_POSIX_ASYNCHRONOUS_IO","_POSIX_ASYNC_IO","_POSIX_BARRIERS","_POSIX_CHILD_MAX","_POSIX_CHOWN_RESTRICTED","_POSIX_CLOCKRES_MIN","_POSIX_CLOCK_SELECTION","_POSIX_DELAYTIMER_MAX","_POSIX_HOST_NAME_MAX","_POSIX_IPV6","_POSIX_JOB_CONTROL","_POSIX_LINK_MAX","_POSIX_LOGIN_NAME_MAX","_POSIX_MAPPED_FILES","_POSIX_MAX_CANON","_POSIX_MAX_INPUT","_POSIX_MEMORY_PROTECTION","_POSIX_NAME_MAX","_POSIX_NGROUPS_MAX","_POSIX_NO_TRUNC","_POSIX_OPEN_MAX","_POSIX_PATH_MAX","_POSIX_PIPE_BUF","_POSIX_PRIO_IO","_POSIX_RAW_SOCKETS","_POSIX_READER_WRITER_LOCKS","_POSIX_REALTIME_SIGNALS","_POSIX_REGEXP","_POSIX_RE_DUP_MAX","_POSIX_RTSIG_MAX","_POSIX_SAVED_IDS","_POSIX_SEMAPHORES","_POSIX_SEM_NSEMS_MAX","_POSIX_SEM_VALUE_MAX","_POSIX_SHELL","_POSIX_SIGQUEUE_MAX","_POSIX_SPIN_LOCKS","_POSIX_SSIZE_MAX","_POSIX_STREAM_MAX","_POSIX_SYMLINK_MAX","_POSIX_SYMLOOP_MAX","_POSIX_SYNC_IO","_POSIX_THREADS","_POSIX_THREAD_DESTRUCTOR_ITERATIONS","_POSIX_THREAD_KEYS_MAX","_POSIX_THREAD_SAFE_FUNCTIONS","_POSIX_THREAD_THREADS_MAX","_POSIX_TIMEOUTS","_POSIX_TIMERS","_POSIX_TIMER_MAX","_POSIX_TIMESTAMP_RESOLUTION","_POSIX_TTY_NAME_MAX","_POSIX_TZNAME_MAX","_POSIX_V7_ILP32_OFF32","_POSIX_V7_ILP32_OFFBIG","_POSIX_V7_LP64_OFF64","_POSIX_V7_LPBIG_OFFBIG","_POSIX_VDISABLE","_POSIX_VERSION","_SC_2_CHAR_TERM","_SC_2_C_BIND","_SC_2_C_DEV","_SC_2_FORT_DEV","_SC_2_FORT_RUN","_SC_2_LOCALEDEF","_SC_2_PBS","_SC_2_PBS_ACCOUNTING","_SC_2_PBS_CHECKPOINT","_SC_2_PBS_LOCATE","_SC_2_PBS_MESSAGE","_SC_2_PBS_TRACK","_SC_2_SW_DEV","_SC_2_UPE","_SC_2_VERSION","_SC_ADVISORY_INFO","_SC_AIO_LISTIO_MAX","_SC_AIO_MAX","_SC_AIO_PRIO_DELTA_MAX","_SC_ARG_MAX","_SC_ASYNCHRONOUS_IO","_SC_ATEXIT_MAX","_SC_BARRIERS","_SC_BC_BASE_MAX","_SC_BC_DIM_MAX","_SC_BC_SCALE_MAX","_SC_BC_STRING_MAX","_SC_CHILD_MAX","_SC_CLK_TCK","_SC_CLOCK_SELECTION","_SC_COLL_WEIGHTS_MAX","_SC_CPUTIME","_SC_DELAYTIMER_MAX","_SC_EXPR_NEST_MAX","_SC_FSYNC","_SC_GETGR_R_SIZE_MAX","_SC_GETPW_R_SIZE_MAX","_SC_HOST_NAME_MAX","_SC_IOV_MAX","_SC_IPV6","_SC_JOB_CONTROL","_SC_LINE_MAX","_SC_LOGIN_NAME_MAX","_SC_MAPPED_FILES","_SC_MEMLOCK","_SC_MEMLOCK_RANGE","_SC_MEMORY_PROTECTION","_SC_MESSAGE_PASSING","_SC_MONOTONIC_CLOCK","_SC_MQ_OPEN_MAX","_SC_MQ_PRIO_MAX","_SC_NGROUPS_MAX","_SC_OPEN_MAX","_SC_PAGESIZE","_SC_PAGE_SIZE","_SC_PRIORITIZED_IO","_SC_PRIORITY_SCHEDULING","_SC_RAW_SOCKETS","_SC_READER_WRITER_LOCKS","_SC_REALTIME_SIGNALS","_SC_REGEXP","_SC_RE_DUP_MAX","_SC_RTSIG_MAX","_SC_SAVED_IDS","_SC_SEMAPHORES","_SC_SEM_NSEMS_MAX","_SC_SEM_VALUE_MAX","_SC_SHARED_MEMORY_OBJECTS","_SC_SHELL","_SC_SIGQUEUE_MAX","_SC_SPAWN","_SC_SPIN_LOCKS","_SC_SPORADIC_SERVER","_SC_SS_REPL_MAX","_SC_STREAM_MAX","_SC_SYMLOOP_MAX","_SC_SYNCHRONIZED_IO","_SC_THREADS","_SC_THREAD_ATTR_STACKADDR","_SC_THREAD_ATTR_STACKSIZE","_SC_THREAD_CPUTIME","_SC_THREAD_DESTRUCTOR_ITERATIONS","_SC_THREAD_KEYS_MAX","_SC_THREAD_PRIORITY_SCHEDULING","_SC_THREAD_PRIO_INHERIT","_SC_THREAD_PRIO_PROTECT","_SC_THREAD_PROCESS_SHARED","_SC_THREAD_ROBUST_PRIO_INHERIT","_SC_THREAD_ROBUST_PRIO_PROTECT","_SC_THREAD_SAFE_FUNCTIONS","_SC_THREAD_SPORADIC_SERVER","_SC_THREAD_STACK_MIN","_SC_THREAD_THREADS_MAX","_SC_TIMEOUTS","_SC_TIMERS","_SC_TIMER_MAX","_SC_TRACE","_SC_TRACE_EVENT_FILTER","_SC_TRACE_EVENT_NAME_MAX","_SC_TRACE_INHERIT","_SC_TRACE_LOG","_SC_TRACE_NAME_MAX","_SC_TRACE_SYS_MAX","_SC_TRACE_USER_EVENT_MAX","_SC_TTY_NAME_MAX","_SC_TYPED_MEMORY_OBJECTS","_SC_TZNAME_MAX","_SC_V7_ILP32_OFF32","_SC_V7_ILP32_OFFBIG","_SC_V7_LP64_OFF64","_SC_V7_LPBIG_OFFBIG","_SC_VERSION","_SC_XOPEN_CRYPT","_SC_XOPEN_ENH_I18N","_SC_XOPEN_REALTIME","_SC_XOPEN_REALTIME_THREADS","_SC_XOPEN_SHM","_SC_XOPEN_STREAMS","_SC_XOPEN_UNIX","_SC_XOPEN_UUCP","_SC_XOPEN_VERSION"];all=types+consts;lens=set(map(len,all));print("".join(map(lambda n: "case {}:{}break;".format(n,"".join(map(lambda tok:"if(!memcmp(text+i,\"{}\",ntok)){{*psyn={};break;}}".format(tok,5 if tok in types else 3),filter(lambda tok:len(tok)==n,all)))),lens)))'
		case 2:if(!memcmp(text+i,"B0",ntok)){*psyn=3;break;}break;case 3:if(!memcmp(text+i,"DIR",ntok)){*psyn=5;break;}if(!memcmp(text+i,"B50",ntok)){*psyn=3;break;}if(!memcmp(text+i,"B75",ntok)){*psyn=3;break;}if(!memcmp(text+i,"CS5",ntok)){*psyn=3;break;}if(!memcmp(text+i,"CS6",ntok)){*psyn=3;break;}if(!memcmp(text+i,"CS7",ntok)){*psyn=3;break;}if(!memcmp(text+i,"CS8",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EIO",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ERA",ntok)){*psyn=3;break;}break;case 4:if(!memcmp(text+i,"cc_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"id_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"B110",ntok)){*psyn=3;break;}if(!memcmp(text+i,"B134",ntok)){*psyn=3;break;}if(!memcmp(text+i,"B150",ntok)){*psyn=3;break;}if(!memcmp(text+i,"B200",ntok)){*psyn=3;break;}if(!memcmp(text+i,"B300",ntok)){*psyn=3;break;}if(!memcmp(text+i,"B600",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ECHO",ntok)){*psyn=3;break;}if(!memcmp(text+i,"F_OK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ISIG",ntok)){*psyn=3;break;}if(!memcmp(text+i,"IXON",ntok)){*psyn=3;break;}if(!memcmp(text+i,"NCCS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"R_OK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"VEOF",ntok)){*psyn=3;break;}if(!memcmp(text+i,"VEOL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"VMIN",ntok)){*psyn=3;break;}if(!memcmp(text+i,"W_OK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"X_OK",ntok)){*psyn=3;break;}break;case 5:if(!memcmp(text+i,"dev_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"gid_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"ino_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"off_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"pid_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"sem_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"uid_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"B1200",ntok)){*psyn=3;break;}if(!memcmp(text+i,"B1800",ntok)){*psyn=3;break;}if(!memcmp(text+i,"B2400",ntok)){*psyn=3;break;}if(!memcmp(text+i,"B4800",ntok)){*psyn=3;break;}if(!memcmp(text+i,"B9600",ntok)){*psyn=3;break;}if(!memcmp(text+i,"CREAD",ntok)){*psyn=3;break;}if(!memcmp(text+i,"CSIZE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"DAY_1",ntok)){*psyn=3;break;}if(!memcmp(text+i,"DAY_2",ntok)){*psyn=3;break;}if(!memcmp(text+i,"DAY_3",ntok)){*psyn=3;break;}if(!memcmp(text+i,"DAY_4",ntok)){*psyn=3;break;}if(!memcmp(text+i,"DAY_5",ntok)){*psyn=3;break;}if(!memcmp(text+i,"DAY_6",ntok)){*psyn=3;break;}if(!memcmp(text+i,"DAY_7",ntok)){*psyn=3;break;}if(!memcmp(text+i,"D_FMT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"E2BIG",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EBADF",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EBUSY",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ECHOE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ECHOK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EFBIG",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EIDRM",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EINTR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ELOOP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ENXIO",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EPERM",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EPIPE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EROFS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ESRCH",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EXDEV",ntok)){*psyn=3;break;}if(!memcmp(text+i,"HUPCL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ICRNL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"IGNCR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"INLCR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"INPCK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"IXANY",ntok)){*psyn=3;break;}if(!memcmp(text+i,"IXOFF",ntok)){*psyn=3;break;}if(!memcmp(text+i,"MAGIC",ntok)){*psyn=3;break;}if(!memcmp(text+i,"MON_1",ntok)){*psyn=3;break;}if(!memcmp(text+i,"MON_2",ntok)){*psyn=3;break;}if(!memcmp(text+i,"MON_3",ntok)){*psyn=3;break;}if(!memcmp(text+i,"MON_4",ntok)){*psyn=3;break;}if(!memcmp(text+i,"MON_5",ntok)){*psyn=3;break;}if(!memcmp(text+i,"MON_6",ntok)){*psyn=3;break;}if(!memcmp(text+i,"MON_7",ntok)){*psyn=3;break;}if(!memcmp(text+i,"MON_8",ntok)){*psyn=3;break;}if(!memcmp(text+i,"MON_9",ntok)){*psyn=3;break;}if(!memcmp(text+i,"OPOST",ntok)){*psyn=3;break;}if(!memcmp(text+i,"P_ALL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"P_PID",ntok)){*psyn=3;break;}if(!memcmp(text+i,"TCION",ntok)){*psyn=3;break;}if(!memcmp(text+i,"TCOON",ntok)){*psyn=3;break;}if(!memcmp(text+i,"TSGID",ntok)){*psyn=3;break;}if(!memcmp(text+i,"TSUID",ntok)){*psyn=3;break;}if(!memcmp(text+i,"T_FMT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"VINTR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"VKILL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"VQUIT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"VSTOP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"VSUSP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"VTIME",ntok)){*psyn=3;break;}break;case 6:if(!memcmp(text+i,"fd_set",ntok)){*psyn=5;break;}if(!memcmp(text+i,"glob_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"mode_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"nfds_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"AI_ALL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"AM_STR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"B19200",ntok)){*psyn=3;break;}if(!memcmp(text+i,"B38400",ntok)){*psyn=3;break;}if(!memcmp(text+i,"BRKINT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"CLOCAL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"CSTOPB",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EACCES",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EAGAIN",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ECHILD",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ECHONL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EDQUOT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EEXIST",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EFAULT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EINVAL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EISDIR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EMFILE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EMLINK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ENFILE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ENODEV",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ENOENT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ENOLCK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ENOMEM",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ENOMSG",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ENOSPC",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ENOSYS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ENOTTY",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EPROTO",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ESPIPE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ESTALE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ICANON",ntok)){*psyn=3;break;}if(!memcmp(text+i,"IEXTEN",ntok)){*psyn=3;break;}if(!memcmp(text+i,"IGNBRK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"IGNPAR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ISTRIP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"MON_10",ntok)){*psyn=3;break;}if(!memcmp(text+i,"MON_11",ntok)){*psyn=3;break;}if(!memcmp(text+i,"MON_12",ntok)){*psyn=3;break;}if(!memcmp(text+i,"NOEXPR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"NOFLSH",ntok)){*psyn=3;break;}if(!memcmp(text+i,"O_EXCL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"O_EXEC",ntok)){*psyn=3;break;}if(!memcmp(text+i,"O_RDWR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"O_SYNC",ntok)){*psyn=3;break;}if(!memcmp(text+i,"PARENB",ntok)){*psyn=3;break;}if(!memcmp(text+i,"PARMRK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"PARODD",ntok)){*psyn=3;break;}if(!memcmp(text+i,"PM_STR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"POLLIN",ntok)){*psyn=3;break;}if(!memcmp(text+i,"P_PGID",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SIGBUS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SIGHUP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SIGURG",ntok)){*psyn=3;break;}if(!memcmp(text+i,"TCIOFF",ntok)){*psyn=3;break;}if(!memcmp(text+i,"TCOOFF",ntok)){*psyn=3;break;}if(!memcmp(text+i,"TGEXEC",ntok)){*psyn=3;break;}if(!memcmp(text+i,"TGREAD",ntok)){*psyn=3;break;}if(!memcmp(text+i,"TMAGIC",ntok)){*psyn=3;break;}if(!memcmp(text+i,"TOEXEC",ntok)){*psyn=3;break;}if(!memcmp(text+i,"TOREAD",ntok)){*psyn=3;break;}if(!memcmp(text+i,"TOSTOP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"TUEXEC",ntok)){*psyn=3;break;}if(!memcmp(text+i,"TUREAD",ntok)){*psyn=3;break;}if(!memcmp(text+i,"VERASE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"VSTART",ntok)){*psyn=3;break;}break;case 7:if(!memcmp(text+i,"iconv_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"nl_catd",ntok)){*psyn=5;break;}if(!memcmp(text+i,"nl_item",ntok)){*psyn=5;break;}if(!memcmp(text+i,"nlink_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"regex_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"speed_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"ssize_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"stack_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"timer_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"ABDAY_1",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ABDAY_2",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ABDAY_3",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ABDAY_4",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ABDAY_5",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ABDAY_6",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ABDAY_7",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ABMON_1",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ABMON_2",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ABMON_3",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ABMON_4",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ABMON_5",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ABMON_6",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ABMON_7",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ABMON_8",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ABMON_9",ntok)){*psyn=3;break;}if(!memcmp(text+i,"AF_INET",ntok)){*psyn=3;break;}if(!memcmp(text+i,"AF_UNIX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"AIO_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ARG_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"BLKTYPE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"CHRTYPE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"CODESET",ntok)){*psyn=3;break;}if(!memcmp(text+i,"C_IRGRP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"C_IROTH",ntok)){*psyn=3;break;}if(!memcmp(text+i,"C_IRUSR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"C_ISBLK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"C_ISCHR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"C_ISCTG",ntok)){*psyn=3;break;}if(!memcmp(text+i,"C_ISDIR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"C_ISGID",ntok)){*psyn=3;break;}if(!memcmp(text+i,"C_ISLNK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"C_ISREG",ntok)){*psyn=3;break;}if(!memcmp(text+i,"C_ISUID",ntok)){*psyn=3;break;}if(!memcmp(text+i,"C_ISVTX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"C_IWGRP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"C_IWOTH",ntok)){*psyn=3;break;}if(!memcmp(text+i,"C_IWUSR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"C_IXGRP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"C_IXOTH",ntok)){*psyn=3;break;}if(!memcmp(text+i,"C_IXUSR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"DIRTYPE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"D_T_FMT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EBADMSG",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EDEADLK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EISCONN",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ENOBUFS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ENOEXEC",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ENOLINK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ENOTDIR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ENOTSUP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ETXTBSY",ntok)){*psyn=3;break;}if(!memcmp(text+i,"F_DUPFD",ntok)){*psyn=3;break;}if(!memcmp(text+i,"F_GETFD",ntok)){*psyn=3;break;}if(!memcmp(text+i,"F_GETFL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"F_GETLK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"F_RDLCK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"F_SETFD",ntok)){*psyn=3;break;}if(!memcmp(text+i,"F_SETFL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"F_SETLK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"F_UNLCK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"F_WRLCK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"LIO_NOP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"LNKTYPE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"MSG_EOR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"MSG_OOB",ntok)){*psyn=3;break;}if(!memcmp(text+i,"NL_SETD",ntok)){*psyn=3;break;}if(!memcmp(text+i,"O_CREAT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"O_TRUNC",ntok)){*psyn=3;break;}if(!memcmp(text+i,"POLLERR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"POLLHUP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"POLLOUT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"POLLPRI",ntok)){*psyn=3;break;}if(!memcmp(text+i,"REGTYPE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SHUT_RD",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SHUT_WR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SIGALRM",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SIGCHLD",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SIGCONT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SIGKILL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SIGPIPE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SIGQUIT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SIGSTOP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SIGTRAP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SIGTSTP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SIGTTIN",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SIGTTOU",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SIGUSR1",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SIGUSR2",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SI_USER",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SO_TYPE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SYMTYPE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"S_IRGRP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"S_IROTH",ntok)){*psyn=3;break;}if(!memcmp(text+i,"S_IRUSR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"S_IRWXG",ntok)){*psyn=3;break;}if(!memcmp(text+i,"S_IRWXO",ntok)){*psyn=3;break;}if(!memcmp(text+i,"S_IRWXU",ntok)){*psyn=3;break;}if(!memcmp(text+i,"S_ISGID",ntok)){*psyn=3;break;}if(!memcmp(text+i,"S_ISUID",ntok)){*psyn=3;break;}if(!memcmp(text+i,"S_IWGRP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"S_IWOTH",ntok)){*psyn=3;break;}if(!memcmp(text+i,"S_IWUSR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"S_IXGRP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"S_IXOTH",ntok)){*psyn=3;break;}if(!memcmp(text+i,"S_IXUSR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"TCSANOW",ntok)){*psyn=3;break;}if(!memcmp(text+i,"TGWRITE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"THOUSEP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"TMAGLEN",ntok)){*psyn=3;break;}if(!memcmp(text+i,"TOWRITE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"TUWRITE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"WEXITED",ntok)){*psyn=3;break;}if(!memcmp(text+i,"WNOHANG",ntok)){*psyn=3;break;}if(!memcmp(text+i,"WNOWAIT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"YESEXPR",ntok)){*psyn=3;break;}break;case 8:if(!memcmp(text+i,"blkcnt_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"idtype_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"locale_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"regoff_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"sigset_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"tcflag_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"ABMON_10",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ABMON_11",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ABMON_12",ntok)){*psyn=3;break;}if(!memcmp(text+i,"AF_INET6",ntok)){*psyn=3;break;}if(!memcmp(text+i,"AREGTYPE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"AT_FDCWD",ntok)){*psyn=3;break;}if(!memcmp(text+i,"CONTTYPE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"CRNCYSTR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"C_ISFIFO",ntok)){*psyn=3;break;}if(!memcmp(text+i,"C_ISSOCK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EAI_FAIL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EALREADY",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EMSGSIZE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ENETDOWN",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ENOTCONN",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ENOTSOCK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"FIFOTYPE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"F_GETOWN",ntok)){*psyn=3;break;}if(!memcmp(text+i,"F_SETLKW",ntok)){*psyn=3;break;}if(!memcmp(text+i,"F_SETOWN",ntok)){*psyn=3;break;}if(!memcmp(text+i,"GLOB_ERR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"LINE_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"LINK_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"LIO_READ",ntok)){*psyn=3;break;}if(!memcmp(text+i,"LIO_WAIT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"LONG_BIT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"MSG_PEEK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"NAME_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"NI_DGRAM",ntok)){*psyn=3;break;}if(!memcmp(text+i,"OPEN_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"O_APPEND",ntok)){*psyn=3;break;}if(!memcmp(text+i,"O_NOCTTY",ntok)){*psyn=3;break;}if(!memcmp(text+i,"O_RDONLY",ntok)){*psyn=3;break;}if(!memcmp(text+i,"O_SEARCH",ntok)){*psyn=3;break;}if(!memcmp(text+i,"O_WRONLY",ntok)){*psyn=3;break;}if(!memcmp(text+i,"PAGESIZE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"PATH_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"PIPE_BUF",ntok)){*psyn=3;break;}if(!memcmp(text+i,"POLLNVAL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"RTLD_NOW",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SIGRTMAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SIGRTMIN",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SI_MESGQ",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SI_QUEUE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SI_TIMER",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SOCK_RAW",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SO_DEBUG",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SO_ERROR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"TCIFLUSH",ntok)){*psyn=3;break;}if(!memcmp(text+i,"TCOFLUSH",ntok)){*psyn=3;break;}if(!memcmp(text+i,"TVERSION",ntok)){*psyn=3;break;}if(!memcmp(text+i,"TVERSLEN",ntok)){*psyn=3;break;}if(!memcmp(text+i,"WORD_BIT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"WSTOPPED",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_CS_PATH",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_IPV6",ntok)){*psyn=3;break;}break;case 9:if(!memcmp(text+i,"blksize_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"clockid_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"in_addr_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"in_port_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"pthread_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"siginfo_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"socklen_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"wordexp_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"AF_UNSPEC",ntok)){*psyn=3;break;}if(!memcmp(text+i,"CHILD_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EAI_AGAIN",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ECANCELED",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EMULTIHOP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ENETRESET",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ENOTEMPTY",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EOVERFLOW",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ERA_D_FMT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ERA_T_FMT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ETIMEDOUT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"GLOB_MARK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"LIO_WRITE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"L_ctermid",ntok)){*psyn=3;break;}if(!memcmp(text+i,"MAP_FIXED",ntok)){*psyn=3;break;}if(!memcmp(text+i,"MAX_CANON",ntok)){*psyn=3;break;}if(!memcmp(text+i,"MAX_INPUT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"MSG_TRUNC",ntok)){*psyn=3;break;}if(!memcmp(text+i,"NI_NOFQDN",ntok)){*psyn=3;break;}if(!memcmp(text+i,"NL_ARGMAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"NL_MSGMAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"NL_SETMAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"O_ACCMODE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"O_CLOEXEC",ntok)){*psyn=3;break;}if(!memcmp(text+i,"PROT_EXEC",ntok)){*psyn=3;break;}if(!memcmp(text+i,"PROT_NONE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"PROT_READ",ntok)){*psyn=3;break;}if(!memcmp(text+i,"RADIXCHAR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"REG_BADBR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"REG_ICASE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"REG_NOSUB",ntok)){*psyn=3;break;}if(!memcmp(text+i,"RTLD_LAZY",ntok)){*psyn=3;break;}if(!memcmp(text+i,"RTSIG_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SHUT_RDWR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SIG_BLOCK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SOMAXCONN",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SO_LINGER",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SO_RCVBUF",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SO_SNDBUF",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SSIZE_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ST_NOSUID",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ST_RDONLY",ntok)){*psyn=3;break;}if(!memcmp(text+i,"TCIOFLUSH",ntok)){*psyn=3;break;}if(!memcmp(text+i,"TCSADRAIN",ntok)){*psyn=3;break;}if(!memcmp(text+i,"TCSAFLUSH",ntok)){*psyn=3;break;}if(!memcmp(text+i,"TIMER_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"UTIME_NOW",ntok)){*psyn=3;break;}if(!memcmp(text+i,"WUNTRACED",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_2_PBS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_2_UPE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_FSYNC",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_SHELL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_SPAWN",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_TRACE",ntok)){*psyn=3;break;}break;case 10:if(!memcmp(text+i,"fsblkcnt_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"fsfilcnt_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"mcontext_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"regmatch_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"sigjmp_buf",ntok)){*psyn=5;break;}if(!memcmp(text+i,"ucontext_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"AI_PASSIVE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ALT_DIGITS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ATEXIT_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"AT_EACCESS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"BC_DIM_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"BUS_ADRALN",ntok)){*psyn=3;break;}if(!memcmp(text+i,"BUS_ADRERR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"BUS_OBJERR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"CLD_DUMPED",ntok)){*psyn=3;break;}if(!memcmp(text+i,"CLD_EXITED",ntok)){*psyn=3;break;}if(!memcmp(text+i,"CLD_KILLED",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EADDRINUSE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EAI_FAMILY",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EAI_MEMORY",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EAI_NONAME",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EAI_SYSTEM",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ECONNRESET",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EOPNOTSUPP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EOWNERDEAD",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EPROTOTYPE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"FD_CLOEXEC",ntok)){*psyn=3;break;}if(!memcmp(text+i,"FD_SETSIZE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"FNM_PERIOD",ntok)){*psyn=3;break;}if(!memcmp(text+i,"FPE_FLTDIV",ntok)){*psyn=3;break;}if(!memcmp(text+i,"FPE_FLTINV",ntok)){*psyn=3;break;}if(!memcmp(text+i,"FPE_FLTOVF",ntok)){*psyn=3;break;}if(!memcmp(text+i,"FPE_FLTRES",ntok)){*psyn=3;break;}if(!memcmp(text+i,"FPE_FLTSUB",ntok)){*psyn=3;break;}if(!memcmp(text+i,"FPE_FLTUND",ntok)){*psyn=3;break;}if(!memcmp(text+i,"FPE_INTDIV",ntok)){*psyn=3;break;}if(!memcmp(text+i,"FPE_INTOVF",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ILL_BADSTK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ILL_COPROC",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ILL_ILLADR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ILL_ILLOPC",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ILL_ILLOPN",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ILL_ILLTRP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ILL_PRVOPC",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ILL_PRVREG",ntok)){*psyn=3;break;}if(!memcmp(text+i,"INADDR_ANY",ntok)){*psyn=3;break;}if(!memcmp(text+i,"IPPROTO_IP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"LIO_NOWAIT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"MAP_FAILED",ntok)){*psyn=3;break;}if(!memcmp(text+i,"MAP_SHARED",ntok)){*psyn=3;break;}if(!memcmp(text+i,"MSG_CTRUNC",ntok)){*psyn=3;break;}if(!memcmp(text+i,"NL_TEXTMAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"O_NOFOLLOW",ntok)){*psyn=3;break;}if(!memcmp(text+i,"O_NONBLOCK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"O_TTY_INIT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"POLLRDBAND",ntok)){*psyn=3;break;}if(!memcmp(text+i,"POLLRDNORM",ntok)){*psyn=3;break;}if(!memcmp(text+i,"POLLWRBAND",ntok)){*psyn=3;break;}if(!memcmp(text+i,"POLLWRNORM",ntok)){*psyn=3;break;}if(!memcmp(text+i,"PROT_WRITE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"REG_BADPAT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"REG_BADRPT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"REG_EBRACE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"REG_EBRACK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"REG_ECTYPE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"REG_EPAREN",ntok)){*psyn=3;break;}if(!memcmp(text+i,"REG_ERANGE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"REG_ESPACE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"REG_NOTBOL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"REG_NOTEOL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"RE_DUP_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"RTLD_LOCAL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SA_NODEFER",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SA_RESTART",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SA_SIGINFO",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SCM_RIGHTS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SEM_FAILED",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SIGEV_NONE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SI_ASYNCIO",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SOCK_DGRAM",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SOL_SOCKET",ntok)){*psyn=3;break;}if(!memcmp(text+i,"STREAM_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"TZNAME_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"T_FMT_AMPM",ntok)){*psyn=3;break;}if(!memcmp(text+i,"UTIME_OMIT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"WRDE_NOCMD",ntok)){*psyn=3;break;}if(!memcmp(text+i,"WRDE_REUSE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"WRDE_UNDEF",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_CS_V7_ENV",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_REGEXP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_TIMERS",ntok)){*psyn=3;break;}break;case 11:if(!memcmp(text+i,"sa_family_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"suseconds_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"AIO_ALLDONE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"AI_V4MAPPED",ntok)){*psyn=3;break;}if(!memcmp(text+i,"BC_BASE_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"CLD_STOPPED",ntok)){*psyn=3;break;}if(!memcmp(text+i,"CLD_TRAPPED",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EAI_SERVICE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EINPROGRESS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ENETUNREACH",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ENOPROTOOPT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ERA_D_T_FMT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EWOULDBLOCK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"FNM_NOMATCH",ntok)){*psyn=3;break;}if(!memcmp(text+i,"GLOB_APPEND",ntok)){*psyn=3;break;}if(!memcmp(text+i,"GLOB_DOOFFS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"GLOB_NOSORT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"IF_NAMESIZE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"IPPROTO_RAW",ntok)){*psyn=3;break;}if(!memcmp(text+i,"IPPROTO_TCP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"IPPROTO_UDP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"IPV6_V6ONLY",ntok)){*psyn=3;break;}if(!memcmp(text+i,"LC_ALL_MASK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"LC_MESSAGES",ntok)){*psyn=3;break;}if(!memcmp(text+i,"MAP_PRIVATE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"MSG_WAITALL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"NGROUPS_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"NI_NAMEREQD",ntok)){*psyn=3;break;}if(!memcmp(text+i,"O_DIRECTORY",ntok)){*psyn=3;break;}if(!memcmp(text+i,"REG_EESCAPE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"REG_ESUBREG",ntok)){*psyn=3;break;}if(!memcmp(text+i,"REG_NEWLINE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"REG_NOMATCH",ntok)){*psyn=3;break;}if(!memcmp(text+i,"RTLD_GLOBAL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SEGV_ACCERR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SEGV_MAPERR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SIG_SETMASK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SIG_UNBLOCK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SOCK_STREAM",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SO_RCVLOWAT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SO_RCVTIMEO",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SO_SNDLOWAT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SO_SNDTIMEO",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SYMLINK_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SYMLOOP_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"TCP_NODELAY",ntok)){*psyn=3;break;}if(!memcmp(text+i,"WRDE_APPEND",ntok)){*psyn=3;break;}if(!memcmp(text+i,"WRDE_BADVAL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"WRDE_CMDSUB",ntok)){*psyn=3;break;}if(!memcmp(text+i,"WRDE_DOOFFS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"WRDE_SYNTAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_PC_PRIO_IO",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_PC_SYNC_IO",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_IPV6",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_2_C_DEV",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_AIO_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_ARG_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_CLK_TCK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_CPUTIME",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_IOV_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_MEMLOCK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_THREADS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_VERSION",ntok)){*psyn=3;break;}break;case 12:if(!memcmp(text+i,"AIO_CANCELED",ntok)){*psyn=3;break;}if(!memcmp(text+i,"AI_CANONNAME",ntok)){*psyn=3;break;}if(!memcmp(text+i,"AT_REMOVEDIR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"BC_SCALE_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EAFNOSUPPORT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EAI_BADFLAGS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EAI_OVERFLOW",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EAI_SOCKTYPE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ECONNABORTED",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ECONNREFUSED",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EDESTADDRREQ",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EHOSTUNREACH",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ENAMETOOLONG",ntok)){*psyn=3;break;}if(!memcmp(text+i,"FILESIZEBITS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"FNM_NOESCAPE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"FNM_PATHNAME",ntok)){*psyn=3;break;}if(!memcmp(text+i,"GLOB_ABORTED",ntok)){*psyn=3;break;}if(!memcmp(text+i,"GLOB_NOCHECK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"GLOB_NOMATCH",ntok)){*psyn=3;break;}if(!memcmp(text+i,"GLOB_NOSPACE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"IPPROTO_ICMP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"IPPROTO_IPV6",ntok)){*psyn=3;break;}if(!memcmp(text+i,"LC_TIME_MASK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"MSG_NOSIGNAL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"REG_ECOLLATE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"REG_EXTENDED",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SA_NOCLDSTOP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SA_RESETHAND",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SIGEV_SIGNAL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SIGEV_THREAD",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SIGQUEUE_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SO_BROADCAST",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SO_DONTROUTE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SO_KEEPALIVE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SO_OOBINLINE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SO_REUSEADDR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"STDIN_FILENO",ntok)){*psyn=3;break;}if(!memcmp(text+i,"TTY_NAME_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"WRDE_BADCHAR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"WRDE_NOSPACE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"WRDE_SHOWERR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_PC_ASYNC_IO",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_PC_LINK_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_PC_NAME_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_PC_NO_TRUNC",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_PC_PATH_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_PC_PIPE_BUF",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_PC_VDISABLE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_SHELL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_2_C_BIND",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_2_SW_DEV",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_BARRIERS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_LINE_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_OPEN_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_PAGESIZE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_TIMEOUTS",ntok)){*psyn=3;break;}break;case 13:if(!memcmp(text+i,"pthread_key_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"AI_ADDRCONFIG",ntok)){*psyn=3;break;}if(!memcmp(text+i,"BC_STRING_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"CLD_CONTINUED",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EADDRNOTAVAIL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EXPR_NEST_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"GLOB_NOESCAPE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"HOST_NAME_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"LC_CTYPE_MASK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"MSG_DONTROUTE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"NL_CAT_LOCALE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SEM_NSEMS_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SEM_VALUE_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SO_ACCEPTCONN",ntok)){*psyn=3;break;}if(!memcmp(text+i,"STDERR_FILENO",ntok)){*psyn=3;break;}if(!memcmp(text+i,"STDOUT_FILENO",ntok)){*psyn=3;break;}if(!memcmp(text+i,"TIMER_ABSTIME",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_PC_MAX_CANON",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_PC_MAX_INPUT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_REGEXP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_TIMERS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_2_VERSION",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_CHILD_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_PAGE_SIZE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_RTSIG_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_SAVED_IDS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_TIMER_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_TRACE_LOG",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_XOPEN_SHM",ntok)){*psyn=3;break;}break;case 14:if(!memcmp(text+i,"pthread_attr_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"pthread_cond_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"pthread_once_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"AIO_LISTIO_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"AI_NUMERICHOST",ntok)){*psyn=3;break;}if(!memcmp(text+i,"AI_NUMERICSERV",ntok)){*psyn=3;break;}if(!memcmp(text+i,"CLOCK_REALTIME",ntok)){*psyn=3;break;}if(!memcmp(text+i,"DELAYTIMER_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"LOGIN_NAME_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"NI_NUMERICHOST",ntok)){*psyn=3;break;}if(!memcmp(text+i,"NI_NUMERICSERV",ntok)){*psyn=3;break;}if(!memcmp(text+i,"SOCK_SEQPACKET",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_PC_2_SYMLINKS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX2_C_BIND",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_AIO_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_ARG_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_PRIO_IO",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_SYNC_IO",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_THREADS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_VERSION",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_2_FORT_DEV",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_2_FORT_RUN",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_ATEXIT_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_BC_DIM_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_RE_DUP_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_SEMAPHORES",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_SPIN_LOCKS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_STREAM_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_TZNAME_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_XOPEN_UNIX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_XOPEN_UUCP",ntok)){*psyn=3;break;}break;case 15:if(!memcmp(text+i,"pthread_mutex_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"AIO_NOTCANCELED",ntok)){*psyn=3;break;}if(!memcmp(text+i,"ENOTRECOVERABLE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"EPROTONOSUPPORT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"F_DUPFD_CLOEXEC",ntok)){*psyn=3;break;}if(!memcmp(text+i,"INET_ADDRSTRLEN",ntok)){*psyn=3;break;}if(!memcmp(text+i,"IPV6_JOIN_GROUP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"LC_COLLATE_MASK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"LC_NUMERIC_MASK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"NI_NUMERICSCOPE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_PC_SYMLINK_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX2_VERSION",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_ASYNC_IO",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_BARRIERS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_LINK_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_NAME_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_NO_TRUNC",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_OPEN_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_PATH_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_PIPE_BUF",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_TIMEOUTS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_VDISABLE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_2_CHAR_TERM",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_2_LOCALEDEF",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_2_PBS_TRACK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_BC_BASE_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_JOB_CONTROL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_MQ_OPEN_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_MQ_PRIO_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_NGROUPS_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_RAW_SOCKETS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_SS_REPL_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_SYMLOOP_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_XOPEN_CRYPT",ntok)){*psyn=3;break;}break;case 16:if(!memcmp(text+i,"pthread_rwlock_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"COLL_WEIGHTS_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"INADDR_BROADCAST",ntok)){*psyn=3;break;}if(!memcmp(text+i,"IPV6_LEAVE_GROUP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"LC_GLOBAL_LOCALE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"LC_MESSAGES_MASK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"LC_MONETARY_MASK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"PTHREAD_CANCELED",ntok)){*psyn=3;break;}if(!memcmp(text+i,"PTHREAD_KEYS_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_PC_FILESIZEBITS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX2_LINE_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX2_SYMLINKS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_CHILD_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_MAX_CANON",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_MAX_INPUT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_RTSIG_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_SAVED_IDS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_SSIZE_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_TIMER_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_2_PBS_LOCATE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_BC_SCALE_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_MAPPED_FILES",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_SIGQUEUE_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_TTY_NAME_MAX",ntok)){*psyn=3;break;}break;case 17:if(!memcmp(text+i,"pthread_barrier_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"AT_SYMLINK_FOLLOW",ntok)){*psyn=3;break;}if(!memcmp(text+i,"IPV6_MULTICAST_IF",ntok)){*psyn=3;break;}if(!memcmp(text+i,"IPV6_UNICAST_HOPS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"PTHREAD_ONCE_INIT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"PTHREAD_STACK_MIN",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX2_CHAR_TERM",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX2_LOCALEDEF",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_RE_DUP_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_SEMAPHORES",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_SPIN_LOCKS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_STREAM_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_TZNAME_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_2_PBS_MESSAGE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_ADVISORY_INFO",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_BC_STRING_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_EXPR_NEST_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_HOST_NAME_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_MEMLOCK_RANGE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_SEM_NSEMS_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_SEM_VALUE_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_TRACE_INHERIT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_TRACE_SYS_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_V7_LP64_OFF64",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_XOPEN_STREAMS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_XOPEN_VERSION",ntok)){*psyn=3;break;}break;case 18:if(!memcmp(text+i,"pthread_condattr_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"pthread_spinlock_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"AIO_PRIO_DELTA_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"CHARCLASS_NAME_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_PC_ALLOC_SIZE_MIN",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_PC_REC_XFER_ALIGN",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX2_BC_DIM_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX2_RE_DUP_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_JOB_CONTROL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_NGROUPS_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_RAW_SOCKETS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_SYMLINK_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_SYMLOOP_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_AIO_LISTIO_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_DELAYTIMER_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_LOGIN_NAME_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_PRIORITIZED_IO",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_THREAD_CPUTIME",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_TRACE_NAME_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_V7_ILP32_OFF32",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_XOPEN_ENH_I18N",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_XOPEN_REALTIME",ntok)){*psyn=3;break;}break;case 19:if(!memcmp(text+i,"pthread_mutexattr_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"AT_SYMLINK_NOFOLLOW",ntok)){*psyn=3;break;}if(!memcmp(text+i,"IPV6_MULTICAST_HOPS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"IPV6_MULTICAST_LOOP",ntok)){*psyn=3;break;}if(!memcmp(text+i,"PTHREAD_THREADS_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX2_BC_BASE_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_CLOCKRES_MIN",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_MAPPED_FILES",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_SIGQUEUE_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_TTY_NAME_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_ASYNCHRONOUS_IO",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_CLOCK_SELECTION",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_MESSAGE_PASSING",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_MONOTONIC_CLOCK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_SPORADIC_SERVER",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_SYNCHRONIZED_IO",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_THREAD_KEYS_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_V7_ILP32_OFFBIG",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_V7_LPBIG_OFFBIG",ntok)){*psyn=3;break;}break;case 20:if(!memcmp(text+i,"pthread_rwlockattr_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"IN6_IS_ADDR_LOOPBACK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"IN6_IS_ADDR_V4COMPAT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"IN6_IS_ADDR_V4MAPPED",ntok)){*psyn=3;break;}if(!memcmp(text+i,"PTHREAD_MUTEX_NORMAL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"PTHREAD_MUTEX_ROBUST",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_PC_CHOWN_RESTRICTED",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX2_BC_SCALE_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_HOST_NAME_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_SEM_NSEMS_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_SEM_VALUE_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_V7_LP64_OFF64",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_2_PBS_ACCOUNTING",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_2_PBS_CHECKPOINT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_COLL_WEIGHTS_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_GETGR_R_SIZE_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_GETPW_R_SIZE_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_REALTIME_SIGNALS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_THREAD_STACK_MIN",ntok)){*psyn=3;break;}break;case 21:if(!memcmp(text+i,"pthread_barrierattr_t",ntok)){*psyn=5;break;}if(!memcmp(text+i,"IN6_IS_ADDR_LINKLOCAL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"IN6_IS_ADDR_MC_GLOBAL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"IN6_IS_ADDR_MULTICAST",ntok)){*psyn=3;break;}if(!memcmp(text+i,"IN6_IS_ADDR_SITELOCAL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"PTHREAD_CANCEL_ENABLE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"PTHREAD_MUTEX_DEFAULT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"PTHREAD_MUTEX_STALLED",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_PC_REC_MAX_XFER_SIZE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_PC_REC_MIN_XFER_SIZE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX2_BC_STRING_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX2_EXPR_NEST_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_AIO_LISTIO_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_DELAYTIMER_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_LOGIN_NAME_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_V7_ILP32_OFF32",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_MEMORY_PROTECTION",ntok)){*psyn=3;break;}break;case 22:if(!memcmp(text+i,"PTHREAD_CANCEL_DISABLE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"PTHREAD_PROCESS_SHARED",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_PC_REC_INCR_XFER_SIZE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_ASYNCHRONOUS_IO",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_CLOCK_SELECTION",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_THREAD_KEYS_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_V7_ILP32_OFFBIG",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_V7_LPBIG_OFFBIG",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_AIO_PRIO_DELTA_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_THREAD_THREADS_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_TRACE_EVENT_FILTER",ntok)){*psyn=3;break;}break;case 23:if(!memcmp(text+i,"IN6_IS_ADDR_MC_ORGLOCAL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"IN6_IS_ADDR_UNSPECIFIED",ntok)){*psyn=3;break;}if(!memcmp(text+i,"PTHREAD_CANCEL_DEFERRED",ntok)){*psyn=3;break;}if(!memcmp(text+i,"PTHREAD_CREATE_DETACHED",ntok)){*psyn=3;break;}if(!memcmp(text+i,"PTHREAD_CREATE_JOINABLE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"PTHREAD_MUTEX_RECURSIVE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"PTHREAD_PROCESS_PRIVATE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_CHOWN_RESTRICTED",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_REALTIME_SIGNALS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_PRIORITY_SCHEDULING",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_READER_WRITER_LOCKS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_THREAD_PRIO_INHERIT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_THREAD_PRIO_PROTECT",ntok)){*psyn=3;break;}break;case 24:if(!memcmp(text+i,"IN6_IS_ADDR_MC_LINKLOCAL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"IN6_IS_ADDR_MC_NODELOCAL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"IN6_IS_ADDR_MC_SITELOCAL",ntok)){*psyn=3;break;}if(!memcmp(text+i,"PTHREAD_COND_INITIALIZER",ntok)){*psyn=3;break;}if(!memcmp(text+i,"PTHREAD_MUTEX_ERRORCHECK",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_PC_TIMESTAMP_RESOLUTION",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX2_COLL_WEIGHTS_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_MEMORY_PROTECTION",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_TRACE_EVENT_NAME_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_TRACE_USER_EVENT_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_TYPED_MEMORY_OBJECTS",ntok)){*psyn=3;break;}break;case 25:if(!memcmp(text+i,"PTHREAD_MUTEX_INITIALIZER",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_THREAD_THREADS_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_SHARED_MEMORY_OBJECTS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_THREAD_ATTR_STACKADDR",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_THREAD_ATTR_STACKSIZE",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_THREAD_PROCESS_SHARED",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_THREAD_SAFE_FUNCTIONS",ntok)){*psyn=3;break;}break;case 26:if(!memcmp(text+i,"PTHREAD_RWLOCK_INITIALIZER",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX2_CHARCLASS_NAME_MAX",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_READER_WRITER_LOCKS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_THREAD_SPORADIC_SERVER",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_XOPEN_REALTIME_THREADS",ntok)){*psyn=3;break;}break;case 27:if(!memcmp(text+i,"PTHREAD_CANCEL_ASYNCHRONOUS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_CS_POSIX_V7_THREADS_CFLAGS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_TIMESTAMP_RESOLUTION",ntok)){*psyn=3;break;}break;case 28:if(!memcmp(text+i,"_CS_POSIX_V7_LP64_OFF64_LIBS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_CS_POSIX_V7_THREADS_LDFLAGS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_POSIX_THREAD_SAFE_FUNCTIONS",ntok)){*psyn=3;break;}break;case 29:if(!memcmp(text+i,"PTHREAD_BARRIER_SERIAL_THREAD",ntok)){*psyn=3;break;}if(!memcmp(text+i,"PTHREAD_DESTRUCTOR_ITERATIONS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_CS_POSIX_V7_ILP32_OFF32_LIBS",ntok)){*psyn=3;break;}break;case 30:if(!memcmp(text+i,"_CS_POSIX_V7_ILP32_OFFBIG_LIBS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_CS_POSIX_V7_LP64_OFF64_CFLAGS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_CS_POSIX_V7_LPBIG_OFFBIG_LIBS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_THREAD_PRIORITY_SCHEDULING",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_THREAD_ROBUST_PRIO_INHERIT",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_THREAD_ROBUST_PRIO_PROTECT",ntok)){*psyn=3;break;}break;case 31:if(!memcmp(text+i,"_CS_POSIX_V7_ILP32_OFF32_CFLAGS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_CS_POSIX_V7_LP64_OFF64_LDFLAGS",ntok)){*psyn=3;break;}break;case 32:if(!memcmp(text+i,"_CS_POSIX_V7_ILP32_OFF32_LDFLAGS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_CS_POSIX_V7_ILP32_OFFBIG_CFLAGS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_CS_POSIX_V7_LPBIG_OFFBIG_CFLAGS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_SC_THREAD_DESTRUCTOR_ITERATIONS",ntok)){*psyn=3;break;}break;case 33:if(!memcmp(text+i,"_CS_POSIX_V7_ILP32_OFFBIG_LDFLAGS",ntok)){*psyn=3;break;}if(!memcmp(text+i,"_CS_POSIX_V7_LPBIG_OFFBIG_LDFLAGS",ntok)){*psyn=3;break;}break;case 34:if(!memcmp(text+i,"_CS_POSIX_V7_WIDTH_RESTRICTED_ENVS",ntok)){*psyn=3;break;}break;case 35:if(!memcmp(text+i,"_POSIX_THREAD_DESTRUCTOR_ITERATIONS",ntok)){*psyn=3;break;}break;
		}
	}
}

/* Assumes it's getting valid UTF-8 displayable glyphs */
void
vertbuf(double x00, double y00, size_t n, uint8_t *buf, char syn)
{
	
	// Loop through every grapheme
	for (size_t i=0; i<n;) {
		
		// Handle tab
		if (buf[i] == '\t') {
			x00 += wtab;
			i++;
			continue;
		}
		
		// Mark unknown glyphs for future lookup
		uint8_t ng,flags; double w; getgraphdisplay(n, buf, i, &ng, &w, &flags);
		uint32_t cps[ng]; size_t ncps=0; for (size_t j=0;j<ng;) {
			struct cp c = utf8(ng, buf+i, j);
			cps[ncps++] = c.c;
			j += c.n;
		}
		struct glyph *g = getglyph(ncps, cps);
		if (!g) {
			
			// Store in unknown glyph list
			if (ncpsstodo < ncps) {if (!(cpsstodo=realloc(cpsstodo,ncps*sizeof(*cpsstodo)))) {fprintf(stderr,"medcn: realloc cpsstodo %zu: %s\n",ncps*sizeof(*cpsstodo),strerror(errno));exit(EXIT_FAILURE);}memset(cpsstodo+ncpsstodo,0,sizeof(*cpsstodo)*(ncps-ncpsstodo));ncpsstodo=ncps;}
			struct arrcps *arr = cpsstodo + ncps-1;
			size_t itodo = getibsnu32(ncps, cps, arr->n, arr->cps);
			if (itodo>=arr->n || memcmp(cps,arr->cps+itodo*ncps,ncps*sizeof(uint32_t))) {
				ensuren(&arr->size, 0, (void**)&arr->cps, sizeof(*arr->cps)*ncps*(arr->n+1));
				if (itodo < arr->n) memmove(arr->cps+(itodo+1)*ncps,arr->cps+itodo*ncps,sizeof(*arr->cps)*ncps*(arr->n-itodo));
				memcpy(arr->cps+itodo*ncps, cps, sizeof(*cps)*ncps);
				arr->n++;
			}
			
			// Mark for redraw and move on
			needsredraw = 1;
			i += ng;
			continue;
		}
		
		// Add to vertices
		double x0=x00+g->offx, x1=x0+g->x1-g->x0, y0=y00+g->offy, y1=y0+g->y1-g->y0;
		double u0=(double)g->x0/wbmfont, u1=(double)g->x1/wbmfont, v0=(double)g->y0/hbmfont, v1=(double)g->y1/hbmfont;
		vertstext[nvertstext++] = (struct vtext){x0, y1, syn, u0, v1};
		vertstext[nvertstext++] = (struct vtext){x0, y0, syn, u0, v0};
		vertstext[nvertstext++] = (struct vtext){x1, y0, syn, u1, v0};
		vertstext[nvertstext++] = (struct vtext){x1, y1, syn, u1, v1};
		vertstext[nvertstext++] = (struct vtext){x0, y1, syn, u0, v1};
		vertstext[nvertstext++] = (struct vtext){x1, y0, syn, u1, v0};
		x00 += g->adv;
		i += ng;
	}
}

/* Assumes it's getting valid UTF-8 displayable glyphs */
void
vertbufov(double x00, double y00, size_t n, uint8_t *buf)
{
	
	// Loop through every grapheme
	for (size_t i=0; i<n;) {
		
		// Handle tab
		if (buf[i] == '\t') {
			x00 += wtab;
			i++;
			continue;
		}
		
		// Mark unknown glyphs for future lookup
		uint8_t ng,flags; double w; getgraphdisplay(n, buf, i, &ng, &w, &flags);
		uint32_t cps[ng]; size_t ncps=0; for (size_t j=0;j<ng;) {
			struct cp c = utf8(ng, buf+i, j);
			cps[ncps++] = c.c;
			j += c.n;
		}
		struct glyph *g = getglyph(ncps, cps);
		if (!g) {
			
			// Store in unknown glyph list
			if (ncpsstodo < ncps) {if (!(cpsstodo=realloc(cpsstodo,ncps*sizeof(*cpsstodo)))) {fprintf(stderr,"medcn: realloc cpsstodo %zu: %s\n",ncps*sizeof(*cpsstodo),strerror(errno));exit(EXIT_FAILURE);}memset(cpsstodo+ncpsstodo,0,sizeof(*cpsstodo)*(ncps-ncpsstodo));ncpsstodo=ncps;}
			struct arrcps *arr = cpsstodo + ncps-1;
			size_t itodo = getibsnu32(ncps, cps, arr->n, arr->cps);
			if (itodo>=arr->n || memcmp(cps,arr->cps+itodo*ncps,ncps*sizeof(uint32_t))) {
				ensuren(&arr->size, 0, (void**)&arr->cps, sizeof(*arr->cps)*ncps*(arr->n+1));
				if (itodo < arr->n) memmove(arr->cps+(itodo+1)*ncps,arr->cps+itodo*ncps,sizeof(*arr->cps)*ncps*(arr->n-itodo));
				memcpy(arr->cps+itodo*ncps, cps, sizeof(*cps)*ncps);
				arr->n++;
			}
			
			// Mark for redraw and move on
			needsredraw = 1;
			i += ng;
			continue;
		}
				
		// Add to vertices
		double x0=x00+g->offx, x1=x0+g->x1-g->x0, y0=y00+g->offy, y1=y0+g->y1-g->y0;
		double u0=(double)g->x0/wbmfont, u1=(double)g->x1/wbmfont, v0=(double)g->y0/hbmfont, v1=(double)g->y1/hbmfont;
		vertstextov[nvertstextov++] = (struct vtextov){x0, y1, u0, v1};
		vertstextov[nvertstextov++] = (struct vtextov){x0, y0, u0, v0};
		vertstextov[nvertstextov++] = (struct vtextov){x1, y0, u1, v0};
		vertstextov[nvertstextov++] = (struct vtextov){x1, y1, u1, v1};
		vertstextov[nvertstextov++] = (struct vtextov){x0, y1, u0, v1};
		vertstextov[nvertstextov++] = (struct vtextov){x1, y0, u1, v0};
		x00 += g->adv;
		i += ng;
	}
}

/* Assumes it's getting valid UTF-8 displayable glyphs */
void
vertbufkb(double x00, double y00, size_t n, uint8_t *buf)
{
	
	// Loop through every grapheme
	for (size_t i=0; i<n;) {
		
		// Handle tab
		if (buf[i] == '\t') {
			x00 += wtab;
			i++;
			continue;
		}
		
		// Mark unknown glyphs for future lookup
		uint8_t ng,flags; double w; getgraphdisplay(n, buf, i, &ng, &w, &flags);
		uint32_t cps[ng]; size_t ncps=0; for (size_t j=0;j<ng;) {
			struct cp c = utf8(ng, buf+i, j);
			cps[ncps++] = c.c;
			j += c.n;
		}
		struct glyph *g = getglyph(ncps, cps);
		if (!g) {
			
			// Store in unknown glyph list
			if (ncpsstodo < ncps) {if (!(cpsstodo=realloc(cpsstodo,ncps*sizeof(*cpsstodo)))) {fprintf(stderr,"medcn: realloc cpsstodo %zu: %s\n",ncps*sizeof(*cpsstodo),strerror(errno));exit(EXIT_FAILURE);}memset(cpsstodo+ncpsstodo,0,sizeof(*cpsstodo)*(ncps-ncpsstodo));ncpsstodo=ncps;}
			struct arrcps *arr = cpsstodo + ncps-1;
			size_t itodo = getibsnu32(ncps, cps, arr->n, arr->cps);
			if (itodo>=arr->n || memcmp(cps,arr->cps+itodo*ncps,ncps*sizeof(uint32_t))) {
				ensuren(&arr->size, 0, (void**)&arr->cps, sizeof(*arr->cps)*ncps*(arr->n+1));
				if (itodo < arr->n) memmove(arr->cps+(itodo+1)*ncps,arr->cps+itodo*ncps,sizeof(*arr->cps)*ncps*(arr->n-itodo));
				memcpy(arr->cps+itodo*ncps, cps, sizeof(*cps)*ncps);
				arr->n++;
			}
			
			// Mark for redraw and move on
			needsredraw = 1;
			i += ng;
			continue;
		}
		
		// Add to vertices
		double x0=x00+g->offx, x1=x0+g->x1-g->x0, y0=y00+g->offy, y1=y0+g->y1-g->y0;
		double u0=(double)g->x0/wbmfont, u1=(double)g->x1/wbmfont, v0=(double)g->y0/hbmfont, v1=(double)g->y1/hbmfont;
		vertstextkb[nvertstextkb++] = (struct vtextkb){x0, y1, u0, v1};
		vertstextkb[nvertstextkb++] = (struct vtextkb){x0, y0, u0, v0};
		vertstextkb[nvertstextkb++] = (struct vtextkb){x1, y0, u1, v0};
		vertstextkb[nvertstextkb++] = (struct vtextkb){x1, y1, u1, v1};
		vertstextkb[nvertstextkb++] = (struct vtextkb){x0, y1, u0, v1};
		vertstextkb[nvertstextkb++] = (struct vtextkb){x1, y0, u1, v0};
		x00 += g->adv;
		i += ng;
	}
}

void
vertchar(double x, double y, char c, char syn)
{
	vertbuf(x, y, 1, (uint8_t*)&c, syn);
}

void
vertexp(double x0, double y0, double x1, double y1, uint8_t borderud)
{
	y0 -= mline / 3;
	y1 -= mline / 3;
	vertsexp[nvertsexp++] = (struct vexp){x0, y1, x1, y0, borderud};
	vertsexp[nvertsexp++] = (struct vexp){x0, y0, x1, y1, borderud};
	vertsexp[nvertsexp++] = (struct vexp){x1, y0, x0, y1, borderud};
	vertsexp[nvertsexp++] = (struct vexp){x1, y1, x0, y0, borderud};
	vertsexp[nvertsexp++] = (struct vexp){x0, y1, x1, y0, borderud};
	vertsexp[nvertsexp++] = (struct vexp){x1, y0, x0, y1, borderud};
}

void
vertflow(double x0, double y0, double x1, double y1, uint8_t borderud)
{
	y0 -= mline / 3;
	y1 -= mline / 3;
	vertsflow[nvertsflow++] = (struct vflow){x0, y1, x1, y0, borderud};
	vertsflow[nvertsflow++] = (struct vflow){x0, y0, x1, y1, borderud};
	vertsflow[nvertsflow++] = (struct vflow){x1, y0, x0, y1, borderud};
	vertsflow[nvertsflow++] = (struct vflow){x1, y1, x0, y0, borderud};
	vertsflow[nvertsflow++] = (struct vflow){x0, y1, x1, y0, borderud};
	vertsflow[nvertsflow++] = (struct vflow){x1, y0, x0, y1, borderud};
}

void
vertselect(double x0, double y0, double x1)
{
	//df("vertselect %.2f,%.2f %.2f", x0, y0, x1);
	y0 -= mline / 3;
	double y1 = y0 + hline + mline;
	vertsselect[nvertsselect++] = (struct vselect){x0, y1};
	vertsselect[nvertsselect++] = (struct vselect){x0, y0};
	vertsselect[nvertsselect++] = (struct vselect){x1, y0};
	vertsselect[nvertsselect++] = (struct vselect){x1, y1};
	vertsselect[nvertsselect++] = (struct vselect){x0, y1};
	vertsselect[nvertsselect++] = (struct vselect){x1, y0};
}

/* Returns the end position after starting at pos
and going the distance implied via the distance d
interpreted via the flags: */
#define BUF 0x2000
/* next two args are size of buffer and buffer to use
instead of text */
#define XSTOP 0x01
/* next arg is an x to get as close to without
being right of */
#define XSTOPCOL 0x040000
/* like XSTOP, but relative to x0 of col (used in gocol) */
#define YSTOP 0x020000
/* next arg is a y to intersect but not start past
(so it includes the mline below) */
#define DBYTES 0x02
/* next arg is number of bytes to move */
#define DGRAPHS 0x04
/* next arg is number of graphemes to move */
#define DROWS 0x08
/* next arg is number of rows to move by, and it does
not go through each character */
#define DSPOTS 0x10
/* next arg is number of cursor locations to move */
#define HEIGHT 0x8000
/* next arg is height to stop after y is greater or equal */
#define MATCH 0x40
/* update match data with the Go regex */
#define MATCHREP0 0x0800
/* update match data with the Go regex */
#define NLINES 0x20
/* next arg is number of lines to loop through each character
of and stay on the end of */
#define NOEXPAND 0x4000
/* don't process any expansions */
#define NOSPACING 0x4000
/* don't process any spaced lines */
#define NROWS 0x80
/* next arg is number of rows to loop through each character
of and stay on the end of */
#define VERTS 0x0100
/* append to the vertex buffer */
#define X0 0x010000
/* x0 coordinate */
#define THREAD 0x0400
/* return early if hasinput() */
#define UNDERLINE 0x1000
/* underline each spot */
#define WIDTH 0x0200
/* use next arg as the width instead of displaySize_.width */
//#define df(...) (debug?df(__VA_ARGS__):0)
#define df0(...)
//#define df0(...) df(__VA_ARGS__)
struct at go(struct at pos, unsigned flags, ...);
union vgoarg { ssize_t ss; double d; size_t sz; uint8_t* p; };
struct at
vgo(struct at pos, unsigned flags, union vgoarg *args)
{
	//if (debug) df("go");

	// Process flags
	size_t nbuf=ntext; uint8_t *buf=text; if (flags&BUF) nbuf=args++->sz, buf=args++->p;
	ssize_t dbytes=SSIZE_MAX; if (flags & DBYTES) dbytes=args++->ss;
	ssize_t dgraphs=SSIZE_MAX; if (flags & DGRAPHS) dgraphs=args++->ss;
	ssize_t nrows=SSIZE_MAX; char isdrows=0; if (flags & DROWS) nrows=args++->ss,isdrows=1;
	ssize_t dspots=SSIZE_MAX; if (flags & DSPOTS) dspots=args++->ss;
	double height = (flags&HEIGHT) ? args++->d : INFINITY;
	if (flags & NROWS) nrows=args++->ss;
	char noexpand = !!(flags & NOEXPAND) || buf!=text;
	char nospacing = !!(flags & NOSPACING) || buf!=text;
	char thread = !!(flags & THREAD);
	char underline = !!(flags & UNDERLINE);
	char verts = !!(flags & VERTS);
	double wrow = flags&WIDTH ? args++->d : displaySize_.width;
	char isstopx = !!(flags & XSTOP);
	double stopx = isstopx ? args++->d : INFINITY;
	double x0 = flags&X0 ? args++->d : /*padwin*/0.0;
	double x1 = x0 + wrow;
	char isstopy = !!(flags & YSTOP);
	double stopy = isstopy ? args++->d : INFINITY;
	char backwards = dbytes<0 || dgraphs<0 || dspots<0 || nrows<0;
	if (backwards) { if(dbytes==SSIZE_MAX)dbytes=-(SSIZE_MAX-1); if(dgraphs==SSIZE_MAX)dgraphs=-(SSIZE_MAX-1); if(dspots==SSIZE_MAX)dspots=-(SSIZE_MAX-1); if(nrows==SSIZE_MAX)nrows=-(SSIZE_MAX-1); }

	// If drows, set stopcol to 0 and increment nrows
	if (isdrows) isstopx=1, stopx=0.0, nrows=nrows==SSIZE_MAX?SSIZE_MAX:nrows<0?nrows-1:nrows+1;

	// Initialize looping variables
	ssize_t row = pos.row,
		rowprev = row,
		ibyte = 0,
		igraph = pos.graph,
		graphprev = igraph,
		ispot = 0;
	size_t i = pos.i,
		iprev = i,
		istopx = SIZE_MAX;
	double xistopx = -1.0f;
	/*uint8_t col = pos.col,
		colprev = col;*/
		//D("backwards %d", backwards)
	double x = pos.x,
		xprev = x,
		y = pos.y,
		yprev = y,
		x0select = INFINITY;
	df0("go nrows%zd dbytes%zu height%.02f x0=%.02f%s%s", nrows, dbytes, height, x0, isstopx?" stopx":"", isstopy?" stopy":"");
	size_t iexp = noexpand ? SIZE_MAX : getiilexp(i),
		iflow = noexpand ? SIZE_MAX : getiflow(getiline(i));
	double y0exp = iexp==SIZE_MAX ? INFINITY : y,
		y0flow = iflow==SIZE_MAX ? INFINITY : y;
	char hastopexp = iexp==SIZE_MAX || ilexps[iexp]==i,
		hastopflow = iflow==SIZE_MAX || isflow[iflow]==i;
	//TODO: move bufexps to inside text buffer!
	size_t i0select, i1select;
	if (iselectstart==SIZE_MAX || (curselect==0?buf!=text:curselect==1?buf!=bufsearch:1) || iselectstart==iselectend) i0select=i1select=SIZE_MAX;
	else if (iselectstart < iselectend) i0select=iselectstart,i1select=iselectend;
	else i0select=iselectend, i1select=iselectstart;
	size_t i1syn=0; char syn=0;
	char issyn = verts && text==buf;
	size_t isyncachenext = nsynsts * 1024;
	char spaced = !nospacing && buf==text && getiline(i)==ilspaced;

	// Loop through each spot
	while (1) {
		df0("go loop i%zu x%.2f y%.02f row%zd%s", i, x, y, row, iexp!=SIZE_MAX?" exp":"");
		//D("i%zu", i)

		// Stop if any ending condition met
		if (backwards) {
			if (!i) { df0("go back !i"); break; }
			if ((ssize_t)(i-pos.i) <= dbytes) { df0("go back i-pos.i<=dbytes %zu-%zu<=%zd",i,pos.i,dbytes); break; }
			if (igraph-pos.graph <= dgraphs) break;
			if (row-pos.row <= nrows) break;
			if (isstopx && row-pos.row<=nrows+1 && fle(x,stopx)) break;
		} else {
		//TODO: stop based on bytes; for the 3-row go calcs, do -1 on the bytes (if end newline (assumed?)) to not continue to the next row
			if (isstopx && !isdrows && (isstopy?y+hline+mline>=stopy:row-pos.row>=nrows-1||y+hline+mline+hline>=height) && fle(stopx,x)) {
				if ((x>stopx&&yprev==y) || y>stopy) i=iprev, x=xprev, row=rowprev, y=yprev, igraph=graphprev;
				df0("go stopx"); break;
			}
			if (i >= nbuf) { df0("go i>=nbuf"); break; }
			if (i-pos.i >= dbytes) { df0("go >=dbytes"); break; }
			if (igraph-pos.graph >= dgraphs) break;
			if (row-pos.row >= nrows) { df0("go >=nrows"); break; }
			if (y > stopy) { df0("go y>stopy"); break; }
			if (isstopy && !isstopx && y+hline+mline>=stopy) break;
			if (y+hline >= height) { df0("go >=height"); break; }
		}

		// Update state values
		iprev=i, rowprev=row, xprev=x, yprev=y, graphprev=igraph;
		if (i0select<=i && i<i1select && (x==x0||i==i0select))
			x0select = x;
		if (verts && i==i1select) vertselect(x0select,y,x);

		// Backwards start of row
		if (backwards && fle(x,x0)) {

			// Go to prev line start, then end
			if (i && buf[i-1]=='\n') {

				// Find start of previous line
				df0("go start of prev from %zu", i-1);
				size_t j = getilinebuf(i-1, buf);
				df0("go start of prev got %zu; going %zu", j, i-1-j);
				
				// Go to end of unflowed first row
				if (noexpand || getiflow(j)==SIZE_MAX) {
					struct at endrow0 = go((at){.i=j,.x=x0}, NROWS|WIDTH|X0, 1, wrow, !nospacing&&text==buf&&j==ilspaced?x0spacing:x0);
					df0("go pop");
					x = endrow0.x;
					//i = endrow0.i==j ? j : endrow0.i-1;
					i = endrow0.i;

				// Go to end of flowed line
				} else {
					struct at endflow = go((at){.i=j,.x=x0}, DBYTES|WIDTH|X0, (ssize_t)(i-1-j), wrow, x0);
					df0("go pop");
					x=endflow.x, i=endflow.i;
				}
				iexp = noexpand ? SIZE_MAX : getiilexp(i);
				iflow = noexpand ? SIZE_MAX : getiflow(getiline(i));
				df0("go back exp end last i%zu %f", i, x);

			// Walk backwards through this row
			} else for (size_t j=i; j;) {
				j = igraphprev(nbuf, buf, j);
				if (buf[j] == '\n') break;
				uint8_t n,flags; double w; getgraphdisplay(nbuf, buf, j, &n, &w, &flags);

				// Update 
				if (x1-x < w) break;
				x += w;
				//df0("j %zu col %"PRIu8, j, col);
			}
			df0("after x%f i%zu", x, i);

			// Decrement row
			row--, igraph--, y-=hline+mline;

		// Newline
		} else if (buf[backwards?(i=igraphprev(nbuf,buf,i)):i] == '\n') {
			if (verts && i>=i0select && i<=i1select)
				vertselect(x0select,y,x);
			if (++i!=nbuf || buf!=text) row++, x=x0, y+=hline+mline;
			//if (print) { if (x0<wrow) printf("%s\033[K\033[m",underline?"\033[4m":""); if (row<nrows&&(i<nbuf||buf!=text)) { df0("go newline puts"); puts(""); } }
			size_t iexp0=iexp, iflow0=iflow;
			iexp = noexpand ? SIZE_MAX : getiilexp(i);
			iflow = noexpand ? SIZE_MAX : getiflow(i);
			if (verts && iexp0!=SIZE_MAX && iexp!=iexp0) { vertexp(x0,y0exp,x1,y,hastopexp|2); hastopexp=1; }
			if (verts && iflow0!=SIZE_MAX && iflow!=iflow0) {vertflow(x0,y0flow,x1,y,hastopflow|2);hastopflow=1;}
			if (iexp!=SIZE_MAX && iexp!=iexp0) y0exp=y;
			if (iflow!=SIZE_MAX && iflow!=iflow0) y0flow=y;
			if (spaced = !nospacing&&text==buf && i==ilspaced) x=x0spacing;
			igraph += backwards ? -1 : 1;

		// Normal character
		} else {
			uint8_t n,flags; double w;
			//D("getgraphdisplay");
			uint8_t *s = getgraphdisplay(nbuf, buf, i, &n, &w, &flags);
			//D("getgraphdisplay end");

			// Too big for this row
			df0("go %.*s i%zu n%" PRIu8 " x%.2f w%.2f wrow%d", (int)n, buf+i, i, n, x, w, (int)wrow);
			//if (!backwards && wrow-x<w+(i+n<nbuf&&buf[i+n]!='\n')) {
			if (!backwards && x1-x<w) {
				if (verts && i>=i0select && i<=i1select)
					vertselect(x0select,y,iselectend>i?x1:x);
				df0("too big i%zu", i);
				//if (print && i+n<nbuf) printf("%s\033[45m \033[m",underline?"\033[4m":"");
				//if (print && wrow-col>1) printf("%s\033[K\033[m",underline?"\033[4m":"");
				row++, y+=hline+mline, x=x0;
				//if (print && row<nrows) { df0("go too big puts"); say("\n"); }
				if (iflow == SIZE_MAX) {
					//i += n;
					while (i<nbuf && buf[i-1]!='\n') i++;
					size_t iexp0=iexp, iflow0=iflow;
					iexp = noexpand ? SIZE_MAX : getiilexp(i);
					iflow = noexpand ? SIZE_MAX : getiflow(i);
					if (verts && iexp0!=SIZE_MAX && iexp!=iexp0) { vertexp(x0,y0exp,x1,y,hastopexp|2); hastopexp=1; }
					if (verts && iflow0!=SIZE_MAX && iflow!=iflow0) {vertflow(x0,y0flow,x1,y,hastopflow|2);hastopflow=1;}
					if (iexp!=SIZE_MAX && iexp!=iexp0) y0exp=y;
					if (iflow!=SIZE_MAX && iflow!=iflow0) y0flow=y;
					if (spaced = !nospacing&&text==buf && i==ilspaced) x=x0spacing;
				}

			// Fits in row
			} else {
				if (verts) {
					char green = iexp!=SIZE_MAX && fle(x,x0),
						selected = i>=i0select && i<i1select;
#if 0
					if (selected) fputs("\033[7m",stdout);
					if (green) {
						fputs("\033[42m",stdout);
						size_t ilnext=i+2; while(ilnext<ntext&&text[ilnext-1]!='\n')ilnext++;
						size_t iexp = getiilexp(ilnext);
						if (iexp!=SIZE_MAX && ilexps[iexp]>i) fputs("\033[4m",stdout);
					}
					if (underline) fputs("\033[4m",stdout);
					if (green && buf[i]=='\t') printf(" \033[0m%s%s \033[0m",selected?"\033[7m":"",underline?"\033[4m":"");
					else {
#endif
						if (issyn) {
							if (i>i1syn+1024 && nsynsts) {
								size_t isynst = i / 1024;
								if (isynst >= nsynsts) isynst=nsynsts-1;
								syn=synsts[isynst].syn, i1syn=synsts[isynst].i1;
							}
							while (i1syn <= i) {
								getsyn(i1syn, &syn, &i1syn);
								while (i1syn > isyncachenext) {
									ensuren(&sizesynsts, 0, (void**)&synsts, sizeof(struct synst)*(nsynsts+1));
									synsts[nsynsts++] = (struct synst){.syn=syn, .i1=i1syn};
									isyncachenext += 1024;
								}
							}
#if 0
							switch (syn) {
							case 1: printf("\033[41m");break;
							case 2: printf("\033[36m");break;
							case 3: printf("\033[35m");break;
							case 4: printf("\033[33m");break;
							case 5: printf("\033[32m");break;
							}
#endif
						}

						// saygraphdisplay
						double ybase = y + hline;
						if (flags & GGD_STR0) vertbuf(x,ybase,strlen((char*)s),s,syn);
						else if (flags & GGD_HEX) {
							//fputs("\033[1m", stdout);
							double dx = 0.0;
							if (n > 1) vertchar(x+dx,ybase,'[',syn), dx+=adv('[');
							for (size_t j=0; j<n; j++) { vertchar(x+dx,ybase,hexc0(s[j]),syn); dx+=adv(hexc0(s[j])); vertchar(x+dx,ybase,hexc1(s[j]),syn); dx+=adv(hexc1(s[j])); }
							if (n > 1) vertchar(x+dx,ybase,']',syn), dx+=adv(']');
							//fputs("\033[0m", stdout);
						} else vertbuf(x, ybase, n, s, syn);

						//if (green || selected || underline || (issyn&&syn)) fputs("\033[0m",stdout);
#if 0
					}
#endif
				}
				if (backwards) x-=(spaced*wspacing)+w;
				else i+=n, x+=w+(spaced*wspacing);
			}
			igraph += backwards ? -1 : 1;
		}
	}
	//if (debug) df0("end go");

	// If we passed the row we wanted, use prev spot
	if (backwards
		? row-pos.row<=nrows
		: !isdrows && (row-pos.row >= nrows
			|| y+hline-(y>pos.y?mline:0) > height
			|| (isstopy && y>stopy)))
	{
	df0("go passed row%zd nrows%zd", row, nrows);
		i=iprev, x=xprev, row=rowprev, y=yprev, igraph=graphprev;
	}

	// Vert last selection, maybe duplicate
	if (verts && x!=x0 && x0select!=INFINITY && i>=i0select && i<=i1select)
		vertselect(x0select,y,x);
		
	// Vert ending exp (dupe if ntext?)
	if (verts && iexp!=SIZE_MAX) vertexp(x0,y0exp,x1,y,hastopexp|(i+1==ilexps[iexp]+exps[iexp].n?2:0));

	// Vert ending flow (dupe if ntext?)
	if (verts && iflow!=SIZE_MAX) vertflow(x0,y0flow,x1,y,hastopflow|(i+1<nbuf&&buf[i+1]=='\n'));

	// Return ending spot
	return (at){.i=i, .row=row, .x=x, .y=y, .graph=igraph};
}
#undef df0

struct at
go(struct at pos, unsigned flags, ...)
{
	va_list ap; va_start(ap,flags);
	union vgoarg args[11], *p=args;
	if (flags & BUF) p++->sz=va_arg(ap,size_t), p++->p=va_arg(ap,uint8_t*);
	if (flags & DBYTES) p++->ss=va_arg(ap,ssize_t);
	if (flags & DGRAPHS) p++->ss=va_arg(ap,ssize_t);
	if (flags & DROWS) p++->ss=va_arg(ap,ssize_t);
	if (flags & DSPOTS) p++->ss=va_arg(ap,ssize_t);
	if (flags & HEIGHT) p++->d=va_arg(ap,double);
	if (flags & NROWS) p++->ss=va_arg(ap,ssize_t);
	if (flags & WIDTH) p++->d=va_arg(ap,double);
	if (flags & XSTOP) p++->d=va_arg(ap,double);
	if (flags & X0) p++->d=va_arg(ap,double);
	if (flags & YSTOP) p++->d=va_arg(ap,double);
	va_end(ap);
	return vgo(pos, flags, args);
}

void
free_saved_state(struct android_app* android_app)
{
	pthread_mutex_lock(&android_app->mutex);
	if (android_app->savedState != NULL) {
		free(android_app->savedState);
		android_app->savedState = NULL;
		android_app->savedStateSize = 0;
	}
	pthread_mutex_unlock(&android_app->mutex);
}

/**
* Call when ALooper_pollAll() returns LOOPER_ID_MAIN, reading the next
* app command message.
*/
int8_t
android_app_read_cmd(struct android_app* android_app)
{
	int8_t cmd;
	if (read(android_app->msgread, &cmd, sizeof(cmd)) == sizeof(cmd)) {
		switch (cmd) {
			case APP_CMD_SAVE_STATE:
				free_saved_state(android_app);
				break;
		}
		return cmd;
	} else {
		LOGE0("No data on command pipe!");
	}
	return -1;
}

/* For debug builds, always enable the debug traces in this library */

#ifndef NDEBUG
#  define LOGV0(...)  ((void)printf(__VA_ARGS__))
#else
#  define LOGV0(...)  ((void)0)
#endif

static int pfd[2];
pthread_t debug_capture_thread;
void *
debug_capture_thread_fn( void * v )
{
	//struct android_app * app = (struct android_app*)v;
	ssize_t readSize;
	char buf[2048];

	while((readSize = read(pfd[0], buf, sizeof buf - 1)) > 0) {
		if(buf[readSize - 1] == '\n') {
			--readSize;
		}
		buf[readSize] = 0;  // add null-terminator
		__android_log_write(ANDROID_LOG_DEBUG, APPNAME, buf); // Set any log level you want
#ifdef RDALOGFNCB
		extern void RDALOGFNCB( int size, char * buf );
		RDALOGFNCB( readSize, buf );
#endif
		//if( debug_capture_hook_function ) debug_capture_hook_function( readSize, buf );
	}
	return 0;
}

void
print_cur_config(struct android_app* android_app)
{
	//For additional debugging this can be enabled, but for now - no need for the extra space.
/*
	char lang[2], country[2];
	AConfiguration_getLanguage(android_app->config, lang);
	AConfiguration_getCountry(android_app->config, country);

	LOGV0("Config: mcc=%d mnc=%d lang=%c%c cnt=%c%c orien=%d touch=%d dens=%d "
			"keys=%d nav=%d keysHid=%d navHid=%d sdk=%d size=%d long=%d "
			"modetype=%d modenight=%d",
			AConfiguration_getMcc(android_app->config),
			AConfiguration_getMnc(android_app->config),
			lang[0], lang[1], country[0], country[1],
			AConfiguration_getOrientation(android_app->config),
			AConfiguration_getTouchscreen(android_app->config),
			AConfiguration_getDensity(android_app->config),
			AConfiguration_getKeyboard(android_app->config),
			AConfiguration_getNavigation(android_app->config),
			AConfiguration_getKeysHidden(android_app->config),
			AConfiguration_getNavHidden(android_app->config),
			AConfiguration_getSdkVersion(android_app->config),
			AConfiguration_getScreenSize(android_app->config),
			AConfiguration_getScreenLong(android_app->config),
			AConfiguration_getUiModeType(android_app->config),
			AConfiguration_getUiModeNight(android_app->config));
*/
}

/**
* Call with the command returned by android_app_read_cmd() to do the
* initial pre-processing of the given command.  You can perform your own
* actions for the command after calling this function.
*/
void
android_app_pre_exec_cmd(struct android_app* android_app, int8_t cmd)
{
	switch (cmd) {
		case APP_CMD_INPUT_CHANGED:
			LOGV0("APP_CMD_INPUT_CHANGED\n");
			pthread_mutex_lock(&android_app->mutex);
			if (android_app->inputQueue != NULL) {
				AInputQueue_detachLooper(android_app->inputQueue);
			}
			android_app->inputQueue = android_app->pendingInputQueue;
			if (android_app->inputQueue != NULL) {
				LOGV0("Attaching input queue to looper");
				AInputQueue_attachLooper(android_app->inputQueue,
						android_app->looper, LOOPER_ID_INPUT, NULL,
						&android_app->inputPollSource);
			}
			pthread_cond_broadcast(&android_app->cond);
			pthread_mutex_unlock(&android_app->mutex);
			break;

		case APP_CMD_INIT_WINDOW:
			LOGV0("APP_CMD_INIT_WINDOW\n");
			pthread_mutex_lock(&android_app->mutex);
			android_app->window = android_app->pendingWindow;
			pthread_cond_broadcast(&android_app->cond);
			pthread_mutex_unlock(&android_app->mutex);
			break;

		case APP_CMD_TERM_WINDOW:
			LOGV0("APP_CMD_TERM_WINDOW\n");
			pthread_cond_broadcast(&android_app->cond);
			break;

		case APP_CMD_RESUME:
		case APP_CMD_START:
		case APP_CMD_PAUSE:
		case APP_CMD_STOP:
			LOGV0("activityState=%d\n", cmd);
			pthread_mutex_lock(&android_app->mutex);
			android_app->activityState = cmd;
			pthread_cond_broadcast(&android_app->cond);
			pthread_mutex_unlock(&android_app->mutex);
			break;

		case APP_CMD_CONFIG_CHANGED:
			LOGV0("APP_CMD_CONFIG_CHANGED\n");
			AConfiguration_fromAssetManager(android_app->config,
					android_app->activity->assetManager);
			print_cur_config(android_app);
			break;

		case APP_CMD_DESTROY:
			LOGV0("APP_CMD_DESTROY\n");
			android_app->destroyRequested = 1;
			break;
	}
}

/**
* Call with the command returned by android_app_read_cmd() to do the
* final post-processing of the given command.  You must have done your own
* actions for the command before calling this function.
*/
void
android_app_post_exec_cmd(struct android_app* android_app, int8_t cmd)
{
	switch (cmd) {
		case APP_CMD_TERM_WINDOW:
			LOGV0("APP_CMD_TERM_WINDOW\n");
			pthread_mutex_lock(&android_app->mutex);
			android_app->window = NULL;
			pthread_cond_broadcast(&android_app->cond);
			pthread_mutex_unlock(&android_app->mutex);
			break;

		case APP_CMD_SAVE_STATE:
			LOGV0("APP_CMD_SAVE_STATE\n");
			pthread_mutex_lock(&android_app->mutex);
			android_app->stateSaved = 1;
			pthread_cond_broadcast(&android_app->cond);
			pthread_mutex_unlock(&android_app->mutex);
			break;

		case APP_CMD_RESUME:
			free_saved_state(android_app);
			break;
	}
}

/**
* Dummy function that used to be used to prevent the linker from stripping app
* glue code. No longer necessary, since __attribute__((visibility("default")))
* does this for us.
*/
__attribute__((
	deprecated("Calls to app_dummy are no longer necessary. See "
			   "https://github.com/android-ndk/ndk/issues/381."))) void
app_dummy();

// Android log function wrappers
static const char* kTAG = "Vulkan-Tutorial06c";
#define LOGI(...) \
	((void)__android_log_print(ANDROID_LOG_INFO, kTAG, __VA_ARGS__))
#define LOGW(...) \
	((void)__android_log_print(ANDROID_LOG_WARN, kTAG, __VA_ARGS__))
#define LOGE(...) \
	((void)__android_log_print(ANDROID_LOG_ERROR, kTAG, __VA_ARGS__))

// Create VK shader module from given glsl shader file
// filePath: glsl shader file (including path ) in APK's asset folder
VkResult
buildShaderFromFile(struct android_app* appInfo, /*const char* filePath,*/ size_t nbuf, uint8_t *buf, VkShaderStageFlagBits type, VkDevice vkDevice, VkShaderModule* shaderOut)
{

	// build vulkan shader module
	VkResult result = vkCreateShaderModule(vkDevice,
		&(VkShaderModuleCreateInfo){
			.sType = VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO,
			.pNext = NULL,
			.flags = 0,
			.codeSize = nbuf,
			.pCode = (const uint32_t*)buf
		}, NULL, shaderOut);
	return result;
}

void
Perror(char *s)
{
	__android_log_print(ANDROID_LOG_ERROR, "%s: %s\n", s, strerror(errno));
}


// A help function to map required memory property into a VK memory type
// memory type is an index into the array of 32 entries; or the bit index
// for the memory type ( each BIT of an 32 bit integer is a type ).
VkResult
AllocateMemoryTypeFromProperties(uint32_t typeBits, VkFlags requirements_mask, uint32_t* typeIndex, VkPhysicalDeviceMemoryProperties gpuMemoryProperties)
{
	// Search memtypes to find first index with those properties
	for (uint32_t i = 0; i < 32; i++) {
		if ((typeBits & 1) == 1) {
			// Type is available, does it match user properties?
			if ((gpuMemoryProperties.memoryTypes[i].propertyFlags &
					 requirements_mask) == requirements_mask) {
				*typeIndex = i;
				return VK_SUCCESS;
			}
		}
		typeBits >>= 1;
	}
	// No memory types matched, return failure
	return VK_ERROR_MEMORY_MAP_FAILED;
}

void
setImageLayout(VkCommandBuffer cmdBuffer, VkImage image, VkImageLayout oldImageLayout, VkImageLayout newImageLayout, VkPipelineStageFlags srcStages, VkPipelineStageFlags destStages)
{
	VkImageMemoryBarrier imageMemoryBarrier = {
			.sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER,
			.pNext = NULL,
			.srcAccessMask = 0,
			.dstAccessMask = 0,
			.oldLayout = oldImageLayout,
			.newLayout = newImageLayout,
			.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED,
			.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED,
			.image = image,
			.subresourceRange =
					{
							.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT,
							.baseMipLevel = 0,
							.levelCount = 1,
							.baseArrayLayer = 0,
							.layerCount = 1
					},
	};

	switch (oldImageLayout) {
		case VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL:
			imageMemoryBarrier.srcAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
			break;

		case VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL:
			imageMemoryBarrier.srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
			break;

		case VK_IMAGE_LAYOUT_PREINITIALIZED:
			imageMemoryBarrier.srcAccessMask = VK_ACCESS_HOST_WRITE_BIT;
			break;

		default:
			break;
	}

	switch (newImageLayout) {
		case VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL:
			imageMemoryBarrier.dstAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
			break;

		case VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL:
			imageMemoryBarrier.dstAccessMask = VK_ACCESS_TRANSFER_READ_BIT;
			break;

		case VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL:
			imageMemoryBarrier.dstAccessMask = VK_ACCESS_SHADER_READ_BIT;
			break;

		case VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL:
			imageMemoryBarrier.dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
			break;

		case VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL:
			imageMemoryBarrier.dstAccessMask =
					VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT;
			break;

		default:
			break;
	}

	vkCmdPipelineBarrier(cmdBuffer, srcStages, destStages, 0, 0, NULL, 0, NULL, 1,
											 &imageMemoryBarrier);
}

VKAPI_ATTR VkBool32 VKAPI_CALL
DebugReportCallback(
		VkDebugReportFlagsEXT flags,
   VkDebugReportObjectTypeEXT objectType,
   uint64_t object,
   size_t location,
   int32_t messageCode,
   const char* pLayerPrefix,
   const char* pMessage,
   void* pUserData)
{
	Fprintf(stderr,
		"DebugReportCallback:\n"
		"  flags: %d\n"
		"  objectType: %d\n"
		"  object: %"PRIu64"\n"
		"  location: %zu\n"
		"  messageCode: %"PRId32"\n"
		"  pLayerPrefix: %s\n"
		"  pMessage: %s\n",
		flags, objectType, object, location, messageCode, pLayerPrefix, pMessage);

  // Returning false tells the layer not to stop when the event occurs, so
  // they see the same behavior with and without validation layers enabled.
  return VK_FALSE;
}

size_t
getsizefile(FILE *f)
{
	int fd = fileno(f);
	if (fd == -1) { Perror("D3D12HelloTexture: fileno"); exit(EXIT_FAILURE); }
	struct stat finfo; if (fstat(fd, &finfo) == -1) { Perror("D3D12HelloTexture: fstat"); exit(EXIT_FAILURE); }
	off_t lenf = finfo.st_size;
	if (lenf<0 || lenf>SIZE_MAX) { fprintf(stderr, "D3D12HelloTexture: bad off_t file size: %jd", (intmax_t)lenf); exit(EXIT_FAILURE); }
	return lenf;
}

void
//makepipeline(struct android_app *app, VkImageView view, VkSampler sampler)
makepipeline(struct android_app *app, VkPipelineLayout *playout, VkPipeline *ppipeline, VkPipelineCache *pcache, size_t nbufshadervert, uint8_t *bufshadervert, size_t nbufshaderfrag, uint8_t *bufshaderfrag, int stride, int sizevbuf, VkBuffer *pvbuf, VkDeviceMemory *pmemvbuf, int nvertdescs, ...)
{
	VkResult res;
	VkDescriptorSetLayout dscLayout_ = {0};
	va_list ap; va_start(ap,nvertdescs);

	// Create Graphics Pipeline
	{
	
		if (res=vkCreateDescriptorSetLayout(device_,
			&(VkDescriptorSetLayoutCreateInfo){
				.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO,
				.pNext = NULL,
				.bindingCount = 1,
				.pBindings = &(VkDescriptorSetLayoutBinding) {
					.binding = 0,
					.descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,
					.descriptorCount = 1,
					.stageFlags = VK_SHADER_STAGE_FRAGMENT_BIT,
					.pImmutableSamplers = NULL
				}
			}, NULL, &dscLayout_)) { Fprintf(stderr,"medcn: vkCreateDescriptorSetLayout: %d\n",res); exit(EXIT_FAILURE); }
		*desclayoutnext++ = dscLayout_;
		if (res=vkCreatePipelineLayout(device_,
			&(VkPipelineLayoutCreateInfo){
				.sType = VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO,
				.pNext = NULL,
				.setLayoutCount = 1,
				.pSetLayouts = &dscLayout_,
				.pushConstantRangeCount = 1,
				.pPushConstantRanges = (VkPushConstantRange[1]){{
					.size = sizeof(float) * 2,
					.stageFlags = VK_SHADER_STAGE_VERTEX_BIT
				}}
			}, NULL, playout)) { Fprintf(stderr,"medcn: vkCreatePipelineLayout: %d\n",res); exit(EXIT_FAILURE); }
		VkShaderModule vertexShader, fragmentShader;
		buildShaderFromFile(app, nbufshadervert, bufshadervert, VK_SHADER_STAGE_VERTEX_BIT, device_, &vertexShader);
		buildShaderFromFile(app, nbufshaderfrag, bufshaderfrag, VK_SHADER_STAGE_FRAGMENT_BIT, device_, &fragmentShader);
	
		// Create the pipeline cache
		if (res=vkCreatePipelineCache(device_,
			&(VkPipelineCacheCreateInfo){
				.sType = VK_STRUCTURE_TYPE_PIPELINE_CACHE_CREATE_INFO,
				.pNext = NULL,
				.flags = 0,	// reserved, must be 0
				.initialDataSize = 0,
				.pInitialData = NULL
			}, NULL, pcache)) { Fprintf(stderr,"medcn: vkCreatePipelineCache: %d\n",res); exit(EXIT_FAILURE); }
	
		// Create the pipeline
		VkVertexInputAttributeDescription *vertdescs = calloc(nvertdescs, sizeof(VkVertexInputAttributeDescription)); if (!vertdescs) { Fprintf(stderr, "medcn: calloc nvertdescs %d: %s\n", nvertdescs, strerror(errno)); exit(EXIT_FAILURE); }
		for (int i=0; i<nvertdescs; i++) {
			vertdescs[i] = (VkVertexInputAttributeDescription){
				.location = i,
				.binding = 0,
			};
			vertdescs[i].format = va_arg(ap, VkFormat);
			vertdescs[i].offset = va_arg(ap, int);
		}
		VkResult pipelineResult = vkCreateGraphicsPipelines(device_, *pcache, 1,
			&(VkGraphicsPipelineCreateInfo){
				.sType = VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO,
				.pNext = NULL,
				.flags = 0,
				.stageCount = 2,
				.pStages = (VkPipelineShaderStageCreateInfo[2]) {
				{
						.sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO,
						.pNext = NULL,
						.flags = 0,
						.stage = VK_SHADER_STAGE_VERTEX_BIT,
						.module = vertexShader,
						.pName = "main",
						.pSpecializationInfo = NULL
				},
				{
						.sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO,
						.pNext = NULL,
						.flags = 0,
						.stage = VK_SHADER_STAGE_FRAGMENT_BIT,
						.module = fragmentShader,
						.pName = "main",
						.pSpecializationInfo = NULL
				}},
				.pVertexInputState = &(VkPipelineVertexInputStateCreateInfo) {
					.sType = VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO,
					.pNext = NULL,
					.vertexBindingDescriptionCount = 1,
					.pVertexBindingDescriptions = (VkVertexInputBindingDescription[1]) {{
						.binding = 0,
						.stride = stride,
						.inputRate = VK_VERTEX_INPUT_RATE_VERTEX
					}},
					.vertexAttributeDescriptionCount = nvertdescs,
					.pVertexAttributeDescriptions = vertdescs
				},
				.pInputAssemblyState = &(VkPipelineInputAssemblyStateCreateInfo) {
					.sType = VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO,
					.pNext = NULL,
					.topology = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST,
					.primitiveRestartEnable = VK_FALSE
				},
				.pTessellationState = NULL,
				.pViewportState = &(VkPipelineViewportStateCreateInfo) {
					.sType = VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO,
					.pNext = NULL,
					.viewportCount = 1,
					.pViewports = &(VkViewport) {
						.x = 0,
						.y = 0,
						.width = (float)displaySize_.width,
						.height = (float)displaySize_.height,
						.minDepth = 0.0f,
						.maxDepth = 1.0f
					},
					.scissorCount = 1,
					.pScissors = &(VkRect2D) {
							.offset = {.x = 0, .y = 0},
							.extent = displaySize_
			 		}
				},
				.pRasterizationState = &(VkPipelineRasterizationStateCreateInfo) {
					.sType = VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO,
					.pNext = NULL,
					.depthClampEnable = VK_FALSE,
					.rasterizerDiscardEnable = VK_FALSE,
					.polygonMode = VK_POLYGON_MODE_FILL,
					.cullMode = VK_CULL_MODE_NONE,
					.frontFace = VK_FRONT_FACE_CLOCKWISE,
					.depthBiasEnable = VK_FALSE,
					.lineWidth = 1
				},
				.pMultisampleState = &(VkPipelineMultisampleStateCreateInfo) {
					.sType = VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO,
					.pNext = NULL,
					.rasterizationSamples = VK_SAMPLE_COUNT_1_BIT,
					.sampleShadingEnable = VK_FALSE,
					.minSampleShading = 0,
					.pSampleMask = &(VkSampleMask){~0u},
					.alphaToCoverageEnable = VK_FALSE,
					.alphaToOneEnable = VK_FALSE
				},
				.pDepthStencilState = NULL,
#if 0
				.pColorBlendState = &(VkPipelineColorBlendStateCreateInfo) {
					.sType = VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO,
					.pNext = NULL,
					.flags = 0,
					.logicOpEnable = VK_FALSE,
					.logicOp = VK_LOGIC_OP_COPY,
					.attachmentCount = 1,
					.pAttachments = &(VkPipelineColorBlendAttachmentState) {
						.blendEnable = VK_FALSE,
						.colorWriteMask = VK_COLOR_COMPONENT_R_BIT | VK_COLOR_COMPONENT_G_BIT | VK_COLOR_COMPONENT_B_BIT | VK_COLOR_COMPONENT_A_BIT
					}
				},
#else
				.pColorBlendState = &(VkPipelineColorBlendStateCreateInfo) {
					.sType = VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO,
					.pNext = NULL,
					.flags = 0,
					.logicOpEnable = VK_FALSE,
					.logicOp = VK_LOGIC_OP_COPY,
					.attachmentCount = 1,
					.pAttachments = &(VkPipelineColorBlendAttachmentState) {
						.blendEnable = VK_TRUE,
						.srcColorBlendFactor = VK_BLEND_FACTOR_SRC_ALPHA,
						.dstColorBlendFactor = VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA,
						.colorBlendOp = VK_BLEND_OP_ADD,
						.srcAlphaBlendFactor = VK_BLEND_FACTOR_ONE,
						.dstAlphaBlendFactor = VK_BLEND_FACTOR_ZERO,
						.alphaBlendOp = VK_BLEND_OP_ADD,
						.colorWriteMask = VK_COLOR_COMPONENT_R_BIT | VK_COLOR_COMPONENT_G_BIT | VK_COLOR_COMPONENT_B_BIT | VK_COLOR_COMPONENT_A_BIT
					}
				},
#endif
				.pDynamicState = &(VkPipelineDynamicStateCreateInfo){
					.sType = VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO,
					.pNext = NULL,
					.dynamicStateCount = 0,
					.pDynamicStates = NULL
				},
				.layout = *playout,
				.renderPass = renderPass_,
				.subpass = 0,
				.basePipelineHandle = VK_NULL_HANDLE,
				.basePipelineIndex = 0
			}, NULL, ppipeline);
		free(vertdescs);
	
		// We don't need the shaders anymore, we can release their memory
		vkDestroyShaderModule(device_, vertexShader, NULL);
		vkDestroyShaderModule(device_, fragmentShader, NULL);
	}

	// initialize descriptor set
	int nsamplers = va_arg(ap, int);
	if (nsamplers) {
		VkDescriptorPool *pdescpool = va_arg(ap, VkDescriptorPool*);
		VkDescriptorSet *pdescset = va_arg(ap, VkDescriptorSet*);
		if (res=vkCreateDescriptorPool(device_,
				&(VkDescriptorPoolCreateInfo) {
					.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO,
					.pNext = NULL,
					.maxSets = 1,
					.poolSizeCount = 1,
					.pPoolSizes = (VkDescriptorPoolSize[1]) {{
						.type = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,
						.descriptorCount = nsamplers
					}}
				}, NULL, pdescpool)) { Fprintf(stderr,"medcn: vkCreateDescriptorPool: %d\n",res); exit(EXIT_FAILURE); }
		if (res=vkAllocateDescriptorSets(device_,
			&(VkDescriptorSetAllocateInfo){
				.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO,
				.pNext = NULL,
				.descriptorPool = *pdescpool,
				.descriptorSetCount = 1,
				.pSetLayouts = &dscLayout_
			}, pdescset)) { Fprintf(stderr,"medcn: vkAllocateDescriptorSets: %d\n",res); exit(EXIT_FAILURE); }
	}

	// Make vertex buffer
	{
	
		// Create a vertex buffer
		if (res=vkCreateBuffer(device_,
			&(VkBufferCreateInfo) {
				.sType = VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO,
				.pNext = NULL,
				.flags = 0,
				.size = sizevbuf,
				.usage = VK_BUFFER_USAGE_VERTEX_BUFFER_BIT,
				.sharingMode = VK_SHARING_MODE_EXCLUSIVE,
				.queueFamilyIndexCount = 1,
				.pQueueFamilyIndices = &queueFamilyIndex_
			}, NULL, pvbuf)) { Fprintf(stderr,"medcn: vkCreateBuffer: %d\n",res); exit(EXIT_FAILURE); }
		VkMemoryRequirements memReq;
		vkGetBufferMemoryRequirements(device_, *pvbuf, &memReq);
		VkMemoryAllocateInfo allocInfo = {
			.sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO,
			.pNext = NULL,
			.allocationSize = memReq.size,
			.memoryTypeIndex = 0	// Memory type assigned in the next step
		};
	
		// Assign the proper memory type for that buffer
		uint32_t typeBits = memReq.memoryTypeBits;
		VkPhysicalDeviceMemoryProperties memoryProperties;
		vkGetPhysicalDeviceMemoryProperties(gpuDevice_, &memoryProperties);
		// Search memtypes to find first index with those properties
		for (uint32_t i = 0; i < 32; i++) {
			if ((typeBits & 1) == 1) {
				// Type is available, does it match user properties?
				if ((memoryProperties.memoryTypes[i].propertyFlags & (VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT)) ==
						(VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT)) {
					allocInfo.memoryTypeIndex = i;
					break;
				}
			}
			typeBits >>= 1;
		}
	
		// Allocate memory for the buffer
		if (res=vkAllocateMemory(device_, &allocInfo, NULL, pmemvbuf)) { Fprintf(stderr,"medcn: vkAllocateMemory: %d\n",res); exit(EXIT_FAILURE); }
		if (res=vkBindBufferMemory(device_, *pvbuf, *pmemvbuf, 0)) { Fprintf(stderr,"medcn: vkBindBufferMemory: %d\n",res); exit(EXIT_FAILURE); }
	}
	va_end(ap);
}

size_t
getinonemptyline(size_t i0, size_t i1)
{
	size_t i=i0; while (i < i1) {
		size_t j=0; for (; i+j<i1 && text[i+j]!='\n'; j++) if (!isspace(text[i+j])) goto endblank2;
		i += j + (i+j<i1);
	} endblank2:;
	return i;
}

/* Returns the index to start displaying, assuming
the previous block is unexpanded and you want to hide
starting empty lines */
size_t
getilshown(size_t i0blk, struct block *blk)
{
	size_t i1blk = i0blk + blk->n;
	size_t i = getinonemptyline(i0blk, i1blk);
	if (blk->iminshow1 && i-i0blk>blk->iminshow1-1) i=getiline(i0blk+blk->iminshow1-1);
	if (i==i1blk && i1blk>i0blk) i=getiline(i-1);
	return i;
}

char*
sblk(struct block *blk)
{
//return "disabled";
	static char buf[4096];
	
	if (!blk) { strcpy(buf,"NULL"); return buf; }
	
	for (struct block *b=blocks; b!=blk;) {
		if (b->nblocks) b=b->blocks;
		else while (1) {
			size_t nsib; struct block *head;
			if (b->parent) nsib=b->parent->nblocks,head=b->parent->blocks;
			else nsib=nblocks,head=blocks;
			if (b-head < nsib-1) { b++; break; }
			else if (b->parent) b=b->parent;
			else { sprintf(buf,"?%p",blk); return buf; }
		}
	}
	
	
	int ngen=0; for (struct block *b=blk; b; b=b->parent) ngen++;
	int ibuf = 0;
	for (int iancprint=ngen-1; iancprint>=0; iancprint--) {
		struct block *blkprint=blk; for (int i=0; i<iancprint; i++) blkprint=blkprint->parent;
		size_t nsib; struct block *head;
		if (blkprint->parent) nsib=blkprint->parent->nblocks,head=blkprint->parent->blocks;
		else nsib=nblocks,head=blocks;
		ibuf += sprintf(buf+ibuf, "%ld%s", blkprint-head+1, iancprint?".":"");
	}
	return buf;
}

void
nextblki0(struct block **pblk, size_t *pi0)
{
	if (!*pblk) { *pi0=ntext; return; }
	if ((*pblk)->nblocks) {
		*pi0+=(*pblk)->iblocks, *pblk=(*pblk)->blocks;
		return;
	}
	while (1) {
		if (!(*pblk)->parent || (*pblk)-(*pblk)->parent->blocks+1<(*pblk)->parent->nblocks) {
			*pi0+=(*pblk)->n, (*pblk)++;
			if (*pblk == blocks+nblocks) *pblk=NULL;
			return;
		}
		*pblk = (*pblk)->parent;
		*pi0 -= (*pblk)->iblocks;
		for (size_t i=0; i+1<(*pblk)->nblocks; i++) *pi0-=(*pblk)->blocks[i].n;
	}
}

void
checkblk(struct block *blk, size_t i0)
{
	if (!blk) return;
	struct block *b=blocks; size_t i=0;
	while (b) {
		if (b == blk) {
			if (i != i0) df("BAD BLK %s %zu (%zu) (ntext=%zu)", sblk(blk), i0, i, ntext);
			return;
		}
		nextblki0(&b, &i);
	}
	df("BAD BLK not found %s %zu (ntext=%zu)", sblk(blk), i0, ntext);
}

void
getlabel(size_t i0blk, struct block *blk, size_t *pilabel, size_t *pnlabel)
{

	// Function heuristic: ^[alnum_ *]+(
	size_t ilabel, nlabel, i1blk=i0blk+blk->n;
	char cmt = 0; // no,yes cant end,yes,no cant start
	for (ilabel=i0blk; ilabel<i1blk; ilabel++) {

		// Skip comments
		if (cmt == 1) { cmt++; continue; }
		if (cmt == 2) { cmt+=!memcmp(text+ilabel-2,"*/",2);continue;}
		if (cmt == 3) cmt=0;
		else if(ilabel-i0blk>=2&&!memcmp(text+ilabel-2,"/*",2))cmt=1;

		// Only examine line starts
		if (ilabel==i0blk || text[ilabel-1]!='\n') continue;

		// [alnum_ *]+(
		for (size_t j=ilabel; j<i1blk; j++) {
			if (text[j] == ' ') { ilabel=j+1; continue; }
			if (text[j]=='(' && j>ilabel) { nlabel=j-ilabel; goto donelabel; }
			//if (strchr("{}[]() \t\n.=+/*\"'?!;&\\%",text[j])) break;
			if (strchr("#{}[]()\t\n.=+/\"'?!;&\\%",text[j])) break;
		}
	}

	// Get first nonpunc part
	ilabel = getinonemptyline(i0blk, i1blk);
#if 0
	while (ilabel<i1blk && isspace(text[ilabel])) ilabel++;
#endif
	for (size_t i=ilabel; i<i1blk; i++) {
		char c = text[i];
		if (!isspace(c) && !strchr("/*-",c)) { ilabel=i; break; }
	}
	//if (i1blk-ilabel>=3 && !memcmp("// ",text+ilabel,3)) ilabel+=3;
	nlabel = go((at){.i=ilabel,.x=padwin},DBYTES|NROWS|WIDTH,(ssize_t)(i1blk-ilabel),(ssize_t)1,displaySize_.width-padwin).i - ilabel;
	//TODO: specify width? or gets truncated anyway?

	// Store the result
	donelabel:
	*pilabel=ilabel, *pnlabel=nlabel;
}

/* If a block has text after its subblocks, it will
be returned after them */
void
nextblki0text(struct block **pblk, size_t *pi0)
{
	if (!*pblk) { *pi0=ntext; return; }

	while (1) {

		// Move to sibling
		struct block *parent = (*pblk)->parent;
		size_t nblks; struct block *head;
		if (parent) nblks=parent->nblocks, head=parent->blocks;
		else nblks=nblocks, head=blocks;
		if ((*pblk)-head+1 < nblks) { *pi0+=(*pblk)->n; (*pblk)++; return; }

		// No more blocks
		if (!parent) { *pblk=NULL, *pi0=ntext; return; }

		// Move to parent
		*pi0 -= parent->iblocks;
		for (size_t i=0; i<parent->nblocks-1; i++) *pi0-=parent->blocks[i].n;
		size_t n=parent->iblocks; for (size_t i=0; i<parent->nblocks; i++) n+=parent->blocks[i].n;
		*pblk = parent;
		if (n < (*pblk)->n) return;
	}
}

size_t
getisearchresultsbs(size_t i, char section)
{
	return section > sectionssearched
		? nissearchresults
		: section == 0
		? getibs(i, sectionssearched?isrlabels:nissearchresults, issearchresults)
		: section == 1
		? isrlabels + getibs(i/*-isrlabels*/,(sectionssearched>=2?isrdirect:nissearchresults)-isrlabels,issearchresults+isrlabels)
		: isrdirect + getibs(i/*-isrdirect*/,nissearchresults-isrdirect,issearchresults+isrdirect);
}

char*
getslabel(size_t i0blk, struct block *blk)
{
	size_t i,n; getlabel(i0blk, blk, &i, &n);
	static char *s = NULL;
	static size_t size = 0;
	ensuren(&size, 0, (void**)&s, n+1);
	memcpy(s, text+i, n);
	s[n] = 0;
	return s;
}

void
ensurens(size_t n, size_t *psize, int size0, void **pbuf, ...)
{
	if (n*size0 <= *psize) return;
	while (*psize < n*size0) *psize=*psize?*psize*2:2048;
	int size = size0;
	va_list ap;
	va_start(ap, pbuf);
	while (1) {
		if (!(*pbuf=realloc(*pbuf,*psize/size0*size))) { fprintf(stderr,"D3D12HelloTexture: ensurens realloc %zu: %s\n",*psize/size0*size,strerror(errno)); exit(EXIT_FAILURE); }
		if (!(size=va_arg(ap,int))) break;
		pbuf = va_arg(ap, void**);
	}
	va_end(ap);
}

size_t
geti0ancestor(size_t i0, struct block *desc, struct block *anc)
{
	for (struct block *b=desc; b!=anc; b=b->parent) {
		struct block *p = b->parent;
		i0 -= p->iblocks;
		for (struct block *b2=p->blocks; b2!=b; b2++) i0-=b2->n;
	}
	return i0;
}

void
getblocki(size_t i, struct block** ppblk, size_t* pi0, char allexpanded)
{
	struct block* blk = blocks;
	size_t i0 = 0;
	for (; blk - blocks + 1 < nblocks && i0 + blk->n <= i; i0 += blk++->n);
	while ((allexpanded || blk->expanded) && blk->nblocks && i >= i0 + blk->iblocks) {
		size_t ipost = i0 + blk->iblocks;
		size_t j; for (j = 0; j < blk->nblocks && ipost + blk->blocks[j].n <= i; ipost += blk->blocks[j++].n);
		if (j == blk->nblocks) break;
		i0 = ipost, blk = blk->blocks + j;
	}
	if (ppblk) *ppblk = blk;
	if (pi0) *pi0 = i0;
}

struct atblk
attopblk(void)
{
	struct atblk top = {.x=0, .y=ytop, .i=itop};
	getblocki(itop, &top.blk, &top.i0blk, 0);
	return top;
}

size_t
getnindent(size_t i)
{
	size_t n = 0;
	while (i+n<ntext && isspace(text[i+n]) && text[i+n]!='\n') n++;
	return n;
}

void
ensurentext(size_t n)
{
	ensuren(&sizetext, ntext, (void**)&text, n);
}

void
ensurensearch(size_t n)
{
	ensuren(&sizesearch, nsearch, (void**)&bufsearch, n);
}

void
matchexpansion(struct block old, struct block *blknew, size_t off)
{
	size_t i = 0;
	struct block *b = &old;
	while (b->nblocks) {
		if (off < i+b->iblocks) break;
		i += b->iblocks;
		for (size_t j=0; j<b->nblocks; i+=b->blocks[j++].n) if (off < i+b->blocks[j].n) { b=b->blocks+j; goto nextroot; }
		break;
		nextroot:;
	}
	blknew->expanded = b->expanded;
	if (blknew->nblocks) {
		off += blknew->iblocks;
		for (size_t j=0; j<blknew->nblocks; off+=blknew->blocks[j++].n) matchexpansion(old, blknew->blocks+j, off);
	}
}

#define df0(...)
void
blockize(size_t i0, size_t i1, size_t *psizeblocks, size_t *pnblocks, struct block **pblocks, char stopnegenc)
{
	df0("blockize %zu-%zu", i0, i1);
	ssize_t nbrace=0, nparen=0;
	for (size_t istart=i0; istart<i1;) {
		//df0("blockize new block istart%zu", istart);

		// Append a new block
		if (*pnblocks*sizeof(struct block) == *psizeblocks) *pblocks = (struct block*)Realloc(*pblocks,*psizeblocks=*psizeblocks?*psizeblocks*2:sizeof(struct block)*128);
		struct block *blk = *pblocks + (*pnblocks)++;
		*blk = (struct block){0};
#define B (text + istart + blk->n)
#define HAS(x) (i1-(istart+blk->n) >= x)

		// Consume blank lines
		blk->n = getinonemptyline(istart,i1) - istart;

		// Consume nonblank lines, and entire {}'s
		char str=0, ch=0, cmtln=0, cmtst=0, esc=0, empty=1, closeopen=0;;
		size_t iline=blk->n, icmtst, i1cmtst=SIZE_MAX, iblknest=ntext, iemptyprev=ntext, nindentline0nonempty=SIZE_MAX, ilinepostbrace=SIZE_MAX;
		ssize_t nbraceemptyprev, nbraceline=nbrace, nbracelinepostbrace;
		//ssize_t nbrace=0, nparen=0;
		for (; HAS(1); blk->n++) {
			df0("i%zu iline%zu nbrace%zd%s%s%s%s%s%s%s", istart+blk->n, istart+iline, nbrace, str?" str":"", ch?" ch":"", cmtln?" cmtln":"", cmtst?" cmtst":"", esc?" esc":"", empty?" empty":"", iblknest<ntext?" nest":"");

			// Update line properties
			char empty0;
			{
				empty0 = empty;
				empty = empty && isspace(B[0]);
				closeopen = 0;

				// Mark the indent amount of the first nonempty
				// line after the last empty one if it's not set,
				// with a special exception ignoring labels
				if (nindentline0nonempty==SIZE_MAX && empty0 && !empty) {
					size_t i; for (i=0; istart+blk->n+i<ntext && isalnum(B[i]); i++);
					if (istart+blk->n+i<ntext && B[i]!=':') nindentline0nonempty=blk->n-iline;
				}
			}

			// Newline
			if (B[0] == '\n') {

				// Ending brace/paren from parent block
				if ((nbrace<0||nparen<0) && iline && stopnegenc) {
					
					// These should end on previous line:
					//   }
					//   } endthing:;
					// These should include this line:
					//   || i > 3)
					// So check if there's stuff before a })
					char st = 0; // 1=saw stuff, 2=1 then )}
					for (size_t j=iline; j<blk->n; j++)
						if (strchr(")}",text[istart+j])) {
							if (st) { st=2; break; }
						} else if (!isspace(text[istart+j])) st=1;
					//size_t j=iline; for (; j<blk->n && (isspace(text[istart+j])||strchr("})",text[istart+j])); j++);
					//blk->n = j==blk->n ? iline : blk->n+1;
					blk->n = st==2 ? blk->n+1 : iline;
					break;
				}

				// Empty line = end of block or nesting
				if (empty && !cmtst) {
					iemptyprev = iline;
					nbraceemptyprev = nbraceline;
					//if (!nbrace && !nparen) { blk->n=iline; break; }
					if (nbrace<=0 && nparen<=0) { blk->n=iline; break; }
					//if (iblknest == ntext) iblknest=getinonemptyline(istart+(ilinepostbrace==SIZE_MAX||nbrace<=nbracelinepostbrace?blk->n:ilinepostbrace),ntext); //TODO: just use iline? so empty lines part of start od block nest?
					if (iblknest == ntext) iblknest=istart+(ilinepostbrace==SIZE_MAX||nbrace<=nbracelinepostbrace?iline:ilinepostbrace);
					nindentline0nonempty = SIZE_MAX;
				}

				/*
				// Ending brace/paren from parent block
				if ((nbrace<0||nparen<0) && iline && stopnegenc) {
					blk->n = iline;
					break;
				}
				*/
				
				// Reset line properties
				str = ch = cmtln = esc = 0;
				empty = 1;
				iline = blk->n + 1;
				nbraceline = nbrace;
				if (ilinepostbrace==SIZE_MAX && nbrace) ilinepostbrace=blk->n+1, nbracelinepostbrace=nbrace;
				
			// Escaped
			} else if (esc) {
				esc = 0;
				
			// Comment line
			} else if (cmtln) {
			
			// Comment star
			} else if (cmtst) {
				if (blk->n>=icmtst+3 && !memcmp(B-1,"*/",2)) cmtst=0,i1cmtst=blk->n;
				
			// Backslash
			} else if (B[0] == '\\') {
				esc = 1;
				
			// String
			} else if (str) {
				str = B[0] != '"';
				
			// Char
			} else if (ch) {
				ch = B[0] != '\'';
				
			// New string
			} else if (B[0] == '"') {
				str = 1;
				
			// New char
			} else if (B[0] == '\'') {
				ch = 1;
				
			// New line comment
			} else if (B-text>=1 && blk->n-1!=i1cmtst && !memcmp(B-1,"//",2)) {
				cmtln = 1;
				
			// New star comment
			} else if (B-text>=1 && blk->n-1!=i1cmtst && !memcmp(B-1,"/*",2)) {
				cmtst = 1;
				icmtst = blk->n - 1;
				
			// New brace
			} else if (B[0] == '{') {
				ssize_t nbrace0 = nbrace;
				if (nbrace < 0) nbrace=0; // allow chaining prev close
				nbrace++;
				closeopen = nbrace0 < 0;
				
			// New paren
			} else if (B[0] == '(') {
				if (nparen < 0) nparen=0; // allow chaining prev close
				nparen++;
				//closeopen = nparen == 1;
				
			// End brace
			} else if (B[0] == '}') {
				nbrace--;
				
				// Situation A:
				// // Handle a
				// if (a) {
				//   handle(a);
				//   a = 0;
				//
				// // Handle others
				// } else handle(other);
				// ^
				//
				// Situation B:
				// // Handle cases
				// if (a) {
				//   handle(a);
				//   a = 0;
				//
				//   // Further a handling goes here
				// } else handle(other);
				// ^
				//
				// Situation C:
				// switch (x) {
				//
				// case 1: return x;
				// }
				// ^
				//
				// Situation A should be 2 blocks, Situation B
				// should be 1 outer block. We detect this at the
				// closing brace by tracking the indent of the
				// first line after the last blank line. Situation C
				// should be an inner block, so also check for
				// nonspace before newline.
				if (!nbrace && iemptyprev<ntext && empty0 && blk->n-iline==nindentline0nonempty) {
					char foundnonspace = 0;
					for (size_t i=istart+blk->n+1; i<ntext&&text[i]!='\n'; i++) if (!isspace(text[i])) {foundnonspace=1;break;}
					if (foundnonspace) {
						ssize_t i; for (i=iemptyprev; i>0 && isspace(text[istart+i]); i--);
						if (i > -1) while (text[istart+i] != '\n') i++;
						i++;
						blk->n = i;
						nbrace = nbraceemptyprev;
						if (iblknest >= istart+blk->n) iblknest=ntext;
						break;
					}
				}
				
			// End paren
			} else if (B[0] == ')') {
				nparen--;
			}
				
			// We thought it's nesting because of a brace/paren,
			// but that brace just closed and another opened, so
			// this is a sibling, not a child
			if (closeopen && iemptyprev<ntext && iblknest<ntext) {
				ssize_t i; for (i=iemptyprev; i>0 && isspace(text[istart+i]); i--);
				if (i > -1) while (text[istart+i] != '\n') i++;
				i++;
				blk->n = i;
				if (iblknest >= istart+blk->n) iblknest=ntext;
				break;
			}
		}
		df0("blockize broke block loop");
			
		// If there's never another nonempty line, add to this one
		for (size_t i=0; HAS(i+1); i++) if (!isspace(B[i])) goto hasnonempty;
		blk->n = i1 - istart;
		hasnonempty:;
		
		// Get nested blocks
		if (iblknest < istart+blk->n) {
			blk->iblocks = iblknest - istart;
			blockize(istart+blk->iblocks, istart+blk->n, &blk->sizeblocks, &blk->nblocks, &blk->blocks, 1);
			df0("blockize %zu-%zu CONT", i0, i1);
		}
		
		// Stop if we hit a parent's end brace / paren
		if (nbrace<0 || nparen<0) break;
		
		// Increment to next block
		istart += blk->n;
#undef B
#undef HAS
	}
	
	// Set parents of subblocks
	for (size_t i=0; i<*pnblocks; i++) for (size_t j=0; j<(*pblocks)[i].nblocks; j++) (*pblocks)[i].blocks[j].parent=(*pblocks)+i;
	df0("blockize %zu-%zu end", i0, i1);
}
#undef df0

void
freeblocks(size_t nblks, struct block *blks)
{
	for (size_t i=0; i<nblks; i++) if (blks[i].nblocks) freeblocks(blks[i].nblocks,blks[i].blocks);
	free(blks);
}

void
setparents(size_t n, struct block *blks)
{
	for (size_t i=0; i<n; i++)
		for (size_t j=0; j<blks[i].nblocks; j++)
			blks[i].blocks[j].parent = blks + i;
}

/* Blockizes and inserts the resulting blocks in
place, preserving expanded state. Returns new
equivalent blk */
struct block*
reblockize(size_t i0blk, struct block *blk)
{
							
	// Get new blocks
	size_t nblks=0,sizeblks=0; struct block*blks=NULL;
	blockize(i0blk, i0blk+blk->n, &sizeblks, &nblks, &blks, 0);
	df("blocks sub new");
	printblocks(nblks, blks, fdf);

	// Insert in place
	size_t *psize, *pn; struct block **phead;
	struct block *parent = blk->parent;
	if (parent) psize=&parent->sizeblocks,pn=&parent->nblocks,phead=&parent->blocks;
	else psize=&sizeblocks,pn=&nblocks,phead=&blocks;
	size_t iblk = blk - *phead;
	size_t nadd = nblks - 1;
	df("blocks iblk%zu nadd%zu", iblk, nadd);
	struct block blk0 = *blk;
	while (*psize < sizeof(struct block)*(*pn+nadd)) if (!(*phead=(struct block*)realloc(*phead,*psize=(*psize)*2))) { fprintf(stderr,"medc: realloc insert block %zu: %s",*psize,strerror(errno)); exit(EXIT_FAILURE); }
	memmove(*phead+iblk+1+nadd, *phead+iblk+1, (*pn-iblk-1)*sizeof(struct block));
	memcpy(*phead+iblk, blks, sizeof(struct block)*nblks);
	(*pn) += nadd;
	for (size_t i=0; i<nblks; i++) (*phead)[iblk+i].parent=parent;
	setparents(*pn, *phead);

	// Match expansion state from original
	for (size_t j=0,off=0; j<nblks; off+=(*phead)[iblk+j++].n) matchexpansion(blk0, *phead+iblk+j, off);

	// Free dangling blocks
	for (size_t i=0; i<blk0.nblocks; i++) freeblocks(blk0.blocks[i].nblocks,blk0.blocks[i].blocks);
	free(blks);
	return *phead + iblk;
}

/* 1: can include self
2: return 1 if pending input
Sets NULL and ntext if none
returns 1 if pending input, otherwise 0 */
#define df(...)
char
nextblki0search(struct block **pblk, size_t *pi0blk, char *ppasttoplevel, unsigned flags, char *ptype)
{
	df("nextblki0search blk%s i%zu pasttop%d", sblk(*pblk), *pi0blk, (int)*ppasttoplevel);
	checkblk(*pblk, *pi0blk);
	
	// End of text
	if (!*pblk || *pi0blk>=ntext) goto notfound;
	
	// Get cache index of next
	size_t isr;
	while (1) {
	
		// Get index where it should be
		isr = getisearchresultsbs(*pi0blk, *ppasttoplevel);
		if (!(flags&1) && isr<nissearchresults && *pi0blk==issearchresults[isr] && (!sectionssearched||*ppasttoplevel||isr<isrlabels)) isr++;
		if (isr<nissearchresults || sectionssearched>=2 || (sectionssearched==1&&nsearched>=ntext)) break;
			
		// Get next search index
		size_t i0next = nsearched;
		struct block *bnext; getblocki(i0next,&bnext,NULL,1);
		df("nextblki0search isr%zu i0next(nsearched)%zu bnext%s", isr, i0next, sblk(bnext));
		checkblk(bnext, i0next);
		{
			
			// Compile regex
			regex_t reg;
			ensuren(&sizesearch, nsearch, (void**)&bufsearch, nsearch+1);
			bufsearch[nsearch] = 0;
			if (regcomp(&reg,(char*)bufsearch,(btnssearch[SEARCHCASE].lines[0][3]=='I'?REG_ICASE:0)|REG_NEWLINE)) goto notfound;

			// Find block
			ensurentext(ntext+1);
			//if (!(flags&1)) nextblki0(&b,&i);
			if (sectionssearched) while (bnext && !bnext->parent) nextblki0(&bnext,&i0next);
			while (i0next<ntext || !sectionssearched) {
				df("nextblki0search loop blk%s i%zu :%.9s", sblk(bnext), i0next, getslabel(i0next,bnext));
				checkblk(bnext, i0next);

				// End early if pending input
				if ((flags&2) && (appg->ntype||appg->ispendingbackspace)) {
					return 1;
				}
				
				// Check if match
				if (bnext->needsreblockize) bnext=reblockize(i0next,bnext);
				size_t ilabel,nlabel; getlabel(i0next,bnext,&ilabel,&nlabel);
				char cend = text[ilabel+nlabel];
				text[ilabel+nlabel] = 0;
				regmatch_t match;
				char matched = !regexec(&reg, (char*)text+ilabel, 1, &match, (ilabel&&text[ilabel-1]!='\n')*REG_NOTBOL|(ilabel+nlabel<ntext&&cend!='\n')*REG_NOTEOL);
				text[ilabel+nlabel] = cend;
				if (matched) break;
				
				// Move to next
				if (!sectionssearched && bnext==blocks+nblocks-1) sectionssearched=1, isrlabels=nissearchresults, bnext=blocks, i0next=0;
				if (sectionssearched) do nextblki0(&bnext,&i0next); while (bnext && !bnext->parent);
				else i0next+=bnext->n, bnext++;
			}
			regfree(&reg);
		}
				
		// Cache all of its entries
		if ((nsearched=i0next) < ntext) {
		
			// Cover this block's search area with nsearched
			if (sectionssearched) {
				struct block *b=bnext; nextblki0(&b,&nsearched);
			} else if (bnext==blocks+nblocks-1) sectionssearched=1, isrlabels=nissearchresults, nsearched=0;
			else nsearched+=bnext->n;
				
			// Add all parent entries
			struct block *prev = NULL;
			if (nissearchresults) getblocki(issearchresults[nissearchresults-1],&prev,NULL,1);
			size_t nanc=0; for (struct block *b=bnext->parent; b; b=b->parent) nanc++;
			for (size_t igen=0; igen<nanc; igen++) {
				struct block *anc=bnext->parent; for (size_t jgen=nanc-1; jgen>igen; jgen--) anc=anc->parent;
				for (struct block *b=prev; b; b=b->parent) if (b == anc) goto nextanc;
				ensurens(nissearchresults+1, &sizeissearchresults, sizeof(size_t), (void**)&issearchresults, sizeof(char), (void**)&typessearchresults, 0);
				issearchresults[nissearchresults]=geti0ancestor(i0next,bnext,anc), typessearchresults[nissearchresults]=0;
				nissearchresults++;
				nextanc:;
			}
					
			// Add row start entry
			ensurens(nissearchresults+1, &sizeissearchresults, sizeof(size_t), (void**)&issearchresults, sizeof(char), (void**)&typessearchresults, 0);
			issearchresults[nissearchresults]=i0next, typessearchresults[nissearchresults]=1;
			nissearchresults++;
		}
	}
	
	// Store result
	if (isr<nissearchresults && (sectionssearched<2||isr<isrdirect)) {
		getblocki((*pi0blk=issearchresults[isr]), pblk, NULL, 1);
		*ppasttoplevel = sectionssearched && isr>=isrlabels;
		if (ptype) *ptype=typessearchresults[isr];
	} else {
		notfound:
		*pi0blk=ntext, *pblk=NULL;
		if (ptype) *ptype=-1;
	}
	return 0;
}
#undef df

/* search means do the contiguous ones that match,
and pblk will be the next match */
#define df0(...)
void
getlabelsrow(struct block **pblk, size_t *pi0blk, size_t max, double *ppad, size_t *pnblks, size_t *is, size_t *ns, double *ws, size_t *pindent, size_t *pi, char search, char *ppasttoplevel)
{
	df0("getlabelsrow blk%s i%zu pad%.2f", sblk(*pblk), *pi0blk, *ppad);

	// Get indent
	double pad0 = *ppad;
	if (search) {
		*pindent = 0;
		for (struct block *blk=*pblk; blk->parent; blk=blk->parent) (*pindent)++;
	} else *pindent = getnindent(getinonemptyline(*pi0blk,ntext));
	*ppad -= *pindent * windentlabel;

	// Get labels
	struct block *blk0 = *pblk;
	size_t nfrom = (blk0->parent?blk0->parent->blocks+blk0->parent->nblocks:blocks+nblocks) - blk0;
	for (*pnblks=0; *pnblks<max;) {
			
		// Get block label
		size_t i1blk = *pi0blk + (*pblk)->n;
		size_t ilabel, nlabel; getlabel(*pi0blk,*pblk,&ilabel,&nlabel);
			
		// Get block label width, clamped at max length
		double mlr = *pnblks ? mlrb : 0;
		debug=ilabel>179000;
		struct at endlabel = go((at){.i=ilabel}, DBYTES|NROWS|XSTOP, (ssize_t)nlabel, (ssize_t)1, pad0-mlr-2*plrb-*pindent*windentlabel-1);
		debug=0;
		double w = endlabel.x;
		df0("getlabelsrow ilabel%zu nlabel%zu stop%.02f w%.02f w+%.02f pad%.02f", ilabel, nlabel, pad0-mlr-2*plrb-*pindent*windentlabel-1, w, w+mlr+2*plrb, *ppad);
		if (w+mlr+2*plrb > *ppad) break;
				
		// Add to list
		(*ppad)-=w+mlr+2*plrb, is[*pnblks]=ilabel, ns[*pnblks]=endlabel.i-ilabel, ws[*pnblks]=w;
		(*pnblks)++;

		// Move to next search block
		if (search) {
			if (*pnblks > 1) typessearchresults[getisearchresultsbs(*pi0blk,*ppasttoplevel)] = 2;
			//TODO have parents of matches single line
			char type; nextblki0search(pblk,pi0blk,ppasttoplevel,0,&type);
			df0("getlabelsrow next blk%s i%zu", sblk(*pblk), *pi0blk);
			checkblk(*pblk, *pi0blk);
			if (!type) break;
			size_t nsibs = *pblk&&(*pblk)->parent ? (*pblk)->parent->nblocks : nblocks;
			for (size_t j=0; j<nfrom; j++) if ((*pblk) == blk0+j) goto foundsibling;
			break;
			foundsibling:;
			
		// Move to next block
		} else {
			//*pi = (*pi0blk += (*pblk)->n);
			*pi = *pi0blk + (*pblk)->n;
			struct block *parent = (*pblk)->parent;
			char lastchild = parent ? (*pblk)-parent->blocks==parent->nblocks-1 : (*pblk)-blocks==nblocks-1;
			nextblki0text(pblk, pi0blk);
			df0("getlabelsrow next %s@%zu", sblk(*pblk), *pi0blk);
			checkblk(*pblk, *pi0blk);
			if (lastchild || (*pblk)->expanded) break;
			//if (*pi0blk == ntext) break;
		}
	}
	df0("getlabelsrow end");
}
#undef df0

void
vertund(double x0, double y0, double x1, double y1)
{
	vertsund[nvertsund++] = (struct vund){x0, y1};
	vertsund[nvertsund++] = (struct vund){x0, y0};
	vertsund[nvertsund++] = (struct vund){x1, y0};
	vertsund[nvertsund++] = (struct vund){x1, y1};
	vertsund[nvertsund++] = (struct vund){x0, y1};
	vertsund[nvertsund++] = (struct vund){x1, y0};
}

void
printblockrow(double x00, double y00, int indent, double padtotal, size_t nblks, size_t *is, size_t *ns, double *ws, char und, int indrowprev)
{

	// Draw indent bars
#if 0
	if (und) {
		for (int i=0; i<indent; i++) {
			double xund = x00 + i*windentsearch + windentsearch/4;
			vertund(xund-1, y00-(i<indrowprev?mudb:0), xund+1, y00+pudb+hline+pudb);
		}
	}
#endif

	//df("printblockrow nblks%zu", nblks);
	double padeach = padtotal / nblks / 2;
	double x0 = x00 + indent*windentlabel; //TODO: pass indent width?
	double y0=y00/*-hline-pudb*/, y1=y0+pudb+hline+pudb;
	for (int iblk=0; iblk<nblks; iblk++) {
		if (iblk) x0+=mlrb;

		// Draw block
		double x1 = x0 + padeach + plrb + ws[iblk] + plrb + padeach;
		vertsblks[nvertsblks++] = (struct vblks){x0, y1, 0};
		vertsblks[nvertsblks++] = (struct vblks){x0, y0, 0};
		vertsblks[nvertsblks++] = (struct vblks){x1, y0, 0};
		vertsblks[nvertsblks++] = (struct vblks){x1, y1, 0};
		vertsblks[nvertsblks++] = (struct vblks){x0, y1, 0};
		vertsblks[nvertsblks++] = (struct vblks){x1, y0, 0};

		// Set text vertices
		//vertbuf(x0+padeach+plrb, y00+pudb+hline, ns[iblk], text+is[iblk], 0);
		double x0text = x0 + padeach + plrb;
		go((at){.x=x0text,.y=y00+pudb,.i=is[iblk]}, DBYTES|VERTS|WIDTH|X0, (ssize_t)ns[iblk], (double)displaySize_.width, x0text);
		x0 = x1;
	}
}

void
vertbackov(double x0, double y0, double x1, double y1)
{
	vertsbackov[nvertsbackov++] = (struct vbackov){x0, y1};
	vertsbackov[nvertsbackov++] = (struct vbackov){x0, y0};
	vertsbackov[nvertsbackov++] = (struct vbackov){x1, y0};
	vertsbackov[nvertsbackov++] = (struct vbackov){x1, y1};
	vertsbackov[nvertsbackov++] = (struct vbackov){x0, y1};
	vertsbackov[nvertsbackov++] = (struct vbackov){x1, y0};
}

void
vertbtnov(double x0, double y0, double x1, double y1)
{
	vertsbtnov[nvertsbtnov++] = (struct vbtnov){x0, y1, x1, y0};
	vertsbtnov[nvertsbtnov++] = (struct vbtnov){x0, y0, x1, y1};
	vertsbtnov[nvertsbtnov++] = (struct vbtnov){x1, y0, x0, y1};
	vertsbtnov[nvertsbtnov++] = (struct vbtnov){x1, y1, x0, y0};
	vertsbtnov[nvertsbtnov++] = (struct vbtnov){x0, y1, x1, y0};
	vertsbtnov[nvertsbtnov++] = (struct vbtnov){x1, y0, x0, y1};
}

void
vertbackkb(double x0, double y0, double x1, double y1)
{
	vertsbackkb[nvertsbackkb++] = (struct vbackkb){x0, y1};
	vertsbackkb[nvertsbackkb++] = (struct vbackkb){x0, y0};
	vertsbackkb[nvertsbackkb++] = (struct vbackkb){x1, y0};
	vertsbackkb[nvertsbackkb++] = (struct vbackkb){x1, y1};
	vertsbackkb[nvertsbackkb++] = (struct vbackkb){x0, y1};
	vertsbackkb[nvertsbackkb++] = (struct vbackkb){x1, y0};
}

void
vertbtnkb(double x0, double y0, double x1, double y1)
{
	vertsbtnkb[nvertsbtnkb++] = (struct vbtnkb){x0, y1, x1, y0};
	vertsbtnkb[nvertsbtnkb++] = (struct vbtnkb){x0, y0, x1, y1};
	vertsbtnkb[nvertsbtnkb++] = (struct vbtnkb){x1, y0, x0, y1};
	vertsbtnkb[nvertsbtnkb++] = (struct vbtnkb){x1, y1, x0, y0};
	vertsbtnkb[nvertsbtnkb++] = (struct vbtnkb){x0, y1, x1, y0};
	vertsbtnkb[nvertsbtnkb++] = (struct vbtnkb){x1, y0, x0, y1};
}

char
getiscoalesced(struct block *blk, size_t i0blk, size_t *pi0post, struct block **pblkpost)
{
	if (blk->parent || blk==blocks || blk->expanded) return 0;
	
	// Get index of start of coalescing
	struct block *b0=blk; size_t i00=i0blk; for (;;i00 -= (--b0)->n) {
		if (b0->expanded) {
			if (b0->expanded == 3) return 0;
			break;
		}
		if (b0 == blocks) return 0;
	}
	i00 += b0++->n;
	
	// Get expanded after
	struct block *bc=blk+1; size_t ic=i0blk+blk->n; for (;;ic += bc++->n) {
		if (bc == blocks+nblocks) return 0;
		if (bc->expanded) break;
	}
	
	// Make sure the blocks are more than 1 row
	size_t i01=i00,i1=i01,nblks,is[MAXLABELS],ns[MAXLABELS],indent; double ws[MAXLABELS],pad=displaySize_.width; struct block *blk1=b0; getlabelsrow(&blk1,&i01,MAXLABELS,&pad,&nblks,is,ns,ws,&indent,&i1,0,NULL);
	if (!blk1 || blk1>=bc) return 0;
	
	// Return success
	if (pi0post) *pi0post=ic;
	if (pblkpost) *pblkpost=bc;
	return 1;
}

//#define df(...)
#define df0(...)
//#define df0(...) df(__VA_ARGS__)
struct atblk
vgoblk(struct atblk pos, unsigned flags, union ssize_tdouble *args)
{

	// Process flags
	ssize_t dbytes=SSIZE_MAX; if (flags & DBYTES) dbytes=args++->s;
	ssize_t dgraphs=SSIZE_MAX; if (flags & DGRAPHS) dgraphs=args++->s;
	ssize_t nrows=SSIZE_MAX; char isdrows=0; if (flags & DROWS) nrows=args++->s,isdrows=1;
	ssize_t dspots=SSIZE_MAX; if (flags & DSPOTS) dspots=args++->s;
	double height = (flags&HEIGHT) ? args++->d : INFINITY;
	if (flags & NROWS) nrows=args++->s;
	char thread = !!(flags & THREAD);
	char underline = !!(flags & UNDERLINE);
	char verts = !!(flags & VERTS);
	double wrow = flags&WIDTH ? args++->d : displaySize_.width;
	char isstopx = !!(flags & XSTOP);
	double stopx = isstopx ? args++->d : INFINITY;
	double x0 = flags&X0 ? args++->d : 0;
	char isstopy = !!(flags & YSTOP);
	double stopy = isstopy ? args++->d : INFINITY;
	char backwards = dbytes<0 || dgraphs<0 || dspots<0 || nrows<0;
	if (backwards) { if(dbytes==SSIZE_MAX)dbytes=-(SSIZE_MAX-1); if(dgraphs==SSIZE_MAX)dgraphs=-(SSIZE_MAX-1); if(dspots==SSIZE_MAX)dspots=-(SSIZE_MAX-1); if(nrows==SSIZE_MAX)nrows=-(SSIZE_MAX-1); }
	// Note: backwards not implemented

	// Initialize looping variables
	ssize_t row = pos.row/*,
		rowprev = row,
		ibyte = 0,
		igraph = 0,
		ispot = 0*/;
	size_t i = pos.i,/*
		iprev = i,
		istopcol = SIZE_MAX,
		colistopcol = 0xFF,*/
		i0blk = pos.i0blk;
	struct block *blk = pos.blk;
	double x = pos.x,
		y = pos.y;
	df0("goblk wrow%.2f x0=%.2f height%.2f%s", wrow, x0, height, isstopx?" x":"");
	//df0("sblk blocks+nblocks %s", sblk(blocks+nblocks));
	//printblocks(nblocks, blocks, fdf);
	
	// Loop through each block
	df0("goblk PRELOOP i0blk%zu blk%s i%zu y%.02f/%.02f row%zd/%zd", i0blk, sblk(blk), i, y, height, row, nrows);
	while (i0blk<ntext && i<ntext && row<nrows && y+hline+(blk->expanded?0:2*pudb)<height && i-pos.i<dbytes/* && ((row+1<nrows&&y+hline<height)||!isstopx||!fle(stopx,x))*/) {
		
		// Draw coalesced blocks
		if (getiscoalesced(blk,i0blk,NULL,NULL)) {
			
			// Print ... block
			if (verts) {
				double y1=y+pudb+hline+pudb;
				vertsblks[nvertsblks++] = (struct vblks){0, y1, 0};
				vertsblks[nvertsblks++] = (struct vblks){0, y, 0};
				vertsblks[nvertsblks++] = (struct vblks){displaySize_.width, y, 0};
				vertsblks[nvertsblks++] = (struct vblks){displaySize_.width, y1, 0};
				vertsblks[nvertsblks++] = (struct vblks){0, y1, 0};
				vertsblks[nvertsblks++] = (struct vblks){displaySize_.width, y, 0};
				size_t ncoalesced=0; for (struct block *b=blk; !b->expanded; b++) ncoalesced++;
				int n = snprintf(NULL, 0, "[ ... %zu blocks ]", ncoalesced);
				char s[n+1]; snprintf(s,n+1,"[ ... %zu blocks ]",ncoalesced);
				if (ncoalesced == 1) memmove(s+n-3,s+n-2,3), n--;
				double x0text = displaySize_.width/2 - advs(s)/2;
				go((at){.x=x0text,.y=y+pudb}, BUF|DBYTES|VERTS|WIDTH, (size_t)n, s, (ssize_t)n, (double)displaySize_.width);
			}

			// Break if stop in here
			double ynext = y+hline+2*pudb+mudb;
			if ((row+1>=nrows/*||y>height*/||(isstopy&&fle(stopy,ynext))) && !isdrows) break;
			
			// Increment past coalesced blocks
			while (!blk->expanded) i0blk+=blk++->n;
			row++, y=ynext, i=i0blk;

		// Draw expanded block
		} else if (blk->expanded) {
			ssize_t i1blk = i0blk + blk->n;
		
			// Determine whether pre subblocks or post them
			char presubblocks = !blk->nblocks || i<i0blk+blk->iblocks;

			// Skip empty if pre and prev not expanded, except
			// last line of all empty
			size_t i0 = presubblocks && i==i0blk && blk!=(blk->parent?blk->parent->blocks:blocks) && !(blk-1)->expanded
				? getilshown(i0blk,blk)
				: i;
				
			// Get drawing limits
			ssize_t ngo = presubblocks&&blk->nblocks ? blk->iblocks-(i0-i0blk) : i1blk-i0,
				nrowsgo = nrows - row;
			if (i0+ngo-pos.i > dbytes) ngo=pos.i+dbytes-i0;
		
			// Draw text
			df0("goblk exp ngo %zd", ngo);
			unsigned flagsgo=DBYTES|HEIGHT|(isdrows?DROWS:NROWS)|(verts?VERTS:0)|WIDTH|(isstopx?XSTOP:0)|X0|(isstopy?YSTOP:0); struct at start={.x=x0,.y=y,.i=i0};
			struct at end = isstopx
				? (isdrows
					? (isstopy
						? go(start, flagsgo, ngo, nrowsgo, height, wrow, stopx, x0, stopy)
						: go(start, flagsgo, ngo, nrowsgo, height, wrow, stopx, x0)
					) : (isstopy
						? go(start, flagsgo, ngo, height, nrowsgo, wrow, stopx, x0, stopy)
						: go(start, flagsgo, ngo, height, nrowsgo, wrow, stopx, x0)
					)
				) : (isdrows
					? (isstopy
						? go(start, flagsgo, ngo, nrowsgo, height, wrow, x0, stopy)
						: go(start, flagsgo, ngo, nrowsgo, height, wrow, x0)
					) : (isstopy
						? go(start, flagsgo, ngo, height, nrowsgo, wrow, x0, stopy)
						: go(start, flagsgo, ngo, height, nrowsgo, wrow, x0)
					)
				);
			df0("goblk exp end.row%zd", end.row);
				
			// Update screen position
			row+=end.row, x=end.x, y=end.y;
			
			// Update block and text position
			if (presubblocks && row-isdrows<nrows && (isdrows||y+hline<height) && (!isstopy||y/*+hline+mline*/<=stopy) && end.i-pos.i<dbytes && end.i==i0+ngo) {
				df0("goblk exp pre end");
				if (blk->nblocks) i0blk=i=end.i, blk=blk->blocks;
				else {
					i = i0blk + blk->n;
					nextblki0text(&blk, &i0blk);
				}
			} else if (!presubblocks && row<nrows && y+hline<height && (!isstopy||y/*+hline+mline*/<stopy) && end.i-pos.i<dbytes && end.i==i0+ngo) {
				df0("goblk exp post end");
				i=i0blk+blk->n, nextblki0text(&blk,&i0blk);
			} else {
				df0("goblk exp mid");
				i=end.i;
			}
			df0("goblk exp1 i%zu blk%s i0blk%zu row%zd", i, sblk(blk), i0blk, row);
			
			// Break if couldn't fit
			if (((row+1==nrows||fle(height,y+hline+mline+hline)||(isstopy&&fle(stopy,y+hline+mline))) && !isdrows/**/ && end.i-i0!=ngo/**/)
				|| end.i-pos.i >= dbytes) break;
				//|| end.graph-pos.graph >= dgraphs) break;
		
		// Draw unexpanded blocks
		} else {
		
			// Get labels for row
			struct block *blk0 = blk;
			size_t i0blk0=i0blk, row0=row, nblks, is[MAXLABELS], ns[MAXLABELS], indent; double ws[MAXLABELS], pad=wrow;
			getlabelsrow(&blk, &i0blk, MAXLABELS, &pad, &nblks, is, ns, ws, &indent, &i, 0, NULL);
			double y0 = y;
			//i = i0blk;
			df0("goblk post-labels %s@%zu", sblk(blk), i0blk);
			checkblk(blk, i0blk);
			//df0("nblks %zu", nblks);
			
			// Print blocks
			if (verts) {
				df0("goblk print unexp");
				printblockrow(x0, y/*+pudb*/, indent, pad, nblks, is, ns, ws, 0, 0);
				row++, y+=hline+2*pudb+mudb;
				if ((row>=nrows||fle(height,y)) || (!isdrows&&!blk)) {
					if (!isdrows) row--;
					df0("goblk print unexp break (%s) row%zd nrows%zu blk%s block+nblocks%s", (row+1>=nrows?"row>=nrows":"blk==blocks+nblocks"), row, nrows, sblk(blk), sblk(blocks+nblocks));
					break;
				}

			// Just increment
			} else {
				row++, y+=hline+2*pudb+mudb;
				df0("goblk just increment i0blk%zu i%zu", i0blk, i);
				if ((row>=nrows/*||y>height*/||(isstopy&&fle(stopy,y))) && !isdrows) {
					blk=blk0, i=i0blk=i0blk0, row=row0, y=y0;
					//for (size_t j=0; j<nblks; j++) i0blk-=(--blk)->n;
					if (isstopx) {
						double w = x0 + indent*windentlabel;
						double padeach = pad / nblks;
						for (size_t j=0; j+1<nblks; j++) {
							double wb = (j?mlrb:0) + 2*plrb + padeach + ws[j];
							if (stopx <= w+wb) break;
							i0blk+=(blk++)->n, w+=wb;
						}
						break;
						//i = i0blk;
					} else if (isstopy) break;
				}
			}
			x = x0;
		}
		
		// Move past hidden expanded opening newlines
		if (blk && blk->expanded && i==i0blk && blk!=(blk->parent?blk->parent->blocks:blocks) && !(blk-1)->expanded) i=getilshown(i0blk,blk);
	}
	//df0("redraw block loop done");

	// Return ending spot
	//return structatblkii0blkrowblkxy(i, i0blk, row, blk, x, y);
	return (struct atblk){.i=i, .i0blk=i0blk, .row=row, .blk=blk, .x=x, .y=y};
}
#undef df0

struct atblk
goblk(struct atblk pos, unsigned flags, ...)
{

	// Process flags
	va_list ap;
	va_start(ap, flags);
	union ssize_tdouble args[10], *p=args;
	if (flags & DBYTES) p++->s=va_arg(ap,ssize_t);
	if (flags & DGRAPHS) p++->s=va_arg(ap,ssize_t);
	if (flags & DROWS) p++->s=va_arg(ap,ssize_t);
	if (flags & DSPOTS) p++->s=va_arg(ap,ssize_t);
	if (flags & HEIGHT) p++->d=va_arg(ap,double);
	if (flags & NROWS) p++->s=va_arg(ap,ssize_t);
	if (flags & WIDTH) p++->d=va_arg(ap,double);
	if (flags & XSTOP) p++->d=va_arg(ap,double);
	if (flags & X0) p++->d=va_arg(ap,double);
	if (flags & YSTOP) p++->d=va_arg(ap,double);
	va_end(ap);
	return vgoblk(pos, flags, args);
}

uint64_t
getns(void)
{
	struct timespec ts; if (clock_gettime(CLOCK_MONOTONIC,&ts)) { Perror("medcn: clock_gettime"); exit(EXIT_FAILURE); }
	return ts.tv_sec*1e9 + ts.tv_nsec;
}

double
et(uint64_t ns)
{
	return (ns-nsstartup) / 1.0e9;
}

void
geti01selection(size_t *pi0, size_t *pi1)
{
	size_t i0=SIZE_MAX, i1=SIZE_MAX;
	if (iselectstart != SIZE_MAX) {
		if (iselectstart < iselectend) i0=iselectstart,i1=iselectend;
		else i0=iselectend,i1=iselectstart;
	}
	*pi0=i0, *pi1=i1;
}

size_t
getoverlap(size_t i0, size_t i1, size_t j0, size_t j1)
{
	size_t max0=i0<j0?j0:i0, min1=j1<i1?j1:i1;
	if (max0 >= min1) return 0;
	return min1 - max0;
}

void
prevblki0(struct block **pblk, size_t *pi0blk)
{
	if (*pblk == blocks) { *pi0blk=0; return; }
	struct block *parent = (*pblk)->parent;
	struct block *head;
	if (parent) head=parent->blocks;
	else head=blocks;
	if (head == *pblk) *pblk=parent, *pi0blk-=parent->iblocks;
	else {
		(*pblk)--, *pi0blk-=(*pblk)->n;;
		while ((*pblk)->nblocks) {
			*pi0blk += (*pblk)->iblocks;
			for (size_t i=0; i<(*pblk)->nblocks-1; i++) *pi0blk+=(*pblk)->blocks[i].n;
			*pblk = (*pblk)->blocks + (*pblk)->nblocks-1;
		}
	}
}

/* Removes and frees the block and children from
its parent, doesnt update .n */
void
removeblock(struct block *blk)
{
	df("removeblock0");
	//printblocks(nblocks, blocks, stderr);
	if (blk->nblocks) freeblocks(blk->nblocks,blk->blocks);
	struct block *head; size_t *pn;
	if (blk->parent) head=blk->parent->blocks, pn=&blk->parent->nblocks;
	else head=blocks, pn=&nblocks;
	memmove(blk, blk+1, sizeof(struct block)*(*pn-(blk-head)-1));
	(*pn)--;
	setparents(*pn, head);
	df("removeblocks1");
	//printblocks(nblocks, blocks, stderr);
}

size_t
getilinenonemptyorlast(size_t i0, size_t i1)
{
	size_t i = getinonemptyline(i0, i1);
	return i==i1 ? getiline(i1-1) : i;
}

size_t
getipost(struct block *blk)
{
	if (!blk->nblocks) return 0;
	size_t i = blk->iblocks;
	for (size_t j=0; j<blk->nblocks; j++) i+=blk->blocks[j].n;
	return i;
}

void
updateindex(size_t *pi, size_t i, ssize_t d)
{
	if (d<0 && i<*pi && *pi<i-d) *pi=i;
	else if (i < *pi) *pi+=d;
}

void
updateindexn(size_t *pi, size_t *pn, size_t i, ssize_t d)
{
	size_t overlap;
	if (d<0 ? i-d<=*pi : i<*pi) *pi+=d;
	else if ((overlap=getoverlap(i,d<0?i-d:i+d,*pi,*pi+*pn))) {
		if (d <0) updateindex(pi,i,d),*pn-=overlap;
		else *pn+=d;
	}
}

#define df(...)
void
updateindices(size_t i, ssize_t d, uint64_t flags)
{
	df("updateindices %zu %zd %" PRIx64, i, d, flags);

	// Update block indices
	if (flags & 1) {
		//printblocks(nblocks, blocks, stderr);
		
		// Increment block ancestry
		if (d >= 0) {
			struct block *blk; size_t i0blk; getblocki(i,&blk,&i0blk,1);
			df("updateindices blk%s i0%zu nbl,ibl%zu", sblk(blk), i0blk, blk->nblocks?blk->iblocks:0);
			blk->needsreblockize = 1;
			if (blk->nblocks && i<i0blk+blk->iblocks)
				blk->iblocks+=d;
			for (struct block *b=blk; b; b=b->parent) b->n+=d;
		
		// Delete as appropriate
		} else {
			size_t i1 = i - d;
			df("updateindices block delete i1 %zu", i1);
			
			// Get last block
			struct block *blk=blocks; size_t i0blk=0;
			size_t nsib = nblocks;
			while (i0blk < i1) {
				for (size_t i=0; i<nsib-1 && i0blk<i1; i++) i0blk+=(blk++)->n;
				if (i0blk < i1) {
					if (blk->nblocks) i0blk+=blk->iblocks, nsib=blk->nblocks, blk=blk->blocks;
					else break;
				}
			}
			
			// Loop backwards updating
			while (1) {
			
				// Skip no overlap
				size_t i1blk = i0blk + blk->n;
				size_t overlapblk = getoverlap(i, i1, i0blk, i1blk);
				df("updateindices blk- %s %zu-%zu %zu-%zu %zu", sblk(blk), i, i1, i0blk, i1blk, overlapblk);
				if (!overlapblk) {
					if (blk == blocks) break;
					else prevblki0(&blk,&i0blk);
				
				// Whole block is consumed
				} else if (overlapblk == blk->n) {
					struct block *blk0 = blk;
					char end = blk == blocks;
					if (!end) prevblki0(&blk, &i0blk);
					removeblock(blk0);
					if (end) break;
					
				// Partial block deletion
				} else {
					if (!blk->nblocks || getoverlap(i,i1,i0blk,i0blk+blk->iblocks) || getoverlap(i,i1,i0blk+getipost(blk),i1blk))
						blk->needsreblockize = 1;
					struct block *blk0 = blk;
					size_t i0blk0 = i0blk;
					char end = blk == blocks;
					if (!end) prevblki0(&blk, &i0blk);
					blk0->n -= overlapblk;
					if (blk0->nblocks) blk0->iblocks -= getoverlap(i, i1, i0blk0, i0blk0+blk0->iblocks);
					if (end) break;
				}
			}
		}
		//printblocks(nblocks, blocks, stderr);
	}

	// Update expansion indices
	if (flags & 2) {
		
		// Update subtracted ones
		if (d < 0) {
			size_t i1 = i - d;
			for (size_t j=0; j<nilexps; j++) {
				size_t i0exp=ilexps[j], i1exp=i0exp+exps[j].n;
				size_t overlap = getoverlap(i, i1, i0exp, i1exp);
				if (!overlap) continue;
				exps[j].norig = 0;
				exps[j].unsaved = 1;
				if (!(exps[j].n-=overlap)) free(exps[j].orig), memmove(ilexps+j,ilexps+j+1,sizeof(size_t)*(nilexps-j-1)),memmove(exps+j,exps+j+1,sizeof(struct expanse)*(nilexps-j-1)),nilexps--,j--;
				if (i0exp > i) ilexps[j]=i;
			}
			
		// Update inserted one
		} else {
			size_t iexp = getiilexp(i);
			if (iexp != SIZE_MAX) exps[iexp].n+=d,exps[iexp].norig=0,exps[iexp].unsaved=1;
		}
		
		// Update indices
		for (size_t j=0; j<nilexps; j++) if (ilexps[j] > i) ilexps[j]+=d;
	}
	
	// Invalidate syntax cache
	if (flags & 4) {
		size_t isynst = i / 1024;
		if (nsynsts > isynst) {
			nsynsts = isynst + 1;
			while (nsynsts && synsts[nsynsts-1].i1>i) nsynsts--;
		}
	}
	
	// Update multi cursor indices
	if (flags & 8) {
		for (struct multicur *m=multis; m<multis+nmulti; m++) {
			updateindex(&m->i, i, d);
			if (m->iselect != SIZE_MAX) updateindex(&m->iselect,i,d);
		}
	}
	
	// Update flow indices
	if (flags & 16) {
		for (size_t *pflow=isflow; pflow<isflow+nflow; pflow++) {
			updateindex(pflow, i, d);
		}
		for (size_t *pflow=isflowmulti; pflow<isflowmulti+nflowmulti; pflow++)
			updateindex(pflow, i, d);
		for (size_t *pflow=isflowreplace; pflow<isflowreplace+nflowreplace; pflow++)
			updateindex(pflow, i, d);
	}
	
	// Update replace indices
	if (flags & 32) {
		updateindex(&i0replace,i,d); updateindex(&i1replace,i,d);
		for (struct replace *r=replaces; r<replaces+nreplace; r++) {
			updateindexn(isreplace+(r-replaces), &r->n, i, d);
		}
	}
	
	// Update selection indices
	if (flags & 64) {
		if (iselectstart != SIZE_MAX) updateindex(&iselectstart,i,d),updateindex(&iselectend,i,d);
	}
	
	// Update make function indices
	if (flags & 128) {
		if (inamemkfn != SIZE_MAX) updateindex(&inamemkfn,i,d);
	}
}
#undef df

void
appendundo(char type, size_t i, size_t n, uint8_t *buf)
{
	
	// Continue previous
	if (!nundo) goto createnewundo;
	struct undo *u = undos + nundo-1;
	if (u->type!=type || (u->type=='i'&&i!=u->i+u->n) || (u->type=='b'&&i!=u->i-u->n)) goto createnewundo;
	if (u->sizebuf<u->n+n && !(u->buf=realloc(u->buf,u->sizebuf=u->n+n))) {fprintf(stderr,"medcn: realloc undo extend %zu: %s\n",u->n+n,strerror(errno));exit(EXIT_FAILURE);}
	if (u->type == 'i') memcpy(u->buf+u->n,buf,n);
	else { memmove(u->buf+n,u->buf,u->n); memcpy(u->buf,buf,n); }
	u->n += n;
	return;
	
	// Create new
	createnewundo:;
	size_t sizeundo0=sizeundo; ensuren(&sizeundo,0,(void**)&undos,(nundo+1)*sizeof(*undos)); if (sizeundo > sizeundo0) memset((char*)undos+sizeundo0,0,sizeundo-sizeundo0);
	u = undos + nundo++;
	u->type=type, u->i=i, u->n=n, u->idchain=idchainundo;
	if (!(idchainundo % 2)) idchainundo+=2;
	df("appendundo sizebuf=%zu n=%zu buf=%p", u->sizebuf, n, u->buf);
	if (u->sizebuf<n && !(u->buf=realloc(u->buf,u->sizebuf=n))) {fprintf(stderr,"medcn: realloc undo buf %zu: %s\n",n,strerror(errno));exit(EXIT_FAILURE);}
	memcpy(u->buf, buf, n);
}

void
insertupdate(size_t i, size_t n, uint8_t *buf, uint64_t flags)
{
	
	// Add to undo list
	if (!isundoing) appendundo('i', i, n, buf);

	// Insert the character
	ensurentext(ntext + n);
	memmove(text+i+n, text+i, ntext-i);
	memcpy(text+i, buf, n);
	ntext += n;
	vtext++;
	
	// Update indices
	updateindices(i, n, flags);
}

/* Extend the block this is at the end of rather than
the one it's at the start of */
void
insertextendblock(size_t i, size_t n, uint8_t *buf)
{
	struct block *blk; size_t i0blk; getblocki(i-1,&blk,&i0blk,1);
	insertupdate(i, n, buf, ~(uint64_t)1);
	if (blk->nblocks && i<=i0blk+blk->iblocks)
		blk->iblocks+=n;
	for (struct block *b=blk; b; b=b->parent) b->n+=n;
}

void
insert(size_t i, size_t n, uint8_t *buf)
{
	insertupdate(i, n, buf, UINT64_MAX);
}

void
insertcopy(size_t i, size_t n, uint8_t *buf)
{
	uint8_t *buf2 = (uint8_t*)Malloc(n);
	memcpy(buf2, buf, n);
	insert(i, n, buf2);
	free(buf2);
}

void
backspaceupdate(size_t i, size_t n, uint64_t flags)
{
	
	// Add to undo list
	if (!isundoing) appendundo('b', i, n, text+i-n);

	// Remove the text
	memmove(text+i-n, text+i, ntext-i);
	ntext -= n;
	vtext++;

	// Update indices
	updateindices(i-n, -(ssize_t)n, flags);
}

void
backspace(size_t i, size_t n)
{
	backspaceupdate(i, n, UINT64_MAX);
}

/* And adjusts cursor accordingly
Returns whether a selection was deleted */
char
deleteselection(void)
{
	if (iselectstart == SIZE_MAX) return 0;
	size_t i0,i1; geti01selection(&i0,&i1);
	size_t n = i1 - i0;
	if (!n) return 0;
	if (curselect == 0) backspace(i1,n);
	//else if (curselect == 1) backspacesearch(i1,n);
	else return 0;
	if (cur==curselect && icur!=SIZE_MAX) {
		if (icur>i0 && icur<i1) icur=i0;
		else if (icur >= i1) icur-=n;
	}
	iselectstart = SIZE_MAX;
	if (overlay == OVSELECT) overlay=0;
	needsredraw=1;
	return 1;
}

char
isalnum_(char c)
{
	return isalnum(c) || c=='_';
}

void
getwordbufi(size_t nbuf, uint8_t *buf, size_t i, size_t *piw, size_t *pnw)
{
	size_t iw; if (!piw) piw=&iw;
	for (*piw=i; *piw && isalnum_(buf[*piw-1]); (*piw)--);
	for (*pnw=0; *piw+*pnw<nbuf && isalnum_(buf[*piw+*pnw]); (*pnw)++);
}

void
getwordtext(size_t i, size_t *piw, size_t *pnw)
{
	getwordbufi(ntext, text, i, piw, pnw);
}

/* Finds the word this index is connected to and sets the renaming
word to that. If it's different than what's stored, save it. */
void
setwordrenaming(size_t i)
{
	size_t irenaming0 = irenaming;
	size_t nw; getwordbufi(ntext,text,i,&irenaming,&nw);
	if (vtext!=vtextrenaming || irenaming!=irenaming0) {
		ensuren(&sizerenamed, 0, (void**)&bufrenamed, nw);
		memcpy(bufrenamed, text+irenaming, nrenamed=nw);
	}
}

#if 0
size_t
geticombined(size_t *psize, size_t nbuf, uint8_t **pbuf, size_t i, int ns, uint8_t *s)
{
	ensuren(psize, 0, (void**)pbuf, i+ns);
	uint8_t old[ns]; memcpy(old,(*pbuf)+i,ns);
	memcpy((*pbuf)+i, s, ns);
	size_t icombined = igraphprev(i+ns>nbuf?i+ns:nbuf, *pbuf, i+ns);
	(*pbuf)[i] = old;
	return icombined;
}

/* Moves the cursor to the beginning of the grapheme
it is in after inserting c */
void
gocurcombined(uint8_t c)
{

	// Get cursor buffer
	uint8_t **pbuf=NULL; size_t *psize=NULL, nbuf;
	switch (cur) {
	case 0: pbuf=&text, psize=&sizetext, nbuf=ntext; break;
	case 1: pbuf=&bufsearch, psize=&sizesearch, nbuf=nsearch; break;
	}

	// Move to the start of this graph post-insert
	size_t icombined = geticombined(psize, nbuf, pbuf, icur, c);
	//while (icur > icombined) gocur(DGRAPHS|WIDTH, (ssize_t)-1, wwin-padwin);
	icur = icombined;
}
#endif

size_t
geti0blkrow(size_t i)
{
	for (struct atblk pos={.blk=blocks};;) {
		//df("unexpand i%zu", pos.i);
		struct atblk pos2 = goblk(pos, DROWS|WIDTH, 1, (double)displaySize_.width);
		//df("unexpand pos2.i%zu .i0blk%zu .irowblk%zu", pos2.i, pos2.i0blk, pos2.irowblk);
		if (pos2.i>i || (pos2.i==pos.i/*&&pos2.irowblk==pos.irowblk*/)) return pos.i;
		pos = pos2;
		pos.row = 0;
	}
}

enum tokentype { PUNC1, PUNC2, PUNC3, PUNC4, COMMENT1, COMMENT2, CHARTOK, STRING, OTHER };
struct token {
	size_t i,n;
	enum tokentype type;
};
void
gettokens(size_t i0, size_t i1, uint8_t *buf, size_t *pntoks, struct token **ptoks)
{
	df("gettokens %zu-%zu", i0, i1);

	// Tokenize
	size_t ntoks=0, sizetoks=0;
	struct token *toks = NULL;
	for (size_t i=i0; i<=i1;) {
		char c = buf[i];
		if (isspace(c)) { i++; continue; }
		
		// Append new token
		if (++ntoks*sizeof(struct token)>sizetoks && !(toks=(struct token*)realloc((void*)toks,sizetoks=sizetoks?sizetoks*2:sizeof(struct token)*256))) { fprintf(stderr,"medc: realloc toks %zu: %s\n",sizetoks,strerror(errno)); exit(EXIT_FAILURE); }
		struct token *tok = toks + ntoks-1;
		tok->i = i;
		
		// //
		if (i1+1-i>=2 && !memcmp(buf+i,"//",2)) {
			tok->type = COMMENT2;
			for (tok->n=2; i+tok->n<i1+1 && buf[i+tok->n]!='\n'; tok->n++);
			i += tok->n;
			
		// /*
		} else if (i1+1-i>=2 && !memcmp(buf+i,"/*",2)) {
			tok->type = COMMENT1;
			for (tok->n=2; i+tok->n<i1+1 && (i1+1-tok->n-i<2||memcmp(buf+i+tok->n,"*/",2)); tok->n++);
			i += (tok->n += (i+tok->n<i1+1));
			
		// "
		} else if (c == '"') {
			tok->type = STRING;
			char esc = 0;
			for (tok->n=1; i+tok->n<i1+1 && (esc||buf[i+tok->n]!='"'); tok->n++) esc=!esc&&buf[i+tok->n]=='\\';
			i += (tok->n += i+tok->n<=i1);
			
		// '
		} else if (c == '\'') {
			tok->type = CHARTOK;
			char esc = 0;
			for (tok->n=1; i+tok->n<=i1 && (esc||buf[i+tok->n]!='\''); tok->n++) esc=!esc&&buf[i+tok->n]=='\\';
			i += (tok->n += i+tok->n<=i1);

		// Match punctuators
#define PUNCS "!#%&()*+,-./:;<=>?^{|}~[]"
		} else if (strchr(PUNCS,c)) {
			if (0) {
/* GEN
set -f
while read l; do for punc in $l; do <<! cat; done; done <<!
			} else if (i1+1-i>=${#punc} && !memcmp(buf+i,"$punc",${#punc})) {
				tok->type = PUNC${#punc};
				i += tok->n = ${#punc};
!
<: :> <% %> %: %:%:
? : ; ...
[ ] ( ) { } . ->
*= /= %= += -= <<= >>= &= ^= |=
/ % << >> <= >= == != ^ && ||
++ -- & * + - ~ !
, ##
| = < > #
!
*/
			} else if (i1+1-i>=2 && !memcmp(buf+i,"<:",2)) {
				tok->type = PUNC2;
				i += tok->n = 2;
			} else if (i1+1-i>=2 && !memcmp(buf+i,":>",2)) {
				tok->type = PUNC2;
				i += tok->n = 2;
			} else if (i1+1-i>=2 && !memcmp(buf+i,"<%",2)) {
				tok->type = PUNC2;
				i += tok->n = 2;
			} else if (i1+1-i>=2 && !memcmp(buf+i,"%>",2)) {
				tok->type = PUNC2;
				i += tok->n = 2;
			} else if (i1+1-i>=2 && !memcmp(buf+i,"%:",2)) {
				tok->type = PUNC2;
				i += tok->n = 2;
			} else if (i1+1-i>=4 && !memcmp(buf+i,"%:%:",4)) {
				tok->type = PUNC4;
				i += tok->n = 4;
			} else if (i1+1-i>=1 && !memcmp(buf+i,"?",1)) {
				tok->type = PUNC1;
				i += tok->n = 1;
			} else if (i1+1-i>=1 && !memcmp(buf+i,":",1)) {
				tok->type = PUNC1;
				i += tok->n = 1;
			} else if (i1+1-i>=1 && !memcmp(buf+i,";",1)) {
				tok->type = PUNC1;
				i += tok->n = 1;
			} else if (i1+1-i>=3 && !memcmp(buf+i,"...",3)) {
				tok->type = PUNC3;
				i += tok->n = 3;
			} else if (i1+1-i>=1 && !memcmp(buf+i,"[",1)) {
				tok->type = PUNC1;
				i += tok->n = 1;
			} else if (i1+1-i>=1 && !memcmp(buf+i,"]",1)) {
				tok->type = PUNC1;
				i += tok->n = 1;
			} else if (i1+1-i>=1 && !memcmp(buf+i,"(",1)) {
				tok->type = PUNC1;
				i += tok->n = 1;
			} else if (i1+1-i>=1 && !memcmp(buf+i,")",1)) {
				tok->type = PUNC1;
				i += tok->n = 1;
			} else if (i1+1-i>=1 && !memcmp(buf+i,"{",1)) {
				tok->type = PUNC1;
				i += tok->n = 1;
			} else if (i1+1-i>=1 && !memcmp(buf+i,"}",1)) {
				tok->type = PUNC1;
				i += tok->n = 1;
			} else if (i1+1-i>=1 && !memcmp(buf+i,".",1)) {
				tok->type = PUNC1;
				i += tok->n = 1;
			} else if (i1+1-i>=2 && !memcmp(buf+i,"->",2)) {
				tok->type = PUNC2;
				i += tok->n = 2;
			} else if (i1+1-i>=2 && !memcmp(buf+i,"*=",2)) {
				tok->type = PUNC2;
				i += tok->n = 2;
			} else if (i1+1-i>=2 && !memcmp(buf+i,"/=",2)) {
				tok->type = PUNC2;
				i += tok->n = 2;
			} else if (i1+1-i>=2 && !memcmp(buf+i,"%=",2)) {
				tok->type = PUNC2;
				i += tok->n = 2;
			} else if (i1+1-i>=2 && !memcmp(buf+i,"+=",2)) {
				tok->type = PUNC2;
				i += tok->n = 2;
			} else if (i1+1-i>=2 && !memcmp(buf+i,"-=",2)) {
				tok->type = PUNC2;
				i += tok->n = 2;
			} else if (i1+1-i>=3 && !memcmp(buf+i,"<<=",3)) {
				tok->type = PUNC3;
				i += tok->n = 3;
			} else if (i1+1-i>=3 && !memcmp(buf+i,">>=",3)) {
				tok->type = PUNC3;
				i += tok->n = 3;
			} else if (i1+1-i>=2 && !memcmp(buf+i,"&=",2)) {
				tok->type = PUNC2;
				i += tok->n = 2;
			} else if (i1+1-i>=2 && !memcmp(buf+i,"^=",2)) {
				tok->type = PUNC2;
				i += tok->n = 2;
			} else if (i1+1-i>=2 && !memcmp(buf+i,"|=",2)) {
				tok->type = PUNC2;
				i += tok->n = 2;
			} else if (i1+1-i>=1 && !memcmp(buf+i,"/",1)) {
				tok->type = PUNC1;
				i += tok->n = 1;
			} else if (i1+1-i>=1 && !memcmp(buf+i,"%",1)) {
				tok->type = PUNC1;
				i += tok->n = 1;
			} else if (i1+1-i>=2 && !memcmp(buf+i,"<<",2)) {
				tok->type = PUNC2;
				i += tok->n = 2;
			} else if (i1+1-i>=2 && !memcmp(buf+i,">>",2)) {
				tok->type = PUNC2;
				i += tok->n = 2;
			} else if (i1+1-i>=2 && !memcmp(buf+i,"<=",2)) {
				tok->type = PUNC2;
				i += tok->n = 2;
			} else if (i1+1-i>=2 && !memcmp(buf+i,">=",2)) {
				tok->type = PUNC2;
				i += tok->n = 2;
			} else if (i1+1-i>=2 && !memcmp(buf+i,"==",2)) {
				tok->type = PUNC2;
				i += tok->n = 2;
			} else if (i1+1-i>=2 && !memcmp(buf+i,"!=",2)) {
				tok->type = PUNC2;
				i += tok->n = 2;
			} else if (i1+1-i>=1 && !memcmp(buf+i,"^",1)) {
				tok->type = PUNC1;
				i += tok->n = 1;
			} else if (i1+1-i>=2 && !memcmp(buf+i,"&&",2)) {
				tok->type = PUNC2;
				i += tok->n = 2;
			} else if (i1+1-i>=2 && !memcmp(buf+i,"||",2)) {
				tok->type = PUNC2;
				i += tok->n = 2;
			} else if (i1+1-i>=2 && !memcmp(buf+i,"++",2)) {
				tok->type = PUNC2;
				i += tok->n = 2;
			} else if (i1+1-i>=2 && !memcmp(buf+i,"--",2)) {
				tok->type = PUNC2;
				i += tok->n = 2;
			} else if (i1+1-i>=1 && !memcmp(buf+i,"&",1)) {
				tok->type = PUNC1;
				i += tok->n = 1;
			} else if (i1+1-i>=1 && !memcmp(buf+i,"*",1)) {
				tok->type = PUNC1;
				i += tok->n = 1;
			} else if (i1+1-i>=1 && !memcmp(buf+i,"+",1)) {
				tok->type = PUNC1;
				i += tok->n = 1;
			} else if (i1+1-i>=1 && !memcmp(buf+i,"-",1)) {
				tok->type = PUNC1;
				i += tok->n = 1;
			} else if (i1+1-i>=1 && !memcmp(buf+i,"~",1)) {
				tok->type = PUNC1;
				i += tok->n = 1;
			} else if (i1+1-i>=1 && !memcmp(buf+i,"!",1)) {
				tok->type = PUNC1;
				i += tok->n = 1;
			} else if (i1+1-i>=1 && !memcmp(buf+i,",",1)) {
				tok->type = PUNC1;
				i += tok->n = 1;
			} else if (i1+1-i>=2 && !memcmp(buf+i,"##",2)) {
				tok->type = PUNC2;
				i += tok->n = 2;
			} else if (i1+1-i>=1 && !memcmp(buf+i,"|",1)) {
				tok->type = PUNC1;
				i += tok->n = 1;
			} else if (i1+1-i>=1 && !memcmp(buf+i,"=",1)) {
				tok->type = PUNC1;
				i += tok->n = 1;
			} else if (i1+1-i>=1 && !memcmp(buf+i,"<",1)) {
				tok->type = PUNC1;
				i += tok->n = 1;
			} else if (i1+1-i>=1 && !memcmp(buf+i,">",1)) {
				tok->type = PUNC1;
				i += tok->n = 1;
			} else if (i1+1-i>=1 && !memcmp(buf+i,"#",1)) {
				tok->type = PUNC1;
				i += tok->n = 1;
//ENDGEN
			}

		// Other
		} else {
			tok->type = OTHER;
			for (tok->n=1; i+tok->n<i1+1 && !isspace(buf[i+tok->n]) && (buf[i+tok->n]=='.'||!strchr(PUNCS"'\"",buf[i+tok->n])); tok->n++) {
				if (buf[i+tok->n] == '.') {
					for (size_t j=0; j<tok->n; j++) if (!isdigit(buf[i+j])) goto endother;
				}
			} endother:;
			i += tok->n;
		}
	}
	
	// Store values
	*pntoks=ntoks, *ptoks=toks;
}

void
getienclosuretoplevel(char *encs, size_t nenc0, size_t nbrace0, size_t nparen0, size_t ntoks, struct token *toks, uint8_t *buf, ssize_t *pienc0, ssize_t *pienc1)
{
	ssize_t ienc0=-1, ienc1=-1;
	for (ssize_t itok=0,nenc=nenc0,nbrace=nbrace0,nparen=nparen0,ienc=-1; itok+1<ntoks; itok++) {
		char c = buf[toks[itok].i];
		switch (c) { case '{':nbrace++;break; case '}':nbrace--;break;case '(':nparen++;break; case ')':nparen--;break; }
		if (c == encs[0]) {
			if (++nenc==1 && (!nbrace||*encs=='{') && (!nparen||*encs=='(')) ienc0=itok;
		} else if (c == encs[1]) nenc--;
		if (nenc==1 && (!nbrace||*encs=='{') && (!nparen||*encs=='(') && buf[toks[itok+1].i]==encs[1]) { ienc1=itok+1; break; }
	}
	*pienc0=ienc0, *pienc1=ienc1;
}

void
getibrace01statement(size_t nbrace0, size_t nparen0, size_t ntoks, struct token *toks, uint8_t *buf, ssize_t *pibrace0, ssize_t *pibrace1)
{
	getienclosuretoplevel("{}", nbrace0, nbrace0, nparen0, ntoks, toks, buf, pibrace0, pibrace1);
			
	// Skip if not a statement
	if (*pibrace0!=-1 || *pibrace1!=-1) {
		char stbrace = 0; // 0=nothing, 1=non;, 2=;
		size_t i1 = *pibrace1==-1 ? ntoks : *pibrace1;
		for (size_t i=*pibrace0+1; i<i1; i++) {
			if (toks[i].type==COMMENT1 || toks[i].type==COMMENT2) continue;
			if (text[toks[i].i] == ';') stbrace=2;
			else if (stbrace == 0) stbrace=1;
		}
		if (stbrace == 1) *pibrace0=*pibrace1=-1;
	}
}

void
getstarttoks(size_t ntoks, struct token *toks, uint8_t *buf, size_t *pnparen0, size_t *pnbrace0)
{
	ssize_t nparenmin=0, nbracemin=0;
	for (ssize_t itok=0,nbrace=0,nparen=0; itok<ntoks; itok++) {
		if (toks[itok].type==PUNC1) switch (buf[toks[itok].i]) {
		case '(': nparen++; break;
		case '{': nbrace++; break;
		case ')': nparen--; break;
		case '}': nbrace--; break;
		}
		if (nparen < nparenmin) nparenmin=nparen;
		if (nbrace < nbracemin) nbracemin=nbrace;
	}
	*pnparen0=-nparenmin, *pnbrace0=-nbracemin;
}

/* insert a break before this token. And update toks */
void
movebreak(size_t iindent, size_t ntoks, struct token *toks, size_t itok, int nindent)
{
	size_t ibrk = toks[itok-1].i + toks[itok-1].n;
	size_t ipart = toks[itok].i;
	size_t ndel = ipart - ibrk;
	backspace(ipart, ndel);
	insert(ibrk, 1, (uint8_t*)"\n");
	insert(ibrk+1, nindent, text+iindent);
	ssize_t d = 1 + nindent - ndel;
	for (size_t i=itok; i<ntoks; i++) toks[i].i+=d;
}

size_t
getbreakstoplevel(size_t nbrace0, size_t nparen0, size_t ntoks, struct token *toks, char *breaks, uint8_t *buf)
{
	size_t nbreaks = 0;
	char stbrace=0; // 0=nothing seen, 1=non; seen, 2=; seen
	for (ssize_t itok=0,nbrace=nbrace0,nparen=nparen0; itok+1<ntoks; itok++) switch (buf[toks[itok].i]) {
		case'(':nparen++; break; case')':nparen--; break;
		
		// Mark start of brace group
		case '{':
			if (++nbrace == 1) stbrace=0;
			break;

		// Check end of statement group
		case '}':
			if (--nbrace) break;
			if (stbrace==0 || stbrace==2) { breaks[itok]=1; nbreaks++; }
			break;
		
		// ;
		case ';':
		
			// Top-level statement endings
			if (!nbrace && !nparen && itok>1) { breaks[itok]=1; nbreaks++; }
			
			// Update brace state
			stbrace = 2;
			break;
			
		// Update brace state
		default:
			if (stbrace==0 && toks[itok].type!=COMMENT1 && toks[itok].type!=COMMENT2) stbrace=1;
	}
	return nbreaks;
}

/* Returns whether a break happened, also updates toks */
char
breaktoplevel(size_t iindent, size_t ntoksbrk, size_t ntoksall, struct token *toks, int nindent, ssize_t nbrace0, ssize_t nparen0)
{
	//char breaks[ntoksbrk]; memset(breaks,0,ntoksbrk);
	char *breaks = (char*)calloc(1, ntoksbrk); if (!breaks) { fprintf(stderr,"D3D12HelloTexture: calloc brk toks %zu: %s\n",ntoksbrk,strerror(errno)); exit(EXIT_FAILURE); }
	size_t nbreaks=getbreakstoplevel(nbrace0, nparen0, ntoksbrk, toks, breaks, text);
	if (nbreaks) for (size_t itok=ntoksbrk-1; itok>0; itok--) if (breaks[itok-1]) movebreak(iindent,ntoksall,toks,itok,nindent);
	free(breaks);
	return nbreaks > 0;
}

/* Doesn't return comma if it's the last one */
char
getprecedenceoplowest(uint8_t *buf, size_t ntoks, struct token *toks, size_t iopmin)
{
		
/* operators
,
= *= /= %= += -= <<= >>= &= ^= |=
? :
||
&&
|
^
&
== !=
< > <= >=
<< >>
+ -
* / %
end operators */

	// Get lowest precedence
	char precedence = CHAR_MAX;
	for (ssize_t i=0,nparen=0,nbrace=0; i<ntoks; i++) switch(buf[toks[i].i]) {
		case '{':nbrace++;break; case '}':nbrace--;break;case '(':nparen++;break; case ')':nparen--;break;
		default:
			if (i<iopmin || nparen || nbrace) continue;
			size_t n = toks[i].n;
			uint8_t *s = buf + toks[i].i;
			if (i+1==ntoks && *s==',') continue;
/* GEN
prec=0
set -f
unset pre2
<medc.c sed '1,/^\/\* operators/d;/^end operators/,$d' | while read ops; do
	<<! tr -d '\n'
			${pre2}if (precedence>$prec && (
!
	unset pre
	for op in $ops; do <<! tr -d '\n'; pre='||'; done
$pre(n==${#op}&&!memcmp(s,"$op",${#op}))
!
	<<! cat
)) precedence=$prec;
!
	prec=$((prec+1)) pre2='else '
done
*/
			if (precedence>0 && ((n==1&&!memcmp(s,",",1)))) precedence=0;
			else if (precedence>1 && ((n==1&&!memcmp(s,"=",1))||(n==2&&!memcmp(s,"*=",2))||(n==2&&!memcmp(s,"/=",2))||(n==2&&!memcmp(s,"%=",2))||(n==2&&!memcmp(s,"+=",2))||(n==2&&!memcmp(s,"-=",2))||(n==3&&!memcmp(s,"<<=",3))||(n==3&&!memcmp(s,">>=",3))||(n==2&&!memcmp(s,"&=",2))||(n==2&&!memcmp(s,"^=",2))||(n==2&&!memcmp(s,"|=",2)))) precedence=1;
			else if (precedence>2 && ((n==1&&!memcmp(s,"?",1))||(n==1&&!memcmp(s,":",1)))) precedence=2;
			else if (precedence>3 && ((n==2&&!memcmp(s,"||",2)))) precedence=3;
			else if (precedence>4 && ((n==2&&!memcmp(s,"&&",2)))) precedence=4;
			else if (precedence>5 && ((n==1&&!memcmp(s,"|",1)))) precedence=5;
			else if (precedence>6 && ((n==1&&!memcmp(s,"^",1)))) precedence=6;
			else if (precedence>7 && ((n==1&&!memcmp(s,"&",1)))) precedence=7;
			else if (precedence>8 && ((n==2&&!memcmp(s,"==",2))||(n==2&&!memcmp(s,"!=",2)))) precedence=8;
			else if (precedence>9 && ((n==1&&!memcmp(s,"<",1))||(n==1&&!memcmp(s,">",1))||(n==2&&!memcmp(s,"<=",2))||(n==2&&!memcmp(s,">=",2)))) precedence=9;
			else if (precedence>10 && ((n==2&&!memcmp(s,"<<",2))||(n==2&&!memcmp(s,">>",2)))) precedence=10;
			else if (precedence>11 && ((n==1&&!memcmp(s,"+",1))||(n==1&&!memcmp(s,"-",1)))) precedence=11;
			else if (precedence>12 && ((n==1&&!memcmp(s,"*",1))||(n==1&&!memcmp(s,"/",1))||(n==1&&!memcmp(s,"%",1)))) precedence=12;
//ENDGEN
	}
	return precedence;
}

char
isprecedence(char precedence, size_t n, uint8_t *s)
{
	switch (precedence) {
/* GEN
prec=0
set -f
<medc.c sed '1,/^\/\* operators/d;/^end operators/,$d' | while read ops; do
	<<! tr -d '\n'
	case $prec:return 
!
	unset pre
	for op in $ops; do <<! tr -d '\n'; pre='||'; done
$pre(n==${#op}&&!memcmp(s,"$op",${#op}))
!
	<<! cat
;
!
	prec=$((prec+1))
done
*/
	case 0:return (n==1&&!memcmp(s,",",1));
	case 1:return (n==1&&!memcmp(s,"=",1))||(n==2&&!memcmp(s,"*=",2))||(n==2&&!memcmp(s,"/=",2))||(n==2&&!memcmp(s,"%=",2))||(n==2&&!memcmp(s,"+=",2))||(n==2&&!memcmp(s,"-=",2))||(n==3&&!memcmp(s,"<<=",3))||(n==3&&!memcmp(s,">>=",3))||(n==2&&!memcmp(s,"&=",2))||(n==2&&!memcmp(s,"^=",2))||(n==2&&!memcmp(s,"|=",2));
	case 2:return (n==1&&!memcmp(s,"?",1))||(n==1&&!memcmp(s,":",1));
	case 3:return (n==2&&!memcmp(s,"||",2));
	case 4:return (n==2&&!memcmp(s,"&&",2));
	case 5:return (n==1&&!memcmp(s,"|",1));
	case 6:return (n==1&&!memcmp(s,"^",1));
	case 7:return (n==1&&!memcmp(s,"&",1));
	case 8:return (n==2&&!memcmp(s,"==",2))||(n==2&&!memcmp(s,"!=",2));
	case 9:return (n==1&&!memcmp(s,"<",1))||(n==1&&!memcmp(s,">",1))||(n==2&&!memcmp(s,"<=",2))||(n==2&&!memcmp(s,">=",2));
	case 10:return (n==2&&!memcmp(s,"<<",2))||(n==2&&!memcmp(s,">>",2));
	case 11:return (n==1&&!memcmp(s,"+",1))||(n==1&&!memcmp(s,"-",1));
	case 12:return (n==1&&!memcmp(s,"*",1))||(n==1&&!memcmp(s,"/",1))||(n==1&&!memcmp(s,"%",1));
//ENDGEN
	}
	return 0;
}

size_t
breaklowestprecedenceop(size_t ntoks, struct token *toks, size_t iline, size_t nindent)
{
	char precedence = getprecedenceoplowest(text, ntoks, toks, 1);
	if (precedence != CHAR_MAX) {
		for (ssize_t i=0,nparen=0,nbrace=0; i<ntoks; i++) switch (text[toks[i].i]) {
			case '{':nbrace++;break; case '}':nbrace--;break;case '(':nparen++;break; case ')':nparen--;break;
			default:
				df("blpo loop i%zu np%zd nb%zd isprec%d",i,nparen, nbrace, isprecedence(precedence,toks[i].n,text+toks[i].i));
				if (!i || nparen || nbrace || !isprecedence(precedence,toks[i].n,text+toks[i].i)) continue;
				size_t ibrk = i + (precedence<=1);
				if (ibrk >= ntoks) continue;
				movebreak(iline, ntoks, toks, ibrk, nindent);
				if (precedence) {
					insert(toks[ibrk-1].i+toks[ibrk-1].n+1, 1, (uint8_t*)"\t");
					for (size_t j=ibrk; j<ntoks; j++) toks[j].i++;
				}
		}
		return 1;
	}
	return 0;
}

char
isintoken(size_t iins)
{
	for (size_t i=0; i<iins; i++) {
		if (i+2<iins && !memcmp(text+i,"//",2)) {
			i++;
			do { if (++i >= iins) return 1; } while (text[i] != '\n');
		} else if (i+2<iins && !memcmp(text+i,"/*",2)) {
			i++;
			do { if (++i+1 >= iins) return 1; } while (memcmp(text+i,"*/",2));
			i++;
		} else if (strchr("\"'",text[i])) {
			char end=text[i], esc=0;
			while (1) {
				if (++i >= iins) return 1;
				if (!esc && text[i]==end) break;
				esc = !esc && text[i]=='\\';
			}
		}
	}
	return 0;
}

/* Expands the line starting at iline, possibly just flowing it */
void
expandi(size_t iline)
{
	df("expandi %zu", iline);
	printblocks(nblocks, blocks, fdf);
	
	// Flow if inside a comment
	if (isintoken(iline)) {
		size_t iflowbs = getiflowbs(iline);
		if (iflowbs<nflow && isflow[iflowbs]==iline) return;
		insertflowat(iline, iflowbs);
		return;
	}
	for (size_t i=iline; i+2<ntext && text[i]!='\n'; i++) {
		if (!memcmp(text+i,"//",2) || !memcmp(text+i,"/*",2)) {
			insertflowat(iline, getiflowbs(iline));
			return;
		}
		if (!isspace(text[i])) break;
	}
	
	// Insert if needed
	size_t iilexpbs = getiilexpbs(iline);
	size_t iilexp = getiilexpfrombs(iline, iilexpbs);
	uint8_t *line = text + iline;
	size_t nline=1; while (iline+nline<ntext && line[nline-1]!='\n') nline++;
	if (iilexp == SIZE_MAX) {
	
		// Insert into arrays
		iilexp = iilexpbs;
		if ((nilexps+1)*sizeof(size_t) > sizeilexps) {
			if (!(ilexps=(size_t*)realloc((void*)ilexps,sizeilexps=sizeilexps?2*sizeilexps:sizeof(size_t)*256))) { fprintf(stderr,"medc: realloc ilexps %zu: %s\n",sizeilexps,strerror(errno)); exit(EXIT_FAILURE); }
			if (!(exps=(struct expanse*)realloc((void*)exps,sizeilexps/sizeof(size_t)*sizeof(struct expanse)))) { fprintf(stderr,"medc: realloc exps %zu: %s\n",sizeilexps/sizeof(size_t)*sizeof(struct expanse),strerror(errno)); exit(EXIT_FAILURE); }
		}
		memmove(ilexps+iilexp+1, ilexps+iilexp, (nilexps-iilexp)*sizeof(size_t));
		memmove(exps+iilexp+1, exps+iilexp, (nilexps-iilexp)*sizeof(struct expanse));
		ilexps[iilexp] = iline;
		exps[iilexp] = (struct expanse){0};
		nilexps++;
		
		// Copy the original
		struct expanse *exp = exps + iilexp;
		exp->n = nline;
		df("exp create nline%zu", exp->n);
		//fwrite(line, 1, exp->n, fdf); df("");
		size_t norig = exp->n;
		if (!(exp->orig=(uint8_t*)malloc(exp->norig=exp->n))) { fprintf(stderr,"malloc exp orig %zu: %s\n",exp->norig,strerror(errno)); exit(EXIT_FAILURE); }
		memcpy(exp->orig, text+iline, exp->norig);
	}
	struct expanse *exp = exps + iilexp;
	
	// Expand this line and any too big after
	char wasunsaved = vtextsaved != vtext;
	{
		size_t norig = exp->norig;
		size_t nexp0 = exp->n;
		unsigned vtext0 = vtext;

		// Get starting indent
		int nindent; for (nindent=0; nindent<nline && strchr(" \t",line[nindent]); nindent++);
		df("exp indent %d", nindent);
			
		// Get tokens
		struct token *toks; size_t ntoks; gettokens(iline,iline+nline-1,text,&ntoks,&toks);
		df("exp tokens %zu", ntoks);
		for (size_t i=0; i<ntoks; i++) df("%c %zu %zu", text[toks[i].i], toks[i].i, toks[i].n);
				
		// Get starting nbrace and nparen
		size_t nparen0,nbrace0; getstarttoks(ntoks,toks,text,&nparen0,&nbrace0);
		df("exp nparen0 %zu nbrace0 %zu", nparen0, nbrace0);

		// Break top-level statements ;}
		if (breaktoplevel(iline,ntoks,ntoks,toks,nindent,nbrace0,nparen0)) {
			df("expandi broke top level");
			goto endbreaks;
		}

		// Expand inner {}
		ssize_t ibrace0,ibrace1; getibrace01statement(nbrace0,nparen0,ntoks,toks,text,&ibrace0,&ibrace1);
		if (ibrace0!=-1 || ibrace1!=-1) {
			df("expandi {}");
			printblocks(nblocks, blocks, fdf);
				
			// Break between { }
			if (ibrace1 != -1) movebreak(iline,ntoks,toks,ibrace1,nindent);
			if (ibrace0 != -1) movebreak(iline,ntoks,toks,ibrace0+1,nindent);
			
			// Indent inner
			size_t inest = ibrace0==-1 ? iline : toks[ibrace0].i+toks[ibrace0].n+1;
			insert(inest, 1, (uint8_t*)"\t");
			size_t itoknest = ibrace0==-1 ? 0 : ibrace0+1;
			for (size_t itok=itoknest; itok<ntoks; itok++) toks[itok].i++;
			//{ struct block *blk; size_t i0blk; getblocki(iline,&blk,&i0blk,0); df("go new exp {}3 blk%s i0blk%zu blk.iblocks%zu", sblk(blk), i0blk, blk->iblocks); fwrite(text+i0blk, 1, blk->iblocks, fdf); df("END{}3"); }
					
			// Break inner statements
			breaktoplevel(inest, ntoks-itoknest-(ibrace1==-1?0:ntoks-ibrace1), ntoks-itoknest, toks+itoknest, nindent+1, 0, 0);
			df("expandi inner {}");
			goto endbreaks;
		}

		// Break after if/for/while
		for (size_t i=0; i<ntoks; i++)
		if ((toks[i].n==2 && !memcmp(text+toks[i].i,"if",2))
			|| (toks[i].n==3 && !memcmp(text+toks[i].i,"for",3))
			|| (toks[i].n==5&&!memcmp(text+toks[i].i,"while",5)))
		for (ssize_t nparen=0; i<ntoks; i++)
		switch (text[toks[i].i]) {
		case '(': nparen++; break;
		case ')':
		if (!--nparen && i+1<ntoks && !strchr("{;",text[toks[i+1].i])) {
		movebreak(iline,ntoks,toks,i+1,nindent);
		insert(toks[i].i+toks[i].n+1, 1, (uint8_t*)"\t");
		for (i++; i<ntoks; i++) toks[i].i++;
		df("expandi if/for/while");
		goto endbreaks;
		}}
		
		// Break after else
		for (size_t i=0; i<ntoks-1; i++)
			if (toks[i].n==4&&!memcmp(text+toks[i].i,"else",4)) {
				movebreak(iline, ntoks, toks, i+1, nindent);
				insert(toks[i].i+toks[i].n+1,1,(uint8_t*)"\t");
				for (i++; i<ntoks; i++) toks[i].i++;
				df("expandi else");
				goto endbreaks;
			}
				
		// Expand between lowest precedence operators
		if (breaklowestprecedenceop(ntoks, toks, iline, nindent)) goto endbreaks;

		// Expand inner {} expr
		getienclosuretoplevel("{}", nbrace0, nbrace0, nparen0, ntoks, toks, text, &ibrace0, &ibrace1);
		if (ibrace0!=-1 || ibrace1!=-1) {
				
			// Break between { }
			if (ibrace1 != -1) movebreak(iline,ntoks,toks,ibrace1,nindent);
			if (ibrace0 != -1) movebreak(iline,ntoks,toks,ibrace0+1,nindent);
			size_t inest = ibrace0==-1 ? iline : toks[ibrace0].i+toks[ibrace0].n+1;
			size_t itoknest = ibrace0==-1 ? 0 : ibrace0+1;
			
			// Dedent hanging }
			if (ibrace0 == -1) {
				if (nindent) {
					backspace(toks[ibrace1].i, 1);
					for (size_t i=ibrace1; i<ntoks; i++) toks[i].i--;
				}
				
			// Indent inner
			} else {
				insert(inest, 1, (uint8_t*)"\t");
				for (size_t itok=itoknest; itok<ntoks; itok++) toks[itok].i++;
			}
					
			// Break inner op
			//if (breaktoplevel(inest, ntoks-itoknest-(iparen1==-1?0:ntoks-iparen1), ntoks-itoknest, toks+itoknest, nindent+1, 0, 0)) goto endbreaks;
			//if (!islinetoobig(inest)) goto endbreaks;
			df("expandi inner {}");
			goto endbreaks;
		}

		// Expand inner ()
		ssize_t iparen0, iparen1; getienclosuretoplevel("()",nparen0,nbrace0,nparen0,ntoks,toks,text,&iparen0,&iparen1);
		df("exp iparens %zd %zd", iparen0, iparen1);
		if (iparen0!=-1 || iparen1!=-1) {
				
			// Break between ( )
			if (iparen1 != -1) movebreak(iline,ntoks,toks,iparen1,nindent);
			if (iparen0 != -1) movebreak(iline,ntoks,toks,iparen0+1,nindent);
			size_t inest = iparen0==-1 ? iline : toks[iparen0].i+toks[iparen0].n+1;
			size_t itoknest = iparen0==-1 ? 0 : iparen0+1;
			
			// Dedent hanging )
			if (iparen0 == -1) {
				if (nindent) {
					backspace(toks[iparen1].i, 1);
					for (size_t i=iparen1; i<ntoks; i++) toks[i].i--;
				}
				
			// Indent inner
			} else {
				insert(inest, 1, (uint8_t*)"\t");
				for (size_t itok=itoknest; itok<ntoks; itok++) toks[itok].i++;
			}
					
			// Break inner parts if too big
			if (breaktoplevel(inest, ntoks-itoknest-(iparen1==-1?0:ntoks-iparen1), ntoks-itoknest, toks+itoknest, nindent+1, 0, 0)) goto endbreaks;
			//if (!islinetoobig(inest)) goto endbreaks;
			df("expandi inner ()");
			goto endbreaks;
		}

		// Expand inside //
		if (toks[ntoks-1].type == COMMENT2) {
			size_t icmt = toks[ntoks-1].i;
			struct at poscmt = go((at){.i=iline}, DBYTES|NROWS|WIDTH, icmt-iline, 1, (double)displaySize_.width);
			//if (poscmt.i<icmt || widthterm==poscmt.col) goto endexpandcmt;
			
			// Keep breaking words/chars while over line limit
			size_t i0=icmt, i1=getilinenext(iline);
			while (1) {
				
				// Find breaking index
				struct at end = go((at){.i=i0,.x=poscmt.x}, NROWS|WIDTH, 1, (double)displaySize_.width);
				if (text[end.i] == '\n') break;
				
				// Get break index of space or just the last char
				size_t ibrk = poscmt.i;
				for (size_t i=end.i; i>i0; i--)
					if (isspace(text[i])) { ibrk=i; break; }
					
				// Break
				size_t nins = 1 + poscmt.x/adv(' ');
				//uint8_t buf[nins];
				uint8_t *buf = (uint8_t*)malloc(nins); if (!buf) { fprintf(stderr,"D3D12HelloTexture: malloc break buf %zu: %s\n",nins,strerror(errno)); exit(EXIT_FAILURE); }
				buf[0]='\n'; memset(buf+1,' ',nins-1);
				insert(ibrk, nins, buf);
				free(buf);
				size_t ndel=0; while(text[ibrk+nins+ndel]!='\n'&&isspace(text[ibrk+nins+ndel]))ndel++;
				backspace(ibrk+nins+ndel, ndel);
				i0=ibrk+nins, i1+=nins-ndel;
			}
			df("expandi //");
			goto endbreaks;
		} endexpandcmt:;
		
		// Expand token, whitespace, char until no more
		#if 0
		{
			size_t i0=iline, i1=getilinenext(i0), o=0, itokbrk=1;
			while (1) {
				
				// Find breaking index
				struct at end = go((at){.i=i0}, NROWS|WIDTH, 1, (double)displaySize_.width);
				if (text[end.i] == '\n') break;
				size_t ibrk = end.i;
				{
				
					// Break at token
					for (ssize_t i=ntoks-2; i>=0; i--) {
						size_t i1tok = o + toks[i].i + toks[i].n;
						if (i1tok>i0 && i1tok<=i1) { ibrk=i1tok; goto gotibrk; }
					}
					
					// Break at whitespace
					for (size_t i=end.i; i>i0; i--)
						if (isspace(text[i])) { ibrk=i; goto gotibrk; }
				} gotibrk:;
					
				// Break
				insert(ibrk, 1, (uint8_t*)"\n");
				size_t nins = 1 + go((at){.i=i0}, DBYTES|NROWS|WIDTH, getnindent(i0), 1, (double)displaySize_.width).x/adv(' ');
				//uint8_t buf[nins];
				uint8_t *buf = (uint8_t*)malloc(nins); if (!nins) { fprintf(stderr,"D3D12HelloTexture: malloc break insert %zu: %s\n",nins,strerror(errno)); exit(EXIT_FAILURE); }
				buf[0]='\n'; memset(buf+1,' ',nins-1);
				insert(ibrk, nins, buf);
				free(buf);
				size_t ndel=0; while(text[ibrk+nins+ndel]!='\n'&&isspace(text[ibrk+nins+ndel]))ndel++;
				backspace(ibrk+nins+ndel, ndel);
				i0=ibrk+1, i1+=nins-ndel, o+=nins-ndel;
			}
			df("expandi last resort");
			goto endbreaks;
		}
		#endif
		
		// Give up and flow
		insertflowat(iline, getiflowbs(iline));
			
		// Clean up
		endbreaks:;
		exp->norig = norig;
		//fwrite(line, 1, nline, fdf);
		fflush(fdf);
		struct block *blk; size_t i0blk; getblocki(iline,&blk,&i0blk,1);
		//fwrite(text+i0blk, 1, blk->iblocks, fdf);
		df("END");
		free(toks);
		
		// Expand sublines now too big
		if (vtext != vtext0) for (size_t i=iline; i<ilexps[iilexp]+exp->n; i=getilinenext(i)) {
			if (getiflow(i) != SIZE_MAX) continue;
			struct at end = go((at){.i=i}, NROWS|WIDTH, 1, (double)displaySize_.width);
			if (end.i<ntext && text[end.i]!='\n')expandi(i);
		}
	}
	
	// If was save-ready, retain that
	if (!wasunsaved) vtextsaved=vtext;
}

size_t
spacelowestprecedence(size_t ntoks, struct token *toks, char *spaces, uint8_t *buf)
{
	size_t nspaced = getbreakstoplevel(0, 0, ntoks, toks, spaces, buf);
	if (nspaced) return nspaced;
	char precedence = getprecedenceoplowest(buf, ntoks, toks, 1);
	if (precedence != CHAR_MAX) for (ssize_t j=0,nparen2=0,nbrace2=0; j<ntoks; j++) switch (buf[toks[j].i]) {
		case'{':nbrace2++; break; case'}':nbrace2--; break; case'(':nparen2++; break; case')':nparen2--; break;
		default:
			if (nparen2 || nbrace2) continue;
			if (isprecedence(precedence,toks[j].n,buf+toks[j].i)) {
				if (precedence && j) spaces[j-1]=1;
				spaces[j] = 1;
				nspaced++;
			}
	}
	return nspaced;
}

/* Returns whether it spaced */
char
spacestatement(size_t ntoks, struct token *toks, uint8_t *buf, size_t nbrace0, size_t nparen0, char *spaces)
{

	// Spaces after if/for/while/switch/subsequent ), and
	// inner lowest priority op
	char spaced = 0;
	for (size_t i=0; i+1<ntoks; i++)
		if ((toks[i].n==2 && !memcmp(buf+toks[i].i,"if",2))
			|| (toks[i].n==3 && !memcmp(buf+toks[i].i,"for",3))
			|| (toks[i].n==5&&!memcmp(buf+toks[i].i,"while",5))
			|| (toks[i].n==6&&!memcmp(buf+toks[i].i,"switch",6))) {
			spaces[i++] = spaced = 1;
			df("spacestatement if/for/whil..");
			size_t iparen0;
			for (ssize_t nparen=0; i<ntoks; i++) {
				switch (buf[toks[i].i]) {
				case '(': if (++nparen==1)iparen0=i; break;
				case ')':
					if (!--nparen) {
						if (i+1<ntoks && buf[toks[i+1].i]!=';') spaces[i]=1;
						spacelowestprecedence(i-1-iparen0, toks+iparen0+1, spaces+iparen0+1, buf);
						goto endifwsparen;
					}
				}
			} endifwsparen:;
		}

	// Space within a solo {} statement
	ssize_t ibrace0, ibrace1; getibrace01statement(nbrace0, nparen0, ntoks, toks, buf, &ibrace0, &ibrace1);
	if (ibrace0!=-1 || ibrace1!=-1) {
		df("spacestatement {}");
		//if (ibrace0 != -1) for (size_t i=0; i<=ibrace0; i++) if (exp[toks[i].i]!='(' && (i==ntoks-1||exp[toks[i+1].i]!=')')) spaces[i]=1;
		if (ibrace0!=1 && ibrace0+1<ntoks) spaces[ibrace0]=1;
		size_t itoknest = ibrace0==-1 ? 0 : ibrace0+1;
		getbreakstoplevel(0, 0, ntoks-itoknest-(ibrace1==-1?0:ntoks-ibrace1), toks+itoknest, spaces+itoknest, buf);
		//if (ibrace1 != -1) for (size_t itok=ibrace1; itok+1<ntoks; itok++) spaces[itok]=1;
		if (ibrace1 >= 1) spaces[ibrace1-1]=1;
		spaced = 1;
	}
	return spaced;
}

/* Spaces lowest precedence, then tries inner () */
size_t
spaceexpr(size_t ntoks, struct token *toks, char *spaces, uint8_t *buf, size_t nparen0, size_t nbrace0)
{

	// Space lowest precedence
	size_t nspaced = spacelowestprecedence(ntoks, toks, spaces, buf);
	if (nspaced) return nspaced;

	// Spaces between ()
	ssize_t iparen0,iparen1; getienclosuretoplevel("()",nparen0,nbrace0,nparen0,ntoks,toks,buf,&iparen0,&iparen1);
	if (iparen0!=-1 || iparen1!=-1) {
	
		// Space lowest precedence between
		return spacelowestprecedence(ntoks-(iparen0+1)-(iparen1==-1?0:ntoks-iparen1), toks+(iparen0+1), spaces+(iparen0+1), buf);

		/*
		// Add spaces after commas
		for(ssize_t itok=iparen0==-1?0:iparen0+1,nbrace=0,nparen=0; itok<(iparen1==-1?ntoks-1:iparen1); itok++)switch(buf[toks[itok].i]){
		case '{':nbrace++;break; case '}':nbrace--;break;case '(':nparen++;break; case ')':nparen--;break;
		case ',':
			if (!nbrace && !nparen) { spaces[itok]=1; nspaced++; }
		}
		*/

		/*
		// Add spaces before * if function definition
		{

			// Make sure nonspace before function name is
			// a word, not an operator
			//TODO: assumes no comments, doesn't handle
			//mid-paren exp
			if (iparen0==-1 || !iparen0) goto gotspaces;
			size_t i = toks[ibrace0-1].i + (exp-text);
			if (!i) goto gotspaces;
			for (i=i-1; i && isspace(text[i]); i--);
			if (!isalnum(text[i])) goto gotspaces;

			// Add spaces before first * in each param
			char canspacestar = 1;
			for (ssize_t itok=iparen0+1,nbrace=0,nparen=0; itok<(iparen1==-1?ntoks-1:iparen1);itok++) {
				switch (exp[toks[itok].i]) { case '{':nbrace++;break;case '}':nbrace--;break;case '(':nparen++;break;case ')':nparen--;break; }
				if (canspacestar && !nbrace && !nparen && exp[toks[itok+1].i]=='*') { spaces[itok]=1; canspacestar=0; }
				canspacestar = canspacestar || (!nparen&&!nbrace&&exp[toks[itok].i]==',');
			}
		}
		goto gotspaces;
		*/
	}
	return nspaced;
}

/* The returned buffer is only valid until another
call to getunbufanded and cannot be freed.
This is like the method for bufanding, except it puts
spaces instead of newlines. */
void
getunexpanded(size_t nexp, uint8_t *exp, size_t *pnunexp, uint8_t **punexp)
{
	df("getunexpanded");
	static size_t sizeunexp = 0;
	static uint8_t *unexp = NULL;

	// Space between statements
	struct token *toks; size_t ntoks; gettokens(0,nexp-1,exp,&ntoks,&toks);
	size_t nparen0,nbrace0; getstarttoks(ntoks,toks,exp,&nparen0,&nbrace0);
	//char spaces[ntoks]; memset(spaces,0,ntoks);
	char *spaces = (char*)calloc(1, ntoks); if (!spaces) { fprintf(stderr,"D3D12HelloTexture: calloc spaces getunexpanded %zu: %s\n",ntoks,strerror(errno)); exit(EXIT_FAILURE); }
	size_t nbreaks = getbreakstoplevel(nbrace0, nparen0, ntoks, toks, spaces, exp);
	if (nbreaks) {
			df("getunexpanded betw stmt");
		
		// Space final for/while/if/switch
		size_t ilast; for (ilast=ntoks-1; !spaces[ilast-1]; ilast--);
		spacestatement(ntoks-ilast, toks+ilast, exp, 0, 0, spaces+ilast);
		goto gotspaces;
	}
	
	// Space within the single statement
	if (spacestatement(ntoks,toks,exp,nbrace0,nparen0,spaces)) {
		df("getunexpanded 1 stmt");
		goto gotspaces;
	}
	
	// Space at lowest precedence operator / function args
	size_t nspaced = spaceexpr(ntoks, toks, spaces, exp, nparen0, nbrace0);
	if (nspaced == 1) {
		
		// Space other side of =
		char precedence = getprecedenceoplowest(exp,ntoks,toks,1);
		if (precedence == 1)
			for (size_t i=0; i+1<ntoks; i++)
				if (isprecedence(precedence,toks[i].n,exp+toks[i].i)) {
					spaceexpr(ntoks-i-1, toks+i+1, spaces+i+1, exp, nbrace0, nparen0);
					break;
				}
	}
	if (nspaced) {
		df("getunexpanded op");
		goto gotspaces;
	}

	// Mark spaces between words
	gotspaces:
	df("getunexpanded gotspaces");
	for (size_t itok=0; itok+1<ntoks; itok++) if(toks[itok].type==OTHER && toks[itok+1].type==OTHER) spaces[itok]=1;

	// Mark spaces before probable pointer declarations
	char ismul = 0;
	for (size_t i=0; i+3<ntoks; i++) {
		int type = toks[i].type;
		char *s = (char*)exp + toks[i].i;
		if (strchr(",;(){}",*s)) ismul=0;
		else if (type!=COMMENT1 && type!=COMMENT2 && type!=OTHER) ismul=1;
		else if (!ismul && (type==OTHER||*s==',') && exp[toks[i+1].i]=='*' && toks[i+1].type==PUNC1) {
			for (size_t j=i+2; j+1<ntoks; j++)
				if (toks[j].type==OTHER && strchr(",;=)",exp[toks[j+1].i])) {
					spaces[i] = 1;
					break;
				} else if (toks[j].type!=PUNC1 || exp[toks[j].i]!='*') break;
		}
	}
	
	// Mark spaces after starting },?,:
	if (ntoks>1 && strchr("}?:",exp[toks[0].i])) spaces[0]=1;
	
	// Mark spaces after return
	for (size_t i=0; i+1<ntoks; i++) if (toks[i].n==6 && !memcmp(exp+toks[i].i,"return",6)) spaces[i]=1;

	// Copy into buffer with spaces
	size_t nunexp=toks[0].i+1; for (size_t i=0; i<ntoks; i++) nunexp+=toks[i].n+spaces[i];
	if (nunexp>sizeunexp && !(unexp=(uint8_t*)realloc((void*)unexp,sizeunexp=nunexp))) { fprintf(stderr,"medc: realloc unexp %zu: %s\n",sizeunexp,strerror(errno)); exit(EXIT_FAILURE); }
	size_t iunexp = 0;
	memcpy(unexp+iunexp,exp,toks[0].i); iunexp+=toks[0].i;
	for (size_t itok=0; itok<ntoks; itok++) {
		memcpy(unexp+iunexp,exp+toks[itok].i,toks[itok].n); iunexp+=toks[itok].n;
		if (spaces[itok]) unexp[iunexp++]=' ';
	}
	free(spaces);
	free(toks);
	unexp[iunexp++] = '\n';
	*pnunexp=nunexp, *punexp=unexp;
}

size_t
geticlosestafter(size_t i, double x1, double xleft, double xgoal, size_t nbuf, uint8_t *buf)
{

	// End of line = no after
	if (i>=nbuf || buf[i]=='\n') return i;

	// Doesn't fit = no after
	uint8_t n,f; double w; getgraphdisplay(nbuf,buf,i,&n,&w,&f);
	if (x1-xleft < w) return i;
	//struct at after = go(structatxyi(xleft,pos.ab.y,i), DGRAPHS|WIDTH|X0, (ssize_t)1, wwin-padwin, pos.xleft);

	// Choose whichever is closest
	return xgoal-xleft<w/2 ? i : i+n;
}

/* Sets cur either to this spot or the one after,
whichever is closer to x. */
void
setcurclosestafter(struct atblk pos, double x)
{
	icur = geticlosestafter(pos.i, displaySize_.width, pos.x, x, ntext, text);
}

size_t
getinoncmt(size_t i)
{
	for (; i<ntext; i++) {
		if (i+2<ntext && !memcmp("//",text+i,2)) while (i<ntext && text[i]!='\n') i++;
		else if (i+2<ntext && !memcmp("/*",text+i,2)) for (i+=3; i<ntext&&memcmp(text+i-1,"*/",2); i++);
		else if (!isspace(text[i])) break;
	}
	return i;
}

struct atblk
atcurblk(void)
{
	if (icur==SIZE_MAX || icur<itop) return (atblk){.x=-1.0,.y=-1.0,.i=SIZE_MAX};
	//return goblk(attopblk(), DBYTES, (ssize_t)(icur-itop));
	return goblk(attopblk(), DBYTES|WIDTH, (ssize_t)(icur-itop), (double)displaySize_.width);
}

struct at
atcur(void)
{
	struct atblk pos = atcurblk();
	return (at){.i=pos.i, .x=pos.x, .y=pos.y};
}

uint64_t
getms(void)
{
	return getns() / 1e6;
}

struct block*
getblkprev(struct block *blkafter)
{
	struct block *bprev = NULL;
	for (struct block *b=blkafter; b; b=b->parent) {
		if (b == (b->parent?b->parent->blocks:blocks)) {
			if (b->parent && b->parent->iblocks) { bprev=b->parent; break; }
		} else { bprev=b-1; break; }
	}
	return bprev;
}

size_t
igraphprevtext(size_t i)
{
	return igraphprev(ntext, text, i);
}

void
insertsearch(size_t i, size_t n, uint8_t *buf)
{
	ensuren(&sizesearch, nsearch, (void**)&bufsearch, nsearch+n);
	memmove(bufsearch+i+n, bufsearch+i, nsearch-i);
	memcpy(bufsearch+i, buf, n);
	nsearch += n;
	vsearch++;
}

void
backspacesearch(size_t i, size_t n)
{
	memmove(bufsearch+i-n, bufsearch+i, nsearch-i);
	nsearch -= n;
	vsearch++;
}

void
ensurenbufmulti(size_t n)
{
	ensuren(&sizebufmulti, nbufmulti, (void**)&bufmulti, n);
}

void
ensurenbufreplace0(size_t n)
{
	ensuren(&sizebufreplace0, nbufreplace0, (void**)&bufreplace0, n);
}

void
ensurenbufreplace1(size_t n)
{
	ensuren(&sizebufreplace1, nbufreplace1, (void**)&bufreplace1, n);
}

void
insertbufmulti(size_t i, size_t n, uint8_t *buf)
{
	ensurenbufmulti(i+n);
	memmove(bufmulti+i+n, bufmulti+i, nbufmulti-i);
	memcpy(bufmulti+i, buf, n);
	nbufmulti += n;
}

void
insertbufreplace0(size_t i, size_t n, uint8_t *buf)
{
	ensurenbufreplace0(i+n);
	memmove(bufreplace0+i+n, bufreplace0+i, nbufreplace0-i);
	memcpy(bufreplace0+i, buf, n);
	nbufreplace0 += n;
}

void
insertbufreplace1(size_t i, size_t n, uint8_t *buf)
{
	ensurenbufreplace1(i+n);
	memmove(bufreplace1+i+n, bufreplace1+i, nbufreplace1-i);
	memcpy(bufreplace1+i, buf, n);
	nbufreplace1 += n;
}

void
backspacebufmulti(size_t i, size_t n)
{
	memmove(bufmulti+i-n, bufmulti+i, nbufmulti-i);
	nbufmulti -= n;
}

void
backspacebufreplace0(size_t i, size_t n)
{
	memmove(bufreplace0+i-n, bufreplace0+i, nbufreplace0-i);
	nbufreplace0 -= n;
}

void
backspacebufreplace1(size_t i, size_t n)
{
	memmove(bufreplace1+i-n, bufreplace1+i, nbufreplace1-i);
	nbufreplace1 -= n;
}

double
getx1search(void)
{
	return go((at){.x=padwin},BUF,nsearch,bufsearch).x + 50;
}

void
failexceptionenv(JNIEnv *env)
{
	//if ((*activity->env)->ExceptionCheck(activity->env)) { fputs("medcn: jni exception\n",stderr); (*activity->env)->ExceptionDescribe(activity->env); exit(EXIT_FAILURE); }
	jthrowable e = (*env)->ExceptionOccurred(env);
	if (e) {
		fputs("medcn: jni exception\n", stderr);
		jclass clazz = (*env)->GetObjectClass(env, e);
		#define df(s)fprintf(stderr,s"\n"); fflush(stderr)
		df("got e class");
		jmethodID getMessage = (*env)->GetMethodID(env, clazz, "getMessage", "()Ljava/lang/String;");
		df("got getMessage");
		jstring message = (jstring)(*env)->CallObjectMethod(env, e, getMessage);
		df("got message");
		const char *s = (*env)->GetStringUTFChars(env, message, NULL);
		df("got message string");
		if (s) fprintf(stderr,"%s\n",s);
		df("tracing");
		(*env)->ExceptionClear(env);
		jclass StringWriter = (
				*env
			)->FindClass(env,"java/io/StringWriter");
		df("got sw");
		jobject writer = (*env)->NewObject(env,StringWriter,(*env)->GetMethodID(env,StringWriter,"<init>","()V"));
		df("got w");
		jclass PrintWriter = (
				*env
			)->FindClass(env,"java/io/PrintWriter");
			df("new pw");
		jobject printWriter = (*env)->NewObject(env,PrintWriter,(*env)->GetMethodID(env,PrintWriter,"<init>","(Ljava/io/Writer;)V"),writer);
		df("printst");
		(*env)->CallVoidMethod(env,e,(*env)->GetMethodID(env,clazz,"printStackTrace","(Ljava/io/PrintWriter;)V"),printWriter);
		df("flush");
		(*env)->CallVoidMethod(env,printWriter,(*env)->GetMethodID(env,PrintWriter,"flush","()V"));
		df("tostr");
		jstring trace = (*env)->CallObjectMethod(env,writer,(*env)->GetMethodID(env,StringWriter,"toString","()Ljava/lang/String;"));
		s = (*env)->GetStringUTFChars(env,trace,NULL);
		df("printing");
		if (s) fprintf(stderr,"%s\n",s);
		df("printed");
		#undef df
		exit(EXIT_FAILURE);
	}
}

void
failexception(void)
{
	failexceptionenv(activity->env);
}

jmethodID
getmethodenv(JNIEnv *env, jclass class, char *name, char *signature)
{
	jmethodID method=(*env)->GetMethodID(env,class,name,signature); if (!method) {failexceptionenv(env);Fprintf(stderr,"medcn: getmethodid %s %s null\n",name,signature);}
	return method;
}

jmethodID
getmethodstaticenv(JNIEnv *env, jclass class, char *name, char *signature)
{
	jmethodID method=(*env)->GetStaticMethodID(env,class,name,signature); if (!method) {failexceptionenv(env);Fprintf(stderr,"medcn: getstaticmethodid %s %s null\n",name,signature);}
	return method;
}

jmethodID
getmethod(jclass class, char *name, char *signature)
{
	return getmethodenv(activity->env, class, name, signature);
}

jclass
getclassenv(JNIEnv *env, char *name)
{
	jclass class=(*env)->FindClass(env,name); if (!class) {Fprintf(stderr,"medcn: findclass %s null\n",name);failexceptionenv(env);}
	return class;
}

jclass
getclass(char *name)
{
	return getclassenv(activity->env, name);
}

jobject
newobject(jclass class, jmethodID method, ...)
{
	va_list ap; va_start(ap,method);
	jobject obj = (*activity->env)->NewObjectV(activity->env, class, method, ap);
	va_end(ap);
	failexception(); if (!obj) { Fputs("medcn: newobject null\n",stderr); exit(EXIT_FAILURE); }
	return obj;
}

jobject
newobjectenv(JNIEnv *env, jclass class, jmethodID method, ...)
{
	va_list ap; va_start(ap,method);
	jobject obj = (*env)->NewObjectV(env, class, method, ap);
	va_end(ap);
	failexceptionenv(env); if (!obj) { Fputs("medcn: newobjectenv null\n",stderr); exit(EXIT_FAILURE); }
	return obj;
}

jobject
callmethodobjectenv(JNIEnv *env, jobject this, jmethodID method, ...)
{
	va_list ap; va_start(ap,method);
	jobject ret = (*env)->CallObjectMethodV(env,this,method,ap);
	va_end(ap);
	failexceptionenv(env);
	return ret;
}

const char*
getstrfromstringenv(JNIEnv *env, jstring s)
{
	const char *buf = (*env)->GetStringUTFChars(env, s, NULL); if (!buf) { Fprintf(stderr,"medcn: getstringutfchars null\n"); exit(EXIT_FAILURE); }
	return buf;
}

void
callmethodvoidenv(JNIEnv *env, jobject this, jmethodID method, ...)
{
	va_list ap; va_start(ap,method);
	(*env)->CallVoidMethodV(env,this,method,ap);
	va_end(ap);
	failexceptionenv(env);
}

jobject
callmethodstaticobjectenv(JNIEnv *env, jclass class, jmethodID method, ...)
{
	va_list ap; va_start(ap,method);
	jobject ret = (*env)->CallStaticObjectMethodV(env,class,method,ap);
	va_end(ap);
	failexceptionenv(env);
	return ret;
}

jobject
callmethodobject(jobject this, jmethodID method, ...)
{
	va_list ap; va_start(ap,method);
	jobject ret = (*activity->env)->CallObjectMethodV(activity->env,this,method,ap);
	va_end(ap);
	failexception();
	return ret;
}

jboolean
callmethodbooleanenv(JNIEnv *env, jobject this, jmethodID method, ...)
{
	va_list ap; va_start(ap,method);
	jboolean ret = (*env)->CallBooleanMethodV(env,this,method,ap);
	va_end(ap);
	failexceptionenv(env);
	return ret;
}

jint
callmethodintenv(JNIEnv *env, jobject this, jmethodID method, ...)
{
	va_list ap; va_start(ap,method);
	jint ret = (*env)->CallIntMethodV(env,this,method,ap);
	va_end(ap);
	failexceptionenv(env);
	return ret;
}

void
callmethodvoid(jobject this, jmethodID method, ...)
{
	va_list ap; va_start(ap,method);
	(*activity->env)->CallVoidMethodV(activity->env,this,method,ap);
	va_end(ap);
	failexception();
}

jstring
getstringenv(JNIEnv *env, char *s)
{
	jstring ret=(*env)->NewStringUTF(env,s); if (!ret) {fprintf(stderr,"medcn: getstring %s null\n",s);exit(EXIT_FAILURE);}
	return ret;
}

jstring
getstring(char *s)
{
	return getstringenv(activity->env, s);
}

jfieldID
getfieldenv(JNIEnv *env, jclass class, char *name, char *type)
{
	jfieldID ret = (*env)->GetFieldID(env, class, name, type); if (!ret) { failexceptionenv(env); fputs("medcn: getfieldid null\n",stderr); exit(EXIT_FAILURE); }
	return ret;
}

jclass
getclassobjectenv(JNIEnv *env, jobject obj)
{
	jclass ret = (*env)->GetObjectClass(env, obj);
	if (!ret) {
		fputs(
			"medcn: getobjectclass null\n",stderr
		); exit(EXIT_FAILURE); }
	return ret;
}

JNIEnv*
attachjni(void)
{
	jint lResult;
	jint lFlags = 0;
	JavaVM* lJavaVM = activity->vm;
	JNIEnv* env = activity->env;
	JavaVMAttachArgs lJavaVMAttachArgs;
	lJavaVMAttachArgs.version = JNI_VERSION_1_6;
	lJavaVMAttachArgs.name = "NativeThread";
	lJavaVMAttachArgs.group = NULL;
	lResult=(*lJavaVM)->AttachCurrentThread(lJavaVM, &env, &lJavaVMAttachArgs);
	if (lResult == JNI_ERR) {
		Fprintf(stderr, "AttachCurrentThread\n"); exit(EXIT_FAILURE);
	}
	return env;	
}            	

void
showkeyboard(void)
{
	//df("showkeyboard");
	//ANativeActivity_showSoftInput(app->activity, ANATIVEACTIVITY_SHOW_SOFT_INPUT_FORCED);

	// Attaches the current thread to the JVM.
	jint lResult;
	jint lFlags = 0;
	JavaVM* lJavaVM = activity->vm;
	JNIEnv* lJNIEnv = activity->env;
	JavaVMAttachArgs lJavaVMAttachArgs;
	lJavaVMAttachArgs.version = JNI_VERSION_1_6;
	lJavaVMAttachArgs.name = "NativeThread";
	lJavaVMAttachArgs.group = NULL;
	lResult=(*lJavaVM)->AttachCurrentThread(lJavaVM, &lJNIEnv, &lJavaVMAttachArgs);
	if (lResult == JNI_ERR) {
		Fprintf(stderr, "AttachCurrentThread\n"); exit(EXIT_FAILURE);
	}

#if 0
	// Retrieves NativeActivity.
	jobject lNativeActivity = activity->clazz;
	jclass ClassNativeActivity = (*lJNIEnv)->GetObjectClass(lJNIEnv, lNativeActivity);

	//getSystemService(Context.INPUT_METHOD_SERVICE).
	jclass ClassContext = (*lJNIEnv)->FindClass(lJNIEnv, "android/content/Context");
	jfieldID FieldINPUT_METHOD_SERVICE = (*lJNIEnv)->GetStaticFieldID(lJNIEnv, ClassContext, "INPUT_METHOD_SERVICE", "Ljava/lang/String;");
	jobject INPUT_METHOD_SERVICE = (*lJNIEnv)->GetStaticObjectField(lJNIEnv, ClassContext, FieldINPUT_METHOD_SERVICE);
	jclass ClassInputMethodManager = (*lJNIEnv)->FindClass(lJNIEnv, "android/view/inputmethod/InputMethodManager");
	jmethodID MethodGetSystemService = (*lJNIEnv)->GetMethodID(lJNIEnv, ClassNativeActivity, "getSystemService", "(Ljava/lang/String;)Ljava/lang/Object;");
	jobject lInputMethodManager = (*lJNIEnv)->CallObjectMethod(lJNIEnv, lNativeActivity, MethodGetSystemService, INPUT_METHOD_SERVICE);

	// Runs getWindow().getDecorView().
	jmethodID MethodGetWindow = (*lJNIEnv)->GetMethodID(lJNIEnv, ClassNativeActivity, "getWindow", "()Landroid/view/Window;");
	jobject lWindow = (*lJNIEnv)->CallObjectMethod(lJNIEnv, lNativeActivity, MethodGetWindow);
	jclass ClassWindow = (*lJNIEnv)->FindClass(lJNIEnv, "android/view/Window");
	jmethodID MethodGetDecorView = (*lJNIEnv)->GetMethodID(lJNIEnv, ClassWindow, "getDecorView", "()Landroid/view/View;");
	jobject lDecorView = (*lJNIEnv)->CallObjectMethod(lJNIEnv, lWindow, MethodGetDecorView);

	// Runs lInputMethodManager.showSoftInput(...).
	if (1) {
		jmethodID MethodShowSoftInput = (*lJNIEnv)->GetMethodID(lJNIEnv, ClassInputMethodManager, "showSoftInput", "(Landroid/view/View;I)Z");
		jboolean lResult = (*lJNIEnv)->CallBooleanMethod(lJNIEnv, lInputMethodManager, MethodShowSoftInput, lDecorView, lFlags);
	
	// Runs lWindow.getViewToken()
	} else {
		jclass ClassView = (*lJNIEnv)->FindClass(lJNIEnv, "android/view/View");
		jmethodID MethodGetWindowToken = (*lJNIEnv)->GetMethodID(lJNIEnv, ClassView, "getWindowToken", "()Landroid/os/IBinder;");
		jobject lBinder = (*lJNIEnv)->CallObjectMethod(lJNIEnv, lDecorView, MethodGetWindowToken);

		// lInputMethodManager.hideSoftInput(...).
		jmethodID MethodHideSoftInput = (*lJNIEnv)->GetMethodID(lJNIEnv, ClassInputMethodManager, "hideSoftInputFromWindow", "(Landroid/os/IBinder;I)Z");
		jboolean lRes = (*lJNIEnv)->CallBooleanMethod(lJNIEnv, lInputMethodManager, MethodHideSoftInput, lBinder, lFlags);
	}
#endif

	//editText.requestFocus()
	jclass MyEditText = getclassobjectenv(lJNIEnv, editText);
	jmethodID requestFocus = getmethodenv(lJNIEnv, MyEditText, "requestFocus", "()Z");
	callmethodbooleanenv(lJNIEnv, editText, requestFocus);
	
	//InputMethodManager imm = activity.getSystemService(
	//Context.INPUT_METHOD_SERVICE)
	jclass MyNativeActivity = getclassobjectenv(lJNIEnv, activity->clazz);
	jmethodID getSystemService = getmethodenv(lJNIEnv, MyNativeActivity, "getSystemService", "(Ljava/lang/String;)Ljava/lang/Object;");
	jobject imm = callmethodobjectenv(lJNIEnv, activity->clazz, getSystemService, getstringenv(lJNIEnv,"input_method"));
	
	//imm.showSoftInput(editText,
	//InputMethodManager.SHOW_IMPLICIT)
	jclass InputMethodManager = getclassobjectenv(lJNIEnv, imm);
	jmethodID showSoftInput = getmethodenv(lJNIEnv, InputMethodManager, "showSoftInput", "(Landroid/view/View;I)Z");
	callmethodbooleanenv(lJNIEnv, imm, showSoftInput, editText, 1);

	// Finished with the JVM.
	(*lJavaVM)->DetachCurrentThread(lJavaVM);
}

void
hidekeyboard(void)
{
	//df("hidekeyboard");
	//ANativeActivity_hideSoftInput(activity, ANATIVEACTIVITY_HIDE_SOFT_INPUT_IMPLICIT_ONLY);

	// Attaches the current thread to the JVM.
	jint lResult;
	jint lFlags = 0;
	JavaVM* lJavaVM = activity->vm;
	JNIEnv* lJNIEnv = activity->env;
	JavaVMAttachArgs lJavaVMAttachArgs;
	lJavaVMAttachArgs.version = JNI_VERSION_1_6;
	lJavaVMAttachArgs.name = "NativeThread";
	lJavaVMAttachArgs.group = NULL;
	lResult=(*lJavaVM)->AttachCurrentThread(lJavaVM, &lJNIEnv, &lJavaVMAttachArgs);
	if (lResult == JNI_ERR) {
		Fprintf(stderr, "AttachCurrentThread\n"); exit(EXIT_FAILURE);
	}

#if 0
	// Retrieves NativeActivity.
	jobject lNativeActivity = activity->clazz;
	jclass ClassNativeActivity = (*lJNIEnv)->GetObjectClass(lJNIEnv, lNativeActivity);

	// Retrieves Context.INPUT_METHOD_SERVICE.
	jclass ClassContext = (*lJNIEnv)->FindClass(lJNIEnv, "android/content/Context");
	jfieldID FieldINPUT_METHOD_SERVICE = (*lJNIEnv)->GetStaticFieldID(lJNIEnv, ClassContext, "INPUT_METHOD_SERVICE", "Ljava/lang/String;");
	jobject INPUT_METHOD_SERVICE = (*lJNIEnv)->GetStaticObjectField(lJNIEnv, ClassContext, FieldINPUT_METHOD_SERVICE);
	//	jniCheck(INPUT_METHOD_SERVICE);

	// Runs getSystemService(Context.INPUT_METHOD_SERVICE).
	jclass ClassInputMethodManager = (*lJNIEnv)->FindClass(lJNIEnv, "android/view/inputmethod/InputMethodManager");
	jmethodID MethodGetSystemService = (*lJNIEnv)->GetMethodID(lJNIEnv, ClassNativeActivity, "getSystemService", "(Ljava/lang/String;)Ljava/lang/Object;");
	jobject lInputMethodManager = (*lJNIEnv)->CallObjectMethod(lJNIEnv, lNativeActivity, MethodGetSystemService, INPUT_METHOD_SERVICE);

	// Runs getWindow().getDecorView().
	jmethodID MethodGetWindow = (*lJNIEnv)->GetMethodID(lJNIEnv, ClassNativeActivity, "getWindow", "()Landroid/view/Window;");
	jobject lWindow = (*lJNIEnv)->CallObjectMethod(lJNIEnv, lNativeActivity, MethodGetWindow);
	jclass ClassWindow = (*lJNIEnv)->FindClass(lJNIEnv, "android/view/Window");
	jmethodID MethodGetDecorView = (*lJNIEnv)->GetMethodID(lJNIEnv, ClassWindow, "getDecorView", "()Landroid/view/View;");
	jobject lDecorView = (*lJNIEnv)->CallObjectMethod(lJNIEnv, lWindow, MethodGetDecorView);
	
	// Runs lWindow.getViewToken()
	jclass ClassView = (*lJNIEnv)->FindClass(lJNIEnv, "android/view/View");
	jmethodID MethodGetWindowToken = (*lJNIEnv)->GetMethodID(lJNIEnv, ClassView, "getWindowToken", "()Landroid/os/IBinder;");
	jobject lBinder = (*lJNIEnv)->CallObjectMethod(lJNIEnv, lDecorView, MethodGetWindowToken);

	// lInputMethodManager.hideSoftInput(...).
	jmethodID MethodHideSoftInput = (*lJNIEnv)->GetMethodID(lJNIEnv, ClassInputMethodManager, "hideSoftInputFromWindow", "(Landroid/os/IBinder;I)Z");
	jboolean lRes = (*lJNIEnv)->CallBooleanMethod(lJNIEnv, lInputMethodManager, MethodHideSoftInput, lBinder, lFlags);
#endif

	//InputMethodManager imm = activity.getSystemService(
	//Context.INPUT_METHOD_SERVICE)
	jclass MyNativeActivity = getclassobjectenv(lJNIEnv, activity->clazz);
	jmethodID getSystemService = getmethodenv(lJNIEnv, MyNativeActivity, "getSystemService", "(Ljava/lang/String;)Ljava/lang/Object;");
	jobject imm = callmethodobjectenv(lJNIEnv, activity->clazz, getSystemService, getstringenv(lJNIEnv,"input_method"));
	
	//IBinder windowToken = editText.getWindowToken()
	jclass MyEditText = getclassobjectenv(lJNIEnv, editText);
	jmethodID getWindowToken = getmethodenv(lJNIEnv, MyEditText, "getWindowToken", "()Landroid/os/IBinder;");
	jobject windowToken = callmethodobjectenv(lJNIEnv, editText, getWindowToken);
	
	//imm.hideSoftInputFromWindow(windowToken, 0)
	jclass InputMethodManager = getclassobjectenv(lJNIEnv, imm);
	jmethodID hideSoftInputFromWindow = getmethodenv(lJNIEnv, InputMethodManager, "hideSoftInputFromWindow", "(Landroid/os/IBinder;I)Z");
	callmethodbooleanenv(lJNIEnv, imm, hideSoftInputFromWindow, windowToken, 0);

	// Finished with the JVM.
	(*lJavaVM)->DetachCurrentThread(lJavaVM);
}

long
gethframe(void)
{
	
	// Overridden
	if (getms() < msoverridehframe) return hframeoverride;
	
	if (hframe == -1) {
          	
		// ybottom = activity.hFrame;
		JNIEnv *env = attachjni();
		jclass MyNativeActivity = getclassobjectenv(env, activity->clazz);
		jfieldID MyNativeActivity_hFrame = getfieldenv(env, MyNativeActivity, "hFrame", "I");
		hframe=(*env)->GetIntField(env,activity->clazz,MyNativeActivity_hFrame); failexceptionenv(env);
		//df("ybottom %.2f", ybottom);
		(*activity->vm)->DetachCurrentThread(activity->vm);
	}
	return hframe;
}

/* Show/hide the keyboard as appropriate */
void
ensurekeyboard(void)
{
	if (icur == SIZE_MAX) hidekeyboard();
	else showkeyboard();
}

void
ensurekeyboardifneeded(void)
{
	if (getms() > msensurekeyboard) return;
	ensurekeyboard();
}

void
appendmulti(size_t i)
{
	size_t sizeneeded = ++nmulti * sizeof(struct multicur);
	if (sizeneeded > sizemulti) {
		size_t sizemulti0 = sizemulti;
		if (!sizemulti) sizemulti=4096;
		while (sizemulti < sizeneeded) sizemulti*=2;
		if (!(multis=realloc(multis,sizemulti))) {fprintf(stderr,"medcn: realloc multi %zu: %s\n",sizemulti,strerror(errno));exit(EXIT_FAILURE);}
		memset((char*)multis+sizemulti0, 0, sizemulti-sizemulti0);
	}
	struct multicur *m=multis+nmulti-1; m->i=i,m->ncopy=0,m->iselect=SIZE_MAX;
	multis[nmulti-1].i=i, multis[nmulti-1].ncopy=0;
}

void
removemultii(size_t imc)
{
	if (imc < nmulti-1) memmove(multis+imc,multis+imc+1,sizeof(struct multicur)*(nmulti-imc-1));
	nmulti--;
}

/* Flow/unflow lines according to the multi cursor
placements */
void
flowmulti(void)
{
	
	// Unflow all multi-only flows
	for (size_t i=0; i<nflowmulti; i++)
		removeflowi(getiflow(isflowmulti[i]));
	nflowmulti = 0;
	
	// Flow all cursors which go past the screen edge
	for (size_t imc=0; imc<nmulti; imc++) {
		size_t itext=multis[imc].i, il=getiline(itext);
		size_t iflowbs = getiflowbs(il);
		if (iflowbs<nflow && isflow[iflowbs]==il) continue;
		struct at pos = go((at){.i=il}, DBYTES, itext-il);
		if (pos.i == itext) continue;
		insertflowat(il, iflowbs);
		ensuren(&sizeflowmulti,0,(void**)&isflowmulti,++nflowmulti*sizeof(size_t)); isflowmulti[nflowmulti-1]=il;
		needsredraw=1;
	}
}

/* Flow/unflow lines according to the replacement
placements */
void
flowreplace(void)
{
	
	// Unflow all replace-only flows
	for (size_t i=0; i<nflowreplace; i++)
		removeflowi(getiflow(isflowreplace[i]));
	nflowreplace = 0;
	
	// Flow all cursors which go past the screen edge
	for (size_t irep=0; irep<nreplace; irep++) {
		size_t itext=isreplace[irep]+replaces[irep].n, il=getiline(itext);
		size_t iflowbs = getiflowbs(il);
		if (iflowbs<nflow && isflow[iflowbs]==il) continue;
		struct at pos = go((at){.i=il}, DBYTES, itext-il);
		if (pos.i == itext) continue;
		insertflowat(il, iflowbs);
		ensuren(&sizeflowreplace,0,(void**)&isflowreplace,++nflowreplace*sizeof(size_t)); isflowreplace[nflowreplace-1]=il;
		needsredraw=1;
	}
}

char
isshowsearchresults(void)
{
	for (uint8_t *c=bufsearch; c<bufsearch+nsearch; c++) if (!isdigit(*c)) return 1;
	return 0;
}

/* Makes sure the screen at ytop is filled or
clamped. Also that ytop isnt too big  */
void
ensurescroll(void)
{
	
	// Searching
	if (isshowsearchresults()) {
		if (!isrtop && ytop>mudwin) ytop=mudwin;
		
	// Text display
	} else {
		
		// Decrement itop to fill
		while (itop && ytop>0) {
			//df("scrollup itop %zu", itop);

			// Get current block
			struct block *blk; size_t i0blk; getblocki(itop,&blk,&i0blk,0);
			
			// Find out if prev row is an expanded one
			char atpost = blk->expanded && itop>getilinenonemptyorlast(i0blk,i0blk+blk->n) && itop==i0blk+getipost(blk);
			//df("scrollup atpost %d", atpost);
			char prevex = !atpost && (
				 (blk->expanded && itop>getilinenonemptyorlast(i0blk,i0blk+blk->n))
					|| (blk->parent && blk==blk->parent->blocks)
				);
			struct block *prev=NULL; size_t i0prev;
			if (!prevex) {
				if (atpost)
					prev=blk->blocks+blk->nblocks-1, i0prev=itop-prev->n;
				else
					prev=blk-1, i0prev=i0blk-prev->n;
				while ((prevex=prev->expanded) && prev->nblocks) {
					size_t ipost = i0prev + getipost(prev);
					if (ipost < i0prev+prev->n) break;
					prev = prev->blocks + prev->nblocks-1;
					i0prev = ipost - prev->n;
				}
			}
			//df("scrollup prevex %d", prevex);
			
			// Move up a row in expanded one
			if (prevex) {
				//df("going back itop%zu", itop);
				debug=1;
				struct at top = go((at){.i=itop,.y=ytop}, DROWS|WIDTH, (ssize_t)-1, (double)displaySize_.width);
				//delta -= top.y;
				ytop = top.y;
				itop=top.i;
				debug=0;
				//df("itop after %zu", itop);
				}
			
			// Move to bottom of previous unexpanded row
			else {
				
				// Handle coalesce
				if (getiscoalesced(prev,i0prev,NULL,NULL)) {
					blk=prev, itop=i0prev; while (!(blk-1)->expanded) itop-=(--blk)->n;
					ytop -= hline + 2*pudb + mudb;
				
				// Handle normal
				} else {
					blk = prev;
					size_t i = i0prev;
					struct block *head = blk->parent ? blk->parent->blocks : blocks;
					//df("scrollup finding head i%zu", i);
					while (blk != head) i-=(--blk)->n;
					//df("scrollup blk==head i%zu", i);
					size_t istop = atpost ? itop : i0blk;
					while (1) {
						//df("scrollup blk rows i%zu", i);
						if (blk->expanded) i+=blk++->n;
						else {
							size_t j=i, nblks, is[MAXLABELS], ns[MAXLABELS], indent, k; double ws[MAXLABELS], pad=displaySize_.width; getlabelsrow(&blk, &j, MAXLABELS, &pad, &nblks, is, ns, ws, &indent, &k, 0, NULL);
							if (k == istop) break;
							i = k;
						}
					}
					itop = i;
					//delta += hline + 2*pudb + mudb;
					ytop -= hline + 2*pudb + mudb;
				}
			}
		}
		
		// Increment itop if ytop too big
		if (ytop < -1024) {
			struct atblk pos = attopblk();
			while (ytop < -1024) {
				pos.row = 0;
				struct atblk pos2 = goblk(pos, DROWS|WIDTH, 1, (double)displaySize_.width);
				if (pos.i == pos2.i) break;
				itop=pos2.i, ytop=pos2.y, pos=pos2;
			}
		}
			
		// Clamp ytop if no more to scroll
		if (!itop && ytop>mudwin) ytop=mudwin;
	
		// Make sure text is visible
		{
			//df("checking visible ..");
			struct atblk end = goblk(attopblk(), HEIGHT, (double)hline);
			if (end.i >= ntext) {
				//df("not visible!");
				while (1) {
					struct atblk pos = goblk(attopblk(), DROWS|WIDTH, (ssize_t)1, (double)displaySize_.width);
					if (pos.i==itop || pos.i>=ntext) break;
					itop = pos.i;
				}
				ytop = 0; yvelocity=0;
			}
		}
	}
}

void
scrolliinview(size_t i)
{
	
	// Scroll to it at the top
	itop=getiline(i), ytop=mudwin;
	ensurescroll();
}

void
scrollcurinview(void)
{
	if (icur==SIZE_MAX && !nmulti) return;
	
	// If any cursor is in view, return
	if (curshown) {
		long hframe = gethframe();
		df("scrollcurinview hframe %ld", hframe);
		for (struct vcur *v=vertscur; v<vertscur+nvertscur; v+=6)
			if (v[0].y>=0 && v[1].y<=hframe) return;
	}
	
	// Get minimum cursor
	size_t imin;
	if (nmulti) {
		imin=multis[0].i; for (struct multicur *m=multis+1; m<multis+nmulti; m++) if (m->i < imin) imin=m->i;
	} else imin=icur;
	
	// Scroll to it
	scrolliinview(imin);
}

/* Restores the original text of every replacement */
void
clearreplaces(void)
{
	for (; nreplace; nreplace--) {
		struct replace *r = replaces + nreplace - 1;
		size_t i = isreplace[nreplace-1];
		backspace(i+r->n, r->n);
		insert(i, r->norig, r->orig);
	}
}

void
updatereplaces(void)
{
	char type = btnsreplace[REPLACECASE].lines[1][0];
	for (size_t irep=0; irep<nreplace; irep++) {
		size_t i = isreplace[irep]; struct replace*r=replaces+irep;
		backspace(i+r->n, r->n);
		if (nbufreplace1) {
			insert(i, nbufreplace1, bufreplace1);
			r->n = nbufreplace1;
			
			// Match case
			if (r->norig && type=='c') {
				char firstupper = isupper(r->orig[0]);
				char noupper = !firstupper;
				char allupper = firstupper;
				for (size_t ic=1; ic<r->norig; ic++) {
					char icup = isupper(r->orig[ic]);
					noupper = noupper && !icup;
					allupper = allupper && icup;
				}
				if (firstupper && r->n) text[i]=toupper(text[i]);
				if (allupper) for (size_t ic=0; ic<r->n; ic++)
					text[i+ic] = toupper(text[i+ic]);
				if (noupper) for (size_t ic=0; ic<r->n; ic++)
					text[i+ic] = tolower(text[i+ic]);
			}
		}
	}
}

void
recalcreplaces(void)
{
	df("recalcreplaces %zu-%zu: %.*s", i0replace, i1replace, (int)nbufreplace0, bufreplace0);
	size_t ntext0=ntext; clearreplaces();
	//i1replace += (ssize_t)ntext - (ssize_t)ntext0;
	if (!nbufreplace0) goto aftersearchreplaces;
	regex_t reg; ensurenbufreplace0(nbufreplace0+1); bufreplace0[nbufreplace0]=0; if (regcomp(&reg,(char*)bufreplace0,REG_ICASE|REG_NEWLINE)) goto aftersearchreplaces;
	ensurentext(i1replace+1); uint8_t cend=text[i1replace]; text[i1replace]=0;
	for (size_t i=i0replace; i<i1replace;) {
		regmatch_t match; char matched=!regexec(&reg,(char*)text+i,1,&match,(i&&text[i-1]!='\n')*REG_NOTBOL|((strchr((char*)text+i,'\n')||(i+strlen((char*)text+i)==i1replace&&cend=='\n'))*REG_NOTEOL));
		df(" %zu %s", i, matched?"yes":"no");
		if (matched) {
			size_t sizeisreplace0=sizeisreplace; ensurens(nreplace+1,&sizeisreplace,sizeof(size_t),(void**)&isreplace,sizeof(struct replace),(void**)&replaces,0);
			if (sizeisreplace > sizeisreplace0) memset((char*)replaces+sizeisreplace0,0,sizeisreplace-sizeisreplace0);
			struct replace *r = replaces + nreplace;
			isreplace[nreplace++] = i + match.rm_so;
			size_t nmatch = match.rm_eo - match.rm_so;
			ensuren(&r->sizeorig,0,(void**)&r->orig,nmatch); memcpy(r->orig,text+i+match.rm_so,r->norig=r->n=nmatch);
			i += match.rm_eo ? match.rm_eo : 1;
		} else {
			size_t n = strlen((char*)text+i);
			i += n ? n : 1;
		}
	}
	text[i1replace] = cend;
	aftersearchreplaces:;
	updatereplaces();
	flowreplace();
}

/* Requires buf+i1 to be writable
Stops at null byte */
void
copybuf(size_t i0, size_t i1, uint8_t *buf)
{
	size_t n = i1 - i0;
	/*
	ensuren(&sizelcopy, nlcopy, (void**)&lcopy, n);
	memcpy(lcopy, text+i0, nlcopy=n);
	*/

	//ClipboardManager clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
	JNIEnv *env = attachjni();
	jclass MyNativeActivity = getclassobjectenv(env, activity->clazz);
	jmethodID getSystemService = getmethodenv(env, MyNativeActivity, "getSystemService", "(Ljava/lang/String;)Ljava/lang/Object;");
	jobject clipboardManager = callmethodobjectenv(env, activity->clazz,  getSystemService, getstringenv(env,"clipboard"));

	//ClipData clip = ClipData.newPlainText(null, buf+i0);
	jclass ClipData = getclassenv(env, "android/content/ClipData");
	jmethodID newPlainText = getmethodstaticenv(env, ClipData, "newPlainText", "(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;");
	uint8_t end0=buf[i1]; buf[i1]=0;
	jobject clip = callmethodstaticobjectenv(env, ClipData, newPlainText, NULL, getstringenv(env,(char*)buf+i0));
	buf[i1] = end0;

	//clipboardManager.setPrimaryClip(clip);
	jclass ClipboardManager = getclassobjectenv(env, clipboardManager);
	jmethodID setPrimaryClip = getmethodenv(env, ClipboardManager, "setPrimaryClip", "(Landroid/content/ClipData;)V");
	callmethodvoidenv(env, clipboardManager, setPrimaryClip, clip);
	(*activity->vm)->DetachCurrentThread(activity->vm);
}

void
copytext(size_t i0, size_t i1)
{
	ensurentext(i1);
	copybuf(i0, i1, text);
}

void
copysearch(size_t i0, size_t i1)
{
	ensurensearch(i1);
	copybuf(i0, i1, bufsearch);
}

void
copyselection(void)
{
	size_t i0,i1; geti01selection(&i0,&i1);
	if (curselect == 0) copytext(i0, i1);
	else if (curselect == 1) copysearch(i0, i1);
}

void
save(char *path)
{
	FILE *f = fopen(path, "w"); if (!f) { Perror("medcn: fopen"); exit(EXIT_FAILURE); }
	size_t iexp=0, itext=0;
	while (itext < ntext) {
		size_t itextexp = iexp<nilexps ? ilexps[iexp] : ntext;
		if (itext == itextexp) {
			size_t nbuf; uint8_t *buf;
			if (exps[iexp].norig) nbuf=exps[iexp].norig, buf=exps[iexp].orig;
			else getunexpanded(exps[iexp].n,text+itext,&nbuf,&buf);
			fwrite(buf, 1, nbuf, f); if (ferror(f)) { Perror("medcn: fwrite exp"); exit(EXIT_FAILURE); }
			exps[iexp].unsaved = 0;
			itext += exps[iexp++].n;
		} else {
			size_t n = itextexp - itext;
			fwrite(text+itext, 1, n, f); if (ferror(f)) { Perror("medcn: fwrite text"); exit(EXIT_FAILURE); }
			itext += n;
		}
	}
	fclose(f);
	vtextsaved = vtext;
}

void
writeto(size_t n, uint8_t *buf, const char *path)
{
	FILE *f=fopen(path,"w"); if (!f) {fprintf(stderr,"medcn: fopen writeto '%s': %s\n",path,strerror(errno));exit(EXIT_FAILURE);}
	fwrite(buf, n, 1, f);
	if (ferror(f) || fclose(f)) {fprintf(stderr,"medcn: fwrite/fclose writeto %zu '%s': %s\n",n,path,strerror(errno));exit(EXIT_FAILURE);}
}

void
destroytexturefont(void)
{
	vkDestroyImageView(device_, view, NULL);
	vkDestroySampler(device_, sampler, NULL);
	vkFreeMemory(device_, mem, NULL);
	vkDestroyImage(device_, imagetex, NULL);
	imagetex = VK_NULL_HANDLE;
}

void
expandcurline(void)
{
				
	// Get tok-relative cur position
	//TODO: 0 toks?
	size_t i0l = getiline(icur);
	size_t nl=1; while(i0l+nl<ntext&&text[i0l+nl-1]!='\n')nl++;
	struct token*toks; size_t ntoks; gettokens(i0l,i0l+nl-1,text,&ntoks,&toks);
	size_t itok; for(itok=0;itok+1<ntoks&&icur>toks[itok].i+toks[itok].n;itok++);
	size_t otok=icur<toks[itok].i?0:icur-toks[itok].i;
	if (otok > toks[itok].n) otok=toks[itok].n;
	free(toks);
	df("overexp itok%zu otok%zu", itok, otok);

	// Expand the line
	df("overexp expand");
	size_t ntext0 = ntext;
	expandi(i0l);
				
	// Set cur relative to tokens
	df("overexp set cur");
	gettokens(i0l, i0l+nl-1+(ntext-ntext0), text, &ntoks, &toks);
	icur = toks[itok].i + otok;
	df("icur new: %zu", icur);
	df("%.*s", strchr((char*)text+getiline(icur),'\n')-(char*)(text+getiline(icur)), text+getiline(icur));
	df("%.*s", icur-getiline(icur), text+getiline(icur));
	free(toks);
}

// Process the next main command.
void
handle_cmd(struct android_app* app, int32_t cmd)
{
	VkResult res;
	ensurekeyboardifneeded();
	
	// Handle command
	switch (cmd) {

	// Resume
	case APP_CMD_RESUME: {
		df("cmd resume");
		msensurekeyboard = getms() + 500;
		needsredraw = 1;
		break;
	}

	// Start
	case APP_CMD_START: {
		df("cmd start");
		break;
	}
		
	// Initialize
	case APP_CMD_INIT_WINDOW: {
		df("cmd init window");

		VkPhysicalDeviceMemoryProperties gpuMemoryProperties_;
		VkFormat displayFormat_=0;
		VkImageLayout imageLayout;
		int32_t tex_width;
		int32_t tex_height;
		//VkDescriptorSetLayout dscLayout_={0};
		
		// Initialize vulkan
		if (!InitVulkan()) {
			LOGW("Vulkan is unavailable, install vulkan and re-start");
			exit(EXIT_FAILURE);
		}
		df("initd vulkan");
		
		// Create vulkan device
		{
		
			// **********************************************************
			// Create the Vulkan instance
			//df("vkCreateInstance");
			if((res=vkCreateInstance(&(VkInstanceCreateInfo){
						.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO,
						.pNext = NULL,
						.pApplicationInfo = &(VkApplicationInfo){
								.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO,
								.pNext = NULL,
								.pApplicationName = "tutorial05_triangle_window",
								.applicationVersion = VK_MAKE_VERSION(1, 0, 0),
								.pEngineName = "tutorial",
								.engineVersion = VK_MAKE_VERSION(1, 0, 0),
								.apiVersion = VK_MAKE_VERSION(1, 0, 0)
						},
#if 1
						.enabledLayerCount = 1,
						.ppEnabledLayerNames = (const char*[1]){"VK_LAYER_KHRONOS_validation"},
						.enabledExtensionCount = 3,
						.ppEnabledExtensionNames = (const char*[3]){ "VK_KHR_surface", "VK_KHR_android_surface", "VK_EXT_debug_report"}
#else
						.enabledLayerCount = 0,
						.ppEnabledLayerNames = NULL,
						.enabledExtensionCount = 2,
						.ppEnabledExtensionNames = (const char*[2]){ "VK_KHR_surface", "VK_KHR_android_surface"}
#endif
					}, NULL, &instance_)) != VK_SUCCESS) { Fprintf(stderr,"medcn: vkCreateInstance: %d\n",res); exit(EXIT_FAILURE); }
			//df("vkCreateAndroidSurfaceKHR");
			if (res=vkCreateAndroidSurfaceKHR(instance_,
					&(VkAndroidSurfaceCreateInfoKHR){
					.sType = VK_STRUCTURE_TYPE_ANDROID_SURFACE_CREATE_INFO_KHR,
					.pNext = NULL,
					.flags = 0,
					.window = app->window}, NULL, &surface_)) { Fprintf(stderr,"medcn: vkCreateAndroidSurfaceKHR: %d\n",res); exit(EXIT_FAILURE); }
			//df("created dev and sur");

			// Find one GPU to use:
			// On Android, every GPU device is equal -- supporting
			// graphics/compute/present
			// for this sample, we use the very first GPU device found on the system
			uint32_t gpuCount = 0;
			//df("vkEnumeratePhysicalDevices");
			if (res=vkEnumeratePhysicalDevices(instance_, &gpuCount, NULL)) { Fprintf(stderr,"medcn: vkEnumeratePhysicalDevices: %d\n",res); exit(EXIT_FAILURE); }
			VkPhysicalDevice tmpGpus[gpuCount];
			//df("vkEnumeratePhysicalDevices");
			if (res=vkEnumeratePhysicalDevices(instance_, &gpuCount, tmpGpus)) { Fprintf(stderr,"medcn: vkEnumeratePhysicalDevices: %d\n",res); exit(EXIT_FAILURE); }
			gpuDevice_ = tmpGpus[0];	// Pick up the first GPU Device
			vkGetPhysicalDeviceMemoryProperties(gpuDevice_, &gpuMemoryProperties_);
		
			// Find a GFX queue family
			uint32_t queueFamilyCount;
			vkGetPhysicalDeviceQueueFamilyProperties(gpuDevice_, &queueFamilyCount, NULL);
			assert(queueFamilyCount);
			VkQueueFamilyProperties queueFamilyProperties[queueFamilyCount];
			vkGetPhysicalDeviceQueueFamilyProperties(gpuDevice_, &queueFamilyCount, queueFamilyProperties);
			uint32_t queueFamilyIndex;
			for (queueFamilyIndex = 0; queueFamilyIndex < queueFamilyCount;
					 queueFamilyIndex++) {
				if (queueFamilyProperties[queueFamilyIndex].queueFlags &
						VK_QUEUE_GRAPHICS_BIT) {
					break;
				}
			}
			assert(queueFamilyIndex < queueFamilyCount);
			queueFamilyIndex_ = queueFamilyIndex;

			// Create a logical device (vulkan device)
			float priorities[] = {
					1.0f,
			};
			//df("vkCreateDevice");
			if (res=vkCreateDevice(gpuDevice_,
				&(VkDeviceCreateInfo){
					.sType = VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO,
					.pNext = NULL,
					.queueCreateInfoCount = 1,
					.pQueueCreateInfos =
					&(VkDeviceQueueCreateInfo){
						.sType = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO,
						.pNext = NULL,
						.flags = 0,
						.queueFamilyIndex = queueFamilyIndex_,
						.queueCount = 1,
						.pQueuePriorities = priorities,
					},
					.enabledLayerCount = 0,
					.ppEnabledLayerNames = NULL,
					.enabledExtensionCount = 1,
					.ppEnabledExtensionNames = (const char*[1]){"VK_KHR_swapchain"},
					.pEnabledFeatures = NULL,
				}, NULL, &device_)) { Fprintf(stderr,"medcn: vkCreateDevice: %d\n",res); exit(EXIT_FAILURE); }
			vkGetDeviceQueue(device_, 0, 0, &queue_);
		}
		//df("made dev");

#if 1
		//if (!vkCreateDebugReportCallbackEXT && !(vkCreateDebugReportCallbackEXT=(PFN_vkCreateDebugReportCallbackEXT)vkGetInstanceProcAddr(instance_, "vkCreateDebugReportCallbackEXT"))) { Fprintf(stderr,"no FF debug report\n"); exit(EXIT_FAILURE); }
		if (!(vkCreateDebugReportCallbackEXT=(PFN_vkCreateDebugReportCallbackEXT)vkGetInstanceProcAddr(instance_, "vkCreateDebugReportCallbackEXT"))) { Fprintf(stderr,"no FF debug report\n"); exit(EXIT_FAILURE); }
   vkCreateDebugReportCallbackEXT (instance_,
			&(VkDebugReportCallbackCreateInfoEXT){
				.sType = VK_STRUCTURE_TYPE_DEBUG_REPORT_CALLBACK_CREATE_INFO_EXT,
				.pNext = NULL,
				.flags = VK_DEBUG_REPORT_ERROR_BIT_EXT
					| VK_DEBUG_REPORT_WARNING_BIT_EXT,
				.pfnCallback = DebugReportCallback,
				.pUserData = NULL
			}, NULL, &debugUtilsMessenger);
#endif
		
		// Make swapchain
		{
			//LOGI("->createSwapChain");
		
			// **********************************************************
			// Get the surface capabilities because:
			//	 - It contains the minimal and max length of the chain, we will need it
			//	 - It's necessary to query the supported surface format (R8G8B8A8 for
			//	 instance ...)
			VkSurfaceCapabilitiesKHR surfaceCapabilities;
			vkGetPhysicalDeviceSurfaceCapabilitiesKHR(gpuDevice_, surface_, &surfaceCapabilities);

			// Query the list of supported surface format and choose one we like
			uint32_t formatCount = 0;
			vkGetPhysicalDeviceSurfaceFormatsKHR(gpuDevice_, surface_, &formatCount, NULL);
			VkSurfaceFormatKHR* formats = calloc(formatCount, sizeof(VkSurfaceFormatKHR)); if (!formats) { Perror("medcn: calloc formats"); exit(EXIT_FAILURE); }
			vkGetPhysicalDeviceSurfaceFormatsKHR(gpuDevice_, surface_, &formatCount, formats);
			//LOGI("Got %d formats", formatCount);
			uint32_t chosenFormat;
			for (chosenFormat = 0; chosenFormat < formatCount; chosenFormat++) {
				if (formats[chosenFormat].format == VK_FORMAT_R8G8B8A8_UNORM) break;
			}
			assert(chosenFormat < formatCount);
			displaySize_ = surfaceCapabilities.currentExtent;
			df("displaySize_ %"PRIu32",%"PRIu32, displaySize_.width, displaySize_.height);
			displayFormat_ = formats[chosenFormat].format;
		
			// **********************************************************
			// Create a swap chain (here we choose the minimum available number of surface
			// in the chain)
			if (res=vkCreateSwapchainKHR(device_,
					&(VkSwapchainCreateInfoKHR){
						.compositeAlpha = VK_COMPOSITE_ALPHA_INHERIT_BIT_KHR,
						.sType = VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR,
						.pNext = NULL,
						.surface = surface_,
						.minImageCount = surfaceCapabilities.minImageCount,
						.imageFormat = formats[chosenFormat].format,
						.imageColorSpace = formats[chosenFormat].colorSpace,
						.imageExtent = surfaceCapabilities.currentExtent,
						.imageArrayLayers = 1,
						.imageUsage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT,
						.imageSharingMode = VK_SHARING_MODE_EXCLUSIVE,
						.queueFamilyIndexCount = 1,
						.pQueueFamilyIndices = &queueFamilyIndex_,
						.preTransform = VK_SURFACE_TRANSFORM_IDENTITY_BIT_KHR,
						.presentMode = VK_PRESENT_MODE_FIFO_KHR,
						.clipped = VK_FALSE,
						.oldSwapchain = VK_NULL_HANDLE
					}, NULL, &swapchain_)) { Fprintf(stderr,"medcn: vkCreateSwapchainKHR: %d\n",res); exit(EXIT_FAILURE); }
		
			// Get the length of the created swap chain
			if (res=vkGetSwapchainImagesKHR(device_, swapchain_, &swapchainLength_, NULL)) { Fprintf(stderr,"medcn: vkGetSwapchainImagesKHR: %d\n",res); exit(EXIT_FAILURE); }
			free(formats);
			//LOGI("<-createSwapChain");
		}
			//df("made sc");
		
		// Create render pass
		if (res=vkCreateRenderPass(device_,
			&(VkRenderPassCreateInfo){
				.sType = VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO,
				.pNext = NULL,
				.attachmentCount = 1,
				.pAttachments = &(VkAttachmentDescription){
					.format = displayFormat_,
					.samples = VK_SAMPLE_COUNT_1_BIT,
					.loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR,
					.storeOp = VK_ATTACHMENT_STORE_OP_STORE,
					.stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE,
					.stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE,
					.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED,
					.finalLayout = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR
				},
				.subpassCount = 1,
				.pSubpasses = &(VkSubpassDescription){
					.flags = 0,
					.pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS,
					.inputAttachmentCount = 0,
					.pInputAttachments = NULL,
					.colorAttachmentCount = 1,
					.pColorAttachments = &(VkAttachmentReference){
						.attachment = 0,
						.layout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL
					},
					.pResolveAttachments = NULL,
					.pDepthStencilAttachment = NULL,
					.preserveAttachmentCount = 0,
					.pPreserveAttachments = NULL
				},
				.dependencyCount = 0,
				.pDependencies = NULL
			}, NULL, &renderPass_)) { Fprintf(stderr,"medcn: vkCreateRenderPass: %d\n",res); exit(EXIT_FAILURE); }
		//df("created render pass");
		
		// Create framebuffers
		{
			VkImageView depthView = VK_NULL_HANDLE;

			// query display attachment to swapchain
			uint32_t SwapchainImagesCount = 0;
			if (res=vkGetSwapchainImagesKHR(device_, swapchain_, &SwapchainImagesCount, NULL)) { Fprintf(stderr,"medcn: vkGetSwapchainImagesKHR: %d\n",res); exit(EXIT_FAILURE); }
			//df("SwapchainImagesCount %"PRIu32, SwapchainImagesCount);
			displayImages_ = calloc(SwapchainImagesCount, sizeof(VkImage)); if (!displayImages_) { Perror("medcn: calloc displayImages_"); exit(EXIT_FAILURE); }
			if (res=vkGetSwapchainImagesKHR(device_, swapchain_,
																			&SwapchainImagesCount,
																			displayImages_)) { Fprintf(stderr,"medcn: vkGetSwapchainImagesKHR: %d\n",res); exit(EXIT_FAILURE); }
		
			// create image view for each swapchain image
			displayViews_ = calloc(SwapchainImagesCount, sizeof(VkImageView)); if (!displayViews_) { Perror("medcn: calloc displayViews_"); exit(EXIT_FAILURE); }
			for (uint32_t i = 0; i < SwapchainImagesCount; i++) {
				if (res=vkCreateImageView(device_,
						&(VkImageViewCreateInfo){
						.sType = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO,
						.pNext = NULL,
						.flags = 0,
						.image = displayImages_[i],
						.viewType = VK_IMAGE_VIEW_TYPE_2D,
						.format = displayFormat_,
						.components =
								{
										.r = VK_COMPONENT_SWIZZLE_R,
										.g = VK_COMPONENT_SWIZZLE_G,
										.b = VK_COMPONENT_SWIZZLE_B,
										.a = VK_COMPONENT_SWIZZLE_A
								},
						.subresourceRange =
								{
										.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT,
										.baseMipLevel = 0,
										.levelCount = 1,
										.baseArrayLayer = 0,
										.layerCount = 1
								}
				}, NULL, &displayViews_[i])) { Fprintf(stderr,"medcn: vkCreateImageView: %d\n",res); exit(EXIT_FAILURE); }
			}
		
			// create a framebuffer from each swapchain image
			framebuffers_ = calloc(swapchainLength_, sizeof(VkFramebuffer)); if (!framebuffers_) { Perror("medcn: calloc framebuffers_"); exit(EXIT_FAILURE); }
			for (uint32_t i = 0; i < swapchainLength_; i++) {
				VkFramebufferCreateInfo fbCreateInfo = {
						.sType = VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO,
						.pNext = NULL,
						.renderPass = renderPass_,
						.attachmentCount = 1,	// 2 if using depth
						.pAttachments = (VkImageView[2]){
							displayViews_[i], depthView,
						},
						.width = (displaySize_.width),
						.height = (displaySize_.height),
						.layers = 1,
				};
				fbCreateInfo.attachmentCount = (depthView == VK_NULL_HANDLE ? 1 : 2);
				if (res=vkCreateFramebuffer(device_, &fbCreateInfo, NULL, &framebuffers_[i])) { Fprintf(stderr,"medcn: vkCreateFramebuffer: %d\n",res); exit(EXIT_FAILURE); }
			}
		}

		// Make pipelines
		makepipeline(app, &layout_, &pipeline_, &cache_, sizeof(bufshaderverttext), bufshaderverttext, sizeof(bufshaderfragtext), bufshaderfragtext, sizeof(struct vtext), sizevertstext, &vertexBuf_, &deviceMemory,
			3, VK_FORMAT_R32G32_SFLOAT, 0,
				VK_FORMAT_R32_UINT, offsetof(struct vtext,syn),
				VK_FORMAT_R32G32_SFLOAT, offsetof(struct vtext,u),
			1, &descpooltext, &descsettext);
		makepipeline(app, &layoutblks, &pipelineblks, &pipelinecacheblks, sizeof(bufshadervertblks), bufshadervertblks, sizeof(bufshaderfragblks), bufshaderfragblks, sizeof(struct vblks), sizevertsblks, &vbufblks, &memvbufblks,
			2, VK_FORMAT_R32G32_SFLOAT, 0,
				VK_FORMAT_R32_UINT, offsetof(struct vblks,color),
			0);
		makepipeline(app, &layoutund, &pipelineund, &pipelinecacheund, sizeof(bufshadervertund), bufshadervertund, sizeof(bufshaderfragund), bufshaderfragund, sizeof(struct vund), sizevertsund, &vbufund, &memvbufund,
			1, VK_FORMAT_R32G32_SFLOAT, 0,
			0);
		makepipeline(app, &layoutcur, &pipelinecur, &pipelinecachecur, sizeof(bufshadervertcur), bufshadervertcur, sizeof(bufshaderfragcur), bufshaderfragcur, sizeof(struct vcur), sizevertscur, &vbufcur, &memvbufcur, 
			1, VK_FORMAT_R32G32_SFLOAT, 0,
			0);
		makepipeline(app, &layouttextov, &pipelinetextov, &pipelinecachetextov, sizeof(bufshaderverttextov), bufshaderverttextov, sizeof(bufshaderfragtextov), bufshaderfragtextov, sizeof(struct vtextov), sizevertstextov, &vbuftextov, &memvbuftextov, 
			2, VK_FORMAT_R32G32_SFLOAT, 0,
				VK_FORMAT_R32G32_SFLOAT, offsetof(struct vtextov,u),
			1, &descpooltextov, &descsettextov);
		makepipeline(app, &layoutbackov, &pipelinebackov, &pipelinecachebackov, sizeof(bufshadervertbackov), bufshadervertbackov, sizeof(bufshaderfragbackov), bufshaderfragbackov, sizeof(struct vbackov), sizevertsbackov, &vbufbackov, &memvbufbackov,
			1, VK_FORMAT_R32G32_SFLOAT, 0,
			0);
		makepipeline(app, &layoutbtnov, &pipelinebtnov, &pipelinecachebtnov, sizeof(bufshadervertbtnov), bufshadervertbtnov, sizeof(bufshaderfragbtnov), bufshaderfragbtnov, sizeof(struct vbtnov), sizevertsbtnov, &vbufbtnov, &memvbufbtnov,
			2, VK_FORMAT_R32G32_SFLOAT, 0,
				VK_FORMAT_R32G32_SFLOAT, offsetof(struct vbtnov,xopp),
			0);
		makepipeline(app, &layoutexp, &pipelineexp, &pipelinecacheexp, sizeof(bufshadervertexp), bufshadervertexp, sizeof(bufshaderfragexp), bufshaderfragexp, sizeof(struct vexp), sizevertsexp, &vbufexp, &memvbufexp,
			3, VK_FORMAT_R32G32_SFLOAT, 0,
				VK_FORMAT_R32G32_SFLOAT, offsetof(struct vexp,xp),
				VK_FORMAT_R32_UINT, offsetof(struct vexp,borderud),
			0);
		makepipeline(app, &layoutselect, &pipelineselect, &pipelinecacheselect, sizeof(bufshadervertselect), bufshadervertselect, sizeof(bufshaderfragselect), bufshaderfragselect, sizeof(struct vselect), sizevertsselect, &vbufselect, &memvbufselect,
			1, VK_FORMAT_R32G32_SFLOAT, 0,
			0);
		makepipeline(app, &layouttextkb, &pipelinetextkb, &pipelinecachetextkb, sizeof(bufshaderverttextkb), bufshaderverttextkb, sizeof(bufshaderfragtextkb), bufshaderfragtextkb, sizeof(struct vtextkb), sizevertstextkb, &vbuftextkb, &memvbuftextkb, 
			2, VK_FORMAT_R32G32_SFLOAT, 0,
				VK_FORMAT_R32G32_SFLOAT, offsetof(struct vtextkb,u),
			1, &descpooltextkb, &descsettextkb);
		makepipeline(app, &layoutbackkb, &pipelinebackkb, &pipelinecachebackkb, sizeof(bufshadervertbackkb), bufshadervertbackkb, sizeof(bufshaderfragbackkb), bufshaderfragbackkb, sizeof(struct vbackkb), sizevertsbackkb, &vbufbackkb, &memvbufbackkb,
			1, VK_FORMAT_R32G32_SFLOAT, 0,
			0);
		makepipeline(app, &layoutbtnkb, &pipelinebtnkb, &pipelinecachebtnkb, sizeof(bufshadervertbtnkb), bufshadervertbtnkb, sizeof(bufshaderfragbtnkb), bufshaderfragbtnkb, sizeof(struct vbtnkb), sizevertsbtnkb, &vbufbtnkb, &memvbufbtnkb,
			2, VK_FORMAT_R32G32_SFLOAT, 0,
				VK_FORMAT_R32G32_SFLOAT, offsetof(struct vbtnkb,xopp),
			0);
		makepipeline(app, &layoutflow, &pipelineflow, &pipelinecacheflow, sizeof(bufshadervertflow), bufshadervertflow, sizeof(bufshaderfragflow), bufshaderfragflow, sizeof(struct vflow), sizevertsflow, &vbufflow, &memvbufflow,
			3, VK_FORMAT_R32G32_SFLOAT, 0,
				VK_FORMAT_R32G32_SFLOAT, offsetof(struct vflow,xp),
				VK_FORMAT_R32_UINT, offsetof(struct vflow,borderud),
			0);
		//df("made pipelines");

#if 0
		goblk(attopblk(), HEIGHT|VERTS|WIDTH, (double)displaySize_.height, (double)displaySize_.width);
		df("went: nvt%zu nvb%zu", nvertstext, nvertsblks);

		// Update text vertices
		size_t sizecopy = nvertstext * sizeof(struct vtext);
		void* data;
		if (res=vkMapMemory(device_, deviceMemory, 0, sizecopy, 0, &data)) { Fprintf(stderr,"medcn: vkMapMemory text: %d\n",res); exit(EXIT_FAILURE); }
		memcpy(data, vertstext, sizecopy);
		vkUnmapMemory(device_, deviceMemory);

		// Update blks vertices
		sizecopy = nvertsblks * sizeof(struct vblks);
		if (res=vkMapMemory(device_, memvbufblks, 0, sizecopy, 0, &data)) { Fprintf(stderr,"medcn: vkMapMemory blks: %d\n",res); exit(EXIT_FAILURE); }
		memcpy(data, vertsblks, sizecopy);
		vkUnmapMemory(device_, memvbufblks);
#endif
		
		// Create a pool of command buffers to allocate command buffer from
		if (res=vkCreateCommandPool(device_,
				&(VkCommandPoolCreateInfo){
				.sType = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO,
				.pNext = NULL,
				.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT,
				.queueFamilyIndex = 0
			}, NULL, &cmdPool_)) { Fprintf(stderr,"medcn: vkCreateCommandPool: %d\n",res); exit(EXIT_FAILURE); }
		
		// Record a command buffer that just clear the screen
		// 1 command buffer draw in 1 framebuffer
		// In our case we need 2 command as we have 2 framebuffer
		cmdBufferLen_ = swapchainLength_;
		cmdBuffer_ = calloc(swapchainLength_, sizeof(VkCommandBuffer)); if (!cmdBuffer_) { Perror("medcn: calloc cmdBuffer_"); exit(EXIT_FAILURE); }
		if (res=vkAllocateCommandBuffers(device_,
			&(VkCommandBufferAllocateInfo){
				.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO,
				.pNext = NULL,
				.commandPool = cmdPool_,
				.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY,
				.commandBufferCount = cmdBufferLen_
			}, cmdBuffer_)) { Fprintf(stderr,"medcn: vkAllocateCommandBuffers: %d\n",res); exit(EXIT_FAILURE); }
		//df("made everything");
#if 0
		for (int bufferIndex = 0; bufferIndex < swapchainLength_; bufferIndex++) {

			// We start by creating and declare the "beginning" our command buffer
			if (res=vkBeginCommandBuffer(cmdBuffer_[bufferIndex],
				&(VkCommandBufferBeginInfo){
					.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO,
					.pNext = NULL,
					.flags = 0,
					.pInheritanceInfo = NULL
				})) { Fprintf(stderr,"medcn: vkBeginCommandBuffer: %d\n",res); exit(EXIT_FAILURE); }
		
			// transition the buffer into color attachment
			df("setImageLayout %d", __LINE__);
			setImageLayout(cmdBuffer_[bufferIndex],
										 displayImages_[bufferIndex],
										 //VK_IMAGE_LAYOUT_PRESENT_SRC_KHR,
										 VK_IMAGE_LAYOUT_UNDEFINED,
										 VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL,
										 VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,
										 VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT);
		
			// Now we start a renderpass. Any draw command has to be recorded in a
			// renderpass
			df("vkCmdBeginRenderPass %d", __LINE__);
			vkCmdBeginRenderPass(cmdBuffer_[bufferIndex],
				&(VkRenderPassBeginInfo){
					.sType = VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO,
					.pNext = NULL,
					.renderPass = renderPass_,
					.framebuffer = framebuffers_[bufferIndex],
					.renderArea = {.offset =
														 {
																 .x = 0, .y = 0
														 },
												 .extent = displaySize_},
					.clearValueCount = 1,
					.pClearValues = &(VkClearValue){ .color = { .float32 = { 0.0f, 0.0f, 0.0f, 1.0f}},
				}}, VK_SUBPASS_CONTENTS_INLINE);

			// Draw blocks
			{
				vkCmdBindPipeline(cmdBuffer_[bufferIndex], VK_PIPELINE_BIND_POINT_GRAPHICS, pipelineblks);
				//vkCmdBindDescriptorSets(cmdBuffer_[bufferIndex], VK_PIPELINE_BIND_POINT_GRAPHICS, layoutblks, 0, 1, &descSetblks, 0, NULL);
				VkDeviceSize offset = 0;
				vkCmdBindVertexBuffers(cmdBuffer_[bufferIndex], 0, 1, &vbufblks, &offset);
				vkCmdPushConstants(cmdBuffer_[bufferIndex], layoutblks, VK_SHADER_STAGE_VERTEX_BIT, 0, sizeof(float)*2, (float[2]){(double)displaySize_.width/2,(double)displaySize_.height/-2});
				vkCmdDraw(cmdBuffer_[bufferIndex], nvertsblks, 1, 0, 0);
			}

			// Draw text
			{
				vkCmdBindPipeline(cmdBuffer_[bufferIndex], VK_PIPELINE_BIND_POINT_GRAPHICS, pipeline_);
				vkCmdBindDescriptorSets( cmdBuffer_[bufferIndex], VK_PIPELINE_BIND_POINT_GRAPHICS, layout_, 0, 1, &descSet_, 0, NULL);
				VkDeviceSize offset = 0;
				vkCmdBindVertexBuffers(cmdBuffer_[bufferIndex], 0, 1, &vertexBuf_, &offset);
				vkCmdPushConstants(cmdBuffer_[bufferIndex], layout_, VK_SHADER_STAGE_VERTEX_BIT, 0, sizeof(float)*2, (float[2]){(double)displaySize_.width/2,(double)displaySize_.height/-2});
				vkCmdDraw(cmdBuffer_[bufferIndex], nvertstext, 1, 0, 0);
			}
			
			vkCmdEndRenderPass(cmdBuffer_[bufferIndex]);
			df("vkEndCommandBuffer %d", __LINE__);
			if (res=vkEndCommandBuffer(cmdBuffer_[bufferIndex])) { Fprintf(stderr,"medcn: vkEndCommandBuffer: %d\n",res); exit(EXIT_FAILURE); }
		}
		df("drew");
#endif
		
		// We need to create a fence to be able, in the main loop, to wait for our
		// draw command(s) to finish before swapping the framebuffers
		if (res=vkCreateFence(device_,
				&(VkFenceCreateInfo){
				.sType = VK_STRUCTURE_TYPE_FENCE_CREATE_INFO,
				.pNext = NULL,
				.flags = 0
		}, NULL, &fence_)) { Fprintf(stderr,"medcn: vkCreateFence: %d\n",res); exit(EXIT_FAILURE); }
		
		// We need to create a semaphore to be able to wait, in the main loop, for our
		// framebuffer to be available for us before drawing.
		if (res=vkCreateSemaphore(device_,
				&(VkSemaphoreCreateInfo){
				.sType = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO,
				.pNext = NULL,
				.flags = 0
		}, NULL, &semaphore_)) { Fprintf(stderr,"medcn: vkCreateSemaphore: %d\n",res); exit(EXIT_FAILURE); }
		//df("fence and sems");
		initialized_ = true;
		needsredraw=1, overlayverted=-1;
		break;
	}
			
	// The window is being hidden or closed, clean it up.
	case APP_CMD_TERM_WINDOW: {
		df("term window");
		//exit(EXIT_FAILURE);
		vkFreeCommandBuffers(device_, cmdPool_, cmdBufferLen_, cmdBuffer_);
		free(cmdBuffer_);
		vkDestroyCommandPool(device_, cmdPool_, NULL);
		vkDestroyRenderPass(device_, renderPass_, NULL);
		for (int i = 0; i < swapchainLength_; i++) {
			vkDestroyFramebuffer(device_, framebuffers_[i], NULL);
			vkDestroyImageView(device_, displayViews_[i], NULL);
		}
		free(framebuffers_);
		free(displayViews_);
		free(displayImages_);
		vkDestroySwapchainKHR(device_, swapchain_, NULL);
		if (pipeline_ == VK_NULL_HANDLE) return;
		//vkDestroyPipeline(device_, pipeline_, NULL);
		//vkDestroyPipelineCache(device_, cache_, NULL);
		//vkFreeDescriptorSets(device_, descPool_, 1, &descSet_);
		//vkDestroyPipelineLayout(device_, layout_, NULL);
		//vkDestroyBuffer(device_, vertexBuf_, NULL);
		for (VkDescriptorSetLayout *p=desclayouts; p!=desclayoutnext; p++) vkDestroyDescriptorSetLayout(device_,*p,NULL);
		desclayoutnext = desclayouts;
/* GEN
exec 2>&1
<c/AndroidMain.c sed -n '/^\/\/ Pipelines/,/size_t/p' | sed '1d;$d' | while read type vars; do
	case $type in
		VkPipelineLayout) for var in $vars; do <<! cat; done;;
		vkDestroyPipelineLayout(device_, ${var%?}, NULL);
!
		VkPipeline) for var in $vars; do <<! cat; done;;
		vkDestroyPipeline(device_, ${var%?}, NULL);
!
		VkPipelineCache) for var in $vars; do <<! cat; done;;
		vkDestroyPipelineCache(device_, ${var%?}, NULL);
!
		VkBuffer) for var in $vars; do <<! cat; done;;
		vkDestroyBuffer(device_, ${var%?}, NULL);
!
		VkDeviceMemory) for var in $vars; do <<! cat; done;;
		vkFreeMemory(device_, ${var%?}, NULL);
!
		VkDescriptorSet) for var in $vars; do <<! cat; done;;
		//vkFreeDescriptorSets(device_, $(echo ${var%?} | sed 's,set,pool,'), 1, &${var%?});
!
		VkDescriptorPool) for var in $vars; do <<! cat; done;;
		vkDestroyDescriptorPool(device_, ${var%?}, NULL);
!
	esac
done
*/
		vkDestroyPipelineLayout(device_, layout_, NULL);
		vkDestroyPipelineLayout(device_, layoutblks, NULL);
		vkDestroyPipelineLayout(device_, layoutcur, NULL);
		vkDestroyPipelineLayout(device_, layouttextov, NULL);
		vkDestroyPipelineLayout(device_, layoutbackov, NULL);
		vkDestroyPipelineLayout(device_, layoutbtnov, NULL);
		vkDestroyPipelineLayout(device_, layoutexp, NULL);
		vkDestroyPipelineLayout(device_, layoutselect, NULL);
		vkDestroyPipelineLayout(device_, layoutbtnkb, NULL);
		vkDestroyPipelineLayout(device_, layouttextkb, NULL);
		vkDestroyPipelineLayout(device_, layoutbackkb, NULL);
		vkDestroyPipelineLayout(device_, layoutflow, NULL);
		vkDestroyPipelineLayout(device_, layoutund, NULL);
		vkDestroyPipeline(device_, pipeline_, NULL);
		vkDestroyPipeline(device_, pipelineblks, NULL);
		vkDestroyPipeline(device_, pipelinecur, NULL);
		vkDestroyPipeline(device_, pipelinetextov, NULL);
		vkDestroyPipeline(device_, pipelinebackov, NULL);
		vkDestroyPipeline(device_, pipelinebtnov, NULL);
		vkDestroyPipeline(device_, pipelineexp, NULL);
		vkDestroyPipeline(device_, pipelineselect, NULL);
		vkDestroyPipeline(device_, pipelinebtnkb, NULL);
		vkDestroyPipeline(device_, pipelinetextkb, NULL);
		vkDestroyPipeline(device_, pipelinebackkb, NULL);
		vkDestroyPipeline(device_, pipelineflow, NULL);
		vkDestroyPipeline(device_, pipelineund, NULL);
		vkDestroyPipelineCache(device_, cache_, NULL);
		vkDestroyPipelineCache(device_, pipelinecacheblks, NULL);
		vkDestroyPipelineCache(device_, pipelinecachecur, NULL);
		vkDestroyPipelineCache(device_, pipelinecachetextov, NULL);
		vkDestroyPipelineCache(device_, pipelinecachebackov, NULL);
		vkDestroyPipelineCache(device_, pipelinecachebtnov, NULL);
		vkDestroyPipelineCache(device_, pipelinecacheexp, NULL);
		vkDestroyPipelineCache(device_, pipelinecacheselect, NULL);
		vkDestroyPipelineCache(device_, pipelinecachebtnkb, NULL);
		vkDestroyPipelineCache(device_, pipelinecachetextkb, NULL);
		vkDestroyPipelineCache(device_, pipelinecachebackkb, NULL);
		vkDestroyPipelineCache(device_, pipelinecacheflow, NULL);
		vkDestroyPipelineCache(device_, pipelinecacheund, NULL);
		vkDestroyBuffer(device_, vertexBuf_, NULL);
		vkDestroyBuffer(device_, vbufblks, NULL);
		vkDestroyBuffer(device_, vbufcur, NULL);
		vkDestroyBuffer(device_, vbuftextov, NULL);
		vkDestroyBuffer(device_, vbufbackov, NULL);
		vkDestroyBuffer(device_, vbufbtnov, NULL);
		vkDestroyBuffer(device_, vbufexp, NULL);
		vkDestroyBuffer(device_, vbufselect, NULL);
		vkDestroyBuffer(device_, vbufbtnkb, NULL);
		vkDestroyBuffer(device_, vbuftextkb, NULL);
		vkDestroyBuffer(device_, vbufbackkb, NULL);
		vkDestroyBuffer(device_, vbufflow, NULL);
		vkDestroyBuffer(device_, vbufund, NULL);
		vkFreeMemory(device_, deviceMemory, NULL);
		vkFreeMemory(device_, memvbufblks, NULL);
		vkFreeMemory(device_, memvbufcur, NULL);
		vkFreeMemory(device_, memvbuftextov, NULL);
		vkFreeMemory(device_, memvbufbackov, NULL);
		vkFreeMemory(device_, memvbufbtnov, NULL);
		vkFreeMemory(device_, memvbufexp, NULL);
		vkFreeMemory(device_, memvbufselect, NULL);
		vkFreeMemory(device_, memvbufbtnkb, NULL);
		vkFreeMemory(device_, memvbuftextkb, NULL);
		vkFreeMemory(device_, memvbufbackkb, NULL);
		vkFreeMemory(device_, memvbufflow, NULL);
		vkFreeMemory(device_, memvbufund, NULL);
		//vkFreeDescriptorSets(device_, descpooltext, 1, &descsettext);
		//vkFreeDescriptorSets(device_, descpooltextov, 1, &descsettextov);
		//vkFreeDescriptorSets(device_, descpooltextkb, 1, &descsettextkb);
		vkDestroyDescriptorPool(device_, descpooltext, NULL);
		vkDestroyDescriptorPool(device_, descpooltextov, NULL);
		vkDestroyDescriptorPool(device_, descpooltextkb, NULL);
//ENDGEN
		//vkDestroyDescriptorPool(device_, descPool_, NULL);
		vkDestroySemaphore(device_, semaphore_, NULL);
		vkDestroyFence(device_, fence_, NULL);
		destroytexturefont();
		sizeimagetex = nglyphstex = 0;
		vkDestroySurfaceKHR(instance_, surface_, NULL);
		vkDestroyDevice(device_, NULL);
		if (!(vkDestroyDebugReportCallbackEXT=(PFN_vkDestroyDebugReportCallbackEXT)vkGetInstanceProcAddr(instance_, "vkDestroyDebugReportCallbackEXT"))) { Fprintf(stderr,"no FF debug report\n"); exit(EXIT_FAILURE); }
		vkDestroyDebugReportCallbackEXT(instance_, debugUtilsMessenger, NULL);
		vkDestroyInstance(instance_, NULL);
		initialized_ = false;
		break;
	}
	
	// Typing
	case APP_CMD_TYPE: {
		df("%.3f: type %zu %.*s", et(getns()), app->ntype, app->ntype, app->buftype);
		int err=pthread_mutex_lock(&app->mutex); if (err) {fprintf(stderr,"medcn: pthread_mutex_lock type: %d\n",err);exit(EXIT_FAILURE);}
		static uint8_t *buftype = NULL;
		static size_t sizetype = 0;
		if (sizetype<app->ntype && !(buftype=realloc(buftype,sizetype=app->ntype))) {perror("medcn: realloc buftype");exit(EXIT_FAILURE);}
		memcpy(buftype, app->buftype, app->ntype);
		size_t ntype = app->ntype;
		app->ntype = 0;
		if (err=pthread_mutex_unlock(&app->mutex)) {fprintf(stderr,"medcn: pthread_mutex_unlock typing: %d\n",err);exit(EXIT_FAILURE);}
		if (!ntype) break;
		char justbraced0 = justbraced;
		justbraced=0, phasecur=getms()%1000;
		uint8_t c = buftype[ntype-1];
		if (icur==SIZE_MAX && !nmulti) break;
		ilspaced=SIZE_MAX;
		
		// Set as having typed from start
		istypedwordfromstart = !cur && (istypedwordfromstart||!icur||!isalnum_(text[icur-1]));
		
		// Delete the selection
		if (inamemkfn == SIZE_MAX) deleteselection();
		
		// In multi cursor mode
		if (cur==0 && nmulti) {
			scrollcurinview();
			
			// Type into each cursor
			idchainundo++;
			for (struct multicur *m=multis; m<multis+nmulti; m++) {
				insert(m->i, ntype, buftype);
				m->i += ntype;
			}
			idchainundo++;
			flowmulti();
			needsredraw=1;
		
		// In text
		} else if (cur == 0) {

			// No cursor
			if (icur==SIZE_MAX/* || !curshown*/) break;
			scrollcurinview();
			if (overlay==OVCOPIED || overlay==OVUNDID || overlay==OVJOINED) overlay=0;
			
			// Set renaming
			setwordrenaming(icur);
					
			// Insert with cur at graph start
			//size_t icur0 = icur;
			//gocurcombined(c);
			//insert(icur0, 1, &c);
			insert(icur, ntype, buftype);
			
			// Delete } line if not newline
			if (justbraced0 && c!='\n') {
				size_t i1 = getilinenext(icur+1+ntype);
				backspace(i1, i1-(icur+1+ntype));
			}

			// Indent newline
			ssize_t ntyped = ntype;
			if (ntype==1 && c=='\n') {
				
				// Skip if function definition
				for (size_t i=getiline(icur); i<icur; i++) {
					if (text[i]=='(' && i && text[i-1]!='\n') goto noindentnewline;
					if (!isalnum(text[i]) && text[i]!='_') break;
				}
				
				// Indent if ){(
				ssize_t nsp=0, i=icur-1;
				while (i>=0 && text[i]!='\n') nsp=isspace(text[i--])?nsp+1:0;
				insert(icur+1,nsp,text+(i+1)); ntyped+=nsp;
				if (icur && strchr("){(",text[icur-1]) && !isintoken(icur-1)) insert(icur+ntyped++,1,(uint8_t*)"\t");
			} noindentnewline:;

			// Update cursor
			struct atblk pos0 = atcurblk();
			pos0.row = 0;
			struct at pos1 = go((at){.x=pos0.x,.y=pos0.y,.i=pos0.i}, DBYTES|WIDTH, ntyped, (double)displaySize_.width);
			icur += ntyped;
			needsredrawcur=1, xcolud=INFINITY;

			// If it overflowed, expand
			if (c!='\n' && pos1.row) {
				df("overflow expand");
				expandcurline();

				// Re-add space
				if (c==' '/* && colcur<widthterm*/) {
					insert(icur, 1, (uint8_t*)" ");
					icur++;
				}
			}
					
			// If it was a brace, add matching close
			if (c=='{' && text[icur]=='\n') {
				
				// Skip if next non-comment is a different
				// indent or not }, add }
				size_t inoncmt = getinoncmt(icur+1);
				size_t il = getiline(icur);
				size_t nindent = getnindent(il);
				if (inoncmt<ntext && text[inoncmt]=='}' && getnindent(getiline(inoncmt))==nindent) goto noaddclose;
				
				// Skip if in a comment, ', or "
				if (isintoken(icur-1)) goto noaddclose;
				
				// Insert } line
				insert(icur, 1, (uint8_t*)"\n");
				insert(icur+1, nindent, text+il);
				insert(icur+1+nindent, 1, (uint8_t*)"}");
				justbraced = 1;
			} noaddclose:;

			// If block start newline, show it
			if (c == '\n') {
				size_t ilcur0 = getiline(icur-1);
				struct block *blk; size_t i0blk; getblocki(ilcur0,&blk,&i0blk,1);
				if (ilcur0 < getilshown(i0blk,blk)) blk->iminshow1=ilcur0-i0blk+1;
			}
			
			// Remember we updated renaming
			vtextrenaming = vtext;
			needsredraw = 1;

		// In search
		} else if (cur == 1) {
			if (!nsearch) itoppresearch=itop,ytoppresearch=ytop;
			if (c == '\n') {
				nsearch=0, vsearch++, cur=0;
				icur=icurpresearch, itop=itoppresearch, ytop=ytoppresearch;
				needsredraw=1;
				ensurekeyboard();
				break;
			}
			size_t icur0 = icur;
			//gocurcombined(c);
			//insertsearch(icur0, 1, &c);
			//uint8_t n,f; double w; getgraphdisplay(nsearch,bufsearch,icur,&n,&w,&f);
			//icur += n;
			insertsearch(icur0, ntype, buftype);
			icur += ntype;
			ytop=0;
			needsredraw=1;
			
		// In multicur buffer
		} else if (cur == CURMULTI) {
			
			// Enter the back match
			if (c=='\n' && overlay==OVMCBACKMATCH) {
				
				// Compile regex
				ensurenbufmulti(nbufmulti+1); bufmulti[nbufmulti]=0;
				regex_t reg; if (regcomp(&reg,(char*)bufmulti,REG_NEWLINE)) break;
				
				// Move every multicursor back to the first match
				for (size_t imc=0; imc<nmulti; imc++) {
					size_t ipast; for (ipast=multis[imc].i; ipast<ntext&&text[ipast]!='\n'; ipast++);
					ensurentext(ipast+1); text[ipast]='\0';
					for (size_t i=multis[imc].i; i&&text[--i]!='\n';) {
						regmatch_t match; char matched=!regexec(&reg,(char*)text+i,1,&match,(i&&text[i-1]!='\n')*REG_NOTBOL);
						if (matched && !match.rm_so) { multis[imc].i=i; break; }
					}
					text[ipast] = '\n';
				}
				flowmulti();
				
				// Update UI state
				icur=SIZE_MAX, nbufmulti=0, cur=0;
				overlay=OVMULTICURACT, needsredraw=1;
				
			// Normal type
			} else {
				if (c == '\n') break;
				insertbufmulti(icur, ntype, buftype);
				icur += ntype;
				needsredraw=1;
			}

		// In replace buffer 0
		} else if (cur == CURREPLACE0) {
			
			// Move to buffer 1
			if (c == '\n') {
				cur=CURREPLACE1, icur=nbufreplace1;
				needsredrawcur=1;
				
			// Type in replace buffer 0
			} else {
				insertbufreplace0(icur, ntype, buftype);
				icur += ntype;
				needsredraw=1;
				recalcreplaces();
			}
			
		// In replace buffer 1
		} else if (cur == CURREPLACE1) {
			
			// Move to buffer 0
			if (c == '\n') {
				cur=CURREPLACE0, icur=nbufreplace0;
				needsredrawcur=1;
				
			// Type in replace buffer 1
			} else {
				insertbufreplace1(icur, ntype, buftype);
				icur += ntype;
				needsredraw=1;
				updatereplaces();
				flowreplace();
			}
		}
		break;
	}
	
	// Hframe changed
	case APP_CMD_HFRAME: {
		if (app->hframenew != hframe) hframe=app->hframenew, needsredraw=1;
		break;
	}
	
	// Backspace
	case APP_CMD_BACKSPACE: {
		df("%.3f: backspace", et(getns()));
		char justbraced0 = justbraced;
		justbraced=0, phasecur=getms()%1000;
		if (icur==SIZE_MAX && !nmulti) break;
		ilspaced=SIZE_MAX;
		
		// Cut the selection
		if (inamemkfn==SIZE_MAX && iselectstart!=SIZE_MAX) {
			copyselection();
			deleteselection();
			overlay = OVCOPIED;
			break;
		}
		
		// Backspace in multi cursor mode
		if (cur==0 && nmulti) {
			scrollcurinview();
			idchainundo++;
			for (struct multicur *m=multis; m<multis+nmulti; m++) {
				if (!m->i) continue;
				size_t i0 = m->i;
				m->i = igraphprevtext(m->i);
				backspace(i0, i0-m->i);
			}
			idchainundo++;
			flowmulti();
			needsredraw=1;

		// Backspace in text
		} else if (cur == 0) {
			scrollcurinview();
			df("PRE BS"); printblocks(nblocks,blocks,fdf);
			if (istypedwordfromstart && icur>=2 && isspace(text[icur-1]) && !isspace(text[icur-2])) istypedwordfromstart=0;
				
			// Get cursor block
			struct block *blkcur; size_t i0blkcur; getblocki(icur,&blkcur,&i0blkcur,0);

			// Handle backspace at block start
			size_t ishowblk = getilshown(i0blkcur, blkcur);
			if (icur <= ishowblk) {
				df(" bs <= shown (%zu <= %zu)", icur, ishowblk);
				
				// Get prev block
				//TODO: bug if parent of prev has leftover
				struct block *bprev = getblkprev(blkcur);
				
				// If prev not expanded, expand it and stop
				if (bprev && !bprev->expanded) {
					bprev->expanded = 1;
					//icur = SIZE_MAX;
					needsredraw=1;
					break;
				}
				
				// Merge if no more newlines between
				if (bprev && icur && text[icur-1]=='\n') {
					df(" bs merge");
					size_t ilnonempty = getinonemptyline(i0blkcur, ntext);
					size_t nnl=0; for (size_t i=i0blkcur; i<ilnonempty; i++) if (text[i]=='\n' && ++nnl==2) break;
						
					// Merge leaf blocks
					if (nnl<2 && blkcur==bprev+1 && !blkcur->nblocks && !bprev->nblocks) {
						bprev->n += blkcur->n;
						/*size_t *pn; struct block *head;
						if (bprev->parent) pn=&bprev->parent->nblocks,head=bprev->parent->blocks;
						else pn=&nblocks,head=blocks;
						memmove(blkcur, blkcur+1, (--(*pn)-(blkcur-head))*sizeof(*head));
						*/
						removeblock(blkcur);
					}
					df("MERGED BS"); printblocks(nblocks,blocks,fdf);
				}
			}
			
			// Set prev word as renaming one
			setwordrenaming(igraphprevtext(icur));

			// Backspace before chomped line
			if (icur && text[icur-1]=='\n' && go((at){.i=getiline(icur-1)},NROWS|WIDTH,1,(double)displaySize_.width).i!=icur-1) {
				backspace(icur, 1);
				icur = SIZE_MAX;
				needsredraw=1;
				
			// Backspace normal
			} else {

				// Move cursor back
				size_t icur0 = icur;
				df("backspace pre i%zu", icur);
				//gocur(DGRAPHS|WIDTH, -1, wwin-padwin);
				icur = icur ? igraphprev(ntext,text,icur) : 0;
				df("backspace post i%zu", icur);

				// Remove character
				uint8_t c = text[icur];
				backspace(icur0, icur0-icur);
				needsredraw = 1;

				// Delete } line if deleting {
				if (justbraced0) {
					size_t i1 = getilinenext(icur+1);
					backspace(i1, i1-(icur+1));
				}
				
				// If this line is now hidden, show it
				size_t ilcur = getiline(icur);
				if (c!='\n' && getilshown(i0blkcur,blkcur)>ilcur) blkcur->iminshow1=ilcur-i0blkcur+1;
			}
			vtextrenaming = vtext;
			df("POST BS"); printblocks(nblocks,blocks,fdf);

		// Backspace in search
		} else if (cur == 1) {
			if (!icur) break;
			size_t icur0 = icur;
			icur = icur ? igraphprev(nsearch,bufsearch,icur) : 0;
			backspacesearch(icur0, icur0-icur);
			//if (!nsearch) icur=SIZE_MAX;
			ytop=0;
			if (!nsearch) itop=itoppresearch, ytop=ytoppresearch;
			needsredraw=1;
			
		// Backspace in multi cursor input buffer
		} else if (cur == CURMULTI) {
			if (!icur) break;
			size_t icur0 = icur;
			icur = igraphprev(nbufmulti, bufmulti, icur);
			backspacebufmulti(icur0, icur0-icur);
			needsredraw = 1;
			
		// Backspace in replace0 buffer
		} else if (cur == CURREPLACE0) {
			if (!icur) break;
			size_t icur0 = icur;
			icur = igraphprev(nbufreplace0, bufreplace0, icur);
			backspacebufreplace0(icur0, icur0-icur);
			needsredraw = 1;
			recalcreplaces();
			
 		// Backspace in replace1 buffer
 		} else if (cur == CURREPLACE1) {
 			if (!icur) break;
 			size_t icur0 = icur;
 			icur = igraphprev(nbufreplace1, bufreplace1, icur);
 			backspacebufreplace1(icur0, icur0-icur);
 			needsredraw = 1;
 			updatereplaces();
 			flowreplace();
		}
		break;
	}

	// Pause
	case APP_CMD_PAUSE: {
		df("cmd pause");
		break;
	}

	// Save state
	case APP_CMD_SAVE_STATE: {
		df("cmd save state");
		
		// Save text to cache file
		writeto(ntext, text, pathsavestate);
		
		// Serialize state
		size_t size=8192; if (!(app->savedState=malloc(size))) { perror("medcn: malloc savestate"); exit(EXIT_FAILURE); }
		#define BUFST ((uint8_t*)app->savedState)
		#define ADDN(n) { \
			/*df(" ADDN "#n" %"PRId64,(int64_t)n);*/ \
			if (size<app->savedStateSize+sizeof(n) && !(app->savedState=realloc(app->savedState,size*=2))) { fprintf(stderr,"medcn: realloc saved state %zu: %s\n",size,strerror(errno)); exit(EXIT_FAILURE); } \
			uint64_t nstore = n + ((uint64_t)1<<((8*sizeof(n))-1)); \
			for (size_t i=0; i<sizeof(n); i++) BUFST[app->savedStateSize++]=(nstore>>(8*i))&0xff; \
			char hs[sizeof(n)*2]; for(int i=0;i<sizeof(n);i++)hs[2*i]=hexc0(BUFST[app->savedStateSize-sizeof(n)+i]),hs[2*i+1]=hexc1(BUFST[app->savedStateSize-sizeof(n)+i]); /*df("  %.*s",sizeof(n)*2,hs);*/ \
		}
		#define ADDF(x) { \
			int len = snprintf(NULL,0,"%a",(double)x) + 1; \
			if (size<app->savedStateSize+len && !(app->savedState=realloc(app->savedState,size*=2))) { fprintf(stderr,"medcn: realloc saved state %zu: %s\n",size,strerror(errno)); exit(EXIT_FAILURE); } \
			app->savedStateSize += sprintf((char*)BUFST+app->savedStateSize,"%a",(double)x) + 1; \
		}
		#define ADDBUF(sizebuf,nbuf,buf) { \
			/*df(" ADDBUF "#sizebuf", "#nbuf", "#buf" = %"PRIu64" %"PRIu64,(uint64_t)(sizebuf),(uint64_t)(nbuf));*/ \
			ADDN(((uint64_t)sizebuf)) \
			uint64_t ncopy = nbuf * sizeof(*buf); \
			ADDN(ncopy) \
			if (size < app->savedStateSize+ncopy) { \
				while (size < app->savedStateSize+ncopy) size*=2; \
				if (!(app->savedState=realloc(app->savedState,size))) { fprintf(stderr,"medcn: realloc saved state %zu: %s\n",size,strerror(errno)); exit(EXIT_FAILURE); } \
			} \
			memcpy(BUFST+app->savedStateSize,buf,ncopy); app->savedStateSize+=ncopy; \
		}
		//TODO: store num+-MIN, restore MIN+each
		//eg store u8 128+n; s8=-128;for ... s8+=; n=s8
		{
/* GEN
exec 2>&1
<c/AndroidMain.c sed -n '/^\/\/ Start of saved state/,/^\/\/ End of saved state/p' | awk "$(<<\! cat
/^	*\/\//{ printf("\n%s\n",$0); next; }
/^typedef /{next}
/^union /{next}
{
	i = 1;

	# Handle definitions
	if (indef) {
		if (substr($1,1,1) == "}") { indef=0; i++; }
		else next;
	} else if ($1 == "enum") {
		type = "N";
		indef=1; next;
	} else if ($i == "struct") {
		type = "STRUCT";
		if ($NF == "{") { indef=1; next; }
		else for (i=3; substr($(i-1),length($(i-1)))!="}"; i++);
	}

	# Update type
	if ($1=="char" || $1=="uint64_t" || $1=="unsigned" || $1=="enum" || $1=="long" || $1=="size_t" || $1=="uint8_t") {
		type="N"; i++;
	} else if ($1=="float" || $1=="double") { type="F"; i++; }

	# Print each variable
	for (; i<=NR; i++) {
	
		# Clean or skip
		if (substr($i,1,2) == "//") next;
		if ($i == "=") { i++; continue; }
		if (!length($i) || substr($i,1,1)~/[0-9-]/) continue;
		if (substr($i,length($i)) ~ /[,;]/) $i=substr($i,1,length($i)-1);
		if ($i=="INFINITY" || $i=="UINT64_MAX" || $i=="SIZE_MAX" || $i=="NULL") continue;
		sub("=.*", "", $i);
		
		# Handle buffer
		if (substr($i,1,1) == "*") {
			var = substr($i, 2);
			if (varbuf0)
				printf("ADDBUF((%s/sizeof(*%s)*sizeof(*%s)), %s, %s)\n", varsize, varbuf0, var, varn, var);
			else {
				printf("ADDBUF(%s, %s, %s)\n", varsize, varn, var);
				varbuf0 = var;
			}
		
		# Handle number
		} else {
			printf("ADD%s(%s)\n", type, $i);
			if (substr($i,1,1) == "n") varn=$i;
			else if (substr($i,1,4) == "size") { varsize=$i; varbuf0=""; }
		}
	}
}
!
)" | sed 's,^,			,'
*/
			
			// Start of saved state sections
			ADDN(needsredraw)
			ADDN(needsredrawcur)
			ADDN(needsredrawkb)
			ADDN(isuptap)
			ADDN(isupswipelr)
			ADDN(isdown)
			ADDN(justbraced)
			ADDN(isselectinglines)
			ADDN(showntab)
			ADDN(shownac)
			ADDN(isenterafterblock)
			ADDN(ispasteafterblock)
			ADDN(iscutblock)
			ADDN(iscopyblock)
			ADDF(xdown)
			ADDF(ydown)
			ADDF(yscr)
			ADDF(ytopdown)
			ADDF(ymoveprev)
			ADDF(yvelocity)
			ADDF(xcolud)
			ADDF(y0tab)
			ADDF(ybottomov)
			ADDN(nsdown)
			ADDN(nsstartup)
			ADDN(nsmoveprev)
			ADDN(nsflingprev)
			ADDN(stateovvert)
			ADDN(statekbvert)
			ADDN(vwinsize)
			ADDN(overlay)
			ADDN(overlaypremain)
			ADDN(overlayverted)
			ADDN(mssaved)
			ADDN(msensurekeyboard)
			ADDN(hframe)
			ADDN(hframeoverride)
			ADDN(msoverridehframe)
			ADDN(hframeovverted)
			ADDN(icurvert)
			
			// Making function from selection
			ADDN(inamemkfn)
			
			// Renaming
			ADDN(irenaming)
			ADDN(nrenamed)
			ADDN(sizerenamed)
			ADDN(vtextrenaming)
			ADDBUF(sizerenamed, nrenamed, bufrenamed)
			
			// Replace
			ADDN(nreplace)
			ADDN(sizeisreplace)
			ADDBUF(sizeisreplace, nreplace, isreplace)
			ADDBUF((sizeisreplace/sizeof(*isreplace)*sizeof(*replaces)), nreplace, replaces)
			ADDN(i0replace)
			ADDN(i1replace)
			ADDN(nreplaced)
			ADDN(nflowreplace)
			ADDN(sizeflowreplace)
			ADDBUF(sizeflowreplace, nflowreplace, isflowreplace)
			ADDN(nbufreplace0)
			ADDN(sizebufreplace0)
			ADDBUF(sizebufreplace0, nbufreplace0, bufreplace0)
			ADDN(nbufreplace1)
			ADDN(sizebufreplace1)
			ADDBUF(sizebufreplace1, nbufreplace1, bufreplace1)
			
			// Flow indices
			ADDN(nflow)
			ADDN(sizeflows)
			ADDBUF(sizeflows, nflow, isflow)
			
			// Multi cursors
			ADDN(nmulti)
			ADDN(sizemulti)
			ADDBUF(sizemulti, nmulti, multis)
			ADDN(imultistart)
			ADDN(nflowmulti)
			ADDN(sizeflowmulti)
			ADDBUF(sizeflowmulti, nflowmulti, isflowmulti)
			ADDN(nbufmulti)
			ADDN(sizebufmulti)
			ADDBUF(sizebufmulti, nbufmulti, bufmulti)
			
			// Cursor location
			ADDN(icur)
			ADDN(curshown)
			ADDN(cur)
			ADDN(phasecur)
			
			// Undo
			ADDN(nundo)
			ADDN(sizeundo)
			ADDBUF(sizeundo, nundo, undos)
			ADDN(idchainundo)
			ADDN(isundoing)
			
			// Positions in the blocks
			
			// Selecting
			ADDN(iselectstart)
			ADDN(iselectend)
			ADDN(curselect)
			
			// Spacing out info
			ADDF(xdowntaptextprev)
			ADDF(ydowntaptextprev)
			ADDN(nsdowntaptextprev)
			ADDF(x0spacing)
			ADDN(ilspaced)
			
			// Search buffer
			ADDN(nsearch)
			ADDN(sizesearch)
			ADDBUF(sizesearch, nsearch, bufsearch)
			ADDN(vsearch)
			ADDN(itoppresearch)
			ADDN(icurpresearch)
			ADDF(ytoppresearch)
			
			// Positions in the search results
			
			// Cached search results, last is ntext
			ADDN(vtextsearchresults)
			ADDN(vsearchsearchresults)
			ADDN(vwinsizesearchresults)
			ADDN(nsearched)
			ADDN(sizeissearchresults)
			ADDN(nissearchresults)
			ADDN(sectionssearched)
			ADDN(isrlabels)
			ADDN(isrdirect)
			ADDBUF(sizeissearchresults, nissearchresults, issearchresults)
			ADDBUF((sizeissearchresults/sizeof(*issearchresults)*sizeof(*typessearchresults)), nissearchresults, typessearchresults)
			
			// Positions in the text+screen
			
			// Top of screen
			ADDN(itop)
			ADDN(isrtop)
			ADDN(irowtop)
			ADDF(ytop)
			
			// Cached syntax states
			ADDN(sizesynsts)
			ADDN(nsynsts)
			ADDBUF(sizesynsts, nsynsts, synsts)
			
			// Text state
			ADDN(vtext)
			ADDN(vtextsaved)
			
			// Expanded lines
			ADDN(nilexps)
			ADDN(sizeilexps)
			ADDBUF(sizeilexps, nilexps, ilexps)
			ADDBUF((sizeilexps/sizeof(*ilexps)*sizeof(*exps)), nilexps, exps)
			
			// End of saved state sections
//ENDGEN

			// Blocks
			ADDBUF(sizeblocks, nblocks, blocks)
			size_t i0=0; struct block *b=blocks;
			while (nextblki0(&b,&i0), b) if (b->nblocks) ADDBUF(b->sizeblocks,b->nblocks,b->blocks);
			
			// Expanse buffers
			for (struct expanse *exp=exps; exp<exps+nilexps; exp++) {
				if (size < app->savedStateSize+exp->norig) { 
					while (size < app->savedStateSize+exp->norig) size*=2;
					if (!(app->savedState=realloc(app->savedState,size))) {fprintf(stderr,"medcn: realloc saved state (exps) %zu: %s\n",size,strerror(errno));exit(EXIT_FAILURE);}
				}
				memcpy(BUFST+app->savedStateSize,exp->orig,exp->norig); app->savedStateSize+=exp->norig;
			}
		}
		df(" serialized %zu @%p - %p", app->savedStateSize, app->savedState, app->savedState+app->savedStateSize);
		//app->savedStateSize = 0;
		//{char hs[32];for (int i=0; i<sizeof(hs)/2; i++) hs[2*i]=hexc0(BUFST[i]),hs[2*i+1]=hexc1(BUFST[i]);df("  %.*s",sizeof(hs),hs);}
		#undef BUFST
		#undef ADDN
		#undef ADDF
		#undef ADDBUF
	}

	// Unhandled command
	default:
		__android_log_print(ANDROID_LOG_INFO, "Vulkan Tutorials", "event not handled: %d", cmd);
	}
	//if (cmd == APP_CMD_TYPE) {
	//	app->ntype = 0;
	//	if (!app->isfaketype) df("%.3f broadcast type", et(getns()));
	//	if (!app->isfaketype) pthread_cond_broadcast(&app->cond);
	//}
	if (cmd == APP_CMD_BACKSPACE) {
		app->ispendingbackspace = 0;
		if (!app->isfaketype) pthread_cond_broadcast(&app->cond);
	}
}

void
app_dummy()
{
}

void
process_input(struct android_app* app, struct android_poll_source* source)
{
	AInputEvent* event = NULL;
	while (AInputQueue_getEvent(app->inputQueue, &event) >= 0) {
		//LOGV0("New input event: type=%d\n", AInputEvent_getType(event));
		if (AInputQueue_preDispatchEvent(app->inputQueue, event)) {
			continue;
		}
		int32_t handled = 0;
		if (app->onInputEvent != NULL) handled = app->onInputEvent(app, event);
		AInputQueue_finishEvent(app->inputQueue, event, handled);
	}
}

void
process_cmd(struct android_app* app, struct android_poll_source* source)
{
	int8_t cmd = android_app_read_cmd(app);
	android_app_pre_exec_cmd(app, cmd);
	if (app->onAppCmd != NULL) app->onAppCmd(app, cmd);
	android_app_post_exec_cmd(app, cmd);
}

struct atsearch
attopsearch(void)
{
	struct atsearch top = {.y=ytop, .isr=isrtop, .irow=irowtop};
	return top;
}

/* isr SIZE_MAX returned if pending input */
#define df(...)
struct atsearch
vgosearch(struct atsearch pos, unsigned flags, union ssize_tdouble *args)
{

	// Process flags
	ssize_t nrows=SSIZE_MAX; char isdrows=0; if (flags & DROWS) nrows=args++->s,isdrows=1;
	double height = (flags&HEIGHT) ? args++->d : INFINITY;
	if (flags & NROWS) nrows=args++->s;
	char verts = !!(flags & VERTS);
	double wrow = flags&WIDTH ? args++->d : INFINITY;
	char isstopx = !!(flags & XSTOP);
	double stopx = isstopx ? args++->d : INFINITY;
	double x0 = flags&X0 ? args++->d : /*padwin*/0;
	char isstopy = !!(flags & YSTOP);
	double stopy = isstopy ? args++->d : INFINITY;
	char backwards = nrows < 0;
	if (backwards) if(nrows==SSIZE_MAX)nrows=-(SSIZE_MAX-1);
	// Note: backwards not implemented
	df("gosearch h%.2f%s irow%zu", height, isstopx?" stopx":"", pos.irow);

	// Initialize looping variables
	ssize_t row = pos.row;
	size_t isr = pos.isr,
		irow = pos.irow;
	double x = pos.x,
		y = pos.y;
	int indentrowprev = 0;
	
	// Clear cache if outdated
	if (vtextsearchresults!=vtext || vsearchsearchresults!=vsearch || vwinsizesearchresults!=vwinsize)
		nissearchresults=nsearched=sectionssearched=0, vtextsearchresults=vtext, vsearchsearchresults=vsearch, vwinsizesearchresults=vwinsize;

	// Loop through each block row
	while (row<nrows && (isr<nissearchresults||sectionssearched<2||nsearched<ntext) && (row+1<nrows||!isstopx)) {
		df("gosearch loop");
	
		// Find next entry
		while (isr>=nissearchresults && (sectionssearched<2||nsearched<ntext)) {
			df("gosearch isr%zu nsr%zu ssr%d nsd%zu", isr, nissearchresults, (int)sectionssearched, nsearched);
		
			// Move through label sections
			if (sectionssearched < 2) {
				struct block *blk=blocks; size_t i0blk=0;
				if (nissearchresults) getblocki(issearchresults[nissearchresults-1],&blk,&i0blk,1);
				char section = sectionssearched && isrlabels<nissearchresults;
				char type;
				if (nextblki0search(&blk,&i0blk,&section,(!nissearchresults)|(verts?2:0),&type)) return (atsearch){.isr=SIZE_MAX};

				// End of label sections
				if (!blk) {
					df("gosearch none left");
					sectionssearched=2, isrdirect=nissearchresults, nsearched=0;
				}
				df("gosearch next blk%s i%zu section%d isr%zu nsr%zu", sblk(blk), i0blk, (int)section, isr, nissearchresults);
				checkblk(blk, i0blk);
			}
			
			// Move through direct results
			if (sectionssearched == 2) {
			
				// Fill til past cache index
				while (isr>=nissearchresults && nsearched<ntext) {
						
					// Get next search index
					size_t inext = nsearched;
					{
						
						// Compile regex
						regex_t reg;
						ensuren(&sizesearch, nsearch, (void**)&bufsearch, nsearch+1);
						bufsearch[nsearch] = 0;
						if (regcomp(&reg,(char*)bufsearch,(btnssearch[SEARCHCASE].lines[0][3]=='I'?REG_ICASE:0)|REG_NEWLINE)) {nsearched=ntext;break;}
			
						// Find line
						ensurentext(ntext+1);
						text[ntext] = 0;
						while (inext < ntext) {
							if (verts && (appg->ntype||appg->ispendingbackspace)) return (struct atsearch){isr=SIZE_MAX};
							df("gosearch 2 @%zu", inext);
							
							// Match until ^0
							size_t inull=0; if (ntext-inext > 1024) {
								inull = getilinenext(inext+1024) - 1;
								text[inull] = 0;
							}
							regmatch_t match;
							char matched = !regexec(&reg, (char*)text+inext, 1, &match, REG_NEWLINE|(inext?REG_NOTBOL:0)|REG_NOTEOL);

							// Matched, use prev line start
							if (matched) {
								if (inull) text[inull]='\n';
								inext += match.rm_so;
								break;
							}

							// Move past
							inext += strlen((char*)text+inext) + 1;
							if (inull) text[inull]='\n';
						}
						regfree(&reg);
					}

					// Cache it
					if ((nsearched=inext) < ntext) {
						df("gosearch 2 cache %zu", inext);
					
						// Get result section start
						struct block *bnext; size_t i0next; getblocki(inext,&bnext,&i0next,1);
						inext=getiline(inext); if (inext) inext=getiline(inext-1);
						if (inext < i0next) inext=i0next;
						df("gosearch 2 cache start %zu", inext);
					
						// Cover this result's area with nsearched
						nsearched = go((at){.i=inext}, DROWS|WIDTH, 3, (double)displaySize_.width).i;
						df("gosearch 2 cache searched %zu", nsearched);

						// Add all parent entries
						struct block *prev = NULL;
						if (nissearchresults) getblocki(issearchresults[nissearchresults-1],&prev,NULL,1);
						size_t nanc=0; for (struct block *b=bnext; b; b=b->parent) nanc++;
						for (size_t igen=0; igen<nanc; igen++) {
							struct block *anc=bnext; for (size_t jgen=nanc-1; jgen>igen; jgen--) anc=anc->parent;
							for (struct block *b=prev; b; b=b->parent) if (b == anc) goto nextanc2;
							ensurens(nissearchresults+1, &sizeissearchresults, sizeof(size_t), (void**)&issearchresults, sizeof(char), (void**)&typessearchresults, 0);
							issearchresults[nissearchresults]=geti0ancestor(i0next,bnext,anc), typessearchresults[nissearchresults]=0;
							nissearchresults++;
							df("gosearch 2 cache parent %zu", issearchresults[nissearchresults-1]);
							nextanc2:;
						}

						// Add entry
						ensurens(nissearchresults+1, &sizeissearchresults, sizeof(size_t), (void**)&issearchresults, sizeof(char), (void**)&typessearchresults, 0);
						issearchresults[nissearchresults]=inext, typessearchresults[nissearchresults]=3;
						nissearchresults++;
					}
				}
				
				/*
				// Get entry or break
				if (isr < nissearchresults) {
					getblocki(i=issearchresults[isr], &blk, &i0blk, 1);
					type = typessearchresults[isr];
				} else {
					i = i0blk = ntext;
					blk = NULL;
					break;
				}*/
			}
		}
		if (isr >= nissearchresults) break;

		// Break if past height
		char type = typessearchresults[isr];
		if (y+hline+(type==1||type==2?2*pudb:0) > height) break;

		// It's a parent entry
		if (type == 0) {
			if (verts) {
				int indent = 0;
				size_t i0blk; struct block *blk; getblocki(issearchresults[isr],&blk,&i0blk,1);
				char underline = sectionssearched>=2 && isr>=isrdirect && typessearchresults[isr+1];
				//if (underline) fputs("\033[4m",stdout);
				for (struct block *b=blk->parent; b; b=b->parent,indent++) {
					double xund = x0 + indent*windentsearch + windentsearch/4;
					vertund(xund-1, y-(indent<indentrowprev?mudb:0), xund+1, y+hline+mline);
				}
				size_t ilabel,nlabel; getlabel(i0blk,blk,&ilabel,&nlabel);
				//if (go((at){.i=ilabel,.col=indent}, DBYTES|NROWS|PRINT|(underline?UNDERLINE:0), nlabel, 1).col < widthterm) printf("%s\033[K\033[m",underline?"\033[4m":"");
				go((at){.x=x0+indent*windentsearch,.y=y,.i=ilabel}, DBYTES|NROWS|VERTS|WIDTH, nlabel, 1, (double)displaySize_.width);
				//if (row+1 < nrows) putchar('\n');
			}
			row++, isr++, y+=hline+mline;
			indentrowprev = 0;
		
		// It's a row entry
		} else if (type <= 2) {
			
			// Get labels for row
			char section = sectionssearched>=2&&isr>=isrdirect ? 2 : sectionssearched>=1&&isr>=isrlabels ? 1 : 0;
			size_t i0blk; struct block *blk; getblocki(issearchresults[isr],&blk,&i0blk,1);
			struct block *blk0 = blk;
			size_t i0blk0=i0blk, nblks, is[MAXLABELS], ns[MAXLABELS], indent; double ws[MAXLABELS], pad=wrow;
			size_t isr0 = isr;
			getlabelsrow(&blk, &i0blk, MAXLABELS, &pad, &nblks, is, ns, ws, &indent, NULL, 1, &section);
			isr += nblks;
			df("gosearch post-getlabels next blk%s i%zu", sblk(blk), i0blk);
			checkblk(blk, i0blk);
			//df("nblks %zu", nblks);
			
			// Increment rows
			double y0 = y;
			row++, y+=hline+2*pudb+mudb;
			
			// Print them
			//stopcol not made for print
			if (verts) {
				printblockrow(x0, y0, indent, pad, nblks, is, ns, ws, 1, indentrowprev);
				/*if (row>=nrows || (!isdrows&&!blk)) {
					if (!isdrows) row--;
					break;
				}*/
				//? fputc('\n', stdout);
			}

			// Stop in one of them
			if ((row>=nrows||(isstopy&&fle(stopy,y))) && !isdrows) {
				isr=isr0, blk=blk0, i0blk=i0blk0;
				if (isstopx) {
					/*
					size_t w=indent, j=0;
					while (j+1<nblks && w+ws[j]+2+PAD<=stopcol) w+=ws[j]+2+PAD,j++;
					isr += j;
					*/
					double w = x0 + indent*windentlabel;
					double padeach = pad / nblks;
					size_t j;
					for (j=0; j+1<nblks; j++) {
						double wb = (j?mlrb:0) + 2*plrb + padeach + ws[j];
						if (stopx <= w+wb) break;
						i0blk+=(blk++)->n, w+=wb;
					}
					isr += j;
					break;
				} else if (isstopy) break;
			}
			x = x0;
			indentrowprev = indent;
			
		// It's a direct entry
		} else {
			df("gosearch direct i0 %zu", issearchresults[isr]);
			size_t igo = issearchresults[isr];
			if (irow) igo=go((at){.i=igo}, DROWS|WIDTH, irow, (double)displaySize_.width).i;
			df("gosearch direct i1 %zu", igo);
			if (irow < 2) {
				size_t nrowsgo = nrows-row<2-irow ? nrows-row : 2-irow;
				struct at pos = go((at){.x=x0,.y=y,.i=igo}, NROWS|(verts?VERTS:0)|WIDTH|X0, nrowsgo, (double)displaySize_.width, x0);
				size_t nrowswent = pos.row + (igo<ntext);
				irow+=nrowswent, row+=nrowswent, y+=nrowswent*(hline+mline), igo=go(pos,NROWS|WIDTH|XSTOP|X0,2,(double)displaySize_.width,x0,x0).i;
				df("gosearch direct i2 %zu", igo);
				//if (print && row<nrows) putchar('\n');
			}
			if (row < nrows) {
				if (igo < ntext) {
					if (verts) {
						go((at){.x=x0,.y=y,.i=igo}, NROWS|VERTS|WIDTH|X0/*|UNDERLINE*/, 1, (double)displaySize_.width, x0);
						double yund = y + hline + mline/2;
						vertund(x0, yund-1, x0+displaySize_.width, yund+1);
					}
					row++, y+=hline+mline;
					//if (print && row<nrows) putchar('\n');
				}
				irow = 0;
				if (isstopy && y >= stopy) break;
				isr++;
			}
			indentrowprev = 0;
		}
	}
	
	// Return ending spot
	df("gosearch end");
	//return (atsearch){.isr=isr, .irowblk=irowblk, .row=row};
	return (atsearch){.row=row, isr=isr, irow=irow, .x=x, .y=y};
}
#undef ADD
#undef df

struct atsearch
gosearch(struct atsearch pos, unsigned flags, ...)
{

	// Process flags
	va_list ap; va_start(ap,flags);
	union ssize_tdouble args[10], *p=args;
	if (flags & DROWS) p++->s=va_arg(ap,ssize_t);
	if (flags & HEIGHT) p++->d=va_arg(ap,double);
	if (flags & NROWS) p++->s=va_arg(ap,ssize_t);
	if (flags & WIDTH) p++->d=va_arg(ap,double);
	if (flags & XSTOP) p++->d=va_arg(ap,double);
	if (flags & X0) p++->d=va_arg(ap,double);
	if (flags & YSTOP) p++->d=va_arg(ap,double);
	va_end(ap);
	return vgosearch(pos, flags, args);
}
            	
double       	
gety0search(void)
{            	
            	
	// Get y of bottom (above keyboard if there)
	double ybottom = gethframe();

	return ybottom - hline;
}

void
drawoverlaybuttons(size_t nbtns, struct buttoninfo *btns, uint64_t state)
{
	nvertstextov = nvertsbackov = nvertsbtnov = 0;
	if ((ybottomov=gethframe()) == displaySize_.height) ybottomov=displaySize_.height*rhbtn0+hbtn;
	else ybottomov -= hbtntab;
	for (int ibtn=0; ibtn<nbtns; ibtn++) {
		struct buttoninfo b = btns[ibtn];
		//df("drawing button (%s) %"PRIx64" ("PRIx64")", b.lines[0]?b.lines[0]:"NULL", b.flag, state);
		if (!b.lines[0]) continue;
		if (!b.flag || (state&b.flag)) {
			double x0=displaySize_.width*0.2*(ibtn%5), y0=ybottomov-hbtn-hbtn*(ibtn/5);
			vertbtnov(x0, y0, x0+displaySize_.width*0.2, y0+hbtn);
			int nlines=0; while (nlines<2 && b.lines[nlines]) nlines++;
			double htext = nlines*hline + (nlines-1)*mline;
			double y0text = y0 + hbtn/2 - htext/2;
			for (int i=0; i<nlines; i++) {
				double x0text = x0 + displaySize_.width*0.1 - advs(b.lines[i])/2;
				vertbufov(x0text, y0text+hline, strlen(b.lines[i]), (uint8_t*)b.lines[i]);
				vertbackov(x0text, y0text, vertstextov[nvertstextov-1].x, y0text+hline+8);
				y0text += hline + mline;
			}
		}
	}
	needsverttextov = needsvertbackov = needsvertbtnov = 1;
}

void
vertcurxy(double x0, double y0)
{
	curshown = 1;
	double x1=x0+2, y1=y0+(hline+10);
	vertscur[nvertscur++] = (struct vcur){x0, y1};
	vertscur[nvertscur++] = (struct vcur){x0, y0};
	vertscur[nvertscur++] = (struct vcur){x1, y0};
	vertscur[nvertscur++] = (struct vcur){x1, y1};
	vertscur[nvertscur++] = (struct vcur){x0, y1};
	vertscur[nvertscur++] = (struct vcur){x1, y0};
}

void
vertcur(size_t i)
{
	if (i==SIZE_MAX || i<itop) return;
	struct atblk pos = goblk(attopblk(), DBYTES, (ssize_t)(i-itop));
	//fprintf(stderr, "vertcur pos i %zu\n", pos.i);
	if (pos.i != i) return;
	if (pos.y+hline+10>=0 && pos.y-hline-7<=displaySize_.height) vertcurxy(pos.x,pos.y-3);
	//df("vertcur text %.3f,%.3f %.3f,%.3f", x0, y0, x1, y1);
	//fprintf(stderr, "vertcur %f,%f  ->  %f,%f %f,%f\n", pos.x, pos.y, x0, y0, x1, y1);
}

uint64_t
getstateoverlay(void)
{
	uint64_t state = 0;
	if (overlay == OVMAIN) {
		state = 1
			| 2 * (overlay==1&&cur==0&&icur!=SIZE_MAX&&curshown)
			| 4 * (iselectstart!=SIZE_MAX&&iselectstart!=iselectend)
			| 8 * (cur==0&&icur!=SIZE_MAX&&curshown)
			| 16 * (itop||ytop<=mudwin)
			// 32 below
			// 64 below
			| 128 * (nundo>0)
			|0x100 * (cur==0&&icur!=SIZE_MAX&&curshown&&getilinenext(icur)<ntext)
			|0x200 * (cur==0&&icur!=SIZE_MAX&&curshown&&getiilexp(icur)!=SIZE_MAX);
		if (!nmulti && cur==0 && icur!=SIZE_MAX) {
			size_t il = getiline(icur);
			size_t i=il; while (i<ntext && isspace(text[i])) i++;
			if ((ntext-i>=7 && !memcmp(text+i,"/* GEN\n",7))
				|| (ntext-i>=14 && !memcmp(text+i,"// Generated: ",14)))
					state |= 32;
		}
		if (cur==0 && icur!=SIZE_MAX && curshown) {
			char c0 = buttons[FLOWLINE].lines[0][0];
			if (getiflow(getiline(icur)) == SIZE_MAX) {
				buttons[FLOWLINE].lines[0] = "Flow";
				struct at end = go((at){.i=getiline(icur)}, NOSPACING|NROWS|WIDTH, (ssize_t)1, (double)displaySize_.width);
				if (end.i<ntext && text[end.i]!='\n') state|=64;
			} else {
				buttons[FLOWLINE].lines[0] = "Unflow";
				state |= 64;
			}
			if (c0 != buttons[FLOWLINE].lines[0][0]) needsredraw=1;
		}
	} else if (overlay == OVCOPIED) {
		state = 1 * (cur==0&&icur!=SIZE_MAX&&curshown);
	} else if (overlay == OVUNDID) {
		state = 1 * (nundo>0);
	} else if (overlay == OVJOINED) {
		state = 1 * (cur==0&&icur!=SIZE_MAX&&curshown&&getilinenext(icur)<ntext);
	} else if (overlay == OVSELECT) {
		size_t i0,i1; geti01selection(&i0,&i1);
		struct block *blk; size_t i0blk; getblocki(i0,&blk,&i0blk,1);
		//df("checking select pre");
		if (i0 != getilshown(i0blk,blk)) goto endselectstate1;
		//df(" it's ilshown");
		if (blk->parent ? blk==blk->parent->blocks : blk==blocks) goto endselectstate1;
		//df(" it's not first child");
		if ((blk-1)->expanded) goto endselectstate1;
		//df(" its prev sib not expanded");
		for (size_t i=getiline(i0-1); i<i0; i++) if (!isspace(text[i])) goto endselectstate1;
		//df(" there's only space before");
		state |= 1;
		endselectstate1:;
	}
	return state;
}

// Font NDK C prototypes
void *AFontMatcher_createc(void);
void * AFontMatcher_matchc(void*,char*,uint16_t*,uint32_t,uint32_t*);
void AFontMatcher_destroyc(void*);
char *AFont_getFontFilePathc(void*);
void AFont_closec(void*);
	
void
getwordcurtext(size_t *piw, size_t *pnw)
{
	getwordbufi(ntext, text, icur, piw, pnw);
}
	
void
getwordcursearch(size_t *piw, size_t *pnw)
{
	getwordbufi(nsearch, bufsearch, icur, piw, pnw);
}

void
getwordcur(uint8_t **pw, size_t *pn)
{
	if (cur == 0) {
		size_t i; getwordcurtext(&i, pn);
		*pw = text + i;
	} else if (cur == 1) {
		size_t i; getwordcursearch(&i, pn);
		*pw = bufsearch + i;
	}
}

/* Moves pi to the last char of any comment or
string or char it begins. Returns whether it did
that. Assumes won't go past i1. */
char
eattoken(size_t *pi, size_t i1)
{
	size_t i = *pi;
			
	// /*
	if (i1-i>=2 && !memcmp(text+i,"/*",2)) for (i+=3; memcmp(text+i-1,"*/",2); i++);
			
	// //
	else if (i1-i>=2 && !memcmp(text+i,"//",2)) for (i+=2; text[i]!='\n'; i++);
			
	// "
	else if (text[i] == '"') {
		i++;
		char esc = 0;
		while (text[i]!='"' || esc) esc=!esc&&text[i]=='\\',i++;
			
	// '
	} else if (text[i] == '\'') {
		i++;
		char esc = 0;
		while (text[i]!='\'' || esc) esc=!esc&&text[i]=='\\', i++; 
		
	// Nothing to eat
	} else return 0;
	
	// Store and return
	*pi = i;
	return 1;
}

/* eattoken but skips #if 0 as well */
char
eattokenskip(size_t *pi, size_t i1)
{
	
	// Eat standard
	if (eattoken(pi,i1)) return 1;
	
	// Eat #if 0
	if (*pi+6<=ntext && !memcmp(text+*pi,"#if 0\n",6)) {
		
		// Make sure only whitespace til prev newline
		if (*pi) for (size_t j=*pi-1; j&&text[j]!='\n'; j--) if (!isspace(text[j])) goto endif0eat;
		
		// Eat til #endif
		*pi += 6;
		while (*pi < i1) {
			while (*pi<i1 && isspace(text[*pi])) (*pi)++;
			if (*pi >= i1) break;
			if (*pi+7<=i1 && !memcmp(text+*pi,"#endif\n",7)) { *pi+=7; break; }
			(*pi)++;
			while (*pi<i1 && text[*pi-1]!='\n') (*pi)++;
		}
		return 1;
	} endif0eat:;
	return 0;
}

char
addacw(size_t nw, uint8_t *w, size_t ns, uint8_t *s)
{
				
	// Same word = no autocorrect
	//df("word? %zu %.*s", i, (int)ns, text+i);
	if (ns==nw && !memcmp(s,w,nw)) {
		nisac = 0;
		return 1;
	}
				
	// It's a known suggestion
	for (size_t j=0; j<nisac; j++) if (nsac[j]==ns && !memcmp(wsac[j],s,ns)) {
		countsac[j]++;
		return 0;
	}
					
	// It's a superstring
	uint8_t dist = 0;
	if (ns>nw && !memcmp(w,s,nw)) goto gotedit1;

	// It's a subtraction
	dist = 1;
	if (nw>1 && ns>=nw-1)
		for (size_t j=0; j<nw; j++)
			if (!memcmp(w,s,j) && !memcmp(w+j+1,s+j,nw-j-1))
				goto gotedit1;
							
	// It's a replacement
	if (nw>1 && ns>=nw)
		for (size_t j=0; j<nw; j++)
			if (!memcmp(w,s,j) && !memcmp(w+j+1,s+j+1,nw-j-1))
				goto gotedit1;
							
	// It's an addition
	if (ns >= nw+1)
		for (size_t j=0; j<nw+1; j++)
			if (!memcmp(w,s,j) && !memcmp(w+j,s+j+1,nw-j))
				goto gotedit1;
							
	// It's an adjacent swap
	if (ns >= nw)
		for (size_t j=0; j<nw-1; j++)
			if (!memcmp(w,s,j) && w[j]==s[j+1] && w[j+1]==s[j] && !memcmp(w+j+2,s+j+2,nw-j-2))
				goto gotedit1;
							
	// Add to list
	if (0) { gotedit1:;
		ensurens(++nisac, &sizeisac, sizeof(uint8_t*), (void**)&wsac, sizeof(size_t), (void**)&nsac, sizeof(size_t), (void**)&countsac, sizeof(uint8_t), (void**)&distsac, 0);
		wsac[nisac-1]=s, nsac[nisac-1]=ns, countsac[nisac-1]=1, distsac[nisac-1]=dist;
	}
	return 0;
}

/* Returns whether it matches the matching word exactly */
char
addac(size_t nw, uint8_t *w, size_t i)
{
	size_t n2=1; while (i+n2<ntext && (cur==0 ? isalnum_(text[i+n2]) : !ispunct(text[i+n2])&&!isspace(text[i+n2]))) n2++;
	return addacw(nw, w, n2, text+i);
}

size_t
getilsearch(char *pfound)
{
	ensuren(&sizesearch,0,(void**)bufsearch,nsearch+1); bufsearch[nsearch]=0;
	char *p; unsigned long long nlsearch=(errno=0,strtoull((char*)bufsearch,&p,10));
	if (!nlsearch && (errno||p!=(char*)bufsearch+nsearch)) nlsearch=SIZE_MAX;
	if (nlsearch < 1) nlsearch=1;
	size_t i=0; for (unsigned long long in=1; in<nlsearch&&i<ntext; i++) if (text[i] == '\n') in++;
	char found = i<ntext; if (!found) i=getiline(i-1);
	if (pfound) *pfound=found;
	return i;
}

/* 1 means skipautocorrect */
char
appendacfor(size_t nw, uint8_t *w)
{
	
	// Get all contenders
	{
								
		// Get labels if after goto
		{
									
			// Break if not a goto
			if (cur) goto endlabelsac;
			size_t iw=w-text, i=iw;
			while (i && isspace(text[i-1])) i--;
			if (i<4 || memcmp(text+i-4,"goto",4) || (i!=4&&isalnum_(text[i-5]))) goto endlabelsac;
									
			// Get function block
			size_t nbrace=0, ibrace0=SIZE_MAX;
			for (i=0; i<iw; i++) {
				if (appg->ntype || appg->ispendingbackspace) return 1;
				if (eattokenskip(&i,ntext)) continue;
				if (text[i] == '{') {
					if (!nbrace++) ibrace0=i;
				} else if (text[i] == '}') nbrace--;
			}
			if (ibrace0 == SIZE_MAX) goto endlabelsac;
									
			// Add all labels in block
			for (i=ibrace0+1,nbrace=1; i<ntext; i++) {
				if (appg->ntype || appg->ispendingbackspace) return 1;
				if (eattokenskip(&i,ntext)) continue;
										
				// Update brace counts
				if (text[i] == '{') nbrace++;
				else if (text[i] == '}' ) {
					if (!--nbrace) break;
											
				// Check for label before colon
				} else if (text[i] == ':') {
					size_t iname=i; while (isalnum_(text[iname-1])) iname--;
					if (iname == i) continue;
					for (size_t j=iname-1; text[j]!='?'; j--) {
						if (strchr(";{}",text[j])) {
							if(/*finishedac=*/addac(nw,w,iname))return 0; /*goto endautocorrect;*/
							break;
						}
					}
				}
			}
			//finishedac = 1;
			goto gotcontendersac;
		} endlabelsac:;
								
		// Get struct tags if after struct
		{
									
			// Break if not a struct
			if (cur) goto endstructac;
			size_t iw=w-text, i=iw;
			while (i && isspace(text[i-1])) i--;
			if (i<6 || memcmp(text+i-6,"struct",6) || (i!=6&&isalnum_(text[i-6-1]))) goto endstructac;
									
			// Get all prev struct tags
			size_t i1 = i - 6;
			for (size_t i=0; i<i1; i++) {
				if (appg->ntype || appg->ispendingbackspace) return 1;
				if (eattokenskip(&i,i1)) continue;
										
				// { skip if doesn't contain iw
				if (text[i] == '{') {
					for (size_t j=i+1, nbrace=1; j<i1; j++) {
						if (eattokenskip(&j,i1)) continue;
						if (text[j] == '{') nbrace++;
						else if (text[j]=='}' && !--nbrace) { i=j; break; }
					}
											
				// Potential struct tag
				} else if (i1-i>=9 && !memcmp(text+i,"struct",6) && isspace(text[i+6])) {
					i+=7; while (isspace(text[i])) i++;
					size_t i0tag=i; while (isalnum_(text[i])) i++;
					if (i0tag == i) continue;
					if(/*finishedac=*/addacw(nw,w,i-i0tag,text+i0tag))return 0; /*goto endautocorrect;*/
				}
			}
			//finishedac = 1;
			goto gotcontendersac;
		} endstructac:;
								
		// Get general suggestions
		{
									
			// Add keywords
			// Generated: printf '\t\t\t'; for kw in alignof break case continue default do else for goto if return sizeof switch while; do printf 'if(/*finishedac=*/addacw(nw,w,%s,(uint8_t*)"%s"))return 0;/*goto endautocorrect;*/' ${#kw} $kw; done
			if(/*finishedac=*/addacw(nw,w,7,(uint8_t*)"alignof"))return 0;/*goto endautocorrect;*/if(/*finishedac=*/addacw(nw,w,5,(uint8_t*)"break"))return 0;/*goto endautocorrect;*/if(/*finishedac=*/addacw(nw,w,4,(uint8_t*)"case"))return 0;/*goto endautocorrect;*/if(/*finishedac=*/addacw(nw,w,8,(uint8_t*)"continue"))return 0;/*goto endautocorrect;*/if(/*finishedac=*/addacw(nw,w,7,(uint8_t*)"default"))return 0;/*goto endautocorrect;*/if(/*finishedac=*/addacw(nw,w,2,(uint8_t*)"do"))return 0;/*goto endautocorrect;*/if(/*finishedac=*/addacw(nw,w,4,(uint8_t*)"else"))return 0;/*goto endautocorrect;*/if(/*finishedac=*/addacw(nw,w,3,(uint8_t*)"for"))return 0;/*goto endautocorrect;*/if(/*finishedac=*/addacw(nw,w,4,(uint8_t*)"goto"))return 0;/*goto endautocorrect;*/if(/*finishedac=*/addacw(nw,w,2,(uint8_t*)"if"))return 0;/*goto endautocorrect;*/if(/*finishedac=*/addacw(nw,w,6,(uint8_t*)"return"))return 0;/*goto endautocorrect;*/if(/*finishedac=*/addacw(nw,w,6,(uint8_t*)"sizeof"))return 0;/*goto endautocorrect;*/if(/*finishedac=*/addacw(nw,w,6,(uint8_t*)"switch"))return 0;/*goto endautocorrect;*/if(/*finishedac=*/addacw(nw,w,5,(uint8_t*)"while"))return 0;/*goto endautocorrect;*/
									
			// Get tokens from previous text
			size_t i1 = cur==0 ? w-text : ntext;
			for (size_t i=0; i<i1; i++) {
				if (appg->ntype || appg->ispendingbackspace) return 1;
				if (cur==0 && eattokenskip(&i,i1)) continue;
								
				// Remember enum values
				if (i>=4 && text[i]=='{') {
									
					// Confirm enum name? {
					size_t j = i;
					while (j && isspace(text[j-1])) j--;
					if (j < 4) goto endenumac;
					if (!memcmp(text+j-4,"enum",4) && (j==4||!isalnum_(text[j-5]))) goto isenumac;
					size_t i1name = j;
					while (j>=5 && isalnum_(text[j-1])) j--;
					if (j<5 || j==i1name) goto endenumac;
					while (j && isspace(text[j-1])) j--;
					if (j < 4) goto endenumac;
					if (memcmp(text+j-4,"enum",4) || (j!=4&&isalnum_(text[j-5]))) goto endenumac;
					isenumac:;
									
					// Store every enum name
					j=i+1;
					while (j < i1) {
										
						// Add name to list
						while (j<i1 && (eattokenskip(&j,i1)||isspace(text[j]))) j++;
						for (i1name=j; i1name<i1&&isalnum_(text[i1name]); i1name++);
						if (i1name > j) if (/*finishedac=*/addac(nw,w,j)) return 0; //goto endautocorrect;
										
						// Eat til next name
						size_t nbrace=0,nparen=0;
						for (; j < i1; j++) {
							if (eattokenskip(&j,i1)) continue;
							if (!nbrace && !nparen) {
								if (text[j] == ',') { j++; break; }
								if (text[j] == '}') goto endenumac;
							}
							switch (text[j]) {case'{':nbrace++;break;case'}':nbrace--;break;case'(':nparen++;break;case')':nparen--;break;}
						}
					}
				} endenumac:;
								
				// text: { skip if doesn't contain iw
				if (cur==0 && text[i]=='{') {
					for (size_t j=i+1, nbrace=1; j<i1; j++) {
						if (eattokenskip(&j,i1)) continue;
						if (text[j] == '{') nbrace++;
						else if (text[j]=='}' && !--nbrace) { i=j; break; }
					}
			
				// Potential word start
				} else if (cur==0 ? isalpha(text[i])||text[i]=='_' : !ispunct(text[i])&&!isspace(text[i])) {
					if (/*finishedac=*/addac(nw,w,i)) return 0; //goto endautocorrect;
					
					// Increment past word
					size_t n2=1; while (i+n2<ntext && (cur==0 ? isalnum_(text[i+n2]) : !ispunct(text[i+n2])&&!isspace(text[i+n2]))) n2++;
					i += n2 - 1;
				}
			}
			//finishedac = 1;
		}
	} gotcontendersac:;
	//for (size_t i=0; i<nisac; i++) df("%zu %.*s", countsac[i], (int)(nsac[i]), text+isac[i]);

	// Put top 5 in order
	for (size_t i=0; i<nisac; i++)
		for (size_t j=0; j<i && j<5; j++)
			if (distsac[i]<distsac[j] || countsac[i] > countsac[j]) {
				size_t count=countsac[i],n=nsac[i]; uint8_t disti=distsac[i],*wac=wsac[i];
				memmove(wsac+j+1,wsac+j,sizeof(uint8_t*)*(i-j)), memmove(nsac+j+1,nsac+j,sizeof(size_t)*(i-j)), memmove(countsac+j+1,countsac+j,sizeof(size_t)*(i-j)), memmove(distsac+j+1,distsac+j,sizeof(uint8_t)*(i-j));
				wsac[j]=wac, nsac[j]=n, countsac[j]=count, distsac[j]=disti;
			}
	return 0;
}

void*
android_app_entry(void* param)
{
	struct android_app* app = (struct android_app*)param;

	app->config = AConfiguration_new();
	AConfiguration_fromAssetManager(app->config, app->activity->assetManager);

	print_cur_config(app);

	app->cmdPollSource.id = LOOPER_ID_MAIN;
	app->cmdPollSource.app = app;
	app->cmdPollSource.process = process_cmd;
	app->inputPollSource.id = LOOPER_ID_INPUT;
	app->inputPollSource.app = app;
	app->inputPollSource.process = process_input;

	ALooper* looper = ALooper_prepare(ALOOPER_PREPARE_ALLOW_NON_CALLBACKS);
	ALooper_addFd(looper, app->msgread, LOOPER_ID_MAIN, ALOOPER_EVENT_INPUT, NULL,
			&app->cmdPollSource);
	app->looper = looper;

	pthread_mutex_lock(&app->mutex);
	app->running = 1;
	pthread_cond_broadcast(&app->cond);
	pthread_mutex_unlock(&app->mutex);

	//android_main(app);
	nsstartup = getns();
	fdf = freopen("/storage/emulated/0/Android/data/com.vulkan.tutorials.sixcsim/files/log.txt", "a", stderr);
	//df("test..");
	if (chdir("/storage/emulated/0/Android/data/com.vulkan.tutorials.sixcsim/files/")) { perror("mednative: chdir"); exit(EXIT_FAILURE); }
	//char pwd[2048]; if (!getcwd(pwd,sizeof(pwd))) return NULL;
	//df("%s", pwd);
	//DIR *dir = opendir(".");
	//			if (dir) {
	//				struct dirent *entry;
	//				while (errno=0, entry=readdir(dir)) {
	//					df("%s", entry->d_name);
	//				}
	//				if (errno) {  df("readdir '%s'",".");  }
	//			} else if (errno != ENOENT) { df("opendir '%s'",".");  }

	// Set the callback to process system events
	app->onAppCmd = handle_cmd;

	// Used to poll the events in the main loop
	int events;
	struct android_poll_source* source;
	
	// Restore app state
	if (app->savedStateSize) {
		df("restoring app state %zu", app->savedStateSize);
		
		// Load file from disk
		FILE *f = fopen(pathsavestate, "r");
		if (!f && errno==ENOENT);
		else if (!f) { Perror("medcn: fopen savestate"); exit(EXIT_FAILURE); }
		else {
			ensuren(&sizetext, 0, (void**)&text, ntext=getsizefile(f));
			fread(text, 1, ntext, f);
			if (ferror(f)) { Perror("medcn: fread savestate"); exit(EXIT_FAILURE); }
			fclose(f);
		}
		
		// Load state from memory
		size_t ibuf = 0;
		#define BUFST ((uint8_t*)app->savedState)
		{char hs[32];for (int i=0; i<sizeof(hs)/2; i++) hs[2*i]=hexc0(BUFST[i]),hs[2*i+1]=hexc1(BUFST[i]);df(" %.*s",sizeof(hs),hs);}
		#define GETN(n) { \
			/*df(" GETN "#n); char hs[sizeof(n)*2]; for(int i=0;i<sizeof(n);i++)hs[2*i]=hexc0(BUFST[ibuf+i]),hs[2*i+1]=hexc1(BUFST[ibuf+i]); df("  %.*s",sizeof(n)*2,hs);*/ \
			int64_t m = -((int64_t)1<<((8*sizeof(n))-2)) * 2; \
			for (size_t i=0; i<sizeof(n); i++) m+=(uint64_t)BUFST[ibuf++]<<(8*i); \
			n = m; \
			/*df("  %"PRId64" (%"PRId64")", (int64_t)n,(int64_t)m);*/ \
		}
		#define GETF(x) { \
			char *p; x=strtod((char*)BUFST+ibuf,&p); \
			ibuf = p - (char*)BUFST + 1; \
		}
		#define GETBUF(buf) { \
			uint64_t sizebuf; GETN(sizebuf) \
			if (!(buf=malloc(sizebuf))) { fprintf(stderr,"medcn: malloc GETBUF %zu: %s\n",sizebuf,strerror(errno)); exit(EXIT_FAILURE); } \
			uint64_t nbuf; GETN(nbuf) \
			memcpy(buf,BUFST+ibuf,nbuf); ibuf+=nbuf; \
		}
		//TODO: store num+-MIN, restore MIN+each
		//eg store u8 128+n; s8=-128;for ... s8+=; n=s8
		{
/* GEN
exec 2>&1
<c/AndroidMain.c sed -n '/^\/\/ Start of saved state/,/^\/\/ End of saved state/p' | awk "$(<<\! cat
/^	*\/\//{ printf("\n%s\n",$0); next; }
/^typedef /{next}
/^union /{next}
{
	i = 1;

	# Handle definitions
	if (indef) {
		if (substr($1,1,1) == "}") { indef=0; i++; }
		else next;
	} else if ($1 == "enum") {
		type = "N";
		indef=1; next;
	} else if ($i == "struct") {
		type = "STRUCT";
		if ($NF == "{") { indef=1; next; }
		else for (i=3; substr($(i-1),length($(i-1)))!="}"; i++);
	}

	# Update type
	if ($1=="char" || $1=="uint64_t" || $1=="unsigned" || $1=="enum" || $1=="long" || $1=="size_t" || $1=="uint8_t") {
		type="N"; i++;
	} else if ($1=="float" || $1=="double") { type="F"; i++; }

	# Print each variable
	for (; i<=NR; i++) {
	
		# Clean or skip
		if (substr($i,1,2) == "//") next;
		if ($i == "=") { i++; continue; }
		if (!length($i) || substr($i,1,1)~/[0-9-]/)
			continue;
		if (substr($i,length($i)) ~ /[,;]/) $i=substr($i,1,length($i)-1);
		if ($i=="INFINITY" || $i=="UINT64_MAX" || $i=="SIZE_MAX" || $i=="NULL") continue;
		sub("=.*", "", $i);
		
		# Handle buffer
		if (substr($i,1,1) == "*")
			printf("GETBUF(%s)\n", substr($i,2));
		
		# Handle number
		else
			printf("GET%s(%s)\n", type, $i);
	}
}
!
)" | sed 's,^,			,'
*/
			
			// Start of saved state sections
			GETN(needsredraw)
			GETN(needsredrawcur)
			GETN(needsredrawkb)
			GETN(isuptap)
			GETN(isupswipelr)
			GETN(isdown)
			GETN(justbraced)
			GETN(isselectinglines)
			GETN(showntab)
			GETN(shownac)
			GETN(isenterafterblock)
			GETN(ispasteafterblock)
			GETN(iscutblock)
			GETN(iscopyblock)
			GETF(xdown)
			GETF(ydown)
			GETF(yscr)
			GETF(ytopdown)
			GETF(ymoveprev)
			GETF(yvelocity)
			GETF(xcolud)
			GETF(y0tab)
			GETF(ybottomov)
			GETN(nsdown)
			GETN(nsstartup)
			GETN(nsmoveprev)
			GETN(nsflingprev)
			GETN(stateovvert)
			GETN(statekbvert)
			GETN(vwinsize)
			GETN(overlay)
			GETN(overlaypremain)
			GETN(overlayverted)
			GETN(mssaved)
			GETN(msensurekeyboard)
			GETN(hframe)
			GETN(hframeoverride)
			GETN(msoverridehframe)
			GETN(hframeovverted)
			GETN(icurvert)
			
			// Making function from selection
			GETN(inamemkfn)
			
			// Renaming
			GETN(irenaming)
			GETN(nrenamed)
			GETN(sizerenamed)
			GETN(vtextrenaming)
			GETBUF(bufrenamed)
			
			// Replace
			GETN(nreplace)
			GETN(sizeisreplace)
			GETBUF(isreplace)
			GETBUF(replaces)
			GETN(i0replace)
			GETN(i1replace)
			GETN(nreplaced)
			GETN(nflowreplace)
			GETN(sizeflowreplace)
			GETBUF(isflowreplace)
			GETN(nbufreplace0)
			GETN(sizebufreplace0)
			GETBUF(bufreplace0)
			GETN(nbufreplace1)
			GETN(sizebufreplace1)
			GETBUF(bufreplace1)
			
			// Flow indices
			GETN(nflow)
			GETN(sizeflows)
			GETBUF(isflow)
			
			// Multi cursors
			GETN(nmulti)
			GETN(sizemulti)
			GETBUF(multis)
			GETN(imultistart)
			GETN(nflowmulti)
			GETN(sizeflowmulti)
			GETBUF(isflowmulti)
			GETN(nbufmulti)
			GETN(sizebufmulti)
			GETBUF(bufmulti)
			
			// Cursor location
			GETN(icur)
			GETN(curshown)
			GETN(cur)
			GETN(phasecur)
			
			// Undo
			GETN(nundo)
			GETN(sizeundo)
			GETBUF(undos)
			GETN(idchainundo)
			GETN(isundoing)
			
			// Positions in the blocks
			
			// Selecting
			GETN(iselectstart)
			GETN(iselectend)
			GETN(curselect)
			
			// Spacing out info
			GETF(xdowntaptextprev)
			GETF(ydowntaptextprev)
			GETN(nsdowntaptextprev)
			GETF(x0spacing)
			GETN(ilspaced)
			
			// Search buffer
			GETN(nsearch)
			GETN(sizesearch)
			GETBUF(bufsearch)
			GETN(vsearch)
			GETN(itoppresearch)
			GETN(icurpresearch)
			GETF(ytoppresearch)
			
			// Positions in the search results
			
			// Cached search results, last is ntext
			GETN(vtextsearchresults)
			GETN(vsearchsearchresults)
			GETN(vwinsizesearchresults)
			GETN(nsearched)
			GETN(sizeissearchresults)
			GETN(nissearchresults)
			GETN(sectionssearched)
			GETN(isrlabels)
			GETN(isrdirect)
			GETBUF(issearchresults)
			GETBUF(typessearchresults)
			
			// Positions in the text+screen
			
			// Top of screen
			GETN(itop)
			GETN(isrtop)
			GETN(irowtop)
			GETF(ytop)
			
			// Cached syntax states
			GETN(sizesynsts)
			GETN(nsynsts)
			GETBUF(synsts)
			
			// Text state
			GETN(vtext)
			GETN(vtextsaved)
			
			// Expanded lines
			GETN(nilexps)
			GETN(sizeilexps)
			GETBUF(ilexps)
			GETBUF(exps)
			
			// End of saved state sections
//ENDGEN

			// Blocks
			size_t ibuf0=ibuf;
			uint64_t num; GETN(num) sizeblocks=num;
			GETN(num) nblocks=num/sizeof(struct block);
			ibuf = ibuf0;
			GETBUF(blocks)
			for (struct block *b=blocks;;) {
				if (b->nblocks) {
					GETBUF(b->blocks)
					setparents(1, b);
					b = b->blocks;
				} else {
					while (b == (b->parent?b->parent->blocks+b->parent->nblocks:blocks+nblocks)-1) {
						if (!b->parent) goto endreadblocks;
						b = b->parent;
					}
					b++;
				}
			} endreadblocks:;
			
			// Expand buffers
			for (struct expanse *exp=exps; exp<exps+nilexps; exp++) {
				if (!(exp->orig=malloc(exp->norig))) {fprintf(stderr,"medcn: malloc restore exp %zu: %s\n",exp->norig,strerror(errno));exit(EXIT_FAILURE);}
				memcpy(exp->orig,BUFST+ibuf,exp->norig); ibuf+=exp->norig;
			}
		}
		#undef BUFST
		#undef GETN
		#undef GETF
		#undef GETBUF
		
	// Initialize app state
	} else {

		// Read maybe file into text buffer
		FILE *f = fopen(pathopen, "r");
		if (!f && errno==ENOENT);
		else if (!f) { Perror("medcn: fopen"); exit(EXIT_FAILURE); }
		else {
			ensuren(&sizetext, 0, (void**)&text, ntext=getsizefile(f));
			fread(text, 1, ntext, f);
			if (ferror(f)) { Perror("medcn: fread"); exit(EXIT_FAILURE); }
			fclose(f);
		}
		df("read file: ntext: %zu", ntext);

		// Get blocks
		blockize(0, ntext, &sizeblocks, &nblocks, &blocks, 0);
		if (nblocks == 1) blocks->expanded=1;
		printblocks(nblocks, blocks, stderr);
	}

	// Initialize font
#if 0
	{

		// Load font
		appendfont("/system/fonts/DroidSans.ttf");

		// Get ASCII bitmap
		{

			// Find dimensions needed for ascii bitmap
			wbmascii=0, hbmascii=0;
			scalefont = stbtt_ScaleForPixelHeight(&font, pxhfont);
			fprintf(stderr, "scalefont: %f\n", scalefont);
			int ascent,descent,linegap; stbtt_GetFontVMetrics(&font,&ascent,&descent,&linegap);
			fprintf(stderr, "asc,desc,linegap %d,%d,%d\n", ascent, descent, linegap);
			for (int cp=32; cp<=126; cp++) {
				int x0,y0,x1,y1; stbtt_GetCodepointBitmapBox(&font,cp,scalefont,scalefont,&x0,&y0,&x1,&y1);
				int h = y1 - y0 + 2;
				wbmascii+=x1-x0+2, hbmascii=h>hbmascii?h:hbmascii;
			}
			fprintf(stderr, "bmascii %dx%d\n", wbmascii, hbmascii);

			// Bake it
			bmascii = (uint8_t*)malloc(wbmascii*hbmascii); if (!bmascii) { fprintf(stderr,"D3D12HelloTexture: malloc ascii bitmap (%dx%d): %s\n",wbmascii,hbmascii,strerror(errno)); exit(EXIT_FAILURE); }
			stbtt_pack_context spc; if (!stbtt_PackBegin(&spc,(unsigned char*)bmascii,wbmascii,hbmascii,0,1,NULL)) { fputs("D3D12HelloTexture: stbtt_PackBegin failed\n",stderr); exit(EXIT_FAILURE); }
			fputs("packing\n", stderr);
			if (!stbtt_PackFontRange(&spc,(const unsigned char*)buffont,0,pxhfont,32,95,charsascii)) { fputs("D3D12HelloTexture: stbtt_PackFontRange failed\n",stderr); exit(EXIT_FAILURE); }
			stbtt_PackEnd(&spc);
			fputs("done packing\n", stderr);
			for (int i=0; i<wbmascii*hbmascii; i++) if (bmascii[i]) { fputs("got nonzero font pixel\n",stderr); break; } else if (i==wbmascii*hbmascii-1) { fputs("font is all zeroes\n",stderr); exit(EXIT_FAILURE); }
		}
	}
#endif

	// Vertex positions
	if (!(vertstext=malloc(sizevertstext))) { Perror("medcn: malloc vertices text"); exit(EXIT_FAILURE); }
	if (!(vertsblks=malloc(sizevertsblks))) { Perror("medcn: malloc vertices blks"); exit(EXIT_FAILURE); }
	if (!(vertscur=malloc(sizevertscur))) {Perror("medcn: malloc vertices cur");exit(EXIT_FAILURE);}
	if (!(vertstextov=malloc(sizevertstextov))) { Perror("medcn: malloc vertices textov"); exit(EXIT_FAILURE); }
	if (!(vertsbackov=malloc(sizevertsbackov))) { Perror("medcn: malloc vertices backov"); exit(EXIT_FAILURE); }
	if (!(vertsbtnov=malloc(sizevertsbtnov))) { Perror("medcn: malloc vertices btnov"); exit(EXIT_FAILURE); }
	if (!(vertsexp=malloc(sizevertsexp))) { Perror("medcn: malloc vertices exp"); exit(EXIT_FAILURE); }
	if (!(vertsselect=malloc(sizevertsselect))) { Perror("medcn: malloc vertices select"); exit(EXIT_FAILURE); }
	if (!(vertstextkb=malloc(sizevertstextkb))) { Perror("medcn: malloc vertices textkb"); exit(EXIT_FAILURE); }
	if (!(vertsbackkb=malloc(sizevertsbackkb))) { Perror("medcn: malloc vertices backkb"); exit(EXIT_FAILURE); }
	if (!(vertsbtnkb=malloc(sizevertsbtnkb))) { Perror("medcn: malloc vertices btnkb"); exit(EXIT_FAILURE); }
	if (!(vertsflow=malloc(sizevertsflow))) { Perror("medcn: malloc vertices flow"); exit(EXIT_FAILURE); }
	if (!(vertsund=malloc(sizevertsund))) {Perror("medcn: malloc vertices und");exit(EXIT_FAILURE);}

	// Main loop
	int ndfloop = ndf - 1;
	do {
		if (ndf != ndfloop) df("%.3f main loop", et(getns()));
		ndfloop = ndf;
		ensurekeyboardifneeded();
		if (ALooper_pollAll(initialized_, NULL, &events, (void**)&source) >= 0)
			if (source != NULL) source->process(app, source);

		// Fling
		if (!isdown && yvelocity) {
			//df("%.3f: fling @%.6fpx/s ytop%.2f", et(getns()), yvelocity, ytop);
			if (yvelocity<-8000)yvelocity=-8000; else if (yvelocity>8000)yvelocity=8000;
			uint64_t ns = getns();
			if (nsflingprev == UINT64_MAX) nsflingprev=nsmoveprev;
			double dt = (ns-nsflingprev) * 1.0e-9;
			char negvel = yvelocity < 0;
			double a = (negvel?1:-1) * 30000.0;
			double dy = yvelocity*dt + (0.5*a*dt*dt);
			nsflingprev = ns;
			if (fabs(yvelocity+=a*dt)<5 || negvel!=(yvelocity<0)) yvelocity=0.0;
			if (xdown > displaySize_.width*0.667) {
				ytop += dy;
				ensurescroll();
				df(" dt%.6f a%.6f dy%.6f ytop%.2f", dt, a, dy, ytop);
				needsredraw = 1;
			}
		}

		// render if vulkan is ready
		if (initialized_) {
			//df("rendering");
			VkResult res;

			// Redraw
			if (vtextvert != vtext) needsredraw=1;
			while (1) {
				
				// Fill bitmap with needed glyphs
				for (struct arrcps *arrtodo=cpsstodo; arrtodo<cpsstodo+ncpsstodo; arrtodo++) if (arrtodo->n) {
					needsredraw = 1;
					size_t ng = arrtodo - cpsstodo + 1;
					df("glyph lookup: len %zu (%zu)", ng, arrtodo->n);
					for(uint32_t *cp=arrtodo->cps;cp<arrtodo->cps+arrtodo->n*ng;cp+=ng)for(size_t i=0;i<ng;i++)dfnl(i?",%"PRIx32:" %"PRIx32,cp[i]); df("");
					if (nglyphss < ng) {if (!(glyphss=realloc(glyphss,ng*sizeof(*glyphss)))) {fprintf(stderr,"medcn: realloc glyphss %zu: %s\n",ng*sizeof(*glyphss),strerror(errno));exit(EXIT_FAILURE);}memset(glyphss+nglyphss,0,sizeof(*glyphss)*(ng-nglyphss));nglyphss=ng;}
					struct arrglyphs *arrglyphs = glyphss + ng-1;
					
					// Allocate space for new glyphs
					if (!(arrglyphs->glyphs=realloc(arrglyphs->glyphs,sizeof(*arrglyphs->glyphs)*(arrglyphs->n+arrtodo->n)))) {fprintf(stderr,"medcn: realloc arrglyphs->glyphs %zu: %s\n",arrglyphs->n+arrtodo->n,strerror(errno));exit(EXIT_FAILURE);}
					if (!(arrglyphs->cps=realloc(arrglyphs->cps,sizeof(*arrglyphs->cps)*ng*(arrglyphs->n+arrtodo->n)))) {fprintf(stderr,"medcn: realloc arrglyphs->cps %zu: %s\n",arrglyphs->n+arrtodo->n,strerror(errno));exit(EXIT_FAILURE);}
	
					// Convert to UTF-16
					uint16_t sutf16[arrtodo->n*ng*2]; size_t nsutf16=0; for (uint32_t *cps=arrtodo->cps; cps<arrtodo->cps+arrtodo->n*ng; cps++)
						if (*cps <= 0xffff) sutf16[nsutf16++]=*cps;
						else {
							uint32_t Up = *cps - 0x10000;
							sutf16[nsutf16++] = 0xd800 + ((Up>>10)&0x3ff);
							sutf16[nsutf16++] = 0xdc00 + (Up&0x3ff);
						}
	
					// Load all the text
					for (uint16_t *s=sutf16; s<sutf16+nsutf16;) {
						
						// See what font Android suggests
						void *matcher = AFontMatcher_createc();
						uint32_t nmatch; void *afont=AFontMatcher_matchc(matcher,"system-ui",s,nsutf16-(s-sutf16),&nmatch);
						AFontMatcher_destroyc(matcher);
						char *pathfont = AFont_getFontFilePathc(afont);
						
						// Load that font
						struct font *font; for (font=fonts; font<fonts+nfonts; font++) if (!strcmp(pathfont,font->path)) break;
						if (font == fonts+nfonts) {
							df("new font: %s",pathfont);
							FILE *f=fopen(pathfont,"r"); if (!f) {fprintf(stderr,"D3D12HelloTexture: fopen font %s: %s\n",pathfont,strerror(errno));exit(EXIT_FAILURE);}
							size_t nbuffont = getsizefile(f);
							char *buffont = malloc(nbuffont); if (!buffont) { fprintf(stderr,"medcn: malloc font %zu %s: %s\n",nbuffont,pathfont,strerror(errno)); exit(EXIT_FAILURE); } // held onto by the font structure
							size_t r = fread(buffont, 1, nbuffont, f); if (ferror(f)) { Perror("D3D12HelloTexture: fread font"); exit(EXIT_FAILURE); }if (r < nbuffont) { fprintf(stderr,"D3D12HelloTexture: short read font: %zu<%zu\n",r,nbuffont); exit(EXIT_FAILURE); }
							fclose(f);
							if (!(fonts=realloc(fonts,sizeof(*fonts)*(nfonts+1)))) {fprintf(stderr,"medcn: realloc fonts %zu: %s\n",nfonts+1,strerror(errno));exit(EXIT_FAILURE);}
							font = fonts + nfonts++;
							if (!stbtt_InitFont(&font->font,(const unsigned char*)buffont,0)) { fputs("D3D12HelloTexture: stb_InitFont failed\n",stderr); exit(EXIT_FAILURE); }
							if (!(font->path=malloc(strlen(pathfont)+1))) {perror("medcn: malloc font path");exit(EXIT_FAILURE);}
							strcpy(font->path, pathfont);
							font->scale = stbtt_ScaleForPixelHeight(&font->font, pxhfont);
							df(" scale: %f",font->scale);
						}
						AFont_closec(afont);
						
						// Add all matches to the texture
						df("font matched %"PRIu32, nmatch);
						uint16_t *endmatch = s + nmatch;
						while (s < endmatch) {
							
							// Decode codepoints
							uint32_t cps[ng]; for (size_t icp=0; icp<ng; icp++) {
								uint32_t cp = *s++;
								if (cp > 0xffff) cp=((cp&0x3ff)<<10)|(*s++&0x3ff);
								cps[icp] = cp;
							}
							for(size_t i=0;i<ng;i++)dfnl(i?",%"PRIx32:"decoded %"PRIx32,cps[i]); df("");
							
							// Get bitmap TODO
							int x0,x1,y0,y1; stbtt_GetCodepointBitmapBox(&font->font,*cps,font->scale,font->scale,&x0,&y0,&x1,&y1);
							int w=x1-x0, h=y1-y0;
							static size_t sizebmcp = 0;
							static uint8_t *bmcp = NULL;
							if (sizebmcp<w*h && !(bmcp=realloc(bmcp,sizebmcp=w*h))) {fprintf(stderr,"medcn: realloc bmcp %zu: %s\n",sizebmcp,strerror(errno));exit(EXIT_FAILURE);}
							stbtt_MakeCodepointBitmap(&font->font, bmcp, w, h, w, font->scale, font->scale, *cps);
							df("add glyph %c (%"PRIx32") %d,%d - %d,%d", (char)(*cps&0x7f), *cps, x0, y0, x1, y1);
							//if (cp == 'Y') df("add Y %d,%d - %d,%d",x0,y0,x1,y1);
							//if (cp == 'Y') df(" font: %s",font->path);
							//if (cp == 'Y') df(" scale: %f",font->scale);
							
							// Add to texture
							if (xnextbmfont+w > wbmfont) {
								if (ynextrowbmfont+500>hbmfont && !(bmfont=realloc(bmfont,wbmfont*(hbmfont=hbmfont?hbmfont*2:1024)))) {fprintf(stderr,"medcn: realloc bmfont %dx%d: %s\n",wbmfont,hbmfont,strerror(errno));exit(EXIT_FAILURE);}
								xnextbmfont=0, ynextbmfont=ynextrowbmfont;
							}
							if (xnextbmfont+w>wbmfont || ynextbmfont+h>hbmfont) {fprintf(stderr,"medcn: glyph too big U+%"PRIx32" %dx%d\n",*cps,w,h);exit(EXIT_FAILURE);}
							for (int x=0; x<w; x++) for (int y=0; y<h; y++) bmfont[(ynextbmfont+y)*wbmfont+xnextbmfont+x]=bmcp[y*w+x];
							xnextbmfont+=w; if (ynextbmfont+h > ynextrowbmfont) ynextrowbmfont=ynextbmfont+h;
							
							// Add to arrglyphs->glyphs
							size_t iglyph = getibsnu32(ng, cps, arrglyphs->n, arrglyphs->cps);
							if (iglyph < arrglyphs->n) memmove(arrglyphs->cps+(iglyph+1)*ng,arrglyphs->cps+iglyph*ng,sizeof(*arrglyphs->cps)*ng*(arrglyphs->n-iglyph)),memmove(arrglyphs->glyphs+iglyph+1,arrglyphs->glyphs+iglyph,sizeof(*arrglyphs->glyphs)*(arrglyphs->n-iglyph));
							memcpy(arrglyphs->cps+iglyph*ng, cps, sizeof(*cps)*ng);
							int adv,lsb; stbtt_GetCodepointHMetrics(&font->font,*cps,&adv,&lsb);
							arrglyphs->glyphs[iglyph] = (struct glyph){.x0=xnextbmfont-w,.x1=xnextbmfont,.y0=ynextbmfont,.y1=ynextbmfont+h,.offx=x0,.offy=y0,.adv=adv*font->scale};
							//if (cp == 'Y') df(" glyph i%zu %d,%d - %d,%d",iglyph,arrglyphs->glyphs[iglyph].x0,arrglyphs->glyphs[iglyph].y0,arrglyphs->glyphs[iglyph].x1,arrglyphs->glyphs[iglyph].y1);
							arrglyphs->n++;
						}
						//s += nmatch;
					}
					arrtodo->n = 0;
				}
					
				// Update the texture
				size_t nglyphs=0; for (struct arrglyphs *arr=glyphss; arr<glyphss+nglyphss; arr++) nglyphs+=arr->n;
				if (nglyphs != nglyphstex) {
					df("%.3f updating texture...", et(getns()));
					VkPhysicalDeviceMemoryProperties gpuMemoryProperties_;
					vkGetPhysicalDeviceMemoryProperties(gpuDevice_, &gpuMemoryProperties_);
					int imgWidth=wbmfont, imgHeight=hbmfont;
					VkImageLayout layout0 = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
					
					// Create new texture if resized
					if (wbmfont*hbmfont != sizeimagetex) {
						layout0 = VK_IMAGE_LAYOUT_PREINITIALIZED;
						
						// Destroy old texture
						if (sizeimagetex) destroytexturefont();
						
						// Create new texture
						sizeimagetex = wbmfont * hbmfont;
						{
							{
				
								// Check for linear supportability
								VkFormatProperties props;
								bool needBlit = true;
								vkGetPhysicalDeviceFormatProperties(gpuDevice_, VK_FORMAT_R8G8B8A8_UNORM, &props);
								assert((props.linearTilingFeatures | props.optimalTilingFeatures) &
												VK_FORMAT_FEATURE_SAMPLED_IMAGE_BIT);
								if (props.linearTilingFeatures & VK_FORMAT_FEATURE_SAMPLED_IMAGE_BIT) {
									// linear format supporting the required texture
									needBlit = false;
								}
				
								// Read the file:
								unsigned char *imageData = bmfont;
								//tex_width = imgWidth;
								//tex_height = imgHeight;
				
								// Allocate the linear texture so texture could be copied over
								VkImageCreateInfo image_create_info = {
										.sType = VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO,
										.pNext = NULL,
										.flags = 0,
										.imageType = VK_IMAGE_TYPE_2D,
										.format = VK_FORMAT_R8G8B8A8_UNORM,
										.extent = {(imgWidth),
																(imgHeight), 1},
										.mipLevels = 1,
										.arrayLayers = 1,
										.samples = VK_SAMPLE_COUNT_1_BIT,
										.tiling = VK_IMAGE_TILING_LINEAR,
										.usage = (needBlit ? VK_IMAGE_USAGE_TRANSFER_SRC_BIT
																				: VK_IMAGE_USAGE_SAMPLED_BIT),
										.sharingMode = VK_SHARING_MODE_EXCLUSIVE,
										.queueFamilyIndexCount = 1,
										.pQueueFamilyIndices = &queueFamilyIndex_,
										.initialLayout = VK_IMAGE_LAYOUT_PREINITIALIZED
								};
								mem_alloc = (VkMemoryAllocateInfo){
										.sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO,
										.pNext = NULL,
										.allocationSize = 0,
										.memoryTypeIndex = 0
								};
								if (res=vkCreateImage(device_, &image_create_info, NULL, &imagetex)) { Fprintf(stderr,"medcn: vkCreateImage: %d\n",res); exit(EXIT_FAILURE); }
								vkGetImageMemoryRequirements(device_, imagetex, &mem_reqs);
								mem_alloc.allocationSize = mem_reqs.size;
								if (res=AllocateMemoryTypeFromProperties(mem_reqs.memoryTypeBits, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT, &mem_alloc.memoryTypeIndex, gpuMemoryProperties_)) { Fprintf(stderr,"medcn: AllocateMemoryTypeFromProperties create new: %d\n",res); exit(EXIT_FAILURE); }
								if (res=vkAllocateMemory(device_, &mem_alloc, NULL, &mem)) { Fprintf(stderr,"medcn: vkAllocateMemory: %d\n",res); exit(EXIT_FAILURE); }
								if (res=vkBindImageMemory(device_, imagetex, mem, 0)) { Fprintf(stderr,"medcn: vkBindImageMemory: %d\n",res); exit(EXIT_FAILURE); }
							}
		
							VkImageViewCreateInfo infoview = {
									.sType = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO,
									.pNext = NULL,
									.flags = 0,
									.image = VK_NULL_HANDLE,
									.viewType = VK_IMAGE_VIEW_TYPE_2D,
									.format = VK_FORMAT_R8G8B8A8_UNORM,
									.components =
											{
													VK_COMPONENT_SWIZZLE_R, VK_COMPONENT_SWIZZLE_G,
													VK_COMPONENT_SWIZZLE_B, VK_COMPONENT_SWIZZLE_A,
											},
									.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1}
							};
							if (res=vkCreateSampler(device_,
									&(VkSamplerCreateInfo) {
									.sType = VK_STRUCTURE_TYPE_SAMPLER_CREATE_INFO,
									.pNext = NULL,
									.magFilter = VK_FILTER_NEAREST,
									.minFilter = VK_FILTER_NEAREST,
									.mipmapMode = VK_SAMPLER_MIPMAP_MODE_NEAREST,
									.addressModeU = VK_SAMPLER_ADDRESS_MODE_REPEAT,
									.addressModeV = VK_SAMPLER_ADDRESS_MODE_REPEAT,
									.addressModeW = VK_SAMPLER_ADDRESS_MODE_REPEAT,
									.mipLodBias = 0.0f,
									.maxAnisotropy = 1,
									.compareOp = VK_COMPARE_OP_NEVER,
									.minLod = 0.0f,
									.maxLod = 0.0f,
									.borderColor = VK_BORDER_COLOR_FLOAT_OPAQUE_WHITE,
									.unnormalizedCoordinates = VK_FALSE
							}, NULL, &sampler)) { Fprintf(stderr,"medcn: vkCreateSampler: %d\n",res); exit(EXIT_FAILURE); }
							infoview.image = imagetex;
							if (res=vkCreateImageView(device_, &infoview, NULL, &view)) { Fprintf(stderr,"medcn: vkCreateImageView: %d\n",res); exit(EXIT_FAILURE); }
						}
						
						// Update the descriptor sets
						VkDescriptorSet descsets[] = {descsettext,descsettextov,descsettextkb};
						for (VkDescriptorSet *p=descsets; p<descsets+sizeof(descsets)/sizeof(*descsets); p++) {
							vkUpdateDescriptorSets(device_, 1,
								(VkWriteDescriptorSet[1]){{
									.sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET,
									.pNext = NULL,
									.dstSet = *p,				
									.dstBinding = 0,
									.dstArrayElement = 0,
									.descriptorCount = 1,
									.descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,
									.pImageInfo = (VkDescriptorImageInfo[1]){{
										.sampler=sampler,
										.imageView=view,
										.imageLayout=VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL
									}},
									.pTexelBufferView = NULL
								}}, 0, NULL);
						}
					}
					
					// Copy bitmap to texture
					{
						nglyphstex = nglyphs;
				
						// Check for linear supportability
						VkFormatProperties props;
						bool needBlit = true;
						vkGetPhysicalDeviceFormatProperties(gpuDevice_, VK_FORMAT_R8G8B8A8_UNORM, &props);
						assert((props.linearTilingFeatures | props.optimalTilingFeatures) &
										VK_FORMAT_FEATURE_SAMPLED_IMAGE_BIT);
						if (props.linearTilingFeatures & VK_FORMAT_FEATURE_SAMPLED_IMAGE_BIT) {
							// linear format supporting the required texture
							needBlit = false;
						}
						
						//int imgWidth=wbmfont, imgHeight=hbmfont;
						VkImageCreateInfo image_create_info = {
								.sType = VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO,
								.pNext = NULL,
								.flags = 0,
								.imageType = VK_IMAGE_TYPE_2D,
								.format = VK_FORMAT_R8G8B8A8_UNORM,
								.extent = {(imgWidth),
														(imgHeight), 1},
								.mipLevels = 1,
								.arrayLayers = 1,
								.samples = VK_SAMPLE_COUNT_1_BIT,
								.tiling = VK_IMAGE_TILING_LINEAR,
								.usage = (needBlit ? VK_IMAGE_USAGE_TRANSFER_SRC_BIT
																		: VK_IMAGE_USAGE_SAMPLED_BIT),
								.sharingMode = VK_SHARING_MODE_EXCLUSIVE,
								.queueFamilyIndexCount = 1,
								.pQueueFamilyIndices = &queueFamilyIndex_,
								//.initialLayout = VK_IMAGE_LAYOUT_PREINITIALIZED
								.initialLayout = VK_IMAGE_LAYOUT_PREINITIALIZED
						};
				
						// Read the file:
						int imgWidth=wbmfont, imgHeight=hbmfont;
						unsigned char *imageData = bmfont;
						//tex_width = imgWidth;
						//tex_height = imgHeight;
				
						{
							VkSubresourceLayout layout;
							void* data;
							vkGetImageSubresourceLayout(device_, imagetex,
								&(VkImageSubresource) {
									.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT, .mipLevel = 0, .arrayLayer = 0
								}, &layout);
							if (res=vkMapMemory(device_, mem, 0, mem_alloc.allocationSize, 0, &data)) { Fprintf(stderr,"medcn: vkMapMemory: %d\n",res); exit(EXIT_FAILURE); }
							for (int32_t y = 0; y < imgHeight; y++) {
								unsigned char* row = (unsigned char*)((char*)data + layout.rowPitch * y);
								for (int32_t x = 0; x < imgWidth; x++) {
									uint8_t grey = bmfont[y*wbmfont+x];
									row[x * 4] = grey;
									row[x * 4 + 1] = grey;
									row[x * 4 + 2] = grey;
									row[x * 4 + 3] = grey;
								}
							}
							vkUnmapMemory(device_, mem);
							//stbi_image_free(imageData);
						}
						//free(fileContent);
				
						VkImageLayout imageLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
				
				
						VkCommandPool cmdPool;
						if (res=vkCreateCommandPool(device_,
								&(VkCommandPoolCreateInfo){
								.sType = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO,
								.pNext = NULL,
								.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT,
								.queueFamilyIndex = queueFamilyIndex_
						}, NULL, &cmdPool)) { Fprintf(stderr,"medcn: vkCreateCommandPool: %d\n",res); exit(EXIT_FAILURE); }
				
						VkCommandBuffer gfxCmd;
				
						if (res=vkAllocateCommandBuffers(device_,
								&(VkCommandBufferAllocateInfo) {
								.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO,
								.pNext = NULL,
								.commandPool = cmdPool,
								.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY,
								.commandBufferCount = 1
						}, &gfxCmd)) { Fprintf(stderr,"medcn: vkAllocateCommandBuffers: %d\n",res); exit(EXIT_FAILURE); }
						if (res=vkBeginCommandBuffer(gfxCmd,
								&(VkCommandBufferBeginInfo){
								.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO,
								.pNext = NULL,
								.flags = 0,
								.pInheritanceInfo = NULL})) { Fprintf(stderr,"medcn: vkBeginCommandBuffer: %d\n",res); exit(EXIT_FAILURE); }
				
						// If linear is supported, we are done
						VkImage stageImage = VK_NULL_HANDLE;
						VkDeviceMemory stageMem = VK_NULL_HANDLE;
						//df("needblit: %d", needBlit);
						if (!needBlit) {
							df("!needBlit");
							//setImageLayout(gfxCmd, imagetex, VK_IMAGE_LAYOUT_PREINITIALIZED, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL, VK_PIPELINE_STAGE_HOST_BIT, VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT);
							setImageLayout(gfxCmd, imagetex, layout0, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL, VK_PIPELINE_STAGE_HOST_BIT, VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT);
						} else {

							// save current image and mem as staging image and memory
							stageImage = imagetex;
							stageMem = mem;
							imagetex = VK_NULL_HANDLE;
							mem = VK_NULL_HANDLE;
				
							// Create a tile texture to blit into
							image_create_info.tiling = VK_IMAGE_TILING_OPTIMAL;
							image_create_info.usage =
									VK_IMAGE_USAGE_TRANSFER_DST_BIT | VK_IMAGE_USAGE_SAMPLED_BIT;
							image_create_info.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
							if (res=vkCreateImage(device_, &image_create_info, NULL,
																		&imagetex)) { Fprintf(stderr,"medcn: vkCreateImage: %d\n",res); exit(EXIT_FAILURE); }
							vkGetImageMemoryRequirements(device_, imagetex, &mem_reqs);
				
							mem_alloc.allocationSize = mem_reqs.size;
							if (res=AllocateMemoryTypeFromProperties(
									mem_reqs.memoryTypeBits, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT,
									&mem_alloc.memoryTypeIndex, gpuMemoryProperties_)) { Fprintf(stderr,"medcn: AllocateMemoryTypeFromProperties create blit tile: %d\n",res); exit(EXIT_FAILURE); }
							if (res=vkAllocateMemory(device_, &mem_alloc, NULL, &mem)) { Fprintf(stderr,"medcn: vkAllocateMemory: %d\n",res); exit(EXIT_FAILURE); }
							if (res=vkBindImageMemory(device_, imagetex, mem, 0)) { Fprintf(stderr,"medcn: vkBindImageMemory: %d\n",res); exit(EXIT_FAILURE); }
				
							// transitions image out of UNDEFINED type
							setImageLayout(gfxCmd, stageImage, VK_IMAGE_LAYOUT_PREINITIALIZED,
															VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
															VK_PIPELINE_STAGE_HOST_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT);
							setImageLayout(gfxCmd, imagetex, VK_IMAGE_LAYOUT_UNDEFINED,
															VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
															VK_PIPELINE_STAGE_HOST_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT);
							vkCmdCopyImage(gfxCmd, stageImage, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
															imagetex, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 1,
												
														&(VkImageCopy){
									.srcSubresource = {
											.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT,
											.mipLevel = 0,
											.baseArrayLayer = 0,
											.layerCount = 1
										},
									.srcOffset = { .x = 0, .y = 0, .z = 0 },
									.dstSubresource = {
											.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT,
											.mipLevel = 0,
											.baseArrayLayer = 0,
											.layerCount = 1
										},
									.dstOffset = { .x = 0, .y = 0, .z = 0},
									.extent = { .width = imgWidth, .height = imgHeight, .depth = 1}
							});
				
							setImageLayout(gfxCmd, imagetex, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
															VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,
															VK_PIPELINE_STAGE_TRANSFER_BIT,
															VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT);
						}
				
						if (res=vkEndCommandBuffer(gfxCmd)) { Fprintf(stderr,"medcn: vkEndCommandBuffer: %d\n",res); exit(EXIT_FAILURE); }
						VkFence fence;
						if (res=vkCreateFence(device_,
								&(VkFenceCreateInfo){
								.sType = VK_STRUCTURE_TYPE_FENCE_CREATE_INFO,
								.pNext = NULL,
								.flags = 0
						}, NULL, &fence)) { Fprintf(stderr,"medcn: vkCreateFence: %d\n",res); exit(EXIT_FAILURE); }
				
						if (res=vkQueueSubmit(queue_, 1,
								&(VkSubmitInfo){
								.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO,
								.pNext = NULL,
								.waitSemaphoreCount = 0,
								.pWaitSemaphores = NULL,
								.pWaitDstStageMask = NULL,
								.commandBufferCount = 1,
								.pCommandBuffers = &gfxCmd,
								.signalSemaphoreCount = 0,
								.pSignalSemaphores = NULL
						}, fence) != VK_SUCCESS) { Fprintf(stderr,"medcn: vkQueueSubmit: %d\n",res); exit(EXIT_FAILURE); }
						if (res=vkWaitForFences(device_, 1, &fence, VK_TRUE, 100000000) !=
										VK_SUCCESS) { Fprintf(stderr,"medcn: vkWaitForFences: %d\n",res); exit(EXIT_FAILURE); }
						vkDestroyFence(device_, fence, NULL);
				
						vkFreeCommandBuffers(device_, cmdPool, 1, &gfxCmd);
						vkDestroyCommandPool(device_, cmdPool, NULL);
						if (stageImage != VK_NULL_HANDLE) {
							vkDestroyImage(device_, stageImage, NULL);
							vkFreeMemory(device_, stageMem, NULL);
						}
					}
					df("%.3f  done", et(getns()));
				}
				
				// Get overlay state
				uint64_t stateov = 0;
				if (overlay) {
					if (gethframe() != hframeovverted) needsredraw=1;
					else if (overlay != overlayverted) needsredraw=1;
					else if ((stateov=getstateoverlay()) != stateovvert) needsredraw=1;
				}
				
				// Break if no need to redraw
				if (!needsredraw) break;
				
				// Reset vertices
				nvertstext = nvertsblks = nvertsund = nvertsexp = nvertsflow = nvertsselect = 0;

				// Draw search
				if (isshowsearchresults()) {
					go((at){.x=padwin,.y=gety0search()-7}, BUF|VERTS, nsearch, bufsearch);
					appg = app;
					gosearch(attopsearch(), HEIGHT|VERTS|WIDTH, (double)displaySize_.height, (double)displaySize_.width);
					//if (app->ntype || app->ispendingbackspace) goto nextmainloop;
					if (!overlay) drawoverlaybuttons(sizeof(btnssearch)/sizeof(struct buttoninfo),btnssearch,stateov);
					
				// Draw searched line
				} else if (nsearch) {
					go((at){.x=padwin,.y=gety0search()-7}, BUF|VERTS, nsearch, bufsearch);
					
					// Get index of line in text or ntext
					char found; size_t i = getilsearch(&found);
					
					// Draw with underline
					struct block *blk; getblocki(i,&blk,NULL,1);
					for (struct block *b=blk; b; b=b->parent) if (!b->expanded) b->expanded=2;
					itop=i; ytop=displaySize_.width/3; ensurescroll();
					goblk(attopblk(), HEIGHT|VERTS|WIDTH, (double)displaySize_.height+pudb*2+hline, (double)displaySize_.width);
					if (found) {
						struct atblk pos = goblk(attopblk(), DBYTES|WIDTH, (ssize_t)i-itop, (double)displaySize_.width);
						vertund(0, pos.y+mline+hline-1, displaySize_.width, pos.y+mline+hline+1);
					}
					for (struct block *b=blk; b; b=b->parent) if (b->expanded == 2) b->expanded=0;

				// Draw text
				} else {
					goblk(attopblk(), HEIGHT|VERTS|WIDTH, (double)displaySize_.height+pudb*2+hline, (double)displaySize_.width);
				}
				vtextvert = vtext;

				// Draw overlay
				if (overlay) {
					stateovvert=-1; //TODO just remove checks around this
					
					// Main overlay
					if (overlay == OVMAIN) {
						drawoverlaybuttons(sizeof(buttons)/sizeof(struct buttoninfo), buttons, stateov);
						
					// Cancel overlay
					} else if (overlay == OVCANCEL) {
						drawoverlaybuttons(5,(struct buttoninfo[]){{0},{0},{0},{0},{{"Cancel"}}},0);
						
					// Select overlay
					} else if (overlay == OVSELECT) {
						//df("drawing select %"PRIx64, stateov);
						drawoverlaybuttons(sizeof(btnsselect)/sizeof(struct buttoninfo),btnsselect,stateov);
						
					// Replace overlay
					} else if (overlay == OVREPLACE) {
						drawoverlaybuttons(sizeof(btnsreplace)/sizeof(struct buttoninfo),btnsreplace,stateov);
						go((at){.x=padwin,.y=gethframe()-7-hline-mline-hline}, BUF|VERTS, nbufreplace0, bufreplace0);
						go((at){.x=padwin,.y=gethframe()-7-hline}, BUF|VERTS, nbufreplace1, bufreplace1);
						
					// Multi cursor choosing range overlay
					} else if (overlay == OVMULTICURSTOP) {
						drawoverlaybuttons(sizeof(btnsmulticurstop)/sizeof(struct buttoninfo),btnsmulticurstop,stateov);
						df("verted multicurstop btn%zu", nvertsbtnov);
						
					// Multi cursor neutral overlay
					} else if (overlay == OVMULTICURACT) {
						drawoverlaybuttons(sizeof(btnsmulticuract)/sizeof(struct buttoninfo),btnsmulticuract,stateov);
						
					// Multi cursor toggle lines
					} else if (overlay == OVMCTOGGLELINES) {
						drawoverlaybuttons(sizeof(btnsmctoglines)/sizeof(struct buttoninfo),btnsmctoglines,stateov);

					// Multi cursor back match
					} else if (overlay == OVMCBACKMATCH) {
						drawoverlaybuttons(sizeof(btnsmcbackmatch)/sizeof(struct buttoninfo),btnsmcbackmatch,stateov);
						go((at){.x=padwin,.y=gethframe()-7-hline}, BUF|VERTS, nbufmulti, bufmulti);
				
					// Make function
					} else if (overlay == OVMAKEFUNCTION) {
						drawoverlaybuttons(sizeof(btnsmakefunction)/sizeof(struct buttoninfo),btnsmakefunction,stateov);
					
					// Just copied
					} else if (overlay == OVCOPIED) {
						drawoverlaybuttons(sizeof(btnscopied)/sizeof(struct buttoninfo),btnscopied,stateov);

					// Just undid
					} else if (overlay == OVUNDID) {
						drawoverlaybuttons(sizeof(btnsundid)/sizeof(struct buttoninfo), btnsundid, stateov);

					// Just joined
					} else if (overlay == OVJOINED) {
						drawoverlaybuttons(sizeof(btnsjoined)/sizeof(struct buttoninfo), btnsjoined, stateov);
						
					// Tapped at start of line
					} else if (overlay == OVTAP0) {
						drawoverlaybuttons(sizeof(btnstap0)/sizeof(struct buttoninfo), btnstap0, stateov);
					}
					
					// Update overlay verted state
					overlayverted=overlay, stateovvert=stateov, hframeovverted=gethframe();
				}
				needsredraw=0, needsredrawcur=needsredrawkb=needsverttext=needsvertblks=needsvertund=needsvertexp=needsvertflow=needsvertselect=1;
				statekbvert = 0;

				// Draw multi cursor selections
				for (struct multicur *m=multis; m<multis+nmulti; m++) {
					if (m->iselect == SIZE_MAX) continue;
					size_t i0,i1; if(m->i<m->iselect)i0=m->i,i1=m->iselect; else i0=m->iselect,i1=m->i;
					if (i1 < itop) continue;
					if (i0 < itop) i0=itop;
					struct atblk pos0 = goblk(attopblk(), DBYTES|WIDTH, (ssize_t)(i0-itop), (double)displaySize_.width);
					//df("pos0.y %.2f i %zd %.9s", pos0.y, pos0.i, text+pos0.i);
					for (struct at pos={.y=pos0.y,.x=pos0.x,.i=pos0.i}; pos.i<i1;) {
						pos.row = 0;
						struct at pos2 = go(pos, DBYTES|NROWS|WIDTH, (ssize_t)(i1-pos.i), (ssize_t)1, (double)displaySize_.width);
						//df("pos2.y %.2f .x %.2f i %zd %.9s", pos2.y, pos2.x, pos2.i, text+pos2.i);
						vertselect(pos.x, pos.y, pos2.x);
						pos2.row = 0;
						pos = go(pos2, NROWS|WIDTH|XSTOP, (ssize_t)2, (double)displaySize_.width, 0.0);
						//df("pos.y %.2f i %zd %.9s", pos.y, pos.i, text+pos.i);
					}
					needsvertselect = 1;
				}

				// Draw saved indicator
				if (getms()-mssaved <= 500) go((at){.x=displaySize_.width-advs("Saved")},BUF|VERTS,5,"Saved");
				for (struct arrcps *arrtodo=cpsstodo; arrtodo<cpsstodo+ncpsstodo; arrtodo++) if (arrtodo->n) needsredraw=1;
			}
			
			// Draw cursor(s)
			if (icur != icurvert) needsredrawcur=1;
			if (needsredrawcur) {
				char curshown0 = curshown;
				nvertscur = curshown = 0;
				needsvertcur = 1;
				icurvert = icur;
					
				// Multi cursor
				if (nmulti) {
					//df("verting multi cur %zu", nmulti);
					for (size_t i=0; i<nmulti; i++) vertcur(multis[i].i);
						
				// Quick check unseen
				} else if (icur==SIZE_MAX || (cur==0&&icur<itop));
					
				// In text
				else if (cur == 0) {
					vertcur(icur);
						
				// In search
				} else if (cur == 1) {
					curshown = 1;
					double x0=go((at){.x=padwin},BUF|DBYTES,nsearch,bufsearch,icur).x, y0=gety0search()-10;
					vertcurxy(x0, y0);
					
				// In multi buffer
				} else if (cur == CURMULTI) {
					curshown = 1;
					double x0=go((at){.x=padwin},BUF|DBYTES,nbufmulti,bufmulti,icur).x, y0=gety0search()-10;
					vertcurxy(x0, y0);
					
				// In replace buffer 0
				} else if (cur == CURREPLACE0) {
					curshown = 1;
					double x0=go((at){.x=padwin},BUF|DBYTES,nbufreplace0,bufreplace0,icur).x, y0=gety0search()-mline-hline-10;
					vertcurxy(x0, y0);
					
 				// In replace buffer 1
 				} else if (cur == CURREPLACE1) {
 					curshown = 1;
 					double x0=go((at){.x=padwin},BUF|DBYTES,nbufreplace1,bufreplace1,icur).x, y0=gety0search()-10;
 					vertcurxy(x0, y0);
				}
				if (curshown && !curshown0) phasecur=getms()%500;
				//if (curshown != curshown0) curshown?showkeyboard():hidekeyboard();
				needsredrawcur=0, needsvertcur=1;
				//df("verted cur %zu (%zu)", nvertscur, nvertscur/6);
			}
			
			// Draw keyboard overlay
			if (gethframe()<displaySize_.height && (!statekbvert||(icur!=SIZE_MAX&&curshown&&(icurac!=icur||curac!=cur||vtextac!=vtext)))) needsredrawkb=1;
			if (needsredrawkb) {
				nvertstextkb = nvertsbtnkb = nvertsbackkb = 0;
				long hframe = gethframe();
				if (hframe < displaySize_.height) {
					
					// Redraw Tab
					statekbvert = 1;
					double x0=rx0tab*displaySize_.width, x1=rx1tab*displaySize_.width, y0=y0tab=hframe-hbtntab, y1=y0+hbtntab;
					vertbtnkb(x0, y0, x1, y1);
					double htext = hline;
					char *s = "Tab";
					double x0text=(x0+x1)/2-advs(s)/2, y0text=/*(y0+y1)/2-htext/2*/y1-hline-mline;
					vertbufkb(x0text, y0text+hline, strlen(s), (uint8_t*)s);
					vertbackkb(x0text, y0text, vertstextkb[nvertstextkb-1].x, y0text+hline+8);
					
					// Redraw autocorrect
					if (icur!=SIZE_MAX && curshown && !overlay) {
						
						// Recalculate autocorrect
						char recalcdauto = 0;
						//char finishedac = 0;
						if (icurac!=icur || curac!=cur || vtextac!=vtext) {
							df("%.3f recalcin autocorrect", et(getns()));
							appg = app;
							recalcdauto = 1;
							iacpre0 = 5;
	
							// Reset
							nisac = 0;
		
							// Get current word
							uint8_t *w; size_t nw; getwordcur(&w,&nw);
							if (!nw || (!cur&&isintoken(w-text)) || isdigit(*w)) {/*finishedac=1;*/goto endautocorrect;}
							//df("autocorrecting: %.*s", (int)nw, w);
							
							// Autocorrect current word
							if (appendacfor(nw, w)) goto skipautocorrect;
									
							// Add options for pre-cursor word if typed from start
							iacpre0 = nisac;
							if (istypedwordfromstart && w<text+icur && icur-(w-text)<nw && nisac<5) if (appendacfor(icur-(w-text),w)) goto skipautocorrect;
						} endautocorrect:;
						/*if (finishedac)*/ icurac=icur, curac=cur, vtextac=vtext;
						if (recalcdauto) df("%.3f  done"/* (%d)"*/,et(getns())/*,finishedac*/);
						
						// Draw autocorrect
						for (int iac=0; iac<nisac && iac<5; iac++) {
							double x0=displaySize_.width*0.2*(((int[]){2,3,1,4,0})[iac]), y0=hframe-hbtntab-hbtn;
							vertbtnkb(x0, y0, x0+displaySize_.width*0.2, y0+hbtn);
							int nlines=0; size_t is[5],ns[5]; double ws[5]; while (nlines < 5) {
								size_t i = is[nlines] = nlines?is[nlines-1]+ns[nlines-1]:0;
								struct at pos = go((at){.i=i}, BUF|DBYTES|NROWS|WIDTH, nsac[iac], wsac[iac], (ssize_t)(nsac[iac]-i), (ssize_t)1, displaySize_.width*0.2);
								ns[nlines]=pos.i-i, ws[nlines]=pos.x;
								nlines++;
								if (i+ns[nlines-1] == nsac[iac]) break;
							}
							double htext = nlines*hline + (nlines-1)*mline;
							double y0text = y0 + hbtn/2 - htext/2;
							for (int i=0; i<nlines; i++) {
								double x0text = x0 + displaySize_.width*0.1 - ws[i]/2;
								vertbufkb(x0text, y0text+hline, ns[i], wsac[iac]+is[i]);
								vertbackkb(x0text, y0text, vertstextkb[nvertstextkb-1].x, y0text+hline+8);
								y0text += hline + mline;
							}
						}
						//df("drew autocorrect nbtns %zu", nvertsbtnkb/6);
					} skipautocorrect:;
				}
				needsredrawkb=0, needsvertbtnkb=needsverttextkb=needsvertbackkb=1;
			}

			// Update vertex buffers
			if (needsvertblks && nvertsblks) {
				size_t sizecopy = nvertsblks * sizeof(struct vblks);
				void* data; if (res=vkMapMemory(device_, memvbufblks, 0, sizecopy, 0, &data)) { Fprintf(stderr,"medcn: vkMapMemory blks: %d\n",res); exit(EXIT_FAILURE); }
				memcpy(data, vertsblks, sizecopy);
				vkUnmapMemory(device_, memvbufblks);
				needsvertblks = 0;
			}
			if (needsvertund && nvertsund) {
				size_t sizecopy = nvertsund * sizeof(struct vund);
				void* data; if (res=vkMapMemory(device_, memvbufund, 0, sizecopy, 0, &data)) { Fprintf(stderr,"medcn: vkMapMemory und: %d\n",res); exit(EXIT_FAILURE); }
				memcpy(data, vertsund, sizecopy);
				vkUnmapMemory(device_, memvbufund);
				needsvertund = 0;
			}
			if (needsverttext && nvertstext) {
				size_t sizecopy = nvertstext * sizeof(struct vtext);
				void* data; if (res=vkMapMemory(device_, deviceMemory, 0, sizecopy, 0, &data)) { Fprintf(stderr,"medcn: vkMapMemory text: %d\n",res); exit(EXIT_FAILURE); }
				memcpy(data, vertstext, sizecopy);
				vkUnmapMemory(device_, deviceMemory);
				needsverttext = 0;
			}
			if (needsvertcur && nvertscur) {
				size_t sizecopy = nvertscur * sizeof(struct vcur);
				void* data; if (res=vkMapMemory(device_, memvbufcur, 0, sizecopy, 0, &data)) { Fprintf(stderr,"medcn: vkMapMemory cur: %d\n",res); exit(EXIT_FAILURE); }
				memcpy(data, vertscur, sizecopy);
				vkUnmapMemory(device_, memvbufcur);
				needsvertcur = 0;
			}
			if (needsverttextov && nvertstextov) {
				//df("copying overlay %zu", nvertstextov);
				size_t sizecopy = nvertstextov * sizeof(struct vtextov);
				void *data; if (res = vkMapMemory(device_,memvbuftextov,0,sizecopy,0,&data)) {Fprintf(stderr,"medcn: vkMapMemory textov: %d\n",res);exit(EXIT_FAILURE);}
				memcpy(data, vertstextov, sizecopy);
				vkUnmapMemory(device_,memvbuftextov);
				needsverttextov = 0;
			}
			if (needsvertbackov && nvertsbackov) {
				//df("copying overlay %zu", nvertsbackov);
				size_t sizecopy = nvertsbackov * sizeof(struct vbackov);
				void *data; if (res = vkMapMemory(device_,memvbufbackov,0,sizecopy,0,&data)) {Fprintf(stderr,"medcn: vkMapMemory backov: %d\n",res);exit(EXIT_FAILURE);}
				memcpy(data, vertsbackov, sizecopy);
				vkUnmapMemory(device_,memvbufbackov);
				needsvertbackov = 0;
			}
			if (needsvertbtnov && nvertsbtnov) {
				//df("copying overlay %zu", nvertsbtnov);
				size_t sizecopy = nvertsbtnov * sizeof(struct vbtnov);
				void *data; if (res = vkMapMemory(device_,memvbufbtnov,0,sizecopy,0,&data)) {Fprintf(stderr,"medcn: vkMapMemory btnov: %d\n",res);exit(EXIT_FAILURE);}
				memcpy(data, vertsbtnov, sizecopy);
				vkUnmapMemory(device_,memvbufbtnov);
				needsvertbtnov = 0;
			}
			if (needsvertexp && nvertsexp) {
				size_t sizecopy = nvertsexp * sizeof(struct vexp);
				void *data; if (res = vkMapMemory(device_,memvbufexp,0,sizecopy,0,&data)) {Fprintf(stderr,"medcn: vkMapMemory exp: %d\n",res);exit(EXIT_FAILURE);}
				memcpy(data, vertsexp, sizecopy);
				vkUnmapMemory(device_,memvbufexp);
				needsvertexp = 0;
			}
			if (needsvertflow && nvertsflow) {
				size_t sizecopy = nvertsflow * sizeof(struct vflow);
				void *data; if (res = vkMapMemory(device_,memvbufflow,0,sizecopy,0,&data)) {Fprintf(stderr,"medcn: vkMapMemory flow: %d\n",res);exit(EXIT_FAILURE);}
				memcpy(data, vertsflow, sizecopy);
				vkUnmapMemory(device_,memvbufflow);
				needsvertflow = 0;
			}
			if (needsvertselect && nvertsselect) {
				//df("verting select %zu", nvertsselect);
				size_t sizecopy = nvertsselect * sizeof(struct vselect);
				void *data; if (res = vkMapMemory(device_,memvbufselect,0,sizecopy,0,&data)) {Fprintf(stderr,"medcn: vkMapMemory select: %d\n",res);exit(EXIT_FAILURE);}
				memcpy(data, vertsselect, sizecopy);
				vkUnmapMemory(device_,memvbufselect);
				needsvertselect = 0;
			}
			if (needsverttextkb && nvertstextkb) {
				//df("copying kberlay %zu", nvertstextkb);
				size_t sizecopy = nvertstextkb * sizeof(struct vtextkb);
				void *data; if (res = vkMapMemory(device_,memvbuftextkb,0,sizecopy,0,&data)) {Fprintf(stderr,"medcn: vkMapMemory textkb: %d\n",res);exit(EXIT_FAILURE);}
				memcpy(data, vertstextkb, sizecopy);
				vkUnmapMemory(device_,memvbuftextkb);
				needsverttextkb = 0;
			}
			if (needsvertbackkb && nvertsbackkb) {
				//df("copying kberlay %zu", nvertsbackkb);
				size_t sizecopy = nvertsbackkb * sizeof(struct vbackkb);
				void *data; if (res = vkMapMemory(device_,memvbufbackkb,0,sizecopy,0,&data)) {Fprintf(stderr,"medcn: vkMapMemory backkb: %d\n",res);exit(EXIT_FAILURE);}
				memcpy(data, vertsbackkb, sizecopy);
				vkUnmapMemory(device_,memvbufbackkb);
				needsvertbackkb = 0;
			}
			if (needsvertbtnkb && nvertsbtnkb) {
				//df("copying kberlay %zu", nvertsbtnkb);
				size_t sizecopy = nvertsbtnkb * sizeof(struct vbtnkb);
				void *data; if (res = vkMapMemory(device_,memvbufbtnkb,0,sizecopy,0,&data)) {Fprintf(stderr,"medcn: vkMapMemory btnkb: %d\n",res);exit(EXIT_FAILURE);}
				memcpy(data, vertsbtnkb, sizecopy);
				vkUnmapMemory(device_,memvbufbtnkb);
				needsvertbtnkb = 0;
			}

			// Get the framebuffer index we should draw in
			uint32_t nextIndex;
			//df("vkAcquireNextImageKHR %d", __LINE__);
			if (res=vkAcquireNextImageKHR(device_, swapchain_,
																		UINT64_MAX, semaphore_, VK_NULL_HANDLE,
																		&nextIndex)) { Fprintf(stderr,"medcn: vkAcquireNextImageKHR: %d\n",res); exit(EXIT_FAILURE); }
			//df("vkResetFences %d", __LINE__);
			if (res=vkResetFences(device_, 1, &fence_)) { Fprintf(stderr,"medcn: vkResetFences: %d\n",res); exit(EXIT_FAILURE); }

			// Update command buffer
			{
				//df("drawing");

				// We start by creating and declare the "beginning" our command buffer
				if (res=vkBeginCommandBuffer(cmdBuffer_[nextIndex],
					&(VkCommandBufferBeginInfo){
						.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO,
						.pNext = NULL,
						.flags = 0,
						.pInheritanceInfo = NULL
					})) { Fprintf(stderr,"medcn: vkBeginCommandBuffer: %d\n",res); exit(EXIT_FAILURE); }
			
				// transition the buffer into color attachment
				//df("setImageLayout %d", __LINE__);
				setImageLayout(cmdBuffer_[nextIndex],
											 displayImages_[nextIndex],
											 //VK_IMAGE_LAYOUT_PRESENT_SRC_KHR,
											 VK_IMAGE_LAYOUT_UNDEFINED,
											 VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL,
											 VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,
											 VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT);
			
				// Now we start a renderpass. Any draw command has to be recorded in a
				// renderpass
				//df("vkCmdBeginRenderPass %d", __LINE__);
				vkCmdBeginRenderPass(cmdBuffer_[nextIndex],
					&(VkRenderPassBeginInfo){
						.sType = VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO,
						.pNext = NULL,
						.renderPass = renderPass_,
						.framebuffer = framebuffers_[nextIndex],
						.renderArea = {.offset =
															 {
																	 .x = 0, .y = 0
															 },
													 .extent = displaySize_},
						.clearValueCount = 1,
						.pClearValues = &(VkClearValue){ .color = { .float32 = { 0.0f, 0.0f, 0.0f, 1.0f}},
					}}, VK_SUBPASS_CONTENTS_INLINE);
	
				// Draw blocks
				if (nvertsblks) {
					vkCmdBindPipeline(cmdBuffer_[nextIndex], VK_PIPELINE_BIND_POINT_GRAPHICS, pipelineblks);
					//vkCmdBindDescriptorSets(cmdBuffer_[nextIndex], VK_PIPELINE_BIND_POINT_GRAPHICS, layoutblks, 0, 1, &descSetblks, 0, NULL);
					VkDeviceSize offset = 0;
					vkCmdBindVertexBuffers(cmdBuffer_[nextIndex], 0, 1, &vbufblks, &offset);
					vkCmdPushConstants(cmdBuffer_[nextIndex], layoutblks, VK_SHADER_STAGE_VERTEX_BIT, 0, sizeof(float)*2, (float[2]){(double)displaySize_.width/2,(double)displaySize_.height/-2});
					vkCmdDraw(cmdBuffer_[nextIndex], nvertsblks, 1, 0, 0);
				}
				
				// Draw underlines
				if (nvertsund) {
					vkCmdBindPipeline(cmdBuffer_[nextIndex], VK_PIPELINE_BIND_POINT_GRAPHICS, pipelineund);
					//vkCmdBindDescriptorSets(cmdBuffer_[nextIndex], VK_PIPELINE_BIND_POINT_GRAPHICS, layoutund, 0, 1, &descSetund, 0, NULL);
					VkDeviceSize offset = 0;
					vkCmdBindVertexBuffers(cmdBuffer_[nextIndex], 0, 1, &vbufund, &offset);
					vkCmdPushConstants(cmdBuffer_[nextIndex], layoutund, VK_SHADER_STAGE_VERTEX_BIT, 0, sizeof(float)*2, (float[2]){(double)displaySize_.width/2,(double)displaySize_.height/-2});
					vkCmdDraw(cmdBuffer_[nextIndex], nvertsund, 1, 0, 0);
				}

				// Draw select
				if (nvertsselect) {
					//df("drawing select %zu", nvertsselect);
					vkCmdBindPipeline(cmdBuffer_[nextIndex], VK_PIPELINE_BIND_POINT_GRAPHICS, pipelineselect);
					VkDeviceSize offset = 0;
					vkCmdBindVertexBuffers(cmdBuffer_[nextIndex], 0, 1, &vbufselect, &offset);
					vkCmdPushConstants(cmdBuffer_[nextIndex], layoutselect, VK_SHADER_STAGE_VERTEX_BIT, 0, sizeof(float)*2, (float[2]){(double)displaySize_.width/2,(double)displaySize_.height/-2});
					vkCmdDraw(cmdBuffer_[nextIndex], nvertsselect, 1, 0, 0);
				}
	
				// Draw text
				if (nvertstext) {
					vkCmdBindPipeline(cmdBuffer_[nextIndex], VK_PIPELINE_BIND_POINT_GRAPHICS, pipeline_);
					vkCmdBindDescriptorSets(cmdBuffer_[nextIndex], VK_PIPELINE_BIND_POINT_GRAPHICS, layout_, 0, 1, &descsettext, 0, NULL);
					VkDeviceSize offset = 0;
					vkCmdBindVertexBuffers(cmdBuffer_[nextIndex], 0, 1, &vertexBuf_, &offset);
					vkCmdPushConstants(cmdBuffer_[nextIndex], layout_, VK_SHADER_STAGE_VERTEX_BIT, 0, sizeof(float)*2, (float[2]){(double)displaySize_.width/2,(double)displaySize_.height/-2});
					vkCmdDraw(cmdBuffer_[nextIndex], nvertstext, 1, 0, 0);
				}

				// Draw exp
				if (nvertsexp) {
					vkCmdBindPipeline(cmdBuffer_[nextIndex], VK_PIPELINE_BIND_POINT_GRAPHICS, pipelineexp);
					VkDeviceSize offset = 0;
					vkCmdBindVertexBuffers(cmdBuffer_[nextIndex], 0, 1, &vbufexp, &offset);
					vkCmdPushConstants(cmdBuffer_[nextIndex], layoutexp, VK_SHADER_STAGE_VERTEX_BIT, 0, sizeof(float)*2, (float[2]){(double)displaySize_.width/2,(double)displaySize_.height/-2});
					vkCmdDraw(cmdBuffer_[nextIndex], nvertsexp, 1, 0, 0);
				}
				
				// Draw flow
				if (nvertsflow) {
					vkCmdBindPipeline(cmdBuffer_[nextIndex], VK_PIPELINE_BIND_POINT_GRAPHICS, pipelineflow);
					VkDeviceSize offset = 0;
					vkCmdBindVertexBuffers(cmdBuffer_[nextIndex], 0, 1, &vbufflow, &offset);
					vkCmdPushConstants(cmdBuffer_[nextIndex], layoutflow, VK_SHADER_STAGE_VERTEX_BIT, 0, sizeof(float)*2, (float[2]){(double)displaySize_.width/2,(double)displaySize_.height/-2});
					vkCmdDraw(cmdBuffer_[nextIndex], nvertsflow, 1, 0, 0);
				}
	
				// Draw cursor(s) if visible
				uint64_t ms = getms() % 1000;
				if (curshown && (phasecur<=500?ms>=phasecur&&ms<phasecur+500:ms<phasecur-500||ms>=phasecur)) {
					vkCmdBindPipeline(cmdBuffer_[nextIndex], VK_PIPELINE_BIND_POINT_GRAPHICS, pipelinecur);
					VkDeviceSize offset = 0;
					vkCmdBindVertexBuffers(cmdBuffer_[nextIndex], 0, 1, &vbufcur, &offset);
					vkCmdPushConstants(cmdBuffer_[nextIndex], layoutcur, VK_SHADER_STAGE_VERTEX_BIT, 0, sizeof(float)*2, (float[2]){(double)displaySize_.width/2,(double)displaySize_.height/-2});
					vkCmdDraw(cmdBuffer_[nextIndex], nvertscur, 1, 0, 0);
				}
				
				// Draw overlay
				if (overlay || isshowsearchresults()) {

					// Draw overlay backings
					if (nvertsbackov) {
						vkCmdBindPipeline(cmdBuffer_[nextIndex], VK_PIPELINE_BIND_POINT_GRAPHICS, pipelinebackov);
						VkDeviceSize offset = 0;
						vkCmdBindVertexBuffers(cmdBuffer_[nextIndex], 0, 1, &vbufbackov, &offset);
						vkCmdPushConstants(cmdBuffer_[nextIndex], layoutbackov, VK_SHADER_STAGE_VERTEX_BIT, 0, sizeof(float)*2, (float[2]){(double)displaySize_.width/2,(double)displaySize_.height/-2});
						vkCmdDraw(cmdBuffer_[nextIndex], nvertsbackov, 1, 0, 0);
					}

					// Draw overlay text
					if (nvertstextov) {
						vkCmdBindPipeline(cmdBuffer_[nextIndex], VK_PIPELINE_BIND_POINT_GRAPHICS, pipelinetextov);
						vkCmdBindDescriptorSets(cmdBuffer_[nextIndex], VK_PIPELINE_BIND_POINT_GRAPHICS, layouttextov, 0, 1, &descsettextov, 0, NULL);
						VkDeviceSize offset = 0;
						vkCmdBindVertexBuffers(cmdBuffer_[nextIndex], 0, 1, &vbuftextov, &offset);
						vkCmdPushConstants(cmdBuffer_[nextIndex], layouttextov, VK_SHADER_STAGE_VERTEX_BIT, 0, sizeof(float)*2, (float[2]){(double)displaySize_.width/2,(double)displaySize_.height/-2});
						vkCmdDraw(cmdBuffer_[nextIndex], nvertstextov, 1, 0, 0);
					}

					// Draw overlay buttons
					if (nvertsbtnov) {
						vkCmdBindPipeline(cmdBuffer_[nextIndex], VK_PIPELINE_BIND_POINT_GRAPHICS, pipelinebtnov);
						VkDeviceSize offset = 0;
						vkCmdBindVertexBuffers(cmdBuffer_[nextIndex], 0, 1, &vbufbtnov, &offset);
						vkCmdPushConstants(cmdBuffer_[nextIndex], layoutbtnov, VK_SHADER_STAGE_VERTEX_BIT, 0, sizeof(float)*2, (float[2]){(double)displaySize_.width/2,(double)displaySize_.height/-2});
						vkCmdDraw(cmdBuffer_[nextIndex], nvertsbtnov, 1, 0, 0);
					}
				}
				
				// Draw keyboard overlay
				if (shownac=showntab=nvertstextkb&&gethframe()<displaySize_.height) {
					//df("drawing kb");
					shownac = nvertsbtnkb > 6;

					// Draw keyboard overlay backings
					if (nvertsbackkb) {
						vkCmdBindPipeline(cmdBuffer_[nextIndex], VK_PIPELINE_BIND_POINT_GRAPHICS, pipelinebackkb);
						VkDeviceSize offset = 0;
						vkCmdBindVertexBuffers(cmdBuffer_[nextIndex], 0, 1, &vbufbackkb, &offset);
						vkCmdPushConstants(cmdBuffer_[nextIndex], layoutbackkb, VK_SHADER_STAGE_VERTEX_BIT, 0, sizeof(float)*2, (float[2]){(double)displaySize_.width/2,(double)displaySize_.height/-2});
						vkCmdDraw(cmdBuffer_[nextIndex], nvertsbackkb, 1, 0, 0);
					}

					// Draw keyboard overlay text
					if (nvertstextkb) {
						vkCmdBindPipeline(cmdBuffer_[nextIndex], VK_PIPELINE_BIND_POINT_GRAPHICS, pipelinetextkb);
						vkCmdBindDescriptorSets(cmdBuffer_[nextIndex], VK_PIPELINE_BIND_POINT_GRAPHICS, layouttextkb, 0, 1, &descsettextkb, 0, NULL);
						VkDeviceSize offset = 0;
						vkCmdBindVertexBuffers(cmdBuffer_[nextIndex], 0, 1, &vbuftextkb, &offset);
						vkCmdPushConstants(cmdBuffer_[nextIndex], layouttextkb, VK_SHADER_STAGE_VERTEX_BIT, 0, sizeof(float)*2, (float[2]){(double)displaySize_.width/2,(double)displaySize_.height/-2});
						vkCmdDraw(cmdBuffer_[nextIndex], nvertstextkb, 1, 0, 0);
					}

					// Draw keyboard overlay buttons
					if (nvertsbtnkb) {
						vkCmdBindPipeline(cmdBuffer_[nextIndex], VK_PIPELINE_BIND_POINT_GRAPHICS, pipelinebtnkb);
						VkDeviceSize offset = 0;
						vkCmdBindVertexBuffers(cmdBuffer_[nextIndex], 0, 1, &vbufbtnkb, &offset);
						vkCmdPushConstants(cmdBuffer_[nextIndex], layoutbtnkb, VK_SHADER_STAGE_VERTEX_BIT, 0, sizeof(float)*2, (float[2]){(double)displaySize_.width/2,(double)displaySize_.height/-2});
						vkCmdDraw(cmdBuffer_[nextIndex], nvertsbtnkb, 1, 0, 0);
					}
				}
				
				vkCmdEndRenderPass(cmdBuffer_[nextIndex]);
				//df("vkEndCommandBuffer %d", __LINE__);
				if (res=vkEndCommandBuffer(cmdBuffer_[nextIndex])) { Fprintf(stderr,"medcn: vkEndCommandBuffer: %d\n",res); exit(EXIT_FAILURE); }
			}

			VkPipelineStageFlags waitStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
			//df("vkQueueSubmit %d", __LINE__);
			if (res=vkQueueSubmit(queue_, 1,
				&(VkSubmitInfo){
					.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO,
					.pNext = NULL,
					.waitSemaphoreCount = 1,
					.pWaitSemaphores = &semaphore_,
					.pWaitDstStageMask = &waitStageMask,
					.commandBufferCount = 1,
					.pCommandBuffers = &cmdBuffer_[nextIndex],
					.signalSemaphoreCount = 0,
					.pSignalSemaphores = NULL
				}, fence_)) { Fprintf(stderr,"medcn: vkQueueSubmit: %d\n",res); exit(EXIT_FAILURE); }
			//df("vkWaitForFences %d", __LINE__);
			if (res=vkWaitForFences(device_, 1, &fence_, VK_TRUE, 100000000)) { Fprintf(stderr,"medcn: vkWaitForFences: %d\n",res); exit(EXIT_FAILURE); }

			//LOGI("Drawing frames......");

			VkResult result;
			//df("vkQueuePresentKHR %d", __LINE__);
			vkQueuePresentKHR(queue_,
				&(VkPresentInfoKHR){
					.sType = VK_STRUCTURE_TYPE_PRESENT_INFO_KHR,
					.pNext = NULL,
					.waitSemaphoreCount = 0,
					.pWaitSemaphores = NULL,
					.swapchainCount = 1,
					.pSwapchains = &swapchain_,
					.pImageIndices = &nextIndex,
					.pResults = &result
			});
		}
		nextmainloop:;
	} while (!app->destroyRequested);

	LOGV0("android_app_destroy!");
	free_saved_state(app);
	pthread_mutex_lock(&app->mutex);
	if (app->inputQueue != NULL) {
		AInputQueue_detachLooper(app->inputQueue);
	}
	AConfiguration_delete(app->config);
	app->destroyed = 1;
	pthread_cond_broadcast(&app->cond);
	pthread_mutex_unlock(&app->mutex);
	// Can't touch android_app object after this.
	return NULL;
}

// --------------------------------------------------------------------
// Native activity interaction (called from main thread)
// --------------------------------------------------------------------

void
android_app_write_cmd(struct android_app* android_app, int8_t cmd)
{
	if (write(android_app->msgwrite, &cmd, sizeof(cmd)) != sizeof(cmd)) {
		LOGE0("Failure writing android_app cmd: %s\n", strerror(errno));
	}
}

void
android_app_set_input(struct android_app* android_app, AInputQueue* inputQueue)
{
	pthread_mutex_lock(&android_app->mutex);
	android_app->pendingInputQueue = inputQueue;
	android_app_write_cmd(android_app, APP_CMD_INPUT_CHANGED);
	while (android_app->inputQueue != android_app->pendingInputQueue) {
		pthread_cond_wait(&android_app->cond, &android_app->mutex);
	}
	pthread_mutex_unlock(&android_app->mutex);
}

void
android_app_set_window(struct android_app* android_app, ANativeWindow* window)
{
	pthread_mutex_lock(&android_app->mutex);
	if (android_app->pendingWindow != NULL) {
		android_app_write_cmd(android_app, APP_CMD_TERM_WINDOW);
	}
	android_app->pendingWindow = window;
	if (window != NULL) {
		android_app_write_cmd(android_app, APP_CMD_INIT_WINDOW);
	}
	while (android_app->window != android_app->pendingWindow) {
		pthread_cond_wait(&android_app->cond, &android_app->mutex);
	}
	pthread_mutex_unlock(&android_app->mutex);
}

void
android_app_set_activity_state(struct android_app* android_app, int8_t cmd)
{
	pthread_mutex_lock(&android_app->mutex);
	android_app_write_cmd(android_app, cmd);
	while (android_app->activityState != cmd) {
		pthread_cond_wait(&android_app->cond, &android_app->mutex);
	}
	pthread_mutex_unlock(&android_app->mutex);
}

void
android_app_free(struct android_app* android_app)
{
	pthread_mutex_lock(&android_app->mutex);
	android_app_write_cmd(android_app, APP_CMD_DESTROY);
	while (!android_app->destroyed) {
		pthread_cond_wait(&android_app->cond, &android_app->mutex);
	}
	pthread_mutex_unlock(&android_app->mutex);

	close(android_app->msgread);
	close(android_app->msgwrite);
	pthread_cond_destroy(&android_app->cond);
	pthread_mutex_destroy(&android_app->mutex);
	free(android_app);
}

void
onDestroy(ANativeActivity* activity)
{
	LOGV0("Destroy: %p\n", activity);
	android_app_free((struct android_app*)activity->instance);
}

void
onStart(ANativeActivity* activity)
{
	LOGV0("Start: %p\n", activity);
	android_app_set_activity_state((struct android_app*)activity->instance, APP_CMD_START);
}

void
onResume(ANativeActivity* activity)
{
	LOGV0("Resume: %p\n", activity);
	android_app_set_activity_state((struct android_app*)activity->instance, APP_CMD_RESUME);
}

void*
onSaveInstanceState(ANativeActivity* activity, size_t* outLen)
{
	struct android_app* android_app = (struct android_app*)activity->instance;
	void* savedState = NULL;

	LOGV0("SaveInstanceState: %p\n", activity);
	pthread_mutex_lock(&android_app->mutex);
	android_app->stateSaved = 0;
	android_app_write_cmd(android_app, APP_CMD_SAVE_STATE);
	while (!android_app->stateSaved) {
		pthread_cond_wait(&android_app->cond, &android_app->mutex);
	}

	if (android_app->savedState != NULL) {
		savedState = android_app->savedState;
		*outLen = android_app->savedStateSize;
		android_app->savedState = NULL;
		android_app->savedStateSize = 0;
	}

	pthread_mutex_unlock(&android_app->mutex);

	return savedState;
}

void
onPause(ANativeActivity* activity)
{
	LOGV0("Pause: %p\n", activity);
	android_app_set_activity_state((struct android_app*)activity->instance, APP_CMD_PAUSE);
}

void
onStop(ANativeActivity* activity)
{
	LOGV0("Stop: %p\n", activity);
	android_app_set_activity_state((struct android_app*)activity->instance, APP_CMD_STOP);
}

void
onConfigurationChanged(ANativeActivity* activity)
{
	struct android_app* android_app = (struct android_app*)activity->instance;
	LOGV0("ConfigurationChanged: %p\n", activity);
	android_app_write_cmd(android_app, APP_CMD_CONFIG_CHANGED);
}

void
onLowMemory(ANativeActivity* activity)
{
	struct android_app* android_app = (struct android_app*)activity->instance;
	LOGV0("LowMemory: %p\n", activity);
	android_app_write_cmd(android_app, APP_CMD_LOW_MEMORY);
}

void
onWindowFocusChanged(ANativeActivity* activity, int focused)
{
	LOGV0("WindowFocusChanged: %p -- %d\n", activity, focused);
	android_app_write_cmd((struct android_app*)activity->instance,
			focused ? APP_CMD_GAINED_FOCUS : APP_CMD_LOST_FOCUS);
}

void
onNativeWindowCreated(ANativeActivity* activity, ANativeWindow* window)
{
	LOGV0("NativeWindowCreated: %p -- %p\n", activity, window);
	android_app_set_window((struct android_app*)activity->instance, window);
}

void
onNativeWindowDestroyed(ANativeActivity* activity, ANativeWindow* window)
{
	LOGV0("NativeWindowDestroyed: %p -- %p\n", activity, window);
	android_app_set_window((struct android_app*)activity->instance, NULL);
}

void
onInputQueueCreated(ANativeActivity* activity, AInputQueue* queue)
{
	LOGV0("InputQueueCreated: %p -- %p\n", activity, queue);
	android_app_set_input((struct android_app*)activity->instance, queue);
}

void
onInputQueueDestroyed(ANativeActivity* activity, AInputQueue* queue)
{
	LOGV0("InputQueueDestroyed: %p -- %p\n", activity, queue);
	android_app_set_input((struct android_app*)activity->instance, NULL);
}

/* Gotta free it */
void
getpaste(size_t *pn, uint8_t **pbuf)
{
	*pn=0, *pbuf=NULL;

	//ClipboardManager clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
	JNIEnv *env = attachjni();
	jclass MyNativeActivity = getclassobjectenv(env, activity->clazz);
	jmethodID getSystemService = getmethodenv(env, MyNativeActivity, "getSystemService", "(Ljava/lang/String;)Ljava/lang/Object;");
	jobject clipboardManager = callmethodobjectenv(env, activity->clazz,  getSystemService, getstringenv(env,"clipboard"));

	//ClipData clip = clipboardManager.getPrimaryClip();
	jclass ClipboardManager = getclassobjectenv(env, clipboardManager);
	jmethodID getPrimaryClip = getmethodenv(env, ClipboardManager, "getPrimaryClip", "()Landroid/content/ClipData;");
	jobject clip = callmethodobjectenv(env, clipboardManager, getPrimaryClip);
	if (!clip) return;

	// ClipData.Item item = clip.getItemAt(0);
	jclass ClipData = getclassobjectenv(env, clip);
	jmethodID getItemAt = getmethodenv(env, ClipData, "getItemAt", "(I)Landroid/content/ClipData$Item;");
	jobject item = callmethodobjectenv(env, clip, getItemAt, 0);

	//Context context = activity.mNativeContentView.getContext();
	jfieldID MyNativeActivity_mNativeContentView = getfieldenv(env, MyNativeActivity, "mNativeContentView", "Landroid/app/NativeActivity$NativeContentView;");
	jobject mNativeContentView = (*env)->GetObjectField(env,activity->clazz,MyNativeActivity_mNativeContentView); if (!mNativeContentView) {failexception();fputs("medcn: getobjectfield mNativeContentView null\n",stderr);exit(EXIT_FAILURE);}
	jclass NativeContentView = getclassobjectenv(env, mNativeContentView);
	jmethodID getContext = getmethodenv(env, NativeContentView, "getContext", "()Landroid/content/Context;");
	jobject context = callmethodobjectenv(env, mNativeContentView, getContext); if (!context) {Fputs("medcn: jni activity.getContext() null\n",stderr);exit(EXIT_FAILURE);}

	// CharSequence sSeq = item.coerceToText(context);
	jclass Item = getclassobjectenv(env, item);
	jmethodID coerceToText = getmethodenv(env, Item, "coerceToText", "(Landroid/content/Context;)Ljava/lang/CharSequence;");
	jobject sSeq = callmethodobjectenv(env, item, coerceToText, context);

	// String s = sSeq = sSeq.toString();
	jclass CharSequence = getclassobjectenv(env, sSeq);
	jmethodID toString = getmethodenv(env, CharSequence, "toString", "()Ljava/lang/String;");
	jstring s = callmethodobjectenv(env, sSeq, toString);
	const char *bufs = getstrfromstringenv(env, s);
	if (!(*pn=strlen(bufs))) return;
	if (!(*pbuf=malloc(*pn))) { Fprintf(stderr, "medcn: failed malloc %zu paste: %s\n", *pn, strerror(errno)); exit(EXIT_FAILURE); }
	memcpy(*pbuf, bufs, *pn);
	(*env)->ReleaseStringUTFChars(env, s, bufs);
	(*activity->vm)->DetachCurrentThread(activity->vm);
}

/* Also adjusts icur for adjustments. */
void
adjustpastedindent(size_t ipaste, size_t nbuf, uint8_t *buf)
{
	df("adjustpastedindent %zu", ipaste);
	
	// Skip if not a pasted line
	if (!nbuf || buf[nbuf-1]!='\n') return;
	
	// Indent prior of } if applicable
	size_t i0adj=ipaste, i1adj=ipaste+nbuf;
	{
	
		// Check if solo } line
		if (nbuf < 2) goto notendbrace;
		for (size_t i=0; i+2<nbuf; i++) if (!isspace(buf[i]) || buf[i]=='\n') goto notendbrace;
		if (memcmp(buf+nbuf-2,"}\n",2)) goto notendbrace;
		
		// Find preceding {
		if (!ipaste) goto notendbrace;
		size_t iopen=ipaste-1; for (size_t nbrace=1;; iopen--) {
			if (text[iopen]=='{' && !isintoken(iopen) && !--nbrace) break;
			else if (text[iopen]=='}' && !isintoken(iopen)) nbrace++;
			else if (!iopen) goto notendbrace;
		}
		df("adjustpastedindent } { %zu", iopen);
		
		// Adjust } line
		size_t nindpaste = getnindent(ipaste);
		ssize_t dend = getnindent(getiline(iopen)) - nindpaste;
		df("adjustpastedindent } %zd=%zu-%zu", dend, getnindent(getiline(iopen)), nindpaste);
		if (dend < 0) backspace(ipaste-dend,-dend); else insert(ipaste,dend,text+getiline(iopen));
		if (dend<0 && icur>=ipaste && icur<ipaste-dend) icur=ipaste;
		else if (icur > ipaste) icur+=dend;

		// Adjust inner indent
		i0adj=getilinenext(iopen), i1adj=ipaste;
	} notendbrace:;
	
	// Skip if empty
	size_t ilnonsp=i0adj; for (size_t j=i0adj; j<i1adj; j++)
		if (text[j] == '\n') ilnonsp=j+1;
		else if (!isspace(text[j])) break;
	if (ilnonsp >= i1adj) return;
	
	// Get expected indent
	size_t nindexp = 0;
	if (i0adj >= 2) {
		
		// Get prev nonspace
		size_t i=i0adj-1; while (i && isspace(text[i])) i--;
		if (!i) goto endexpindent;
		
		// Handle after {
		if (text[i] == '{') nindexp=getnindent(getiline(i))+1;
		
		// After , means same indent
		else if (text[i] == ',') nindexp=getnindent(getiline(i));
	
		// Check indent of start of previous statement
		else {
			for (; i>=2 && memcmp(text+i-2,";\n",2); i--) {
				if (!memcmp(text+i-2,"{\n",2)) {
					ssize_t nparen = 0;
					for (size_t j=i-2; j; j--) {
						if (!nparen && text[j]=='=') break;
						if (text[j]=='\n' || (!nparen&&text[j]==';')) goto gotendprevstatement;
						if (text[j]=='(')nparen--;else if(text[j]==')')nparen++;
					}
				}
			} gotendprevstatement:;
			if (i>=2) {
				while (isspace(text[i])) i++;
				nindexp=getnindent(getiline(i));
			}
		}
		
		// Decrement if paste starts with }
		if (nindexp) for (size_t j=i0adj; j<i1adj; j++) {
			if (i1adj-j>=2 && !memcmp(text+j,"//",2) && eattoken(&j,i1adj)) continue;
			if (!isspace(text[j])) {
				if (text[j] == '}') nindexp--;
				break;
			}
		}
	} endexpindent:;
	
	// Adjust each nonempty line's indent
	ssize_t dind = (ssize_t)nindexp - (ssize_t)getnindent(ilnonsp);
	df("adjustpastedindent %zd=%zu-%zu", dind, nindexp, getnindent(ilnonsp));
	for (size_t i=i0adj; i<i1adj; i++) {
		size_t il = i;
		
		// Skip starting #
		if (text[il] == '#') {
			while (text[i] != '\n') i++;
			continue;
		}
		
		// Handle other
		while (i<i1adj && isspace(text[i]) && text[i]!='\n') i++;
		if (i>=i1adj || text[i]=='\n') continue;
		ssize_t d;
		if (dind <= 0) {
			d = -(ssize_t)(i-il < -dind ? i-il : -dind);
			backspace(i, -d);
		} else {
			uint8_t *tabs = (uint8_t*)malloc(d=dind); if (!tabs) { fprintf(stderr,"D3D12HelloTexture: malloc adjust paste buf %zd: %s\n",dind,strerror(errno)); exit(EXIT_FAILURE); }
			memset(tabs, '\t', d);
			insert(il, d, tabs);
			free(tabs);
		}
		if (d<0 && icur>=il && icur<il-d) icur=il;
		else if (icur > il) icur+=d;
		i1adj+=d, i+=d;
		while (text[i] != '\n') i++;
	}
}

struct block*
insertblockbuf(struct block *parent, struct block *pinsert, size_t nbuf, uint8_t *buf)
{
	struct block **phead; size_t *pn, *psize;
	if (parent) phead=&parent->blocks,pn=&parent->nblocks,psize=&parent->sizeblocks;
	else phead=&blocks, pn=&nblocks, psize=&sizeblocks;
	size_t i = pinsert - *phead;
	
	// Get text index of this block
	char isappend = i == *pn;
	struct block *bsearch = *phead + i - isappend;
	size_t i0=0; for(struct block *b=blocks;b!=bsearch;nextblki0(&b,&i0));
	if (isappend) i0+=bsearch->n;
	
	// Insert block
	ensuren(psize, 0, (void**)phead, sizeof(struct block) *++(*pn));
	struct block *blk = (*phead) + i;
	if (!isappend) memmove(blk+1,blk,sizeof(struct block)**pn-i-1);
	*blk = (struct block){.parent=parent};
	setparents(*pn, *phead);
	
	// Insert buf
	insertupdate(i0, nbuf, buf, ~(uint64_t)1);
	for (struct block *b=blk; b; b=b->parent) b->n+=nbuf;
	return blk;
}

/* Inserts a new block in that index with two newlines
in it */
struct block*
insertblocklines(struct block *parent, struct block *pinsert)
{
	return insertblockbuf(parent, pinsert, 2, (uint8_t*)"\n\n");
}

size_t
copyindent(size_t from, size_t to)
{
	size_t n = getnindent(from);
	if (from+n < to) insert(to, n, text+from);
	else insertcopy(to, n, text+from);
	return n;
}

/* Makes sure this index's block ancestry is expanded */
void
ensureiexpanded(size_t i)
{
	struct block *b; getblocki(i,&b,NULL,1);
	for (; b; b=b->parent) b->expanded=1;
}

/* Returns the start of the line, or if in an
expansion, the start of its expansion */
size_t
getilineunexp(size_t i)
{
	size_t iexp = getiilexp(i);
	return iexp==SIZE_MAX ? getiline(i) : ilexps[iexp];
}

int32_t
onInputEvent(struct android_app *app, AInputEvent *event)
{
	int32_t type = AInputEvent_getType(event);
	
	// Motion event
	if (type == AINPUT_EVENT_TYPE_MOTION) {
		int32_t action = AMotionEvent_getAction(event);

		// Pointer down
		if (action == AMOTION_EVENT_ACTION_DOWN) {
			xdown=AMotionEvent_getX(event,0), ydown=/*yscr=*/AMotionEvent_getY(event,0), nsdown=AMotionEvent_getEventTime(event);
			df("%.3f: down %.2f,%.2f", et(nsdown), xdown, ydown);
			ytopdown=ytop, isuptap=isupswipelr=1, ymoveprev=INFINITY, isdown=1, nsflingprev=UINT64_MAX, nsmoveprev=UINT64_MAX, yvelocity=0;
			yscr = INFINITY;

		// Pointer up
		} else if (action == AMOTION_EVENT_ACTION_UP) {
			double xup=AMotionEvent_getX(event,0), yup=AMotionEvent_getY(event,0); uint64_t nsup=AMotionEvent_getEventTime(event);
			df("%.3f: up %.2f,%.2f", et(nsup), xup, yup);
			isdown=0;

			// Swipe left
			if (isupswipelr && xdown-xup>100 && nsup-nsdown<2e8) {
				df(" (swipe left)");
				struct atblk pos = goblk(attopblk(), WIDTH|XSTOP|YSTOP, (double)displaySize_.width, (double)xdown, (double)ydown);

				// Unexpand block
				size_t iexp=getiilexp(pos.i), iflow=getiflow(getiline(pos.i));
				if (iexp==SIZE_MAX && iflow==SIZE_MAX) {
					
					// Unexpand expanded block
					if (pos.blk->expanded) {
				
						// Re-blockize it if needed
						if (pos.blk->needsreblockize) {
							df("blocks pre");
							printblocks(nblocks, blocks, fdf);
						
							// Reblockize
							reblockize(pos.i0blk, pos.blk);
						
							// Re-get position
							pos = goblk(attopblk(), WIDTH|XSTOP|YSTOP, (double)displaySize_.width, (double)xdown, (double)ydown);
							df("blocks post");
							printblocks(nblocks, blocks, fdf);
						}
				
						// Unexpand
						pos.blk->expanded=0, needsredraw=1;
				
						// If this block is an ancestor of the top,
						// recalculate the label row for the top position
						struct block *blktop; size_t i0blktop; getblocki(itop,&blktop,&i0blktop,0);
						df("unexpand i0blktop%zu itop%zu pos.i0blk%zu", i0blktop, itop, pos.i0blk);
						for (struct block *anctop=blktop; anctop; anctop=anctop->parent) if (anctop == pos.blk) {
							itop = geti0blkrow(i0blktop);
							break;
						}
					
						// Hide keyboard if cursor hidden
						if (icur != SIZE_MAX) {
							struct block *blkcur; getblocki(icur,&blkcur,NULL,1);
							for (struct block *anccur=blkcur; anccur; anccur=anccur->parent) if (anccur == pos.blk) {hidekeyboard();break;}
						}
					
						// Dirty cursor vertices 
						needsredrawcur = 1;
						
					// Unexpand coalesced blocks maybe
					} else {
						if (pos.blk->parent || pos.blk==blocks) return 0;
						for (struct block *b=pos.blk-1;; b--) {
							if (b->expanded) {
								if (b->expanded == 3) b->expanded=1,needsredraw=1;
								break;
							}
							if (b == blocks) break;
						}
					}

				// Unexpand individual line
				} else if (iexp != SIZE_MAX) {
					char wastextunsaved = vtext != vtextsaved,
						wasbufsaved = !exps[iexp].unsaved;
					size_t ntext0 = ntext;

					// Get unexpanded buffer
					size_t itext=ilexps[iexp], nexp=exps[iexp].n;
					uint8_t *buf; size_t nbuf;
					if (exps[iexp].norig) nbuf=exps[iexp].norig,buf=exps[iexp].orig;
					else getunexpanded(nexp,text+itext,&nbuf,&buf);
					df("unexp buffer %.*s", (int)nbuf, buf);
					uint8_t *bufcopy = (uint8_t*)malloc(nbuf); if (!bufcopy) { fprintf(stderr,"D3D12HelloTexture: malloc unexp buf %zu: %s\n",nbuf,strerror(errno)); exit(EXIT_FAILURE); }
					memcpy(bufcopy, buf, nbuf);

					// Replace it in the text
					df("unexp line0");
					printblocks(nblocks, blocks, fdf);
					//backspaceupdate(itext+nexp, nexp, ~(uint64_t)2);
					backspace(itext + nexp, nexp);
					df("unexp line1");
					printblocks(nblocks, blocks, fdf);
					df("unexp buffer %.*s", (int)nbuf, bufcopy);
					insertextendblock(itext, nbuf, bufcopy);
					free(bufcopy);

					df("unexp line2");
					printblocks(nblocks, blocks, fdf);
					size_t iexpafter = getiilexp(itext);
					if (iexpafter != SIZE_MAX) ilexps[iexpafter]+=nbuf,exps[iexpafter].n-=nbuf;

					/*
					// Remove it from the expanded indices
					free(exps[iexp].orig);
					memmove(ilexps+iexp, ilexps+iexp+1, (nilexps-1-iexp)*sizeof(size_t));
					memmove(exps+iexp, exps+iexp+1, (nilexps-1-iexp)*sizeof(struct expanse));
					nilexps--;
					*/

					// Update cursor/top
					if (itop>=itext && itop<itext+nexp) itop=itext;
					if (icur>=itext && icur<itext+nexp) icur=SIZE_MAX;
					else if (icur > itext+nexp) icur-=ntext0-ntext;
					needsredraw=1, needsvertcur=1;
					
					// Preserve saved status if relevant
					if (!wastextunsaved && wasbufsaved) vtextsaved=vtext;
				
				// Unflow individual line
				} else if (iflow != SIZE_MAX) {
					removeflowi(iflow);
					needsredraw = 1;
				}

			// Tap
			} else if (isuptap && nsup-nsdown<2e8) {
				df(" (tap)");
				char justbraced0 = justbraced;
				justbraced = 0;
				
				// In tab overlay
				if (showntab && xdown>=rx0tab*displaySize_.width && xdown<=rx1tab*displaySize_.width && ydown>=y0tab && ydown<=y0tab+hbtntab) {
					df(" tab");
					pthread_mutex_lock(&app->mutex);
					app->ntype = 1;
					if (app->sizetype < 1) app->buftype=realloc(app->buftype,app->sizetype=1);
					app->buftype[0] = '\t';
					//fprintf(f,"type %d %.*s\n", app->ntype, app->ntype, app->buftype);
					write(app->msgwrite, (uint8_t[1]){APP_CMD_TYPE}, 1);
					pthread_mutex_unlock(&app->mutex);
					
				// In autocorrect
				} else if (shownac && !overlay && ydown>=y0tab-hbtn && ydown<y0tab && (nisac>=5||(xdown>=displaySize_.width*0.2&&(nisac>=4||(xdown<displaySize_.width*0.8&&(nisac>=3||(xdown>=displaySize_.width*0.4&&(nisac>=2||(xdown<displaySize_.width*0.6&&nisac))))))))) {
					df(" autocorrect");
					size_t iac = ((int[]){4,2,0,1,3})[(int)(xdown/(displaySize_.width*0.2))];
					size_t nac=nsac[iac]; uint8_t *wac=wsac[iac];
					size_t iw;
					if (cur == 0) {
						size_t nw; getwordcurtext(&iw,&nw);
						if (iac>=iacpre0 && iw+nw>icur) nw=icur-iw;
						insertcopy(iw, nac, wac);
						backspace(iw+nac+nw, nw);
						icur=iw+nac;
						if (atcurblk().i != icur) expandcurline();
					} else if (cur == 1) {
						size_t nw; getwordcursearch(&iw,&nw);
						if (iac>=iacpre0 && iw+nw>icur) nw=icur-iw;
						backspacesearch(iw+nw, nw);
						insertsearch(iw, nac, wac);
						icur=iw+nac;
					}
					needsredraw = 1;
					
				// Save
				#define INBTNI(ibtn) (ybottomov-hbtn-hbtn*(ibtn/5)<ydown &&ydown<ybottomov-hbtn*(ibtn/5) &&displaySize_.width*0.2*(ibtn%5)<xdown &&xdown<displaySize_.width*0.2*((ibtn%5)+1))
				#define INBTN(ov, ibtn, btns)(ov==overlay&&(!btns[ibtn].flag||(stateovvert&btns[ibtn].flag))&&INBTNI(ibtn))
				//#define INBTN(ov, ibtn, btns)(ov==overlay&&(!btns[ibtn].flag||(stateovvert&btns[ibtn].flag))&&ybottomov-hbtn-hbtn*(ibtn/5)<ydown&&ydown<ybottomov-hbtn*(ibtn/5)&&displaySize_.width*0.2*(ibtn%5)<xdown&&xdown<displaySize_.width*0.2*((ibtn%5)+1))
				} else if (INBTN(OVMAIN,SAVE,buttons)) {
					df(" save");
					save(pathopen);
					mssaved = getms();
					overlay=overlaypremain, needsredraw=1, justbraced=justbraced0; ensurekeyboard();

				// Select lines
				} else if (INBTN(OVMAIN,SELECTLINES,buttons)) {
					df(" select lines");
					iselectstart=getiline(icur), iselectend=getilinenext(iselectstart), isselectinglines=1, curselect=0;
					overlay=OVSELECT, needsredraw=1;
					
				// Undo
				} else if (INBTN(OVMAIN,UNDO,buttons) || INBTN(OVUNDID,UNDIDUNDO,btnsundid)) {
					df(" undo");
					isundoing = 1;
					while (nundo) {
						struct undo *u = undos + --nundo;
						if (u->type == 'i') {
							backspace(u->i+u->n,u->n);
							if (icur != SIZE_MAX) updateindex(&icur, u->i, -(ssize_t)u->n);
						} else {
							insert(u->i-u->n,u->n,u->buf);
							if (icur != SIZE_MAX) {
								updateindex(&icur, u->i-u->n, u->n);
								if (icur == u->i-u->n) icur+=u->n;
							}
						}
						if (nundo && undos[nundo-1].idchain!=u->idchain) break;
					}
					isundoing = 0;
					overlay=OVUNDID; ensurekeyboard();
					
				// Intent Termux
				} else if (INBTN(OVMAIN,INTENTTERMUX,buttons)) {
					df(" intent termux");
					
					// Intent intent = new Intent();
					JNIEnv *env = attachjni();
					df("making intent");
					jclass Intent = getclassenv(env, "android/content/Intent");
					jmethodID new_Intent = getmethodenv(env, Intent, "<init>", "()V");
					jobject intent = newobjectenv(env, Intent, new_Intent);
					
					// intent.setClassName("com.termux", "com.termux.app.RunCommandService");
					df("setting class name");
					jmethodID setClassName = getmethodenv(env, Intent, "setClassName", "(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;");
					callmethodobjectenv(env, intent, setClassName, getstringenv(env,"com.termux"), getstringenv(env,"com.termux.app.RunCommandService"));

					// intent.setAction("com.termux.RUN_COMMAND");
					df("setting action");
					jmethodID setAction = getmethodenv(env, Intent, "setAction", "(Ljava/lang/String;)Landroid/content/Intent;");
					callmethodobjectenv(env, intent, setAction, getstringenv(env,"com.termux.RUN_COMMAND"));
					
					// intent.putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/medcncmd");
					df("putting path");
					jmethodID putExtra = getmethodenv(env, Intent, "putExtra", "(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;");
					callmethodobjectenv(env, intent, putExtra, getstringenv(env,"com.termux.RUN_COMMAND_PATH"), getstringenv(env,"/data/data/com.termux/files/usr/bin/medcncmd"));

					// startService(intent);
					df("starting service");
					jclass MyNativeActivity = getclassobjectenv(env, activity->clazz);
					jfieldID MyNativeActivity_mNativeContentView = getfieldenv(env, MyNativeActivity, "mNativeContentView", "Landroid/app/NativeActivity$NativeContentView;");
					jobject mNativeContentView = (*env)->GetObjectField(env,activity->clazz,MyNativeActivity_mNativeContentView); if (!mNativeContentView) {failexception();fputs("medcn: getobjectfield mNativeContentView null\n",stderr);exit(EXIT_FAILURE);}
					jclass NativeContentView = getclassobjectenv(env, mNativeContentView);
					jmethodID getContext = getmethodenv(env, NativeContentView, "getContext", "()Landroid/content/Context;");
					jobject context = callmethodobjectenv(env, mNativeContentView, getContext); if (!context) {Fputs("medcn: jni activity.getContext() null\n",stderr);exit(EXIT_FAILURE);}
					jclass Context = getclassobjectenv(env, context);
					jmethodID startService = getmethodenv(env, Context, "startService", "(Landroid/content/Intent;)Landroid/content/ComponentName;");
					callmethodobjectenv(env, context, startService, intent);
					(*activity->vm)->DetachCurrentThread(activity->vm);
					
					// Update state
					overlay = 0;
					
				// Select
				} else if (INBTN(OVMAIN,SELECT,buttons)) {
					df(" select");
					iselectstart=iselectend=icur, isselectinglines=0, curselect=0;
					overlay=OVSELECT, needsredraw=1;
					
				// Enter below
				} else if (INBTN(OVMAIN,ENTERBELOW,buttons)) {
					df(" enter below");
					size_t i = getilinenext(icur);
					insertextendblock(i, 1, (uint8_t*)"\n");
					icur=i+copyindent(getilineunexp(icur),i); showkeyboard();
					if (strchr("{)",text[i-2])) insert(icur++,1,(uint8_t*)"\t");
					overlay = 0;
					
				// Enter out expand
				} else if (INBTN(OVMAIN,ENTEROUTEXPAND,buttons)) {
					df(" enter out expand");
					insert(icur, 1, (uint8_t*)"\n");
					size_t iexp = getiilexp(icur);
					exps[iexp].n -= ilexps[iexp] + exps[iexp].n - (icur+1);
					icur = icur + 1 + copyindent(ilexps[iexp],icur+1);
					needsredraw=1, overlay=0; showkeyboard();
					
				// Join
				} else if (INBTN(OVMAIN,JOIN,buttons) || INBTN(OVJOINED,JOINEDJOIN,btnsjoined)) {
					df(" join");
					size_t il = getilinenext(icur);
					for (size_t i=il;; i++) {
						if (i >= ntext) { backspace(ntext,ntext-il+1); break; }
						if (text[i] == '\n') { backspace(i,i-il+1); break; }
						if (!isspace(text[i])) {
							insert(il-1, 1, (uint8_t*)" ");
							backspace(i+1, i-il+1);
							break;
						}
					}
					overlay=OVJOINED;
					
				// Enter after block
				} else if (INBTN(OVMAIN,ENTERAFTERBLOCK,buttons)) {
					df(" enter after block");
					isenterafterblock = 1;
					overlay=OVCANCEL, needsredraw=1;

				// Copy
				} else if (INBTN(OVSELECT,SELECTCOPY,btnsselect)) {
					df(" copy");
					copyselection();
					iselectstart = SIZE_MAX;
					overlay=OVCOPIED;
					
				// Select include pre lines
				} else if (INBTN(OVSELECT,SELECTINCLUDEPRELINES,btnsselect)) {
					df(" select include pre lines");
					size_t *pi0 = iselectstart<iselectend ? &iselectstart : &iselectend;
					while (1) {
						*pi0 = getiline(*pi0-1);
						if (!*pi0) break;
						for (size_t i=getiline(*pi0-1); i<*pi0; i++) if (!isspace(text[i])) goto endprelinesfinding;
					} endprelinesfinding:;
					
				// Select cancel
				} else if (INBTN(OVSELECT,SELECTCANCEL,btnsselect)) {
					df(" select cancel");
					iselectstart = SIZE_MAX;
					overlay=0, needsredraw=1;
					
				// Replace selection
				} else if (INBTN(OVSELECT,SELECTREPLACE,btnsselect)) {
					df(" replace select");
					geti01selection(&i0replace, &i1replace);
					df("  %zu-%zu", i0replace, i1replace);
					nreplaced = nreplace = nbufreplace0 = nbufreplace1 = 0;
					iselectstart = SIZE_MAX;
					cur=CURREPLACE0, icur=0; showkeyboard();
					overlay=OVREPLACE, needsredraw=1;
					
				// Replace make function
				} else if (INBTN(OVSELECT,SELECTMAKEFUNCTION,btnsselect)) {
					df(" replace make function");
					size_t i0,i1; geti01selection(&i0,&i1);
					insert(i0,1,(uint8_t*)"\n"); 
					if (iselectstart<iselectend)iselectstart++;else iselectend++;
					icur=inamemkfn=i0+copyindent(i0+1,i0); showkeyboard();
					insert(icur, 3, (uint8_t*)"();");
					overlay=OVMAKEFUNCTION, needsredraw=1;
					
				// Replace function done
				} else if (INBTN(OVMAKEFUNCTION,MKFNDONE,btnsmakefunction)) {
					df(" make function done");
					
					// Get insertion point
					size_t iins = 0;
					ssize_t nbrace=0, nparen=0;
					for (size_t i=0; i<inamemkfn; i++) {
						eattoken(&i, inamemkfn);
						switch (text[i]) { case '{':nbrace++;break; case '}':nbrace--;break;case '(':nparen++;break; case ')':nparen--;break; }
						if (!nbrace && !nparen && (!i||text[i-1]=='\n')) {
							for (size_t j=i; j<ntext && text[j]!='\n'; j++)
								if (!isspace(text[j])) goto insinotempty;
							iins = i;
							insinotempty:;
						}
					}
					
					// Move function there
					insert(iins, 6, (uint8_t*)"\nvoid\n");
					size_t nname; getwordtext(inamemkfn,&inamemkfn,&nname);
					insertcopy(iins+6, nname, text+inamemkfn);
					insert(iins+6+nname, 11, (uint8_t*)"(void)\n{\n}\n");
					size_t i0,i1; geti01selection(&i0,&i1);
					insertcopy(iins+6+nname+9, i1-i0, text+i0);
					adjustpastedindent(iins+6+nname+9, i1-i0, text+i0+(i1-i0));
					deleteselection();
					
					// Update UI state
					ensureiexpanded(iins); scrolliinview(iins);
					icur=inamemkfn=SIZE_MAX;
					overlay=0, needsredraw=1;
					
				// Regenerate
				} else if (INBTN(OVMAIN,REGENERATE,buttons)) {
					df(" regenerate");

					// Regenerate Generated:
					size_t i = getiline(icur);
					while (isspace(text[i])) i++;
					if (ntext-i>=14 && !memcmp(text+i,"// Generated: ",14)) {
						size_t inlsh=i; while (inlsh<ntext && text[inlsh]!='\n') inlsh++;
						if (inlsh+1 < ntext) {
							size_t ipastgen = getilinenext(inlsh+1);
							backspace(ipastgen, ipastgen-(inlsh+1));
						}
						ensurentext(inlsh+1); text[inlsh]='\0';
						FILE *f = popen((char*)text+i+14, "r"); if (!f) { fprintf(stderr,"medc: popen '%s': %s\n",text+i+14,strerror(errno)); return EXIT_FAILURE; }
						text[inlsh] = '\n';
						size_t nr=0; while (!feof(f)) {
							uint8_t buf[4096]; size_t r = fread(buf, 1, 4096, f); if (ferror(f)) { fprintf(stderr,"medc: fread popen'd '%s': %s\n",text+i+14,strerror(errno)); return EXIT_FAILURE; }
							uint8_t *pnl = memchr(buf, '\n', r);
							if (pnl) r=pnl-buf;
							insertextendblock(inlsh+1+nr, r, buf);
							nr += r;
							if (pnl) break;
						}
						insertextendblock(inlsh+1+nr, 1, (uint8_t*)"\n");
						if (pclose(f) == -1) { fprintf(stderr,"medc: pclose '%s': %s\n",text+i+14,strerror(errno)); return EXIT_FAILURE; }

					// Regenerate /* GEN
					} else {
						
						// Find end of script
						size_t ish0 = getilinenext(i);
						size_t ish1=ish0; while (ish1<ntext && (ish1+2>=ntext||memcmp(text+ish1,"*/",2))) ish1=getilinenext(ish1);
						if (ish1 == ntext) {
							if (text[ish1-1] !='\n') insert(ish1++,1,(uint8_t*)"\n");
							insert(ish1, 3, (uint8_t*)"*/\n");
						}

						// Find end of generated portion
						size_t igen0 = getilinenext(ish1);
						size_t igen1=igen0; while (igen1<ntext && (igen1+9>=ntext||memcmp(text+igen1,"//ENDGEN\n",9))) igen1=getilinenext(igen1);
						if (igen1 == ntext) {
							if (text[igen1-1] !='\n') insert(igen1++,1,(uint8_t*)"\n");
							insert(igen1, 9, (uint8_t*)"//ENDGEN\n");
						}
						
						// Delete generated portion
						if (igen1 > igen0) backspace(igen1, igen1-igen0);
						
						// Fill with newly generated
						int fds[4]; if (pipe(fds) || pipe(fds+2)) { fprintf(stderr,"medc: pipe: %s\n",strerror(errno)); exit(EXIT_FAILURE); }
						pid_t pid = fork();
						if (pid == -1) { fprintf(stderr,"medc: fork: %s\n",strerror(errno)); exit(EXIT_FAILURE); }
						if (!pid) {
							if (dup2(fds[0],0) == -1) { fprintf(stderr,"medc: dup2 0: %s\n",strerror(errno)); exit(EXIT_FAILURE); }
							if (dup2(fds[3],1) == -1) { fprintf(stderr,"medc: dup2 1: %s\n",strerror(errno)); exit(EXIT_FAILURE); }
							close(fds[1]), close(fds[2]);
							if (setenv("TMPDIR","/data/data/com.vulkan.tutorials.sixcsim/cache",1)) {perror("medcn: setenv tmpdir");exit(EXIT_FAILURE);}
							execl("/bin/sh", "/bin/sh", NULL); fprintf(stderr,"medc: execl /bin/sh: %s\n",strerror(errno)); exit(EXIT_FAILURE);
						}
						if (signal(SIGINT, SIG_IGN) == SIG_ERR) { fprintf(stderr,"med: signal SIGINT SIG_IGN: %s\n",strerror(errno)); return EXIT_FAILURE; }
						close(fds[0]), close(fds[3]);
						struct pollfd polls[] = {{.fd=fds[1],.events=POLLOUT|POLLWRBAND}, {.fd=fds[2],.events=POLLIN|POLLPRI}};
						size_t ish=ish0, igen=igen0;
						while (polls[0].fd!=-1 || polls[1].fd!=-1) {
							int res = poll(polls, 2, -1); if (res==-1 && errno!=EINTR && errno!=EAGAIN) { fprintf(stderr,"med: poll: %s\n",strerror(errno)); exit(EXIT_FAILURE); }
							if (res == -1) continue;
							if (polls[0].revents) {
								if (ish == ish1) polls[0].fd=-1;
								else {
									ssize_t w = write(fds[1], text+ish, ish1-ish); if (w==-1 && errno!=EINTR && errno!=EPIPE) { fprintf(stderr,"med: write GEN pipe: %s\n",strerror(errno)); exit(EXIT_FAILURE); }
									if (w==-1 && errno==EINTR);
									else if (w == -1) polls[0].fd=-1;
									else ish+=w;
								}
								if (polls[0].fd == -1) close(fds[1]);
							}
							if (polls[1].revents) {
								uint8_t buf[4096]; ssize_t r=read(fds[2],buf,4096); if (r==-1 && errno!=EINTR) { fprintf(stderr,"med: read GEN pipe: %s\n",strerror(errno)); exit(EXIT_FAILURE); }
								//fprintf(stderr, "read: %zd\n", r);
								if (r == -1);
								else if (!r) polls[1].fd=-1;
								else {
									insertextendblock(igen, r, buf);
									igen += r;
								}
							}
						}
						if (text[igen-1] != '\n') insertextendblock(igen-1,1,(uint8_t*)"\n");
						//fprintf(stderr, "closed everything\n");
						close(fds[2]);
						while (1) {
							pid_t p = waitpid(pid, NULL, 0); if (p==-1 && errno!=EINTR) { fprintf(stderr,"medc: waitpid: %s\n",strerror(errno)); return EXIT_FAILURE; }
							if (p == pid) break;
						}
						if (signal(SIGINT, SIG_DFL) == SIG_ERR) { fprintf(stderr,"medc: signal SIGINT SIG_DFL: %s\n",strerror(errno)); return EXIT_FAILURE; }
					}
					needsredraw=1, overlay=0;

				// Paste below
				} else if (INBTN(OVMAIN,PASTEBELOW,buttons) || INBTN(OVCOPIED,COPIEDPASTEBELOW,btnscopied)) {
					df(" paste below");
			
					// Check if start of exp
					size_t i = getilinenext(icur);
					size_t iexp = getiilexp(i);
					
					// Paste
					size_t nbuf; uint8_t *buf; getpaste(&nbuf,&buf);
					insertextendblock(i, nbuf, buf);
					adjustpastedindent(i, nbuf, buf);

					// Remove fron exp if start
					if (iexp<nilexps && ilexps[iexp]==i && exps[iexp].n)
						ilexps[iexp]+=nbuf, exps[iexp].n-=nbuf;
					needsredraw=1, overlay=0;

				// Paste after block
				} else if (INBTN(OVMAIN,PASTEAFTERBLOCK,buttons) || INBTN(OVCOPIED,COPIEDPASTEAFTERBLOCK,btnscopied)) {
					df(" paste after block");
					ispasteafterblock=1, overlay=OVCANCEL;
					ensurekeyboard();
				
				// Paste
				} else if (INBTN(OVMAIN,PASTE,buttons) || INBTN(OVCOPIED,COPIEDPASTE,btnscopied)) {
					df(" paste");
			
					// Check if start of exp
					size_t iexp = getiilexp(icur);
					
					// Paste
					size_t nbuf; uint8_t *buf; getpaste(&nbuf,&buf);
					insertextendblock(icur, nbuf, buf);
					adjustpastedindent(icur, nbuf, buf);

					// Remove fron exp if start
					if (iexp<nilexps && ilexps[iexp]==icur && exps[iexp].n)
						ilexps[iexp]+=nbuf, exps[iexp].n-=nbuf;
						
					// Update state
					icur += nbuf; showkeyboard();
					needsredraw=1, overlay=0;
						
					// Expand if overflowed
					{
						for (uint8_t *p=buf; p<buf+nbuf; p++) if (*p == '\n') goto noexpandpaste;
						if (atcurblk().i != icur) expandcurline();
					} noexpandpaste:;

				// Copied hide
				} else if (INBTN(OVCOPIED,COPIEDHIDE,btnscopied)) {
					df(" copied hide");
					overlay = 0;

				// Cut line
				} else if (INBTN(OVMAIN,CUTLINE,buttons)) {
					df(" cut line");
					size_t i0=getiline(icur), i1=getilinenext(i0);
					copytext(i0, i1);
					backspace(i1, i1-i0);
					if (icur>=i0 && icur<i1) icur=i0;
					else if (icur > i1) icur-=i1-i0;
					overlay=OVCOPIED;

				// Cut block
				} else if (INBTN(OVMAIN,CUTBLOCK,buttons)) {
					df(" cut block");
					iscutblock=1, overlay=OVCANCEL;
					ensurekeyboard();

				// Copy block
				} else if (INBTN(OVMAIN,COPYBLOCK,buttons)) {
					df(" copy block");
					iscopyblock=1, overlay=OVCANCEL;
					ensurekeyboard();
					
				// Flow line / Unflow line
				} else if (INBTN(OVMAIN,FLOWLINE,buttons)) {
					df(" flow line / unflow line");
					size_t il = getiline(icur);
					size_t iflow = getiflowbs(il);
					if (iflow<nflow && isflow[iflow]==il) removeflowi(iflow);
					else insertflowat(il, iflow);
					overlay=0, needsredraw=1;
					
				// Multi cursor
				} else if (INBTN(OVMAIN,MULTICURSOR,buttons)) {
					df(" multi cursor");
					overlay = OVMULTICURSTOP;
					nmulti=0; appendmulti(getiline(icur));
					imultistart = 0;
					cur=0, icur=SIZE_MAX; showkeyboard();
					needsredraw=1;
					
				// Go top
				} else if (INBTN(OVMAIN,GOTOP,buttons)) {
					df(" go top");
					itop=0, ytop=mudwin;
					overlay = 0;
					needsredraw = 1;

				// Multi cur choose
				} else if (INBTN(OVMULTICURSTOP,MCSTOPCHOOSE,btnsmulticurstop)) {
					df(" mc choose");
					imultistart = SIZE_MAX;
					overlay = OVMULTICURACT;
					needsredraw = 1;
					
				// Multi cur end of line
				} else if (INBTN(OVMULTICURACT,MCACTENDOFLINE,btnsmulticuract)) {
					df(" mc end of line");
					for (struct multicur *m=multis; m<multis+nmulti; m++)
						while (m->i<ntext && text[m->i]!='\n')
							m->i++;
					needsredraw = 1;
					flowmulti();
					
				// Multi cur next word end
				} else if (INBTN(OVMULTICURACT,MCACTNEXTENDWORD,btnsmulticuract)) {
					df(" mc next end word");
					for (struct multicur *m=multis; m<multis+nmulti; m++) {
						if (m->i>=ntext || text[m->i]=='\n') continue;
						for (size_t i=m->i+1;; i++) {
							if (!isspace(text[i-1]) && (i>=ntext||!isalnum_(text[i]))) {m->i=i;break;}
							if (i>=ntext || text[i]=='\n') break;
						}
					}
					needsredraw = 1;
					flowmulti();
					
				// Multi cur right
				} else if (INBTN(OVMULTICURACT,MCACTRIGHT,btnsmulticuract)) {
					df(" mc right");
					for (struct multicur *m=multis; m<multis+nmulti; m++) {
						if (m->i>=ntext || text[m->i]=='\n') continue;
						uint8_t ng,flags; double w; getgraphdisplay(ntext,text,m->i,&ng,&w,&flags);
						m->i += ng;
					}
					needsredraw = 1;
					flowmulti();
					
				// Multi cur done
				} else if (INBTN(OVMULTICURACT,MCACTDONE,btnsmulticuract)) {
					df(" mc done");
					nmulti = 0;
					flowmulti();
					overlay = 0;
					hidekeyboard();
					needsredraw=1;
					
				// Multi cur back match
				} else if (INBTN(OVMULTICURACT,MCACTBACKMATCH,btnsmulticuract)) {
					df(" mc back match");
					cur=CURMULTI, icur=nbufmulti=0;
					overlay=OVMCBACKMATCH, needsredraw=1, showkeyboard();
				
				// Multi cur select
				} else if (INBTN(OVMULTICURACT,MCACTSELECT,btnsmulticuract)) {
					df(" mc select");
					for (size_t i=0; i<nmulti; i++) multis[i].iselect=multis[i].i;
					needsredraw = 1;
					
				// Multi cur copy
				} else if (INBTN(OVMULTICURACT,MCACTCOPY,btnsmulticuract)) {
					df(" mc copy");
					for (struct multicur *m=multis; m<multis+nmulti; m++) {
						if (m->iselect == SIZE_MAX) continue;
						size_t i0,i1; if(m->i<m->iselect)i0=m->i,i1=m->iselect; else i0=m->iselect,i1=m->i;
						size_t n = i1 - i0;
						ensuren(&m->sizecopy,0,(void**)&m->bufcopy,n); memcpy(m->bufcopy,text+i0,n);
						m->ncopy = n;
						m->iselect = SIZE_MAX;
					}
					needsredraw = 1;
					
				// Cancel
				} else if (INBTN(OVCANCEL,CANCELCANCEL,btnscancel)) {
					df(" cancel");
					if (isenterafterblock) isenterafterblock=0;
					if (ispasteafterblock) ispasteafterblock=0;
					if (iscutblock) iscutblock=0;
					if (iscopyblock) iscopyblock=0;
					overlay=0, needsredraw=1;
					
				// Multi cur paste
				} else if (INBTN(OVMULTICURACT,MCACTPASTE,btnsmulticuract)) {
					df(" mc paste");
					for (struct multicur *m=multis; m<multis+nmulti; m++) {
						if (!m->ncopy) continue;
						insert(m->i, m->ncopy, m->bufcopy);
						m->i += m->ncopy;
					}
					flowmulti();
					needsredraw = 1;
					
				// Multi cur toggle lines
				} else if (INBTN(OVMULTICURACT,MCACTTOGGLELINES,btnsmulticuract)) {
					df(" mc toggle lines");
					overlay = OVMCTOGGLELINES;
					needsredraw = 1;
					
				// Multi cur toggle lines done
				} else if (INBTN(OVMCTOGGLELINES,MCTLDONE,btnsmctoglines)) {
					df(" mc toggle lines done");
					overlay = OVMULTICURACT;
					needsredraw = 1;

				// Replace replace
				} else if (INBTN(OVREPLACE,REPLACEREPLACE,btnsreplace)) {
					df(" replace replace");
					nreplace = 0;
					flowreplace();
					icur=SIZE_MAX, cur=0;
					overlay=0, needsredraw=1;

				// Replace case
				} else if (INBTN(OVREPLACE,REPLACECASE,btnsreplace)) {
					df(" replace case");
					char **pl1 = btnsreplace[REPLACECASE].lines+1;
					*pl1 = (*pl1)[0]=='c' ? "exact" : "case";
					updatereplaces();
					needsredraw = 1;
					
				// Replace cancel
				} else if (INBTN(OVREPLACE,REPLACECANCEL,btnsreplace)) {
					df(" replace cancel");
					clearreplaces();
					flowreplace();
					cur=0, icur=SIZE_MAX;
					overlay=0, needsredraw=1;
					
				// Start of line
				} else if (INBTN(OVTAP0,TAP0STARTOFLINE,btnstap0)) {
					df(" tap0 startofline");
					icur = goblk(attopblk(), XSTOP|YSTOP, (double)0.0, atcur().y+hline).i;
					overlay=0, needsredraw=1, ilspaced=SIZE_MAX;
					
				// Search case
				} else if (isshowsearchresults() && INBTNI(4)) {
					df(" search case");
					char **pl0 = btnssearch[SEARCHCASE].lines;
					*pl0 = (*pl0)[3]=='M' ? "<> Ignore" : "<> Match";
					needsredraw=1, vsearch++;

				// Tap in search results
				} else if (isshowsearchresults()) {

					// Get tap position
					struct atsearch pos = gosearch(attopsearch(), WIDTH|XSTOP|YSTOP, (double)displaySize_.width, (double)xdown, (double)ydown);
		
					// Expand and put top there
					if (pos.isr < nissearchresults) {
						struct block *blk; size_t i0blk; getblocki(issearchresults[pos.isr],&blk,&i0blk,1);
						nsearch=0, vsearch++, cur=0, icur=SIZE_MAX;
						needsredraw=1, needsvertcur=1;
						for (struct block *b=blk; b; b=b->parent) b->expanded=1;
						//irowtop=0, itop=i0blk, ytop=mudwin;
						irowtop=0;
						if (typessearchresults[pos.isr] == 3)
							itop=issearchresults[pos.isr], ytop=pos.y-3*(mline+hline);
						else itop=i0blk, ytop=pos.y-pudb*2-hline;
						ensurescroll();
						hidekeyboard();
					}

				// Tap in line number search
				} else if (nsearch) {
					df(" lineno");
					size_t i = getilsearch(NULL);
					struct block *blk; getblocki(i,&blk,NULL,1);
					for (struct block *b=blk; b; b=b->parent) b->expanded=1;
					nsearch=0, vsearch++, cur=0, icur=i;
					irowtop=0;
					needsredraw=1;
					showkeyboard();

				// Normal tap
				} else {
					df(" normal");
					struct atblk pos = goblk(attopblk(), WIDTH|XSTOP|YSTOP, (double)displaySize_.width, (double)xdown, (double)ydown);

					// Tapped out of range
					if (!pos.blk);

					// Tapped in expanded text
					else if (pos.blk->expanded) {
						istypedwordfromstart = 0;
						
						// Extend multi cursor range
						if (imultistart != SIZE_MAX) {
							df(" extend multi");
							size_t nmulti0 = nmulti;
							size_t ildown = getiline(pos.i);
							nmulti = imultistart + 1;
							for (size_t il=multis[imultistart].i; il!=ildown;) {
								if (il < ildown) il=getilinenext(il);
								else il=getiline(il-1);
								appendmulti(il);
							}
							df(" extended nmulti %zu->%zu", nmulti0, nmulti);
							needsredrawcur=1, phasecur=getms()%1000;
							
						// Toggle multi cursor lines
						} else if (overlay == OVMCTOGGLELINES) {
							df(" toggle multi");
							size_t il=getiline(pos.i),inl=pos.i; while (inl<ntext && text[inl]!='\n') inl++;
							for (struct multicur *m=multis; m<multis+nmulti; m++)
								if (il<=m->i && m->i<=inl) {
									removemultii(m-multis);
									goto foundmultitog;
								}
							appendmulti(il);
							foundmultitog:;
							needsredraw=1, phasecur=getms()%1000;
							
						// Place cursor
						} else {
							size_t icur0 = icur;
							setcurclosestafter(pos, xdown);
							xcolud = INFINITY;

							// Expand overflow at right edge
							if (xdown > displaySize_.width-100.0) {
								struct at end = go((at){.x=pos.x,.y=pos.y,.i=pos.i}, NROWS|WIDTH, 1, (double)displaySize_.width);
								//if (end.i<ntext && text[end.i]!='\n' && getiflow(getiline(end.i))==SIZE_MAX) {
								if (((end.i<ntext&&text[end.i]!='\n')||displaySize_.width-end.x<20) && getiflow(getiline(end.i))==SIZE_MAX) {
									df("expanding tap cuz long");
									expandi(getiline(pos.i));
									icur = icur0;
									needsredraw = 1;
									return 0;
								} else df("didnt exp: %.2f", displaySize_.width-end.x);
							}

							// Update selection
							if (iselectstart != SIZE_MAX) {
								if (isselectinglines) {
									size_t ilstart = iselectstart<iselectend ? iselectstart : getiline(iselectstart-1);
									if (icur >= ilstart) iselectstart=ilstart, iselectend=getilinenext(icur);
									else iselectstart=getilinenext(ilstart), iselectend=getiline(icur);
								} else iselectend=icur;
							}

							// Show keyboard
							showkeyboard();
					
							// Update UI state
							fprintf(stderr, "icur %zu\n", icur);
							phasecur=getms()%1000;
							needsredraw=1;
							cur=0;

							// Space out if second nearby tap
							{
								if (ilspaced != SIZE_MAX) ilspaced=SIZE_MAX;
								else if (nsdown-nsdowntaptextprev<1e9 && fabs(xdown-xdowntaptextprev)<50 && fabs(ydown-ydowntaptextprev)<50) {
									ilspaced = getiline(pos.i);
									struct at possp = go((at){.i=ilspaced}, DBYTES|WIDTH, (ssize_t)(pos.i-ilspaced), INFINITY);
									x0spacing = pos.x - possp.x;
								}
								nsdowntaptextprev=nsdown, xdowntaptextprev=xdown, ydowntaptextprev=ydown;
							}

							// Offer start of line if close
							if (!overlay && atcur().x>0 && xdown<20) overlay=OVTAP0,df("offer start of line");
						}

					// Tapped on unexpanded block
					} else {
						size_t ic=pos.i0blk; struct block *bc; char iscoalesced=getiscoalesced(pos.blk,pos.i0blk,&ic,&bc);
						
						// Enter after
						if (isenterafterblock) {
							if (iscoalesced) pos.i0blk=ic-(bc-1)->n, pos.blk=bc-1;
							df(" inserting newline after block", pos.i0blk);
							size_t i0blk = pos.i0blk + pos.blk->n;
							struct block *b = insertblocklines(pos.blk->parent, pos.blk+1);
							printblocks(nblocks, blocks, fdf);
							b->expanded = 1;
							icur = i0blk + 1 + copyindent(getilinenonemptyorlast(pos.i0blk,i0blk),i0blk+1);
							cur=0;
							showkeyboard();
							overlay=0, needsredraw=1, isenterafterblock=0;
							
						// Paste after block
						} else if (ispasteafterblock) {
							if (iscoalesced) pos.i0blk=ic-(bc-1)->n, pos.blk=bc-1;
							df(" pasting after block %zu", pos.i0blk);
							size_t nbuf; uint8_t *buf; getpaste(&nbuf,&buf);
							insertblockbuf(pos.blk->parent,pos.blk+1,nbuf,buf);
							//adjustpastedindent(i, nbuf, buf);
							if (cur==0 && icur!=SIZE_MAX && icur>=pos.i0blk+pos.blk->n) icur+=nbuf,needsvertcur=1;
							//cur=0;
							ensurekeyboard();
							overlay=0, needsredraw=1, ispasteafterblock=0;
							
						// Cut block
						} else if (iscutblock && !iscoalesced) {
							df(" cut block %zu", pos.i0blk);
							size_t i0=pos.i0blk, i1=i0+pos.blk->n;
							copytext(i0, i1);
							size_t n = i1 - i0;
							if (!cur && icur>=i0 && icur<i1) icur=i0;
							else if (!cur && icur>i1) icur-=n;
							backspace(i1, n);
							ensurekeyboard();
							overlay=OVCOPIED, needsredraw=1, iscutblock=0;
							
						// Copy block
						} else if (iscopyblock && !iscoalesced) {
							df(" copy block %zu", pos.i0blk);
							size_t i0=pos.i0blk, i1=i0+pos.blk->n;
							copytext(i0, i1);
							overlay=OVCOPIED, needsredraw=1, iscopyblock=0;
							
						// Expand coalesced blocks
						} else if (iscoalesced) {
							df(" expand coalesced");
							(pos.blk-1)->expanded = 3;
							needsredraw=1;
						
						// Expand tap
						} else {
							pos.blk->expanded = 1;
							needsredraw = 1;
						}
					}
				}
			}

		// Pointer move
		} else if (action == AMOTION_EVENT_ACTION_MOVE) {
			double xmove=AMotionEvent_getX(event,0), ymove=AMotionEvent_getY(event,0); uint64_t nsmove=AMotionEvent_getEventTime(event);
			df("%.3f: move %.2f,%.2f", et(nsmove), xmove, ymove);

			// Update gesture state
			uint64_t nshold = nsmove - nsdown;
			if (isuptap && (nshold>2e8||fabs(xmove-xdown)>10||fabs(ymove-ydown)>10)) isuptap=0;
			if (isupswipelr && (nshold>2e8||fabs(ymove-ydown)>120)) isupswipelr=0;
			if (ymoveprev!= INFINITY) yvelocity=(ymove-ymoveprev)/((nsmove-nsmoveprev)*1.0e-9);
			if (fabs(ymove-ydown)>70 && xdown>displaySize_.width*0.667 && overlay==OVMAIN) overlay=overlaypremain;
			ymoveprev=ymove, nsmoveprev=nsmove;

			// Scroll top
			//if (nshold>9e7 || (!isuptap&&!isupswipelr)) {
				if (xdown > displaySize_.width*0.667) {
					if (yscr != INFINITY) ytop += ymove - yscr;
					ensurescroll();
					needsredraw=1, yscr=ymove;
				}
			//}
			
			// Down was in middle
			if (displaySize_.width*0.333<xdown && xdown<displaySize_.width*0.667) {

				// Open overlay
				if (overlay!=1 && ymove-ydown>50) {
					hidekeyboard(); hframeoverride=displaySize_.height,msoverridehframe=getms()+500;
					overlaypremain = overlay;
					overlay=1/*, needsredraw=1*/;
				}

				// Search
				if (cur!=1 && ydown-ymove>50) {
					icurpresearch = icur;
					showkeyboard();
					cur=1, icur=0, needsredrawcur=1;
				}
			}

		// Scroll
		} else if (action == AMOTION_EVENT_ACTION_SCROLL) {
			float vscroll = AMotionEvent_getAxisValue(event, AMOTION_EVENT_AXIS_VSCROLL, 0);
			df("%.3f: scroll v%.2f", et(AMotionEvent_getEventTime(event)), vscroll);
			ytop += vscroll * 300;
			ensurescroll();
			needsredraw = 1;

		// Unhandled action
		} else df("%.3f: motion %"PRIu32, et(AMotionEvent_getEventTime(event)), action);
	
	// Keyboard event
	} else if (type == AINPUT_EVENT_TYPE_KEY) {
		int32_t action = AKeyEvent_getAction(event);

		// Key up
		if (action == AKEY_EVENT_ACTION_UP) {
			int32_t keycode = AKeyEvent_getKeyCode(event);
			df("%.3f: keyup %"PRIu32, et(AKeyEvent_getEventTime(event)), (int)keycode);
						
			// Get unicode char
			JNIEnv *env = attachjni();
			jclass KeyEvent = getclassenv(env, "android/view/KeyEvent");
		    jmethodID getUnicodeChar = getmethodenv(env, KeyEvent, "getUnicodeChar", "(I)I");
		    jmethodID new_KeyEvent = getmethodenv(env, KeyEvent, "<init>", "(II)V");
		    jobject eventobj = newobjectenv(env, KeyEvent, new_KeyEvent, (int)action, (int)keycode);
		    uint32_t cp = callmethodintenv(env, eventobj, getUnicodeChar, (int)AKeyEvent_getMetaState(event));
			(*activity->vm)->DetachCurrentThread(activity->vm);
			
			// Skip non-chars
			if (!cp) return 0;
			
			// Encode to UTF-8
			ensuren(&app->sizetype,0,(void**)&app->buftype,4);
			if (cp <= 0x7f) app->ntype=1, app->buftype[0]=cp;
			else if (cp <= 0x7ff) app->ntype=2,app->buftype[0]=0xc0|(cp>>6),app->buftype[1]=0x80|(cp&0x3f);
			else if (cp <= 0xffff) app->ntype=3,app->buftype[0]=0xe0|(cp>>12),app->buftype[1]=0x80|((cp>>6)&0x3f),app->buftype[2]=0x80|(cp&0x3f);
			else app->ntype=4, app->buftype[0]=0xf0|((cp>>18)&0x7), app->buftype[1]=0x80|((cp>>12)&0x3f), app->buftype[2]=0x80|((cp>>6)&0x3f), app->buftype[3]=0x80|(cp&0x3f);
			
			// Handle as typing
			app->isfaketype = 1;
			handle_cmd(app, APP_CMD_TYPE);
			app->isfaketype = 0;
			
		// Key down
		} else if (action == AKEY_EVENT_ACTION_DOWN) {
			df("%.3f: keydown %"PRIu32, et(AKeyEvent_getEventTime(event)), (int)AKeyEvent_getKeyCode(event));
			
			// Handle backspace
			int32_t keycode = AKeyEvent_getKeyCode(event);
			df(" %d", (int)keycode);
			if (keycode == AKEYCODE_DEL) {
				df(" backspace");
				app->isfaketype=1;
				handle_cmd(app, APP_CMD_BACKSPACE);
				app->isfaketype=0;
				
			// Handle left
			} else if (keycode == AKEYCODE_DPAD_LEFT) {
				df(" left");
				phasecur=getms()%1000;
				if (icur && icur!=SIZE_MAX) icur=igraphprevcur(icur);
				
			// Handle right
			} else if (keycode == AKEYCODE_DPAD_RIGHT) {
				df(" right");
				phasecur=getms()%1000;
				if (icur != SIZE_MAX) {
					size_t nbuf; uint8_t*buf; getbufcur(&nbuf,&buf);
					if (icur < nbuf) {
						uint8_t ng,flags; double w; getgraphdisplay(nbuf,buf,icur,&ng,&w,&flags);
						icur += ng;
					}	
				}
			}
			
		// Unhandled action
		} else df("%.3f: key %"PRIu32,et(AKeyEvent_getEventTime(event)),action);
		
	// Unhandled event
	} else df("onInputEvent %"PRIu32, type);
	return 0;
}

JNIEXPORT
void
ANativeActivity_onCreate(ANativeActivity* activitycreate, void* savedState, size_t savedStateSize)
{
	LOGV0("Creating: %p\n", activitycreate);
	activitycreate->callbacks->onDestroy = onDestroy;
	activitycreate->callbacks->onStart = onStart;
	activitycreate->callbacks->onResume = onResume;
	activitycreate->callbacks->onSaveInstanceState = onSaveInstanceState;
	activitycreate->callbacks->onPause = onPause;
	activitycreate->callbacks->onStop = onStop;
	activitycreate->callbacks->onConfigurationChanged = onConfigurationChanged;
	activitycreate->callbacks->onLowMemory = onLowMemory;
	activitycreate->callbacks->onWindowFocusChanged = onWindowFocusChanged;
	activitycreate->callbacks->onNativeWindowCreated = onNativeWindowCreated;
	activitycreate->callbacks->onNativeWindowDestroyed = onNativeWindowDestroyed;
	activitycreate->callbacks->onInputQueueCreated = onInputQueueCreated;
	activitycreate->callbacks->onInputQueueDestroyed = onInputQueueDestroyed;

	struct android_app* android_app = activitycreate->instance = malloc(sizeof(struct android_app)); if (!android_app) { Fprintf(stderr,"medcn: malloc android_app: %s\n",strerror(errno)); exit(EXIT_FAILURE); }
	memset(android_app, 0, sizeof(struct android_app));
	android_app->activity = activity = activitycreate;
	android_app->onInputEvent = onInputEvent;

	pthread_mutex_init(&android_app->mutex, NULL);
	pthread_cond_init(&android_app->cond, NULL);
	pthread_attr_t attr; 
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	//fdf = fopen("/storage/emulated/0/Android/data/com.vulkan.tutorials.sixcsim/files/log.txt", "w");
	//system("cp 
	system("cp /storage/emulated/0/Android/data/com.vulkan.tutorials.sixcsim/files/log.txt /storage/emulated/0/Android/data/com.vulkan.tutorials.sixcsim/files/logprev.txt");
	fdf = freopen("/storage/emulated/0/Android/data/com.vulkan.tutorials.sixcsim/files/log.txt", "w", stderr);
	{ time_t t=time(NULL); dfnl(asctime(localtime(&t))); }

	// Create edittext
	{
		
		//Context context = activity.mNativeContentView.getContext();
		JNIEnv* env = activity->env;
		jclass NativeActivity=(*env)->GetObjectClass(env,activity->clazz); if (!NativeActivity) {failexception();Fputs("medcn: GetObjectClass nativeactivity null\n",stderr);exit(EXIT_FAILURE);}
		jfieldID NativeActivity_mNativeContentView = (*env)->GetFieldID(env, NativeActivity, "mNativeContentView", "Landroid/app/NativeActivity$NativeContentView;"); if (!NativeActivity_mNativeContentView) { failexception(); fputs("medcn: getfieldid mNativeContentView null\n",stderr); exit(EXIT_FAILURE); }
		jobject mNativeContentView=(*env)->GetObjectField(env,activity->clazz,NativeActivity_mNativeContentView); if (!mNativeContentView) {failexception();fputs("medcn: getobjectfield mNativeContentView null\n",stderr);exit(EXIT_FAILURE);}
		jclass View = getclass("android/view/View");
		jmethodID getContext = getmethod(View, "getContext", "()Landroid/content/Context;");
		jobject context=callmethodobject(mNativeContentView,getContext); if (!context) {Fputs("medcn: jni activity.getContext() null\n",stderr);exit(EXIT_FAILURE);}
		
		//MyEditText editText = new MyEditText(context);
		jmethodID getClassLoader = getmethod(NativeActivity, "getClassLoader", "()Ljava/lang/ClassLoader;");
		jobject classLoader = callmethodobject(activity->clazz, getClassLoader);
		jclass ClassLoader = getclass("java/lang/ClassLoader");
		jmethodID loadClass = getmethod(ClassLoader, "loadClass", "(Ljava/lang/String;)Ljava/lang/Class;");
		jclass MyEditText = callmethodobject(classLoader, loadClass, getstring("mark/app/MyNativeActivity$MyEditText"));
		jmethodID new_MyEditText = getmethod(MyEditText, "<init>", "(Landroid/content/Context;Lmark/app/MyNative""Activity;)V");
		editText = newobject(MyEditText, new_MyEditText, context, activity->clazz);
		editText=(*activity->env)->NewGlobalRef(activity->env,editText); if (!editText) {fputs("medcn: newglobalref edittext null\n",stderr);exit(EXIT_FAILURE);}
		
		//editText.setText(" ");
		//jmethodID setText = getmethod(EditText, "setText", "(Ljava/lang/CharSequence;)V");
		//jstring space = getstring(" ");
		//callmethodvoid(editText, setText, space);
		
		//editText.setSelection(1);
		//jmethodID setSelection = getmethod(EditText, "setSelection", "(I)V");
		//callmethodvoid(editText, setSelection, 1);
		
		//editText.setInputType(
		//TYPE_TEXT_FLAG_NO_SUGGESTIONS|TYPE_CLASS_TEXT|
		//multiline)
		jmethodID setInputType = getmethod(MyEditText, "setInputType", "(I)V");
		callmethodvoid(editText, setInputType, /*0x91*//*0xb1*//*2*/0xa0001/*0x10001*/);
		//callmethodvoid(editText, setInputType, 0xa0001);
		
		//ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(250, 250);
		//df("new params");
		jclass ViewGroup_LayoutParams = getclass("android/view/ViewGroup$LayoutParams");
		jmethodID new_ViewGroup_LayoutParams = getmethod(ViewGroup_LayoutParams, "<init>", "(II)V");
		jobject params = newobject(ViewGroup_LayoutParams, new_ViewGroup_LayoutParams, 0, 0);
		
		//activity.addContentView(editText, params);
		//df("addcontentview");
		jmethodID addContentView = getmethod(NativeActivity, "addContentView", "(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V");
		callmethodvoid(activity->clazz, addContentView, editText, params);
		
		//Window window = activity.getWindow();
		//df("getWindow");
		jmethodID getWindow = getmethod(NativeActivity, "getWindow", "()Landroid/view/Window;");
		jobject window=callmethodobject(activity->clazz,getWindow); if (!window) {Fputs("medcn: getWindow null\n",stderr);exit(EXIT_FAILURE);}
		
		//window.setSoftInputMode(
		//WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN
		//WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
		jclass Window = getclass("android/view/Window");
		jmethodID setSoftInputMode = getmethod(Window, "setSoftInputMode", "(I)V");
		//callmethodvoid(window, setSoftInputMode, 2);
		callmethodvoid(window, setSoftInputMode, 18);
				
		// TextWatcher textWatcher =
		//new MyNativeActivity.MyTextWatcher(activity,ed);
		jstring path_MyTextWatcher = getstring("mark/app/MyNativeActivity$MyTextWatcher");
		jclass MyNativeActivity_MyTextWatcher = callmethodobject(classLoader, loadClass, path_MyTextWatcher);
		jmethodID new_MyNativeActivity_MyTextWatcher = getmethod(MyNativeActivity_MyTextWatcher, "<init>", "(Lmark/app/MyNativeActivity;""Landroid/widget/EditText;)V");
		jobject textWatcher = newobject(MyNativeActivity_MyTextWatcher, new_MyNativeActivity_MyTextWatcher, activity->clazz, editText);
		
		// editText.addTextChangedListener(textWatcher);
		jmethodID addTextChangedListener = getmethod(MyEditText, "addTextChangedListener", "(Landroid/text/TextWatcher;)V");
		callmethodvoid(editText, addTextChangedListener, textWatcher);
	}

	//Capture input
	setvbuf(stdout, 0, _IOLBF, 0); // make stdout line-buffered
	setvbuf(stderr, 0, _IONBF, 0); // make stderr unbuffered
	pipe(pfd);
	dup2(pfd[1], 1);
	dup2(pfd[1], 2);
	pthread_create(&debug_capture_thread, &attr, debug_capture_thread_fn, android_app);

	if (savedState != NULL) {
		android_app->savedState = malloc(savedStateSize);
		android_app->savedStateSize = savedStateSize;
		memcpy(android_app->savedState, savedState, savedStateSize);
	}

	int msgpipe[2];
	if (pipe(msgpipe)) {
		LOGE0("could not create pipe: %s", strerror(errno));
		exit(EXIT_FAILURE);
	}
	android_app->msgread = msgpipe[0];
	android_app->msgwrite = msgpipe[1];

	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
	pthread_create(&android_app->thread, &attr, android_app_entry, android_app);

	// Wait for thread to start.
	pthread_mutex_lock(&android_app->mutex);
	while (!android_app->running) {
		pthread_cond_wait(&android_app->cond, &android_app->mutex);
	}
	pthread_mutex_unlock(&android_app->mutex);
}
